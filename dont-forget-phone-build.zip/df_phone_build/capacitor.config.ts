import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.dontforget.app',
  appName: "DON'T FORGET",
  webDir: 'dist',
};

export default config;
