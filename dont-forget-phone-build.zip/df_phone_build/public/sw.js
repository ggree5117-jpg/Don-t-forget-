/**
 * Service Worker — يجعل التطبيق يفتح ويعمل بدون إنترنت
 * ===================================================
 * الإستراتيجية:
 *  1) عند التثبيت: نقرأ index.html ونتعرّف على أسماء ملفات JS/CSS المبنية
 *     (أسماؤها تحتوي هاش يتغير مع كل بناء) ونخزّنها مسبقاً — بدون هذه الخطوة
 *     تفشل إعادة التحميل بدون إنترنت عند أول زيارة.
 *  2) التنقّل: Network-First مع رجوع للنسخة المخزنة.
 *  3) الملفات الثابتة: Cache-First ثم تحديث في الخلفية.
 *  4) طلبات /api/*: لا تُخزَّن ولا تُعترض → ميزات الصحة تحتاج إنترنت فعلاً.
 *
 * المهام والتنبيهات لا تمر من هنا إطلاقاً: localStorage + إشعارات محلية.
 */

const CACHE_VERSION = 'dont-forget-v5';
const CORE = ['/', '/index.html', '/manifest.webmanifest'];

/** يقرأ index.html ويستخرج روابط الأصول المبنية ويخزّنها */
async function precacheAppShell() {
  const cache = await caches.open(CACHE_VERSION);

  // 1) الملفات الأساسية
  await Promise.all(CORE.map((url) => cache.add(url).catch(() => undefined)));

  // 2) أصول البناء (JS/CSS) — أسماؤها مجزّأة في index.html
  try {
    const response = await fetch('/index.html', { cache: 'reload' });
    if (!response.ok) return;

    const html = await response.clone().text();
    await cache.put('/index.html', response);

    const assetUrls = Array.from(html.matchAll(/(?:src|href)="(\/assets\/[^"]+)"/g)).map((m) => m[1]);
    await Promise.all(assetUrls.map((url) => cache.add(url).catch(() => undefined)));
  } catch {
    /* بدون شبكة أثناء التثبيت — سيُخزَّن لاحقاً عبر اعتراض الطلبات */
  }
}

self.addEventListener('install', (event) => {
  event.waitUntil(precacheAppShell().then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
      // بعد السيطرة: نعيد التخزين المسبق حتى لو جاء التثبيت بدون شبكة
      .then(() => precacheAppShell().catch(() => undefined))
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // 1) الـ API لا يُخزَّن أبداً
  if (url.pathname.startsWith('/api/')) return;

  // 2) نطاقات خارجية (Open Food Facts / الخطوط) — لا نتدخّل
  if (url.origin !== self.location.origin) return;

  // 3) التنقّل: الشبكة أولاً ثم الكاش
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put('/index.html', copy)).catch(() => {});
          return response;
        })
        .catch(async () => {
          const opts = { ignoreVary: true, ignoreSearch: true };
          const cached = await caches.match('/index.html', opts);
          return cached || (await caches.match('/', opts)) || Response.error();
        })
    );
    return;
  }

  // 4) الأصول: الكاش أولاً
  event.respondWith(
    caches.match(request, { ignoreVary: true, ignoreSearch: true }).then((cached) => {
      if (cached) {
        // تحديث صامت في الخلفية
        fetch(request)
          .then((fresh) => {
            if (fresh && fresh.status === 200 && fresh.type === 'basic') {
              caches.open(CACHE_VERSION).then((cache) => cache.put(request, fresh)).catch(() => {});
            }
          })
          .catch(() => {});
        return cached;
      }

      return fetch(request)
        .then((response) => {
          if (response && response.status === 200 && response.type === 'basic') {
            const copy = response.clone();
            caches.open(CACHE_VERSION).then((cache) => cache.put(request, copy)).catch(() => {});
          }
          return response;
        })
        .catch(() => Response.error());
    })
  );
});

/** النقر على إشعار يفتح التطبيق أو يركز النافذة المفتوحة */
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) return client.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow('/');
      return undefined;
    })
  );
});
