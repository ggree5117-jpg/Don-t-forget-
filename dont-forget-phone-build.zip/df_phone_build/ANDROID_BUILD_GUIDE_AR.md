# تحويل DON'T FORGET إلى APK

تم تجهيز المشروع ليُبنى كتطبيق Android باستخدام Capacitor.

## ما الذي أُضيف؟
- `capacitor.config.ts` بإعدادات التطبيق ومعرّفه `com.dontforget.app`.
- اعتماد `@capacitor/android`.
- سير عمل GitHub Actions لبناء APK تجريبي قابل للتثبيت.

## إنشاء APK دون تثبيت Android Studio على الهاتف
1. ارفع مجلد المشروع إلى مستودع GitHub جديد (Repository) واجعله خاصاً إذا رغبت.
2. من GitHub افتح تبويب **Actions**.
3. اختر **Build Android APK** ثم **Run workflow**.
4. بعد نجاح العملية افتح نتيجة التشغيل (Workflow run)، ومن قسم **Artifacts** نزّل `dont-forget-debug-apk`.
5. فك ضغط الملف الناتج وثبّت `app-debug.apk` على هاتف Android. قد يطلب الهاتف السماح بالتثبيت من هذا المصدر.

## تنبيهات مهمة قبل الاعتماد على التطبيق
- هذا APK تجريبي (Debug)، وليس نسخة متجر Google Play موقّعة للنشر.
- التطبيق يستخدم واجهة React/Vite، وقد أُعدّ لتغليفها محلياً داخل Android عبر Capacitor.
- المشروع يحتوي خادماً منفصلاً في `server.ts` لميزات تحليل الوجبات والنصائح الغذائية. هذه الواجهات تستخدم مسارات `/api/...`، ولذلك لن تعمل داخل APK بمجرد التغليف إذا لم يكن الخادم منشوراً على الإنترنت. يجب نشر الخادم وإضافة `VITE_API_BASE_URL` بعنوانه قبل البناء حتى تعمل ميزات الذكاء الاصطناعي/الخادم.
- جسر إعلانات Start.io الموجود في `native-android/` يحتاج دمج SDK ومكتباته في مشروع Android واختباره بشكل مستقل؛ لم يتم تفعيله في إعداد البناء الأولي.
- لا تشارك مفاتيح Gemini أو أي أسرار داخل مستودع GitHub. تحفظ مفاتيح الخادم في إعدادات بيئة الاستضافة فقط.

## البناء محلياً على كمبيوتر
بعد تثبيت Node.js وAndroid Studio وAndroid SDK:
```bash
npm install
npm run build
npx cap add android   # مرة واحدة فقط
npx cap sync android
npx cap open android
```
ومن Android Studio اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
