package com.dontforget.app;

/**
 * StartioAdsPlugin — إضافة Capacitor أصلية لشبكة Start.io
 * ======================================================
 * السبب: Start.io لا توفّر إضافة Capacitor رسمية. هذا الملف يربط SDK الخاص بها
 * بواجهة JavaScript الموجودة في src/utils/startioBridge.ts.
 *
 * ⚠️ مكان الملف بعد `npx cap add android`:
 *     android/app/src/main/java/com/dontforget/app/StartioAdsPlugin.java
 *    (غيّر اسم الحزمة إن كان appId تطبيقك مختلفاً)
 *
 * ⚠️ يجب استبدال معرّف التطبيق في ملف StartioAdConfig.java أيضاً.
 */

import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;

import com.startapp.sdk.ads.banner.Banner;
import com.startapp.sdk.ads.banner.BannerListener;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.StartAppSDK;
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;
import com.startapp.sdk.adsbase.model.AdPreferences;

@CapacitorPlugin(
    name = "StartioAds",
    permissions = {
        @Permission(alias = "internet", strings = { android.Manifest.permission.INTERNET })
    }
)
public class StartioAdsPlugin extends Plugin {

    private static final String TAG = "StartioAds";

    /** إعلان كامل محمّل مسبقاً */
    private StartAppAd interstitial;

    private boolean bannerVisible = false;
    private boolean sdkInitialized = false;

    // -----------------------------------------------------------------
    // 1) التهيئة
    // -----------------------------------------------------------------
    @PluginMethod
    public void initialize(PluginCall call) {
        String appId = call.getString("appId", StartioAdConfig.APP_ID);
        boolean testAds = Boolean.TRUE.equals(call.getBoolean("testAds", StartioAdConfig.TEST_ADS));

        try {
            if (!sdkInitialized) {
                // المعامل الثالث = إعلانات العودة (Return Ads). نُعطّلها للتحكم بأنفسنا.
                StartAppSDK.init(getActivity(), appId, false);

                // نُعطّل إعلان السبلاش التلقائي: نحن نتحكم بمتى يظهر الإعلان
                StartAppAd.disableSplash();

                StartAppSDK.setTestAdsEnabled(testAds);

                sdkInitialized = true;
                Log.i(TAG, "Start.io SDK initialized. appId=" + appId + " testAds=" + testAds);
            }

            JSObject ret = new JSObject();
            ret.put("initialized", true);
            call.resolve(ret);
        } catch (Throwable t) {
            Log.e(TAG, "initialize failed", t);
            call.reject("STARTIO_INIT_FAILED: " + t.getMessage());
        }
    }

    // -----------------------------------------------------------------
    // 2) تحميل إعلان كامل مسبقاً
    // -----------------------------------------------------------------
    @PluginMethod
    public void preloadInterstitial(PluginCall call) {
        final String adTag = call.getString("adTag", StartioAdConfig.DEFAULT_INTERSTITIAL_TAG);

        getActivity().runOnUiThread(() -> {
            try {
                if (interstitial == null) {
                    interstitial = new StartAppAd(getContext());
                }

                AdPreferences prefs = new AdPreferences();
                prefs.setAdTag(adTag);

                interstitial.loadAd(StartAppAd.AdMode.AUTOMATIC, prefs, new AdEventListener() {
                    @Override
                    public void onReceiveAd(Ad ad) {
                        Log.i(TAG, "Interstitial loaded");
                        JSObject ret = new JSObject();
                        ret.put("loaded", true);
                        // الطلب الأصلي قد يكون مغلقاً؛ نحرس بذلك
                        if (call.getData().has("keepAlive") == false) {
                            try { call.resolve(ret); } catch (Exception ignored) { }
                        }
                    }

                    @Override
                    public void onFailedToReceiveAd(Ad ad) {
                        Log.w(TAG, "Interstitial failed: " + (ad != null ? ad.getErrorMessage() : "unknown"));
                        JSObject ret = new JSObject();
                        ret.put("loaded", false);
                        try { call.resolve(ret); } catch (Exception ignored) { }
                    }
                });
            } catch (Throwable t) {
                Log.e(TAG, "preload failed", t);
                try { call.reject("STARTIO_PRELOAD_FAILED: " + t.getMessage()); } catch (Exception ignored) { }
            }
        });
    }

    // -----------------------------------------------------------------
    // 3) عرض إعلان كامل
    // -----------------------------------------------------------------
    @PluginMethod
    public void showInterstitial(PluginCall call) {
        final String adTag = call.getString("adTag", StartioAdConfig.DEFAULT_INTERSTITIAL_TAG);

        getActivity().runOnUiThread(() -> {
            try {
                if (interstitial == null) {
                    interstitial = new StartAppAd(getContext());
                }

                if (interstitial.isReady()) {
                    showLoadedInterstitial(call);
                    return;
                }

                // لم يُحمّل بعد → نحمّله ونعرضه فور الجاهزية
                AdPreferences prefs = new AdPreferences();
                prefs.setAdTag(adTag);

                interstitial.loadAd(StartAppAd.AdMode.AUTOMATIC, prefs, new AdEventListener() {
                    @Override
                    public void onReceiveAd(Ad ad) {
                        showLoadedInterstitial(call);
                    }

                    @Override
                    public void onFailedToReceiveAd(Ad ad) {
                        JSObject ret = new JSObject();
                        ret.put("shown", false);
                        ret.put("reason", "NO_FILL");
                        call.resolve(ret);
                    }
                });
            } catch (Throwable t) {
                Log.e(TAG, "showInterstitial failed", t);
                call.reject("STARTIO_SHOW_FAILED: " + t.getMessage());
            }
        });
    }

    private void showLoadedInterstitial(PluginCall call) {
        interstitial.showAd(new AdDisplayListener() {
            @Override
            public void onAdHidden(Ad ad) {
                JSObject ret = new JSObject();
                ret.put("shown", true);
                ret.put("closed", true);
                try { call.resolve(ret); } catch (Exception ignored) { }
            }

            @Override
            public void adDisplayed(Ad ad) {
                Log.i(TAG, "Interstitial displayed");
            }

            @Override
            public void adClicked(Ad ad) { }

            @Override
            public void adNotDisplayed(Ad ad) {
                JSObject ret = new JSObject();
                ret.put("shown", false);
                ret.put("reason", "NOT_DISPLAYED");
                try { call.resolve(ret); } catch (Exception ignored) { }
            }
        });
    }

    // -----------------------------------------------------------------
    // 4) البانر السفلي
    // -----------------------------------------------------------------
    @PluginMethod
    public void showBanner(PluginCall call) {
        final String adTag = call.getString("adTag", StartioAdConfig.DEFAULT_BANNER_TAG);

        getActivity().runOnUiThread(() -> {
            try {
                ViewGroup rootView = getActivity().findViewById(android.R.id.content);

                // نُزيل أي بانر قديم بنفس الوسم
                View existing = rootView.findViewWithTag("startio_banner");
                if (existing != null) rootView.removeView(existing);

                Banner banner = new Banner(getContext());

                int widthPx = ViewGroup.LayoutParams.MATCH_PARENT;
                int heightPx = (int) (StartioAdConfig.BANNER_HEIGHT_DP
                        * getContext().getResources().getDisplayMetrics().density);

                FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(widthPx, heightPx);
                params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;

                banner.setLayoutParams(params);
                banner.setTag("startio_banner");

                banner.setBannerListener(new BannerListener() {
                    @Override public void onReceiveAd(View view) {
                        Log.i(TAG, "Banner received");
                    }
                    @Override public void onFailedToReceiveAd(View view) {
                        Log.w(TAG, "Banner failed (no fill)");
                    }
                    @Override public void onImpression(View view) { }
                    @Override public void onClick(View view) { }
                });

                rootView.addView(banner, params);

                AdPreferences prefs = new AdPreferences();
                prefs.setAdTag(adTag);
                banner.loadAd(prefs);

                bannerVisible = true;

                JSObject ret = new JSObject();
                ret.put("shown", true);
                call.resolve(ret);
            } catch (Throwable t) {
                Log.e(TAG, "showBanner failed", t);
                call.reject("STARTIO_BANNER_FAILED: " + t.getMessage());
            }
        });
    }

    @PluginMethod
    public void hideBanner(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            try {
                ViewGroup rootView = getActivity().findViewById(android.R.id.content);
                View banner = rootView.findViewWithTag("startio_banner");
                if (banner != null) {
                    rootView.removeView(banner);
                }
                bannerVisible = false;

                JSObject ret = new JSObject();
                ret.put("hidden", true);
                call.resolve(ret);
            } catch (Throwable t) {
                Log.e(TAG, "hideBanner failed", t);
                call.reject("STARTIO_HIDE_BANNER_FAILED: " + t.getMessage());
            }
        });
    }

    // -----------------------------------------------------------------
    // 5) دورة الحياة — إعادة تحميل الإعلان بعد الإغلاق
    // -----------------------------------------------------------------
    @Override
    protected void handleOnResume() {
        super.handleOnResume();
        // Start.io يحتاج استئنافاً بعد الخروج من التطبيق
        try {
            if (sdkInitialized && interstitial != null) {
                StartAppAd.onResume(getActivity());
            }
        } catch (Throwable ignored) { }
    }

    @Override
    protected void handleOnPause() {
        try {
            if (sdkInitialized) {
                StartAppAd.onPause(getActivity());
            }
        } catch (Throwable ignored) { }
        super.handleOnPause();
    }
}
