package com.dontforget.app;

/**
 * ثوابت إعدادات Start.io — مكان واحد للتعديل.
 *
 * ⚠️ يجب أن يطابق APP_ID المعرّف في لوحة Start.io وفي AndroidManifest.xml.
 */
public final class StartioAdConfig {

    /** معرّف التطبيق من لوحة Start.io */
    public static final String APP_ID = "210222499";

    /** إعلانات تجريبية — اجعلها false قبل النشر في المتجر */
    public static final boolean TEST_ADS = true;

    /** وسوم الإعلانات (تظهر في تقارير Start.io) */
    public static final String DEFAULT_BANNER_TAG = "bottom_banner";
    public static final String DEFAULT_INTERSTITIAL_TAG = "app_open";

    /** ارتفاع البانر بالـ dp (Start.io القياسي 50) */
    public static final int BANNER_HEIGHT_DP = 50;

    private StartioAdConfig() {
        // فئة ثوابت
    }
}
