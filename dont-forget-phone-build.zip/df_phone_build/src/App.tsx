/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { HomeDashboard } from './components/HomeDashboard';
import { CalendarScreen } from './components/CalendarScreen';
import { CategoriesScreen } from './components/CategoriesScreen';
import { CategoryDetailScreen } from './components/CategoryDetailScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { HealthDashboardScreen } from './components/HealthDashboardScreen';
import { AddTaskModal } from './components/AddTaskModal';
import { BottomNavBar } from './components/BottomNavBar';
import { PhoneFrame } from './components/PhoneFrame';
import { OfflineStrip } from './components/OnlineGate';
import { AppOpenAd } from './components/AppOpenAd';
import { BannerAd } from './components/BannerAd';
import { registerAppOpen, shouldShowBanner } from './utils/adManager';
import {
  hideBanner as hideNativeBanner,
  initStartio,
  isStartioAvailable,
  preloadInterstitial,
  showBanner as showNativeBanner,
} from './utils/startioBridge';
import { ADS_CONFIG } from './utils/adsConfig';
import { AlarmScreenModal } from './components/AlarmScreenModal';
import { Language, MainTab, TaskItem, CategoryType, CustomAudioRecord } from './types';
import { DailyNutritionTarget, LoggedMeal, UserHealthProfile } from './types/health';
import { INITIAL_TASKS } from './utils/data';
import { INITIAL_NUTRITION_TARGET, INITIAL_LOGGED_MEALS, INITIAL_USER_PROFILE } from './utils/healthData';
import { playChimeSound } from './utils/audio';
import {
  scheduleReminder,
  cancelReminder,
  syncAllReminders,
  subscribeToReminders,
  subscribeToTaskUpdates,
  handleRepeatingTaskCompletion,
} from './utils/reminders';
import {
  getAllCustomAudios,
  saveCustomAudio,
  deleteCustomAudio,
} from './utils/customAudioDb';

// 1. One-time legacy cleanup to completely purge old demo data from previous sessions
try {
  const legacyKeys = [
    'dontforget_tasks',
    'dontforget_logged_meals',
    'dontforget_nutrition_target',
    'dontforget_has_initialized',
    'dontforget_language',
  ];
  legacyKeys.forEach((key) => localStorage.removeItem(key));
} catch {}

export default function App() {
  // 1. Language state initialized from df_v2_lang
  const [language, setLanguage] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('df_v2_lang');
      if (saved === 'ar' || saved === 'en') return saved;
    } catch {}
    return 'ar';
  });

  const [currentScreen, setCurrentScreen] = useState<'welcome' | 'app'>('app');
  const [currentTab, setCurrentTab] = useState<MainTab>('home');
  const [selectedCategoryDetail, setSelectedCategoryDetail] = useState<CategoryType | null>(null);
  const [addTaskCategory, setAddTaskCategory] = useState<CategoryType | undefined>(undefined);

  // 2. User profile (weights, height, goals, custom name, water)
  const [userProfile, setUserProfile] = useState<UserHealthProfile>(() => {
    try {
      const saved = localStorage.getItem('df_v2_profile');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_USER_PROFILE;
  });

  // 3. Tasks initialized from df_v2_tasks (Starts completely empty: 0 tasks)
  const [tasks, setTasks] = useState<TaskItem[]>(() => {
    try {
      const saved = localStorage.getItem('df_v2_tasks');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Error reading tasks from localStorage:', e);
    }
    return INITIAL_TASKS;
  });

  const [isAddTaskOpen, setIsAddTaskOpen] = useState(false);

  // 4. In-App Full Alarm Screen state
  const [activeAlarmTask, setActiveAlarmTask] = useState<TaskItem | null>(null);

  // 5. Nutrition target initialized from df_v2_nutrition
  const [nutritionTarget, setNutritionTarget] = useState<DailyNutritionTarget>(() => {
    try {
      const saved = localStorage.getItem('df_v2_nutrition');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Error reading nutrition target from localStorage:', e);
    }
    return INITIAL_NUTRITION_TARGET;
  });

  // 6. Logged meals initialized from df_v2_meals
  const [loggedMeals, setLoggedMeals] = useState<LoggedMeal[]>(() => {
    try {
      const saved = localStorage.getItem('df_v2_meals');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Error reading logged meals from localStorage:', e);
    }
    return INITIAL_LOGGED_MEALS;
  });

  // 7. Alarm ringtones state (default selection + custom IndexedDB audio files)
  const [defaultRingtoneId, setDefaultRingtoneId] = useState<string>(() => {
    try {
      return localStorage.getItem('df_v2_ringtone') || 'chime';
    } catch {}
    return 'chime';
  });

  const [customRingtones, setCustomRingtones] = useState<CustomAudioRecord[]>([]);

  // Load custom audios from IndexedDB on startup
  useEffect(() => {
    getAllCustomAudios()
      .then((records) => setCustomRingtones(records))
      .catch((err) => console.warn('Failed to load custom audio from IndexedDB', err));
  }, []);

  // Persist default ringtone selection
  useEffect(() => {
    try {
      localStorage.setItem('df_v2_ringtone', defaultRingtoneId);
    } catch {}
  }, [defaultRingtoneId]);

  // Keep HTML document direction and language in sync
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
    try {
      localStorage.setItem('df_v2_lang', language);
    } catch {}
  }, [language]);

  // Persist tasks
  useEffect(() => {
    try {
      localStorage.setItem('df_v2_tasks', JSON.stringify(tasks));
    } catch (e) {
      console.warn('Error writing tasks to localStorage:', e);
    }
  }, [tasks]);

  // Persist logged meals
  useEffect(() => {
    try {
      localStorage.setItem('df_v2_meals', JSON.stringify(loggedMeals));
    } catch (e) {
      console.warn('Error writing logged meals to localStorage:', e);
    }
  }, [loggedMeals]);

  // Persist nutrition target
  useEffect(() => {
    try {
      localStorage.setItem('df_v2_nutrition', JSON.stringify(nutritionTarget));
    } catch (e) {
      console.warn('Error writing nutrition target to localStorage:', e);
    }
  }, [nutritionTarget]);

  // Persist user profile
  useEffect(() => {
    try {
      localStorage.setItem('df_v2_profile', JSON.stringify(userProfile));
    } catch (e) {
      console.warn('Error writing user profile to localStorage:', e);
    }
  }, [userProfile]);

  // Unified Reminders Synchronization: Web Timers + Capacitor LocalNotifications
  useEffect(() => {
    // 1. Subscribe to in-app reminder trigger events
    const unsubscribeReminders = subscribeToReminders((task) => {
      setActiveAlarmTask(task);
    });

    // 2. Subscribe to automatic task updates (when repeating tasks advance their date)
    const unsubscribeTaskUpdates = subscribeToTaskUpdates((updatedTask) => {
      setTasks((prev) =>
        prev.map((t) => (t.id === updatedTask.id ? { ...t, ...updatedTask } : t))
      );
    });

    // 3. Synchronize all active reminders
    const cleanupSync = syncAllReminders(tasks, (id) => tasks.find((t) => t.id === id));

    return () => {
      unsubscribeReminders();
      unsubscribeTaskUpdates();
      cleanupSync();
    };
  }, [tasks]);

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  };

  const handleUpdateProfile = (updates: Partial<UserHealthProfile>) => {
    setUserProfile((prev) => {
      const next = { ...prev, ...updates };

      // Synchronize targets into nutritionTarget if updated
      if (
        updates.targetCalories !== undefined ||
        updates.targetProtein !== undefined ||
        updates.targetCarbs !== undefined ||
        updates.targetFats !== undefined
      ) {
        setNutritionTarget((prevTar) => ({
          ...prevTar,
          targetCalories: updates.targetCalories !== undefined ? (updates.targetCalories || 0) : prevTar.targetCalories,
          targetProtein: updates.targetProtein !== undefined ? (updates.targetProtein || 0) : prevTar.targetProtein,
          targetCarbs: updates.targetCarbs !== undefined ? (updates.targetCarbs || 0) : prevTar.targetCarbs,
          targetFats: updates.targetFats !== undefined ? (updates.targetFats || 0) : prevTar.targetFats,
        }));
      }

      return next;
    });
  };

  const handleToggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const next = !t.completed;
          if (next) {
            playChimeSound();
            // للمهام المتكررة (daily / weekly / monthly): بعد الإكمال جدول الموعد الذي يليه
            if (t.repeat && t.repeat !== 'once') {
              const { nextTask } = handleRepeatingTaskCompletion(t);
              return nextTask;
            }
            cancelReminder(id).catch(() => {});
          } else {
            scheduleReminder(t).catch(() => {});
          }
          return { ...t, completed: next };
        }
        return t;
      })
    );
  };

  const handleSaveTask = (newTaskData: Omit<TaskItem, 'id' | 'completed'>) => {
    const newTask: TaskItem = {
      ...newTaskData,
      id: Date.now().toString(),
      completed: false,
    };
    setTasks([newTask, ...tasks]);
    scheduleReminder(newTask).catch(() => {});
  };

  const handleSelectCategory = (cat: CategoryType) => {
    if (cat === 'health') {
      setCurrentTab('health');
      return;
    }
    setSelectedCategoryDetail(cat);
    setCurrentTab('tasks');
  };

  const handleOpenAddTask = (defaultCat?: CategoryType) => {
    setAddTaskCategory(defaultCat);
    setIsAddTaskOpen(true);
  };

  const handleAddMeal = (mealData: Omit<LoggedMeal, 'id' | 'time'>) => {
    const now = new Date();
    const timeFormatted = `${now.getHours() % 12 || 12}:${now.getMinutes().toString().padStart(2, '0')} ${now.getHours() >= 12 ? (language === 'ar' ? 'م' : 'PM') : (language === 'ar' ? 'ص' : 'AM')}`;

    const newMeal: LoggedMeal = {
      ...mealData,
      id: Date.now().toString(),
      time: timeFormatted,
    };

    setLoggedMeals((prev) => [newMeal, ...prev]);

    setNutritionTarget((prev) => ({
      ...prev,
      consumedCalories: prev.consumedCalories + mealData.calories,
      consumedProtein: prev.consumedProtein + Math.round(mealData.protein),
      consumedCarbs: prev.consumedCarbs + Math.round(mealData.carbs),
      consumedFats: prev.consumedFats + Math.round(mealData.fats),
    }));
  };

  const handleDeleteMeal = (mealId: string) => {
    const mealToDelete = loggedMeals.find((m) => m.id === mealId);
    if (!mealToDelete) return;

    setLoggedMeals((prev) => prev.filter((m) => m.id !== mealId));

    setNutritionTarget((prev) => ({
      ...prev,
      consumedCalories: Math.max(0, prev.consumedCalories - mealToDelete.calories),
      consumedProtein: Math.max(0, prev.consumedProtein - Math.round(mealToDelete.protein)),
      consumedCarbs: Math.max(0, prev.consumedCarbs - Math.round(mealToDelete.carbs)),
      consumedFats: Math.max(0, prev.consumedFats - Math.round(mealToDelete.fats)),
    }));
  };

  // Alarm Screen handlers
  const handleDismissAlarm = () => {
    setActiveAlarmTask(null);
  };

  const handleCompleteAlarm = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          if (t.repeat && t.repeat !== 'once') {
            const { nextTask } = handleRepeatingTaskCompletion(t);
            return nextTask;
          }
          cancelReminder(taskId).catch(() => {});
          return { ...t, completed: true };
        }
        return t;
      })
    );
    setActiveAlarmTask(null);
  };

  const handleSnoozeAlarm = (taskId: string, minutes: number = 5) => {
    const targetTime = new Date(Date.now() + minutes * 60000);
    const hour = targetTime.getHours();
    const minute = targetTime.getMinutes().toString().padStart(2, '0');
    const period = hour >= 12 ? (language === 'ar' ? 'م' : 'PM') : (language === 'ar' ? 'ص' : 'AM');
    const hour12 = hour % 12 || 12;
    const newTimeStr = `${hour12.toString().padStart(2, '0')}:${minute} ${period}`;

    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const snoozedTask = { ...t, time: newTimeStr };
          scheduleReminder(snoozedTask).catch(() => {});
          return snoozedTask;
        }
        return t;
      })
    );
    setActiveAlarmTask(null);
  };

  const handleSelectDefaultRingtone = (ringtoneId: string) => {
    setDefaultRingtoneId(ringtoneId);
  };

  const handleAddCustomRingtone = async (file: File) => {
    const record = await saveCustomAudio(file);
    setCustomRingtones((prev) => [record, ...prev]);
    setDefaultRingtoneId(record.id);
  };

  const handleDeleteCustomRingtone = async (id: string) => {
    await deleteCustomAudio(id);
    setCustomRingtones((prev) => prev.filter((r) => r.id !== id));
    if (defaultRingtoneId === id) {
      setDefaultRingtoneId('chime');
    }
  };

  // Test Alarm trigger for Settings screen
  const handleTestAlarm = () => {
    const testTask: TaskItem = tasks[0] || {
      id: 'test-alarm-id',
      title: language === 'ar' ? 'تذكير تجريبي بالمنبه' : 'Test Reminder Alarm',
      description: language === 'ar' ? 'حان موعد هذه المهمة الهامة' : 'Time for this scheduled task',
      category: 'habits',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString(language === 'ar' ? 'ar-EG' : 'en-US', { hour: '2-digit', minute: '2-digit', hour12: true }),
      repeat: 'once',
      priority: 'high',
      completed: false,
      ringtoneId: defaultRingtoneId,
    };
    setActiveAlarmTask(testTask);
  };

  // Complete wipe and reset of all data
  const handleResetData = () => {
    try {
      localStorage.removeItem('df_v2_tasks');
      localStorage.removeItem('df_v2_meals');
      localStorage.removeItem('df_v2_nutrition');
      localStorage.removeItem('df_v2_profile');
    } catch (e) {
      console.warn('Error clearing localStorage:', e);
    }
    // Cancel all reminders
    tasks.forEach((t) => cancelReminder(t.id).catch(() => {}));
    setTasks([]);
    setLoggedMeals([]);
    setNutritionTarget(INITIAL_NUTRITION_TARGET);
    setUserProfile(INITIAL_USER_PROFILE);
    setActiveAlarmTask(null);
    playChimeSound();
  };

  // إعلان الفتح الكامل — القرار داخل adManager
  const [showAppOpenAd, setShowAppOpenAd] = useState<boolean>(true);

  // ارتفاع البانر الأصلي (Start.io) بالبكسل — لحجز مساحة أسفل الشاشة
  const [nativeBannerPx, setNativeBannerPx] = useState<number>(0);

  // تهيئة Start.io مرة واحدة + تحميل إعلان الفتح مسبقاً
  useEffect(() => {
    if (!isStartioAvailable()) return;

    let cancelled = false;
    initStartio().then((ok) => {
      if (!ok || cancelled) return;
      // تحميل مسبق حتى يظهر الإعلان فوراً عند الطلب
      preloadInterstitial(ADS_CONFIG.startio.interstitialAdTag);
    });

    return () => {
      cancelled = true;
    };
  }, []);

  // إظهار/إخفاء البانر الأصلي حسب الشاشة الحالية
  useEffect(() => {
    if (!isStartioAvailable()) return;

    const allowed = shouldShowBanner(currentTab) && currentScreen === 'app';
    if (allowed) {
      showNativeBanner(ADS_CONFIG.startio.bannerAdTag, ADS_CONFIG.banner.heightDp);
    } else {
      hideNativeBanner();
      setNativeBannerPx(0);
    }
  }, [currentTab, currentScreen]);

  // تسجيل "فتح التطبيق" مرة واحدة — يستخدمه مدير الإعلانات للحد اليومي
  if (typeof window !== 'undefined' && !(window as any).__dfAppOpenRegistered) {
    (window as any).__dfAppOpenRegistered = true;
    registerAppOpen();
  }

  return (
    <PhoneFrame activeScreenName={currentScreen === 'welcome' ? 'welcome' : currentTab}>
      {currentScreen === 'welcome' ? (
        <WelcomeScreen
          onGetStarted={() => setCurrentScreen('app')}
          onSignIn={() => setCurrentScreen('app')}
        />
      ) : (
        <div
          className="flex-1 flex flex-col h-full bg-[#F3F7FD] relative"
          style={nativeBannerPx > 0 ? { paddingBottom: `${nativeBannerPx}px` } : undefined}
        >
          {/* شريط حالة الاتصال: المهام تعمل بدون إنترنت / الصحة تحتاج اتصالاً */}
          <OfflineStrip language={language} context={currentTab === 'health' ? 'health' : 'tasks'} />

          {/* Main Content View based on active Tab */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {currentTab === 'home' && (
              <HomeDashboard
                tasks={tasks}
                onToggleTask={handleToggleTask}
                onAddTask={handleSaveTask}
                onOpenSettings={() => setCurrentTab('settings')}
                onSelectCategory={handleSelectCategory}
                onViewAllCategories={() => {
                  setSelectedCategoryDetail(null);
                  setCurrentTab('tasks');
                }}
                onOpenHealthDashboard={() => setCurrentTab('health')}
                language={language}
              />
            )}

            {currentTab === 'health' && (
              <HealthDashboardScreen
                nutritionTarget={nutritionTarget}
                loggedMeals={loggedMeals}
                userProfile={userProfile}
                onUpdateProfile={handleUpdateProfile}
                onAddMeal={handleAddMeal}
                onDeleteMeal={handleDeleteMeal}
                onBack={() => setCurrentTab('home')}
                language={language}
              />
            )}

            {currentTab === 'calendar' && (
              <CalendarScreen
                tasks={tasks}
                onToggleTask={handleToggleTask}
                language={language}
              />
            )}

            {currentTab === 'tasks' && (
              selectedCategoryDetail ? (
                <CategoryDetailScreen
                  category={selectedCategoryDetail}
                  tasks={tasks}
                  onToggleTask={handleToggleTask}
                  onBack={() => setSelectedCategoryDetail(null)}
                  onOpenAddTask={handleOpenAddTask}
                  onOpenHealthDashboard={() => setCurrentTab('health')}
                  language={language}
                />
              ) : (
                <CategoriesScreen
                  tasks={tasks}
                  onToggleTask={handleToggleTask}
                  onBack={() => setCurrentTab('home')}
                  onOpenAddTask={() => handleOpenAddTask()}
                  onSelectCategory={handleSelectCategory}
                  language={language}
                />
              )
            )}

            {currentTab === 'settings' && (
              <SettingsScreen
                language={language}
                userProfile={userProfile}
                defaultRingtoneId={defaultRingtoneId}
                customRingtones={customRingtones}
                onSelectDefaultRingtone={handleSelectDefaultRingtone}
                onAddCustomRingtone={handleAddCustomRingtone}
                onDeleteCustomRingtone={handleDeleteCustomRingtone}
                onUpdateProfile={handleUpdateProfile}
                onLanguageChange={handleLanguageChange}
                onBackToWelcome={() => setCurrentScreen('welcome')}
                onResetData={handleResetData}
                onTestAlarm={handleTestAlarm}
              />
            )}
          </div>

          {/* ===== البانرات السفلية (فوق شريط التنقل) ===== */}
          {currentScreen === 'app' && shouldShowBanner(currentTab) && (
            <div className="shrink-0">
              <BannerAd language={language} slot={1} onNativeHeight={setNativeBannerPx} />
              {ADS_CONFIG.banner.slots === 2 && <BannerAd language={language} slot={2} />}
            </div>
          )}

          {/* Bottom Navigation Bar with Floating Center Plus Button */}
          <BottomNavBar
            currentTab={currentTab}
            onTabChange={(tab) => {
              if (tab === 'tasks' && currentTab === 'tasks') {
                setSelectedCategoryDetail(null);
              }
              setCurrentTab(tab);
            }}
            onOpenAddTask={() => handleOpenAddTask(selectedCategoryDetail || undefined)}
            language={language}
          />

          {/* Add Task Modal Bottom Sheet */}
          <AddTaskModal
            isOpen={isAddTaskOpen}
            onClose={() => setIsAddTaskOpen(false)}
            onSave={handleSaveTask}
            defaultCategory={addTaskCategory}
            defaultRingtoneId={defaultRingtoneId}
            customRingtones={customRingtones}
            language={language}
          />

          {/* 4. Full-Screen Alarm Screen Modal with Repeating Loop and Ringtone support */}
          <AlarmScreenModal
            isOpen={Boolean(activeAlarmTask)}
            task={activeAlarmTask}
            defaultRingtoneId={defaultRingtoneId}
            onDismiss={handleDismissAlarm}
            onComplete={handleCompleteAlarm}
            onSnooze={handleSnoozeAlarm}
            language={language}
          />
        </div>
      )}

      {/* ===== إعلان الفتح الكامل (يقرر بنفسه الظهور وفق الحدود) ===== */}
      {showAppOpenAd && currentScreen === 'app' && (
        <AppOpenAd language={language} onDismissed={() => setShowAppOpenAd(false)} />
      )}
    </PhoneFrame>
  );
}
