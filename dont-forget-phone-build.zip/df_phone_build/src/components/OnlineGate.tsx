import React, { useCallback, useEffect, useState } from 'react';
import { WifiOff, CloudOff, X } from 'lucide-react';
import { Language } from '../types';
import { offlineMessage, useOnlineStatus } from '../utils/connectivity';

/**
 * شريط أفقي رقيق يظهر أعلى الشاشة عند انقطاع الإنترنت.
 * context: 'tasks' تعني أن المهام تعمل، 'health' تعني أن الميزة تحتاج اتصالاً.
 */
export const OfflineStrip: React.FC<{ language: Language; context: 'tasks' | 'health' }> = ({
  language,
  context,
}) => {
  const online = useOnlineStatus();
  const isAr = language === 'ar';

  if (online) return null;

  const text =
    context === 'tasks'
      ? isAr
        ? 'بدون إنترنت — المهام والتنبيهات تعمل بشكل طبيعي'
        : 'Offline — tasks & reminders keep working normally'
      : isAr
      ? 'بدون إنترنت — ميزات الصحة والتصوير تحتاج اتصالاً'
      : 'Offline — health & scanner features need a connection';

  const tone =
    context === 'tasks'
      ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
      : 'bg-amber-50 border-amber-200 text-amber-800';

  return (
    <div className={`flex items-center justify-center gap-1.5 px-3 py-1.5 border-b text-[10.5px] font-bold ${tone}`}>
      {context === 'tasks' ? <CloudOff className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
      <span className="truncate">{text}</span>
    </div>
  );
};

/**
 * Hook يمنع فتح ميزة تحتاج إنترنت ويعرض رسالة لطيفة بدل الفشل الصامت.
 * يعيد: online، guard(fn, feature)، وعنصر toast جاهز للعرض.
 */
export function useOnlineNotice(language: Language) {
  const online = useOnlineStatus();
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 4200);
    return () => clearTimeout(t);
  }, [toast]);

  const guard = useCallback(
    (action: () => void, feature: 'scan' | 'advice' | 'plan' | 'generic' = 'generic') => {
      if (online) {
        action();
        return true;
      }
      setToast(offlineMessage(language === 'ar' ? 'ar' : 'en', feature));
      return false;
    },
    [online, language]
  );

  const toastElement = toast ? (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[60] w-[88%] max-w-sm animate-fadeIn">
      <div className="flex items-start gap-2.5 bg-[#2C2F36] text-white rounded-2xl px-3.5 py-3 shadow-2xl border border-white/10">
        <WifiOff className="w-4 h-4 mt-0.5 text-amber-300 shrink-0" />
        <p className="text-[11.5px] leading-relaxed flex-1">{toast}</p>
        <button
          onClick={() => setToast(null)}
          className="text-white/60 hover:text-white shrink-0 cursor-pointer"
          aria-label="close"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  ) : null;

  return { online, guard, toastElement };
}
