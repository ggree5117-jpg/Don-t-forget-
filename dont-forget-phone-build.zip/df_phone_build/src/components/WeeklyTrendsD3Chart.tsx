import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as d3 from 'd3';
import {
  TrendingUp,
  Flame,
  PieChart,
  BarChart3,
  Calendar,
  Info,
} from 'lucide-react';
import { Language } from '../types';
import { LoggedMeal, DailyNutritionTarget } from '../types/health';

interface WeeklyTrendsD3ChartProps {
  loggedMeals: LoggedMeal[];
  nutritionTarget: DailyNutritionTarget;
  language: Language;
}

export interface DayMetric {
  dayNameAr: string;
  dayNameEn: string;
  dateStr: string;
  fullDate: Date;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  isToday: boolean;
}

export const WeeklyTrendsD3Chart: React.FC<WeeklyTrendsD3ChartProps> = ({
  loggedMeals,
  nutritionTarget,
  language,
}) => {
  const isAr = language === 'ar';
  const svgRef = useRef<SVGSVGElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [activeTab, setActiveTab] = useState<'calories' | 'macros'>('calories');
  const [hoveredData, setHoveredData] = useState<DayMetric | null>(null);
  const [tooltipPos, setTooltipPos] = useState<{ x: number; y: number } | null>(null);

  // Compute 7 days data leading up to today
  const weeklyData = useMemo<DayMetric[]>(() => {
    const today = new Date();
    const days: DayMetric[] = [];

    const daysAr = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const daysEn = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const isToday = i === 0;

      // For today, sum the real logged meals; for past days, synthesize from any historical loggedMeals if available or 0
      let dayCalories = 0;
      let dayProtein = 0;
      let dayCarbs = 0;
      let dayFats = 0;

      if (isToday) {
        dayCalories = loggedMeals.reduce((acc, m) => acc + (m.calories || 0), 0);
        dayProtein = loggedMeals.reduce((acc, m) => acc + (m.protein || 0), 0);
        dayCarbs = loggedMeals.reduce((acc, m) => acc + (m.carbs || 0), 0);
        dayFats = loggedMeals.reduce((acc, m) => acc + (m.fats || 0), 0);

        // Fallback to nutritionTarget.consumedCalories if loggedMeals are being initialized
        if (dayCalories === 0 && nutritionTarget.consumedCalories > 0) {
          dayCalories = nutritionTarget.consumedCalories;
          dayProtein = nutritionTarget.consumedProtein;
          dayCarbs = nutritionTarget.consumedCarbs;
          dayFats = nutritionTarget.consumedFats;
        }
      }

      const dayIdx = d.getDay();
      days.push({
        dayNameAr: isToday ? (isAr ? 'اليوم' : 'Today') : daysAr[dayIdx],
        dayNameEn: isToday ? 'Today' : daysEn[dayIdx],
        dateStr: `${d.getDate()} ${d.toLocaleString(isAr ? 'ar-EG' : 'en-US', { month: 'short' })}`,
        fullDate: d,
        calories: dayCalories,
        protein: Math.round(dayProtein),
        carbs: Math.round(dayCarbs),
        fats: Math.round(dayFats),
        isToday,
      });
    }

    return days;
  }, [loggedMeals, nutritionTarget, isAr]);

  // Totals & Averages
  const totalWeekCalories = weeklyData.reduce((acc, d) => acc + d.calories, 0);
  const activeDaysCount = weeklyData.filter((d) => d.calories > 0).length || 1;
  const avgDailyCalories = Math.round(totalWeekCalories / activeDaysCount);

  const totalProteinGrams = weeklyData.reduce((acc, d) => acc + d.protein, 0);
  const totalCarbsGrams = weeklyData.reduce((acc, d) => acc + d.carbs, 0);
  const totalFatsGrams = weeklyData.reduce((acc, d) => acc + d.fats, 0);

  const proteinKcal = totalProteinGrams * 4;
  const carbsKcal = totalCarbsGrams * 4;
  const fatsKcal = totalFatsGrams * 9;
  const totalMacroKcal = proteinKcal + carbsKcal + fatsKcal || 1;

  const proteinPct = Math.round((proteinKcal / totalMacroKcal) * 100);
  const carbsPct = Math.round((carbsKcal / totalMacroKcal) * 100);
  const fatsPct = Math.max(0, 100 - proteinPct - carbsPct);

  // Render D3 chart whenever weeklyData or activeTab changes
  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove(); // Clear previous drawing

    const containerWidth = containerRef.current.clientWidth || 340;
    const width = Math.max(300, containerWidth);
    const height = 230;

    const margin = { top: 25, right: 18, bottom: 35, left: 38 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    svg.attr('viewBox', `0 0 ${width} ${height}`).attr('width', '100%').attr('height', height);

    const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

    // X Scale: Days
    const xLabels = weeklyData.map((d) => (isAr ? d.dayNameAr : d.dayNameEn));
    const xScale = d3.scaleBand().domain(xLabels).range([0, innerWidth]).padding(0.28);

    // Definitions for gradients
    const defs = svg.append('defs');

    // Gradient for calorie area/bars
    const calGradient = defs
      .append('linearGradient')
      .attr('id', 'calAreaGrad')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');
    calGradient.append('stop').attr('offset', '0%').attr('stop-color', '#2C5282').attr('stop-opacity', 0.45);
    calGradient.append('stop').attr('offset', '100%').attr('stop-color', '#2C5282').attr('stop-opacity', 0.02);

    const barGradient = defs
      .append('linearGradient')
      .attr('id', 'calBarGrad')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');
    barGradient.append('stop').attr('offset', '0%').attr('stop-color', '#3B6CB4');
    barGradient.append('stop').attr('offset', '100%').attr('stop-color', '#2C5282');

    // -------------------------------------------------------------
    // TAB 1: CALORIC INTAKE WITH D3 BARS, AREA & TARGET LINE
    // -------------------------------------------------------------
    if (activeTab === 'calories') {
      const maxVal = Math.max(
        nutritionTarget.targetCalories * 1.25 || 2500,
        d3.max(weeklyData, (d) => d.calories) || 0,
        2200
      );

      const yScale = d3.scaleLinear().domain([0, maxVal]).nice().range([innerHeight, 0]);

      // Grid lines
      const yAxisGrid = d3
        .axisLeft(yScale)
        .ticks(4)
        .tickSize(-innerWidth)
        .tickFormat(() => '');

      g.append('g')
        .attr('class', 'grid')
        .call(yAxisGrid)
        .selectAll('line')
        .attr('stroke', '#E2E8F0')
        .attr('stroke-dasharray', '3,3')
        .attr('stroke-opacity', 0.7);

      g.select('.grid .domain').remove();

      // D3 Area Generator for subtle background trend curve
      const areaGen = d3
        .area<DayMetric>()
        .x((d) => (xScale(isAr ? d.dayNameAr : d.dayNameEn) || 0) + xScale.bandwidth() / 2)
        .y0(innerHeight)
        .y1((d) => yScale(d.calories))
        .curve(d3.curveMonotoneX);

      g.append('path')
        .datum(weeklyData)
        .attr('fill', 'url(#calAreaGrad)')
        .attr('d', areaGen);

      // Target reference line
      if (nutritionTarget.targetCalories > 0) {
        const targetY = yScale(nutritionTarget.targetCalories);
        g.append('line')
          .attr('x1', 0)
          .attr('x2', innerWidth)
          .attr('y1', targetY)
          .attr('y2', targetY)
          .attr('stroke', '#E53E3E')
          .attr('stroke-dasharray', '4,4')
          .attr('stroke-width', 1.5)
          .attr('opacity', 0.75);

        // Target label text
        g.append('text')
          .attr('x', isAr ? 4 : innerWidth - 4)
          .attr('y', targetY - 4)
          .attr('text-anchor', isAr ? 'start' : 'end')
          .attr('fill', '#E53E3E')
          .attr('font-size', '9px')
          .attr('font-weight', '700')
          .text(isAr ? `الهدف (${nutritionTarget.targetCalories})` : `Target (${nutritionTarget.targetCalories})`);
      }

      // D3 Bars for each day
      g.selectAll('.cal-bar')
        .data(weeklyData)
        .enter()
        .append('rect')
        .attr('class', 'cal-bar')
        .attr('x', (d) => xScale(isAr ? d.dayNameAr : d.dayNameEn) || 0)
        .attr('y', (d) => (d.calories > 0 ? yScale(d.calories) : innerHeight - 4))
        .attr('width', xScale.bandwidth())
        .attr('height', (d) => (d.calories > 0 ? innerHeight - yScale(d.calories) : 4))
        .attr('rx', 5)
        .attr('fill', (d) => (d.isToday ? 'url(#calBarGrad)' : '#CBD5E1'))
        .attr('opacity', (d) => (d.calories > 0 ? 0.95 : 0.45))
        .style('cursor', 'pointer')
        .on('mouseenter', function (event, d) {
          d3.select(this).transition().duration(150).attr('opacity', 1).attr('transform', 'scale(1.02)');
          const [x, y] = d3.pointer(event, containerRef.current);
          setHoveredData(d);
          setTooltipPos({ x, y });
        })
        .on('mousemove', function (event) {
          const [x, y] = d3.pointer(event, containerRef.current);
          setTooltipPos({ x, y });
        })
        .on('mouseleave', function () {
          d3.select(this).transition().duration(150).attr('opacity', 0.95).attr('transform', 'scale(1)');
          setHoveredData(null);
          setTooltipPos(null);
        });

      // Data values on top of bars
      g.selectAll('.bar-label')
        .data(weeklyData)
        .enter()
        .filter((d) => d.calories > 0)
        .append('text')
        .attr('x', (d) => (xScale(isAr ? d.dayNameAr : d.dayNameEn) || 0) + xScale.bandwidth() / 2)
        .attr('y', (d) => yScale(d.calories) - 5)
        .attr('text-anchor', 'middle')
        .attr('font-size', '10px')
        .attr('font-weight', 'bold')
        .attr('fill', (d) => (d.isToday ? '#2C5282' : '#64748B'))
        .text((d) => d.calories);

      // Y-Axis
      const yAxis = d3
        .axisLeft(yScale)
        .ticks(4)
        .tickFormat((d) => `${d}`);
      g.append('g')
        .attr('class', 'y-axis text-slate-400')
        .call(yAxis)
        .selectAll('text')
        .attr('font-size', '9px')
        .attr('fill', '#94A3B8');
      g.select('.y-axis .domain').remove();
    }

    // -------------------------------------------------------------
    // TAB 2: STACKED MACRO DISTRIBUTION (PROTEIN, CARBS, FATS)
    // -------------------------------------------------------------
    if (activeTab === 'macros') {
      const keys = ['protein', 'carbs', 'fats'];
      const stack = d3.stack<DayMetric>().keys(keys);
      const stackedData = stack(weeklyData);

      const maxMacroSum =
        d3.max(weeklyData, (d) => d.protein + d.carbs + d.fats) || 200;
      const yScale = d3
        .scaleLinear()
        .domain([0, Math.max(150, maxMacroSum * 1.15)])
        .nice()
        .range([innerHeight, 0]);

      // Y Grid
      g.append('g')
        .attr('class', 'grid')
        .call(
          d3
            .axisLeft(yScale)
            .ticks(4)
            .tickSize(-innerWidth)
            .tickFormat(() => '')
        )
        .selectAll('line')
        .attr('stroke', '#E2E8F0')
        .attr('stroke-dasharray', '3,3')
        .attr('stroke-opacity', 0.7);
      g.select('.grid .domain').remove();

      // Color Scale: Protein (Emerald #10B981), Carbs (Blue #3B82F6), Fats (Amber #F59E0B)
      const colorScale = d3
        .scaleOrdinal<string>()
        .domain(keys)
        .range(['#10B981', '#3B82F6', '#F59E0B']);

      // Draw Stacked Bars
      const layer = g
        .selectAll('.layer')
        .data(stackedData)
        .enter()
        .append('g')
        .attr('class', 'layer')
        .attr('fill', (d) => colorScale(d.key));

      layer
        .selectAll('rect')
        .data((d) => d)
        .enter()
        .append('rect')
        .attr('x', (d) => xScale(isAr ? d.data.dayNameAr : d.data.dayNameEn) || 0)
        .attr('y', (d) => yScale(d[1]))
        .attr('height', (d) => Math.max(0, yScale(d[0]) - yScale(d[1])))
        .attr('width', xScale.bandwidth())
        .attr('rx', 2)
        .style('cursor', 'pointer')
        .on('mouseenter', function (event, d) {
          const [x, y] = d3.pointer(event, containerRef.current);
          setHoveredData(d.data);
          setTooltipPos({ x, y });
        })
        .on('mousemove', function (event) {
          const [x, y] = d3.pointer(event, containerRef.current);
          setTooltipPos({ x, y });
        })
        .on('mouseleave', function () {
          setHoveredData(null);
          setTooltipPos(null);
        });

      // Y-Axis
      const yAxis = d3
        .axisLeft(yScale)
        .ticks(4)
        .tickFormat((d) => `${d}g`);
      g.append('g')
        .attr('class', 'y-axis')
        .call(yAxis)
        .selectAll('text')
        .attr('font-size', '9px')
        .attr('fill', '#94A3B8');
      g.select('.y-axis .domain').remove();
    }

    // X-Axis (Common for both tabs)
    const xAxis = d3.axisBottom(xScale);
    g.append('g')
      .attr('class', 'x-axis')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(xAxis)
      .selectAll('text')
      .attr('font-size', '10px')
      .attr('font-weight', (d) => (d === (isAr ? 'اليوم' : 'Today') ? '800' : '600'))
      .attr('fill', (d) => (d === (isAr ? 'اليوم' : 'Today') ? '#2C5282' : '#64748B'));

    g.select('.x-axis .domain').attr('stroke', '#CBD5E1');
    g.selectAll('.x-axis line').remove();
  }, [weeklyData, activeTab, nutritionTarget, isAr]);

  return (
    <div className="mt-6 select-none" dir={isAr ? 'rtl' : 'ltr'}>
      {/* Header and Toggle Controls */}
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <div
            className="w-8 h-8 rounded-xl flex items-center justify-center text-white shadow-xs"
            style={{ backgroundColor: '#2C5282' }}
          >
            <TrendingUp className="w-4.5 h-4.5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-[#1E293B]">
              {isAr ? 'تحليل التغذية الأسبوعي (D3.js)' : 'Weekly Nutrition Trends (D3.js)'}
            </h2>
            <span className="text-[10px] text-slate-400 font-medium">
              {isAr ? 'بيانات السعرات وتوزيع الماكروز الحقيقية' : 'Real-time intake & macro distribution'}
            </span>
          </div>
        </div>

        {/* View Mode Toggle: Calories vs Macros */}
        <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200/70">
          <button
            onClick={() => setActiveTab('calories')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
              activeTab === 'calories'
                ? 'bg-white text-[#2C5282] shadow-xs'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-blue-600" />
            <span>{isAr ? 'السعرات' : 'Calories'}</span>
          </button>
          <button
            onClick={() => setActiveTab('macros')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
              activeTab === 'macros'
                ? 'bg-white text-[#2C5282] shadow-xs'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <PieChart className="w-3.5 h-3.5 text-emerald-600" />
            <span>{isAr ? 'الماكروز' : 'Macros'}</span>
          </button>
        </div>
      </div>

      {/* Main Chart Card */}
      <div
        ref={containerRef}
        className="relative p-4 rounded-3xl bg-white border border-slate-100 overflow-hidden"
        style={{
          boxShadow: '0 8px 24px -4px rgba(44, 82, 130, 0.08), 0 2px 6px -2px rgba(0, 0, 0, 0.02)',
        }}
      >
        {/* Top Mini Stats */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 text-xs">
          {activeTab === 'calories' ? (
            <>
              <div className="flex items-center gap-2">
                <span className="text-slate-400 font-medium">{isAr ? 'معدل الاستهلاك اليومي:' : 'Daily Average:'}</span>
                <span className="font-bold text-[#1E293B]">{avgDailyCalories.toLocaleString()} {isAr ? 'سعرة' : 'kcal'}</span>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[#2C5282] bg-blue-50 px-2 py-0.5 rounded-lg">
                <Calendar className="w-3 h-3" />
                <span>{isAr ? 'آخر 7 أيام' : 'Last 7 Days'}</span>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-between w-full">
              <div className="flex items-center gap-3">
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>{isAr ? 'بروتين' : 'Protein'} {proteinPct}%</span>
                </span>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-700">
                  <span className="w-2 h-2 rounded-full bg-blue-500" />
                  <span>{isAr ? 'كارب' : 'Carbs'} {carbsPct}%</span>
                </span>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700">
                  <span className="w-2 h-2 rounded-full bg-amber-500" />
                  <span>{isAr ? 'دهون' : 'Fats'} {fatsPct}%</span>
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-medium">
                {isAr ? 'توزيع نسبي' : 'Ratio'}
              </span>
            </div>
          )}
        </div>

        {/* D3 Rendered SVG Canvas */}
        <div className="w-full relative mt-1">
          <svg ref={svgRef} className="w-full overflow-visible" />
        </div>

        {/* Interactive Floating Tooltip */}
        {hoveredData && tooltipPos && (
          <div
            className="absolute z-20 pointer-events-none bg-white/95 backdrop-blur-md p-3 rounded-2xl shadow-xl border border-slate-200 text-xs min-w-[155px] animate-fadeIn"
            style={{
              left: Math.min(tooltipPos.x + 10, (containerRef.current?.clientWidth || 300) - 165),
              top: Math.max(10, tooltipPos.y - 75),
              boxShadow: '0 10px 25px -4px rgba(44, 82, 130, 0.2)',
            }}
          >
            <div className="flex items-center justify-between pb-1 border-b border-slate-100 mb-1.5">
              <span className="font-bold text-[#1E293B]">
                {isAr ? hoveredData.dayNameAr : hoveredData.dayNameEn}
              </span>
              <span className="text-[10px] text-slate-400 font-medium">
                {hoveredData.dateStr}
              </span>
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between text-slate-700">
                <span className="font-medium text-slate-500">{isAr ? 'السعرات:' : 'Calories:'}</span>
                <span className="font-bold text-[#2C5282]">{hoveredData.calories} kcal</span>
              </div>
              <div className="flex items-center justify-between text-emerald-700">
                <span className="text-[11px]">{isAr ? 'بروتين:' : 'Protein:'}</span>
                <span className="font-bold">{hoveredData.protein}g</span>
              </div>
              <div className="flex items-center justify-between text-blue-700">
                <span className="text-[11px]">{isAr ? 'كربوهيدرات:' : 'Carbs:'}</span>
                <span className="font-bold">{hoveredData.carbs}g</span>
              </div>
              <div className="flex items-center justify-between text-amber-700">
                <span className="text-[11px]">{isAr ? 'دهون:' : 'Fats:'}</span>
                <span className="font-bold">{hoveredData.fats}g</span>
              </div>
            </div>
          </div>
        )}

        {/* Footer Legend */}
        <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
          <div className="flex items-center gap-1">
            <Info className="w-3 h-3 text-slate-400" />
            <span>
              {isAr
                ? 'مرر أو المس أي عمود لعرض تفاصيل اليوم بدقة'
                : 'Hover or touch bars to inspect day metrics'}
            </span>
          </div>
          <span className="font-bold text-[#2C5282]">
            {isAr ? `${weeklyData.length} أيام` : '7 Days'}
          </span>
        </div>
      </div>
    </div>
  );
};
