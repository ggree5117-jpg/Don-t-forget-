import React, { useState } from 'react';
import {
  ArrowRight,
  ArrowLeft,
  Camera,
  Flame,
  Plus,
  Trash2,
  Clock,
  Droplets,
  Scale,
  TrendingDown,
  ChevronRight,
  ChevronLeft,
  X,
  Check,
  Settings,
  Target,
  Sparkles,
  UtensilsCrossed,
  Activity,
} from 'lucide-react';
import { Language } from '../types';
import { DailyNutritionTarget, LoggedMeal, FoodAnalysisResult, UserHealthProfile, HealthGoal } from '../types/health';
import { CalorieArcGauge } from './CalorieArcGauge';
import { MacronutrientsMeter } from './MacronutrientsMeter';
import { CalorieTrendsChart } from './CalorieTrendsChart';
import { WeeklyTrendsD3Chart } from './WeeklyTrendsD3Chart';
import { FoodScannerModal } from './FoodScannerModal';
import { FoodAnalysisResultModal } from './FoodAnalysisResultModal';
import { NutritionAdviceModal } from './NutritionAdviceModal';
import { useOnlineNotice } from './OnlineGate';
import { DailyMealPlanSection } from './DailyMealPlanSection';
import { playChimeSound } from '../utils/audio';

interface HealthDashboardScreenProps {
  nutritionTarget: DailyNutritionTarget;
  loggedMeals: LoggedMeal[];
  userProfile: UserHealthProfile;
  onUpdateProfile: (updates: Partial<UserHealthProfile>) => void;
  onAddMeal: (meal: Omit<LoggedMeal, 'id' | 'time'>) => void;
  onDeleteMeal: (mealId: string) => void;
  onBack: () => void;
  language: Language;
}

export const HealthDashboardScreen: React.FC<HealthDashboardScreenProps> = ({
  nutritionTarget,
  loggedMeals,
  userProfile,
  onUpdateProfile,
  onAddMeal,
  onDeleteMeal,
  onBack,
  language,
}) => {
  const isAr = language === 'ar';
  // الإنترنت مطلوب فقط لميزات الذكاء الاصطناعي (استشارة/تحليل صور)
  const { online, guard, toastElement } = useOnlineNotice(language);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isResultOpen, setIsResultOpen] = useState(false);
  const [isAdviceOpen, setIsAdviceOpen] = useState(false);
  const [scannedResult, setScannedResult] = useState<FoodAnalysisResult | null>(null);
  const [activeHealthTab, setActiveHealthTab] = useState<'dashboard' | 'daily_plan'>('dashboard');

  // Health setup / edit modal state
  const [isSetupModalOpen, setIsSetupModalOpen] = useState(false);
  const [setupWeight, setSetupWeight] = useState(userProfile.currentWeight ? userProfile.currentWeight.toString() : '');
  const [setupTargetWeight, setSetupTargetWeight] = useState(userProfile.targetWeight ? userProfile.targetWeight.toString() : '');
  const [setupStartWeight, setSetupStartWeight] = useState(userProfile.startWeight ? userProfile.startWeight.toString() : '');
  const [setupHeight, setSetupHeight] = useState(userProfile.heightCm ? userProfile.heightCm.toString() : '');
  const [setupCalories, setSetupCalories] = useState(userProfile.targetCalories ? userProfile.targetCalories.toString() : '');
  const [setupProtein, setSetupProtein] = useState(userProfile.targetProtein ? userProfile.targetProtein.toString() : '');
  const [setupCarbs, setSetupCarbs] = useState(userProfile.targetCarbs ? userProfile.targetCarbs.toString() : '');
  const [setupFats, setSetupFats] = useState(userProfile.targetFats ? userProfile.targetFats.toString() : '');
  const [setupGoal, setSetupGoal] = useState<HealthGoal | ''>(userProfile.goal || '');

  // Log weight quick modal
  const [isWeightModalOpen, setIsWeightModalOpen] = useState(false);
  const [newWeightInput, setNewWeightInput] = useState('');

  const today = new Date();
  const todayFormatted = today.toLocaleDateString(isAr ? 'ar-EG' : 'en-US', {
    day: 'numeric',
    month: 'short',
  });

  const remainingKcal = nutritionTarget.targetCalories > 0
    ? Math.max(0, nutritionTarget.targetCalories - nutritionTarget.consumedCalories)
    : 0;

  // Real calculations based ONLY on user input
  const currentWeight = userProfile.currentWeight;
  const startWeight = userProfile.startWeight;
  const targetWeight = userProfile.targetWeight;
  const heightCm = userProfile.heightCm;

  const hasWeightData = currentWeight !== null;
  const hasTargetsSet = userProfile.targetCalories !== null && userProfile.targetCalories > 0;

  // Calculate BMI only if both current weight and height exist
  const bmi = (currentWeight !== null && heightCm !== null && heightCm > 0)
    ? parseFloat((currentWeight / ((heightCm / 100) * (heightCm / 100))).toFixed(1))
    : null;

  // Weight progress calculations only if start & target weight are defined
  const weightLostSoFar = (startWeight !== null && currentWeight !== null)
    ? parseFloat((startWeight - currentWeight).toFixed(1))
    : null;

  const remainingWeight = (currentWeight !== null && targetWeight !== null)
    ? parseFloat(Math.abs(currentWeight - targetWeight).toFixed(1))
    : null;

  const weightProgressPct = (startWeight !== null && targetWeight !== null && currentWeight !== null && startWeight !== targetWeight)
    ? Math.min(100, Math.max(0, Math.round(((startWeight - currentWeight) / (startWeight - targetWeight)) * 100)))
    : null;

  const waterGlasses = userProfile.waterGlasses ?? 0;

  // Built-in AI Food Lens: opens internal camera scanner without navigating away, so food info is saved directly
  const openInternalLensScanner = () => {
    setIsScannerOpen(true);
  };

  const handleScanComplete = (result: FoodAnalysisResult) => {
    setIsScannerOpen(false);
    setScannedResult(result);
    setIsResultOpen(true);
  };

  const handleSaveSetup = () => {
    const curW = parseFloat(setupWeight);
    const tarW = parseFloat(setupTargetWeight);
    const stW = parseFloat(setupStartWeight);
    const h = parseFloat(setupHeight);
    const cal = parseInt(setupCalories, 10);
    const prot = parseInt(setupProtein, 10);
    const c = parseInt(setupCarbs, 10);
    const f = parseInt(setupFats, 10);

    onUpdateProfile({
      currentWeight: !isNaN(curW) && curW > 0 ? curW : null,
      targetWeight: !isNaN(tarW) && tarW > 0 ? tarW : null,
      startWeight: !isNaN(stW) && stW > 0 ? stW : (!isNaN(curW) ? curW : null),
      heightCm: !isNaN(h) && h > 0 ? h : null,
      targetCalories: !isNaN(cal) && cal > 0 ? cal : null,
      targetProtein: !isNaN(prot) && prot > 0 ? prot : null,
      targetCarbs: !isNaN(c) && c > 0 ? c : null,
      targetFats: !isNaN(f) && f > 0 ? f : null,
      goal: setupGoal || null,
    });

    playChimeSound();
    setIsSetupModalOpen(false);
  };

  const handleSaveQuickWeight = () => {
    const val = parseFloat(newWeightInput);
    if (!isNaN(val) && val > 20 && val < 350) {
      onUpdateProfile({
        currentWeight: parseFloat(val.toFixed(1)),
        startWeight: userProfile.startWeight ?? parseFloat(val.toFixed(1)),
      });
      playChimeSound();
    }
    setIsWeightModalOpen(false);
  };

  const updateWater = (delta: number) => {
    const nextVal = Math.max(0, Math.min(20, waterGlasses + delta));
    onUpdateProfile({ waterGlasses: nextVal });
    playChimeSound();
  };

  const openSetupModal = () => {
    setSetupWeight(userProfile.currentWeight ? userProfile.currentWeight.toString() : '');
    setSetupTargetWeight(userProfile.targetWeight ? userProfile.targetWeight.toString() : '');
    setSetupStartWeight(userProfile.startWeight ? userProfile.startWeight.toString() : '');
    setSetupHeight(userProfile.heightCm ? userProfile.heightCm.toString() : '');
    setSetupCalories(userProfile.targetCalories ? userProfile.targetCalories.toString() : '');
    setSetupProtein(userProfile.targetProtein ? userProfile.targetProtein.toString() : '');
    setSetupCarbs(userProfile.targetCarbs ? userProfile.targetCarbs.toString() : '');
    setSetupFats(userProfile.targetFats ? userProfile.targetFats.toString() : '');
    setSetupGoal(userProfile.goal || '');
    setIsSetupModalOpen(true);
  };

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="flex-1 flex flex-col bg-[#F8FAFD] text-[#354052] px-5 py-4 overflow-y-auto select-none pb-28 relative"
    >
      {/* 1. Top Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <button
          onClick={onBack}
          className="min-h-[44px] min-w-[44px] rounded-full flex items-center justify-center text-[#718096] hover:bg-slate-100/80 hover:text-[#354052] transition-colors cursor-pointer"
          aria-label={isAr ? 'رجوع' : 'Back'}
          title={isAr ? 'رجوع' : 'Back'}
        >
          {isAr ? <ArrowRight className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
        </button>

        <div className="flex items-center gap-1.5">
          <h1 className="text-xl font-bold text-[#3B6CB4]">
            {isAr ? 'الصحة والتغذية الذكية' : 'Health & AI Nutrition'}
          </h1>
          <span className="w-1.5 h-1.5 rounded-full bg-[#F3D58A]" />
        </div>

        {/* Setup Goals button in header */}
        <button
          onClick={openSetupModal}
          className="w-10 h-10 rounded-2xl flex items-center justify-center text-[#3B6CB4] bg-[#EBF2FA] border border-[#3B6CB4]/20 transition-all shadow-xs cursor-pointer active:scale-95 hover:bg-[#3B6CB4] hover:text-white"
          title={isAr ? 'تعديل الأهداف والوزن' : 'Edit goals & weight'}
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>

      {/* Sub-Navigation Switcher: Dashboard vs Daily Plan */}
      <div className="mt-3.5 p-1 bg-slate-200/70 rounded-2xl border border-slate-200/90 grid grid-cols-2 gap-1">
        <button
          onClick={() => setActiveHealthTab('dashboard')}
          className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeHealthTab === 'dashboard'
              ? 'bg-white text-[#2C5282] shadow-xs font-black'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>{isAr ? 'المؤشرات والوجبات' : "Today's Meals"}</span>
        </button>

        <button
          onClick={() => setActiveHealthTab('daily_plan')}
          className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer relative ${
            activeHealthTab === 'daily_plan'
              ? 'bg-[#2C5282] text-white shadow-xs font-black'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <UtensilsCrossed className="w-3.5 h-3.5" />
          <span>{isAr ? 'الخطة اليومية للأكل' : 'Daily Meal Plan'}</span>
          <span className="w-2 h-2 rounded-full bg-[#F3D58A] animate-pulse" />
        </button>
      </div>

      {/* Conditional View: Daily Meal & Health Plan */}
      {activeHealthTab === 'daily_plan' ? (
        <div className="mt-4">
          <DailyMealPlanSection
            language={language}
            online={online}
            nutritionTarget={nutritionTarget}
            userProfile={userProfile}
            waterGlasses={waterGlasses}
            onUpdateWaterGlasses={(count) => onUpdateProfile({ waterGlasses: count })}
            onAddMeal={onAddMeal}
          />
        </div>
      ) : (
        <>
          {/* Health Target Setup Prompt Banner if not configured yet */}
          {!hasTargetsSet && (
            <div
              onClick={openSetupModal}
              className="mt-3.5 p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200/90 text-amber-900 flex items-center justify-between cursor-pointer hover:bg-amber-100/70 transition-colors"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-200/70 text-amber-800 flex items-center justify-center shrink-0">
                  <Target className="w-4.5 h-4.5" />
                </div>
                <div>
                  <p className="text-xs font-bold">
                    {isAr ? 'حدد أهدافك الصحية وسعراتك اليومية' : 'Set your health goals & calorie target'}
                  </p>
                  <p className="text-[11px] text-amber-700/80">
                    {isAr ? 'اضغط هنا لضبط وزنك وطولك وهدفك دون أي بيانات مسبقة' : 'Tap here to configure your weight, height, and target'}
                  </p>
                </div>
              </div>
              <span className="text-xs font-bold bg-amber-500 text-white px-2.5 py-1 rounded-lg shrink-0">
                {isAr ? 'ضبط' : 'Set'}
              </span>
            </div>
          )}

          {/* Quick Banner: Plan Shortcut in Dashboard */}
          <div
            onClick={() => setActiveHealthTab('daily_plan')}
            className="mt-3.5 p-3 rounded-2xl bg-gradient-to-r from-[#2C5282]/10 via-[#2C5282]/5 to-transparent border border-[#2C5282]/20 flex items-center justify-between cursor-pointer hover:bg-[#2C5282]/15 transition-all group"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-[#2C5282] text-white flex items-center justify-center shadow-xs">
                <UtensilsCrossed className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-[#2C5282] flex items-center gap-1.5">
                  <span>{isAr ? 'الخطة اليومية للأكل والصحة' : 'Daily Eating & Health Plan'}</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded-md bg-[#2C5282] text-white font-black">
                    5 {isAr ? 'وجبات' : 'Meals'}
                  </span>
                </p>
                <p className="text-[10px] text-slate-500">
                  {isAr ? 'استعرض جدول وجباتك المخططة وسجل ما تناولته بنقرة واحدة' : 'Explore planned meals & log them with 1 tap'}
                </p>
              </div>
            </div>
            <span className="text-xs font-bold text-[#2C5282] group-hover:underline">
              {isAr ? 'عرض الخطة ←' : 'View Plan →'}
            </span>
          </div>

          {/* Date Pill & Quick Status */}
          <div className="flex items-center justify-between mt-4 px-1">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-[#354052]">
                {isAr ? 'مؤشرات اليوم الغذائية' : "Today's Nutrition Summary"}
              </span>
              <span className="text-[11px] text-slate-400 font-medium">· {todayFormatted}</span>
            </div>
            <span className="text-[11px] font-bold text-[#3B6CB4] bg-[#EBF2FA] px-2.5 py-0.5 rounded-full">
              {nutritionTarget.targetCalories > 0 ? (
                remainingKcal > 0
                  ? isAr ? `متبقي ${remainingKcal} سعرة` : `${remainingKcal} Kcal left`
                  : isAr ? 'تم الوصول للهدف!' : 'Target reached!'
              ) : (
                isAr ? 'الهدف غير محدد' : 'Target not set'
              )}
            </span>
          </div>

      {/* 2. Main Calorie Semi-Circular Arc Gauge Card */}
      <div
        className="mt-3.5 p-4 rounded-3xl bg-white border border-blue-50/80 transition-all cursor-pointer"
        onClick={() => {
          if (!hasTargetsSet) openSetupModal();
        }}
        style={{
          boxShadow: '0 12px 28px -6px rgba(59, 108, 180, 0.08), 0 2px 8px -2px rgba(0, 0, 0, 0.02)',
        }}
      >
        <CalorieArcGauge
          consumed={nutritionTarget.consumedCalories}
          target={nutritionTarget.targetCalories}
          language={language}
        />
      </div>

      {/* Internal Food Lens Scanner & AI Advice Action Cards (Muted Navy #2C5282 & White #FFFFFF) */}
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {/* Card 1: Built-in AI Food Lens Scanner (100% internal, directly saves meal data) */}
        <div
          onClick={openInternalLensScanner}
          className="p-3.5 rounded-2xl border transition-all duration-200 cursor-pointer flex items-center justify-between group active:scale-98 bg-white hover:border-[#2C5282]/50"
          style={{
            borderColor: 'rgba(44, 82, 130, 0.22)',
            boxShadow: '0 4px 14px -3px rgba(44, 82, 130, 0.08)',
          }}
          title={isAr ? 'عدسة تحليل الطعام وحفظ الوجبة داخل التطبيق' : 'Analyze food & save meal internally'}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-11 h-11 rounded-xl text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform shrink-0"
              style={{ backgroundColor: '#2C5282' }}
            >
              <Camera className="w-5 h-5 stroke-[2.3]" />
            </div>
            <div className="min-w-0">
              <h3 className="text-xs font-bold text-[#2C5282] flex items-center gap-1.5 truncate">
                <span>{isAr ? 'عدسة تحليل الطعام الذكية' : 'AI Food Lens Scanner'}</span>
                <span className="text-[9px] font-black px-1.5 py-0.2 rounded-md bg-[#2C5282]/10 text-[#2C5282]">
                  Lens
                </span>
              </h3>
              <p className="text-[11px] text-slate-500 font-medium mt-0.5 line-clamp-1">
                {isAr ? 'تحليل الوجبة وحفظ بياناتها داخل التطبيق' : 'Scan & save meal data directly'}
              </p>
            </div>
          </div>

          <div
            className="w-7 h-7 rounded-full flex items-center justify-center text-[#2C5282] bg-[#F0F4F8] shrink-0 transition-colors group-hover:bg-[#2C5282] group-hover:text-white"
          >
            {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </div>
        </div>

        {/* Card 2: Get AI Advice with Gemini API */}
        <div
          onClick={() => guard(() => setIsAdviceOpen(true), 'advice')}
          className="p-3.5 rounded-2xl border transition-all duration-200 cursor-pointer flex items-center justify-between group active:scale-98 bg-white hover:border-[#2C5282]/50"
          style={{
            borderColor: 'rgba(44, 82, 130, 0.28)',
            boxShadow: '0 4px 14px -3px rgba(44, 82, 130, 0.1)',
          }}
          title={isAr ? 'استشارة الذكاء الاصطناعي الغذائية' : 'Get AI Nutrition Advice'}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-11 h-11 rounded-xl text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform shrink-0 relative overflow-hidden"
              style={{ backgroundColor: '#2C5282' }}
            >
              <Sparkles className="w-5 h-5 text-[#F3D58A] animate-pulse" />
            </div>
            <div className="min-w-0">
              <h3 className="text-xs font-bold text-[#2C5282] flex items-center gap-1.5 truncate">
                <span>{isAr ? 'استشارة الذكاء الاصطناعي' : 'Get AI Advice'}</span>
                <span className="text-[9px] font-black px-1.5 py-0.2 rounded-md bg-amber-100 text-amber-800">
                  Gemini
                </span>
              </h3>
              <p className="text-[11px] text-slate-500 font-medium mt-0.5 line-clamp-1">
                {isAr ? 'تحليل الوجبات وتوجيهات حسب هدفك' : "Analyze today's meals vs your goals"}
              </p>
            </div>
          </div>

          <div
            className="w-7 h-7 rounded-full flex items-center justify-center text-white shrink-0 shadow-2xs"
            style={{ backgroundColor: '#2C5282' }}
          >
            {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </div>
        </div>
      </div>

      {/* Weekly Caloric Intake & Macro Trends Powered by D3.js */}
      <WeeklyTrendsD3Chart
        loggedMeals={loggedMeals}
        nutritionTarget={nutritionTarget}
        language={language}
      />

      {/* 3. Dedicated Weight Tracking Interface Card */}
      <div className="mt-6">
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center gap-1.5">
            <Scale className="w-4 h-4 text-[#3B6CB4]" />
            <h2 className="text-sm font-bold text-[#3B6CB4]">
              {isAr ? 'واجهة تتبع الوزن ومؤشر الكتلة' : 'Weight & BMI Tracking'}
            </h2>
          </div>
          <button
            onClick={() => {
              setNewWeightInput(currentWeight ? currentWeight.toString() : '');
              setIsWeightModalOpen(true);
            }}
            className="text-xs font-bold text-[#3B6CB4] bg-[#EBF2FA] px-2.5 py-1 rounded-full hover:bg-blue-100 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <Plus className="w-3 h-3 stroke-[3]" />
            <span>{isAr ? 'تسجيل وزن' : 'Log Weight'}</span>
          </button>
        </div>

        <div
          className="p-4 rounded-3xl bg-white border border-blue-50/80 transition-all"
          style={{
            boxShadow: '0 8px 24px -4px rgba(59, 108, 180, 0.06), 0 2px 6px -2px rgba(0, 0, 0, 0.02)',
          }}
        >
          {/* Top Row: Current Weight & BMI */}
          <div className="flex items-center justify-between pb-3.5 border-b border-slate-100">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                {isAr ? 'الوزن الحالي' : 'Current Weight'}
              </span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-2xl font-black text-[#1E293B] tracking-tight">
                  {currentWeight !== null ? currentWeight : '—'}
                </span>
                <span className="text-xs font-bold text-slate-400">
                  {isAr ? 'كجم' : 'kg'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Lost so far badge: only show if start weight exists and differs */}
              {weightLostSoFar !== null ? (
                <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200/80 text-[11px] font-bold">
                  <TrendingDown className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>
                    {weightLostSoFar >= 0 ? `-${weightLostSoFar}` : `+${Math.abs(weightLostSoFar)}`} {isAr ? 'كجم' : 'kg'}
                  </span>
                </div>
              ) : (
                <div className="px-2.5 py-1 rounded-xl bg-slate-50 text-slate-400 text-[11px] font-medium border border-slate-100">
                  <span>{isAr ? 'التغير: —' : 'Diff: —'}</span>
                </div>
              )}

              {/* BMI pill */}
              <div className="px-2.5 py-1 rounded-xl bg-[#EBF2FA] text-[#3B6CB4] text-[11px] font-bold">
                <span>BMI {bmi !== null ? bmi : '—'}</span>
                {bmi !== null && (
                  <span className="text-[9px] text-slate-500 mr-1 ml-1">
                    ({bmi < 18.5 ? (isAr ? 'نحيف' : 'Under') : bmi < 25 ? (isAr ? 'طبيعي' : 'Normal') : bmi < 30 ? (isAr ? 'زيادة' : 'Over') : (isAr ? 'سمنة' : 'Obese')})
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Progress Bar from Start to Target */}
          <div className="mt-3.5">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 mb-1.5">
              <span>
                {isAr
                  ? `البداية: ${startWeight !== null ? `${startWeight} كجم` : '—'}`
                  : `Start: ${startWeight !== null ? `${startWeight}kg` : '—'}`}
              </span>
              <span className="text-[#3B6CB4] font-bold">
                {remainingWeight !== null
                  ? isAr ? `المتبقي للهدف: ${remainingWeight} كجم` : `${remainingWeight}kg to goal`
                  : isAr ? 'المتبقي: —' : 'Remaining: —'}
              </span>
              <span>
                {isAr
                  ? `الهدف: ${targetWeight !== null ? `${targetWeight} كجم` : '—'}`
                  : `Goal: ${targetWeight !== null ? `${targetWeight}kg` : '—'}`}
              </span>
            </div>

            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden p-0.5 shadow-inner">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#3B6CB4] to-emerald-500 transition-all duration-700 ease-out"
                style={{ width: `${weightProgressPct ?? 0}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
              <span>
                {weightProgressPct !== null
                  ? `${weightProgressPct}% ${isAr ? 'منجز نحو هدفك' : 'completed towards goal'}`
                  : isAr ? 'أدخل أهدافك لحساب التقدم' : 'Set goals to track progress'}
              </span>
              <button
                onClick={openSetupModal}
                className="text-[#3B6CB4] font-bold hover:underline cursor-pointer"
              >
                {isAr ? 'تعديل الأهداف' : 'Edit Targets'} 🎯
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Three Linear Progress Bars for Macronutrients */}
      <div className="mt-6">
        <div className="flex items-center justify-between mb-3 px-1">
          <h2 className="text-sm font-bold text-[#3B6CB4]">
            {isAr ? 'توزيع المغذيات الكبرى (الماكروز)' : 'Macronutrients Meter'}
          </h2>
          <span className="text-[11px] text-slate-400 font-semibold">
            {isAr ? 'غرام / يوم' : 'Grams / Day'}
          </span>
        </div>

        <MacronutrientsMeter
          protein={{
            consumed: nutritionTarget.consumedProtein,
            target: nutritionTarget.targetProtein,
          }}
          carbs={{
            consumed: nutritionTarget.consumedCarbs,
            target: nutritionTarget.targetCarbs,
          }}
          fats={{
            consumed: nutritionTarget.consumedFats,
            target: nutritionTarget.targetFats,
          }}
          language={language}
        />
      </div>

      {/* 5. Hydration Water Tracker */}
      <div className="mt-6 p-4 rounded-2xl bg-[#EBF2FA]/60 border border-[#3B6CB4]/20 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white text-[#3B6CB4] flex items-center justify-center shadow-xs">
            <Droplets className="w-5 h-5 fill-[#3B6CB4]" />
          </div>
          <div>
            <span className="text-xs font-bold text-[#354052] block">
              {isAr ? 'معدل شرب الماء اليوم' : 'Daily Water Intake'}
            </span>
            <span className="text-[11px] text-slate-500 font-medium">
              {waterGlasses} / 8 {isAr ? `أكواب (${(waterGlasses * 0.25).toFixed(1)} لتر)` : `glasses (${(waterGlasses * 0.25).toFixed(1)}L)`}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => updateWater(-1)}
            disabled={waterGlasses <= 0}
            className="w-7 h-7 rounded-full bg-white text-slate-600 font-bold text-xs flex items-center justify-center border border-slate-200 hover:bg-slate-50 cursor-pointer disabled:opacity-40"
          >
            -
          </button>
          <span className="text-xs font-bold text-[#354052] min-w-[16px] text-center">
            {waterGlasses}
          </span>
          <button
            onClick={() => updateWater(1)}
            className="w-7 h-7 rounded-full bg-[#3B6CB4] text-white font-bold text-xs flex items-center justify-center shadow-2xs hover:bg-[#3B6CB4]/90 cursor-pointer"
          >
            +
          </button>
        </div>
      </div>

      {/* 6. Logged Meals List for Today */}
      <div className="mt-7">
        <div className="flex items-center justify-between mb-3.5 px-1">
          <div className="flex items-center gap-1.5">
            <h2 className="text-sm font-bold text-[#3B6CB4]">
              {isAr ? 'الوجبات المسجلة اليوم' : "Today's Logged Meals"}
            </h2>
            <span className="text-xs text-slate-400 font-normal">
              ({loggedMeals.length})
            </span>
          </div>
          <div className="flex items-center gap-2">
            {/* Get AI Advice Button */}
            <button
              onClick={() => guard(() => setIsAdviceOpen(true), 'advice')}
              className="text-xs font-bold text-white px-3 py-1.5 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95 transition-all"
              style={{ backgroundColor: '#2C5282' }}
              title={isAr ? 'استشارة الذكاء الاصطناعي حول وجباتك' : 'Get AI Advice on your meals'}
            >
              <Sparkles className="w-3.5 h-3.5 text-[#F3D58A] animate-pulse" />
              <span>{isAr ? 'نصيحة AI' : 'Get AI Advice'}</span>
            </button>

            {/* Add Meal Button */}
            <button
              onClick={() => setIsScannerOpen(true)}
              className="text-xs font-bold text-[#3B6CB4] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>{isAr ? 'إضافة وجبة' : 'Add Meal'}</span>
            </button>
          </div>
        </div>

        <div className="space-y-3">
          {loggedMeals.length === 0 ? (
            <div className="py-10 px-4 text-center text-slate-400 text-xs bg-white rounded-3xl border border-dashed border-slate-200">
              <p className="font-semibold text-slate-600 text-sm mb-1">
                {isAr ? 'لم تسجل أي وجبة اليوم' : 'No meals logged today yet'}
              </p>
              <p className="text-[11px] text-slate-400 mb-3.5 max-w-[260px] mx-auto leading-relaxed">
                {isAr ? 'استخدم عدسة التحليل الذكية لتصوير وجبتك وحساب قيمها فوراً وحفظها في يومياتك' : 'Use AI camera lens to snap, analyze, and save meal data directly'}
              </p>
              <div className="flex items-center justify-center gap-2 flex-wrap">
                <button
                  onClick={openInternalLensScanner}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-white font-bold text-xs shadow-xs hover:opacity-95 transition-all cursor-pointer"
                  style={{ backgroundColor: '#2C5282' }}
                >
                  <Camera className="w-4 h-4" />
                  <span>{isAr ? 'عدسة تحليل الوجبات' : 'AI Food Lens'}</span>
                </button>
                <button
                  onClick={() => guard(() => setIsAdviceOpen(true), 'advice')}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white border border-[#2C5282]/30 text-[#2C5282] font-bold text-xs shadow-xs hover:bg-[#2C5282]/5 transition-all cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>{isAr ? 'استشارة الذكاء الاصطناعي' : 'Get AI Advice'}</span>
                </button>
              </div>
            </div>
          ) : (
            loggedMeals.map((meal) => (
              <div
                key={meal.id}
                className="p-3.5 rounded-2xl border border-slate-100 bg-white transition-all flex items-center justify-between"
                style={{
                  boxShadow: '0 6px 18px -4px rgba(0, 0, 0, 0.04), 0 2px 6px -2px rgba(59, 108, 180, 0.06)',
                }}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {meal.imageUrl ? (
                    <img
                      src={meal.imageUrl}
                      alt={meal.name}
                      className="w-12 h-12 rounded-xl object-cover shrink-0 border border-slate-100"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-xl bg-[#EBF2FA] flex items-center justify-center text-[#3B6CB4] shrink-0">
                      <Flame className="w-5 h-5 fill-current" />
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <h3 className="text-sm font-bold text-[#1E293B] truncate">
                      {isAr ? meal.nameAr || meal.name : meal.name}
                    </h3>
                    <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                      <span className="text-[11px] font-bold text-[#3B6CB4]">
                        {meal.calories} {isAr ? 'سعرة' : 'Kcal'}
                      </span>
                      <span className="text-slate-300 text-xs">·</span>
                      <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{meal.time}</span>
                      </span>
                      <span className="text-slate-300 text-xs">·</span>
                      <span className="text-[10px] text-slate-500 font-semibold">
                        P: {meal.protein}g · C: {meal.carbs}g · F: {meal.fats}g
                        {meal.fiber !== undefined && meal.fiber > 0 && ` · ألياف: ${meal.fiber}g`}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Delete button */}
                <button
                  onClick={() => onDeleteMeal(meal.id)}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-slate-300 hover:text-rose-500 hover:bg-rose-50 transition-colors cursor-pointer shrink-0 ml-1"
                  title={isAr ? 'حذف الوجبة واسترجاع السعرات' : 'Delete meal and restore calories'}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* 7. Floating Action Buttons: AI Advice & Internal Food Lens */}
      <div className="fixed bottom-24 right-5 z-30 flex items-center gap-2">
        {/* AI Advice Quick Floating Pill */}
        <button
          onClick={() => guard(() => setIsAdviceOpen(true), 'advice')}
          className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-full bg-white text-[#2C5282] border border-[#2C5282]/25 font-bold text-xs transition-all duration-200 active:scale-95 hover:scale-105 cursor-pointer shadow-lg hover:shadow-xl"
          title={isAr ? 'استشارة الذكاء الاصطناعي الغذائية' : 'Get AI Nutrition Advice'}
        >
          <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" />
          <span className="hidden sm:inline">{isAr ? 'نصيحة AI' : 'AI Advice'}</span>
        </button>

        {/* AI Food Lens Scanner Primary Button (100% inside app, saves meal directly) */}
        <button
          onClick={openInternalLensScanner}
          className="flex items-center gap-2 px-4 py-3 rounded-full text-white font-bold text-xs transition-all duration-200 active:scale-95 hover:scale-105 cursor-pointer shadow-xl ring-4 ring-white"
          style={{
            backgroundColor: '#2C5282',
            boxShadow: '0 10px 28px -4px rgba(44, 82, 130, 0.55), 0 2px 10px 0 rgba(44, 82, 130, 0.3)',
          }}
          title={isAr ? 'عدسة تصوير الوجبة وتحليلها وحفظها' : 'Scan & save meal'}
        >
          <Camera className="w-5 h-5 stroke-[2.4]" />
          <span>{isAr ? 'عدسة الوجبات' : 'Scan Meal'}</span>
        </button>
      </div>
        </>
      )}

      {/* Quick Weight Log Modal */}
      {isWeightModalOpen && (
        <div
          dir={isAr ? 'rtl' : 'ltr'}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 select-none animate-fadeIn"
        >
          <div className="bg-white rounded-3xl p-6 w-full max-w-xs shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-[#3B6CB4]" />
                <h3 className="text-base font-bold text-[#1E293B]">
                  {isAr ? 'تسجيل الوزن الجديد' : 'Log New Weight'}
                </h3>
              </div>
              <button
                onClick={() => setIsWeightModalOpen(false)}
                className="w-7 h-7 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-500 block mb-1">
                  {isAr ? 'الوزن (كجم)' : 'Weight (kg)'}
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={newWeightInput}
                  onChange={(e) => setNewWeightInput(e.target.value)}
                  className="w-full py-2.5 px-3.5 rounded-xl border border-slate-200 text-lg font-bold text-[#1E293B] focus:outline-none focus:border-[#3B6CB4]"
                  placeholder={isAr ? 'مثال: 70' : 'e.g. 70'}
                  autoFocus
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={handleSaveQuickWeight}
                  className="flex-1 py-2.5 rounded-xl bg-[#3B6CB4] text-white font-bold text-xs shadow-md shadow-[#3B6CB4]/40 flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{isAr ? 'حفظ' : 'Save'}</span>
                </button>
                <button
                  onClick={() => setIsWeightModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-600 font-bold text-xs hover:bg-slate-200 cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Comprehensive Health Targets & Metrics Setup Modal (Starts empty, no fake defaults) */}
      {isSetupModalOpen && (
        <div
          dir={isAr ? 'rtl' : 'ltr'}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 select-none animate-fadeIn"
        >
          <div className="bg-white rounded-3xl p-5 w-full max-w-sm max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-[#3B6CB4]" />
                <h3 className="text-base font-bold text-[#1E293B]">
                  {isAr ? 'إعداد الأهداف والقياسات الصحية' : 'Health Goals & Target Setup'}
                </h3>
              </div>
              <button
                onClick={() => setIsSetupModalOpen(false)}
                className="w-7 h-7 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400 mt-2 mb-4">
              {isAr
                ? 'أدخل قياساتك وأهدافك الخاصة. لن يتم عرض أي أرقام افتراضية دون إدخالك.'
                : 'Enter your personal metrics. No placeholder or fake values will be used.'}
            </p>

            <div className="space-y-3.5">
              {/* Goal selector */}
              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-1.5">
                  {isAr ? 'الهدف الصحي الرئيسي' : 'Primary Health Goal'}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setSetupGoal('lose_weight')}
                    className={`py-2 px-1 text-center rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      setupGoal === 'lose_weight'
                        ? 'border-[#3B6CB4] bg-[#EBF2FA] text-[#3B6CB4]'
                        : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                    }`}
                  >
                    {isAr ? 'خسارة وزن' : 'Lose Weight'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setSetupGoal('maintain')}
                    className={`py-2 px-1 text-center rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      setupGoal === 'maintain'
                        ? 'border-[#3B6CB4] bg-[#EBF2FA] text-[#3B6CB4]'
                        : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                    }`}
                  >
                    {isAr ? 'محافظة' : 'Maintain'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setSetupGoal('gain_muscle')}
                    className={`py-2 px-1 text-center rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      setupGoal === 'gain_muscle'
                        ? 'border-[#3B6CB4] bg-[#EBF2FA] text-[#3B6CB4]'
                        : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                    }`}
                  >
                    {isAr ? 'بناء عضلات' : 'Build Muscle'}
                  </button>
                </div>
              </div>

              {/* Weights row */}
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                    {isAr ? 'الوزن الحالي (كجم)' : 'Current Weight (kg)'}
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={setupWeight}
                    onChange={(e) => setSetupWeight(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-200 text-sm font-bold text-[#1E293B] focus:outline-none focus:border-[#3B6CB4]"
                    placeholder="—"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                    {isAr ? 'الوزن المستهدف (كجم)' : 'Target Weight (kg)'}
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={setupTargetWeight}
                    onChange={(e) => setSetupTargetWeight(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-200 text-sm font-bold text-[#1E293B] focus:outline-none focus:border-[#3B6CB4]"
                    placeholder="—"
                  />
                </div>
              </div>

              {/* Start weight & Height */}
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                    {isAr ? 'وزن البداية (كجم)' : 'Starting Weight (kg)'}
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={setupStartWeight}
                    onChange={(e) => setSetupStartWeight(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-200 text-sm font-bold text-[#1E293B] focus:outline-none focus:border-[#3B6CB4]"
                    placeholder="—"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                    {isAr ? 'الطول (سم لحساب BMI)' : 'Height (cm for BMI)'}
                  </label>
                  <input
                    type="number"
                    value={setupHeight}
                    onChange={(e) => setSetupHeight(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-200 text-sm font-bold text-[#1E293B] focus:outline-none focus:border-[#3B6CB4]"
                    placeholder="—"
                  />
                </div>
              </div>

              {/* Daily Target Calories */}
              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? 'السعرات اليومية المستهدفة (Kcal)' : 'Target Daily Calories (Kcal)'}
                </label>
                <input
                  type="number"
                  value={setupCalories}
                  onChange={(e) => setSetupCalories(e.target.value)}
                  className="w-full py-2 px-3 rounded-xl border border-slate-200 text-sm font-bold text-[#1E293B] focus:outline-none focus:border-[#3B6CB4]"
                  placeholder="—"
                />
              </div>

              {/* Macronutrient Grams */}
              <div>
                <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                  {isAr ? 'الماكروز المستهدفة (غرام)' : 'Target Macros (g)'}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <input
                    type="number"
                    value={setupProtein}
                    onChange={(e) => setSetupProtein(e.target.value)}
                    className="w-full py-2 px-2.5 rounded-xl border border-slate-200 text-xs font-bold text-center text-[#1E293B] focus:outline-none focus:border-[#3B6CB4]"
                    placeholder={isAr ? 'بروتين' : 'Protein'}
                  />
                  <input
                    type="number"
                    value={setupCarbs}
                    onChange={(e) => setSetupCarbs(e.target.value)}
                    className="w-full py-2 px-2.5 rounded-xl border border-slate-200 text-xs font-bold text-center text-[#1E293B] focus:outline-none focus:border-[#3B6CB4]"
                    placeholder={isAr ? 'كارب' : 'Carbs'}
                  />
                  <input
                    type="number"
                    value={setupFats}
                    onChange={(e) => setSetupFats(e.target.value)}
                    className="w-full py-2 px-2.5 rounded-xl border border-slate-200 text-xs font-bold text-center text-[#1E293B] focus:outline-none focus:border-[#3B6CB4]"
                    placeholder={isAr ? 'دهون' : 'Fats'}
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-3">
                <button
                  type="button"
                  onClick={handleSaveSetup}
                  className="flex-1 py-2.5 rounded-xl bg-[#3B6CB4] text-white font-bold text-xs shadow-md shadow-[#3B6CB4]/40 flex items-center justify-center gap-1 cursor-pointer active:scale-95"
                >
                  <Check className="w-4 h-4" />
                  <span>{isAr ? 'حفظ الأهداف' : 'Save Goals'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsSetupModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-600 font-bold text-xs hover:bg-slate-200 cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Camera Food Scanner Modal */}
      <FoodScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScanComplete={handleScanComplete}
        onOpenAdvice={() => {
          setIsScannerOpen(false);
          guard(() => setIsAdviceOpen(true), 'advice');
        }}
        language={language}
        online={online}
      />

      {/* AI Food Analysis Results Modal */}
      <FoodAnalysisResultModal
        isOpen={isResultOpen}
        result={scannedResult}
        onClose={() => {
          setIsResultOpen(false);
          setScannedResult(null);
        }}
        onAddMeal={(mealData) => {
          onAddMeal(mealData);
        }}
        language={language}
        targetCalories={nutritionTarget.targetCalories}
      />

      {/* AI Nutrition Advice Modal with Gemini API */}
      <NutritionAdviceModal
        isOpen={isAdviceOpen}
        onClose={() => setIsAdviceOpen(false)}
        loggedMeals={loggedMeals}
        nutritionTarget={nutritionTarget}
        userProfile={userProfile}
        onAddMeal={onAddMeal}
        language={language}
      />

      {/* تنبيه لطيف عند محاولة ميزة تحتاج إنترنت */}
      {toastElement}
    </div>
  );
};
