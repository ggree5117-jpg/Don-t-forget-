import React, { useEffect, useState, useRef } from 'react';
import {
  Bell,
  CheckCircle2,
  Clock,
  Volume2,
  VolumeX,
  X,
  Sparkles,
  Timer,
  Music,
} from 'lucide-react';
import { TaskItem, Language } from '../types';
import { CATEGORY_STYLES } from '../utils/data';
import { CategoryIcon } from './CategoryIcon';
import {
  startRingtone,
  stopRingtone,
  playChimeSound,
  BUILT_IN_RINGTONES,
  DEFAULT_RINGTONE_ID,
} from '../utils/audio';
import { getCustomAudio } from '../utils/customAudioDb';
import confetti from 'canvas-confetti';

interface AlarmScreenModalProps {
  task: TaskItem | null;
  isOpen: boolean;
  defaultRingtoneId?: string;
  onDismiss: () => void;
  onComplete: (taskId: string) => void;
  onSnooze: (taskId: string, minutes: number) => void;
  language: Language;
}

export const AlarmScreenModal: React.FC<AlarmScreenModalProps> = ({
  task,
  isOpen,
  defaultRingtoneId = DEFAULT_RINGTONE_ID,
  onDismiss,
  onComplete,
  onSnooze,
  language,
}) => {
  const isAr = language === 'ar';
  const [currentTimeStr, setCurrentTimeStr] = useState<string>('');
  const [isMuted, setIsMuted] = useState(false);
  const [activeRingtoneLabel, setActiveRingtoneLabel] = useState<string>('');
  const activeBlobRef = useRef<Blob | null>(null);

  // Update digital clock every second
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTimeStr(
        now.toLocaleTimeString(isAr ? 'ar-EG' : 'en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [isAr]);

  // Load ringtone and start looping playback upon modal open
  useEffect(() => {
    let isCancelled = false;

    if (!isOpen || !task) {
      stopRingtone();
      activeBlobRef.current = null;
      return;
    }

    setIsMuted(false);
    const targetRingtoneId = task.ringtoneId || defaultRingtoneId || 'chime';

    // Find label for built-in or custom
    const builtIn = BUILT_IN_RINGTONES.find((r) => r.id === targetRingtoneId);
    if (builtIn) {
      setActiveRingtoneLabel(isAr ? builtIn.nameAr : builtIn.nameEn);
      startRingtone(targetRingtoneId).catch(() => {});
    } else if (targetRingtoneId.startsWith('custom-')) {
      // Fetch custom audio blob from IndexedDB
      getCustomAudio(targetRingtoneId)
        .then((record) => {
          if (isCancelled) return;
          if (record && record.blob) {
            activeBlobRef.current = record.blob;
            setActiveRingtoneLabel(record.name || (isAr ? 'نغمة مخصصة' : 'Custom Ringtone'));
            startRingtone(targetRingtoneId, record.blob).catch(() => {
              startRingtone('chime').catch(() => {});
            });
          } else {
            // Fallback to default
            setActiveRingtoneLabel(isAr ? 'جرس هادئ (افتراضي)' : 'Calm Chime (Default)');
            startRingtone('chime').catch(() => {});
          }
        })
        .catch(() => {
          if (isCancelled) return;
          startRingtone('chime').catch(() => {});
        });
    } else {
      setActiveRingtoneLabel(isAr ? 'جرس هادئ' : 'Calm Chime');
      startRingtone('chime').catch(() => {});
    }

    return () => {
      isCancelled = true;
      stopRingtone();
    };
  }, [isOpen, task, defaultRingtoneId, isAr]);

  if (!isOpen || !task) return null;

  const catStyle = CATEGORY_STYLES[task.category] || CATEGORY_STYLES.other;

  const handleToggleMute = () => {
    if (isMuted) {
      const targetRingtoneId = task.ringtoneId || defaultRingtoneId || 'chime';
      startRingtone(targetRingtoneId, activeBlobRef.current).catch(() => {});
      setIsMuted(false);
    } else {
      stopRingtone();
      setIsMuted(true);
    }
  };

  const handleCompleteAction = () => {
    stopRingtone();
    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#3B6CB4', '#F3D58A', '#22C55E'],
      });
    } catch {}
    playChimeSound();
    onComplete(task.id);
  };

  const handleDismissAction = () => {
    stopRingtone();
    onDismiss();
  };

  const handleSnoozeAction = (minutes: number = 5) => {
    stopRingtone();
    playChimeSound();
    onSnooze(task.id, minutes);
  };

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-lg select-none p-4 animate-fadeIn"
      style={{
        background: 'radial-gradient(circle at 50% 30%, rgba(44, 82, 130, 0.45) 0%, rgba(10, 15, 29, 0.95) 100%)',
      }}
    >
      <div className="relative w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-slate-100/90 text-center flex flex-col justify-between overflow-hidden">
        {/* Ambient Top Glow */}
        <div
          className="absolute -top-24 left-1/2 -translate-x-1/2 w-48 h-48 rounded-full blur-2xl opacity-40 pointer-events-none"
          style={{ backgroundColor: '#3B6CB4' }}
        />

        {/* Top Header: Mute Audio Toggle & Close */}
        <div className="flex items-center justify-between relative z-10 mb-3">
          <button
            onClick={handleToggleMute}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
              isMuted
                ? 'bg-rose-50 text-rose-500 border border-rose-200'
                : 'bg-[#EBF2FA] text-[#3B6CB4] border border-[#3B6CB4]/20 animate-pulse'
            }`}
            title={isMuted ? (isAr ? 'تشغيل النغمة' : 'Unmute') : (isAr ? 'كتم النغمة' : 'Mute')}
          >
            {isMuted ? <VolumeX className="w-4.5 h-4.5" /> : <Volume2 className="w-4.5 h-4.5" />}
          </button>

          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EBF2FA] text-[#3B6CB4] text-xs font-bold border border-[#3B6CB4]/20 shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            <span>{isAr ? 'منبه تذكيري نشط' : 'Active Reminder Alarm'}</span>
          </div>

          <button
            onClick={handleDismissAction}
            className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition-colors cursor-pointer"
            aria-label={isAr ? 'إغلاق' : 'Close'}
          >
            <X className="w-4.5 h-4.5" />
          </button>
        </div>

        {/* Active Ringtone Chip */}
        {activeRingtoneLabel && (
          <div className="flex items-center justify-center gap-1.5 mb-2 text-[11px] font-semibold text-slate-400">
            <Music className="w-3.5 h-3.5 text-[#3B6CB4]" />
            <span>{isAr ? `النغمة: ${activeRingtoneLabel}` : `Ringtone: ${activeRingtoneLabel}`}</span>
          </div>
        )}

        {/* Animated Central Alarm Bell with Concentric Rings */}
        <div className="relative my-3 flex items-center justify-center">
          {/* Outer Pulsing Glow Rings */}
          <div className="absolute w-28 h-28 rounded-full bg-[#3B6CB4]/15 animate-ping" />
          <div className="absolute w-24 h-24 rounded-full bg-[#F3D58A]/25 animate-pulse" />

          {/* Central Bell Container */}
          <div
            className="relative w-20 h-20 rounded-3xl flex items-center justify-center text-white shadow-xl shadow-[#3B6CB4]/40"
            style={{ backgroundColor: '#3B6CB4' }}
          >
            <Bell className="w-10 h-10 stroke-[2.2] animate-bounce" />
            <Sparkles className="w-4 h-4 text-[#F3D58A] absolute -top-1 -right-1 animate-spin" />
          </div>
        </div>

        {/* Real-time Digital Clock */}
        <div className="mb-4">
          <span className="text-3xl font-black text-[#1E293B] tracking-tight font-mono block">
            {currentTimeStr}
          </span>
          <span className="text-xs text-slate-400 font-semibold mt-0.5 block">
            {task.time || (isAr ? 'حان الموعد المحدد' : 'Scheduled time reached')}
          </span>
        </div>

        {/* Task Details Card */}
        <div
          className="p-4 rounded-2xl border transition-all mb-5 text-right relative overflow-hidden"
          style={{
            backgroundColor: catStyle.bgTint,
            borderColor: catStyle.borderColor,
          }}
        >
          <div className="flex items-center justify-between mb-2">
            {/* Category tag */}
            <div className="flex items-center gap-1.5">
              <CategoryIcon category={task.category} size="sm" className="!bg-white !p-1 !border-0 !shadow-2xs" />
              <span className="text-xs font-bold" style={{ color: catStyle.iconColor }}>
                {isAr ? catStyle.titleAr : catStyle.titleEn}
              </span>
            </div>

            {/* Priority Pill */}
            {task.priority === 'high' && (
              <span className="px-2 py-0.5 rounded-md bg-[#F3D58A]/40 text-[#8C6D1F] border border-[#F3D58A]/70 text-[10px] font-bold">
                {isAr ? 'أولوية قصوى' : 'High Priority'}
              </span>
            )}
          </div>

          <h2 className="text-base font-bold text-[#1E293B] leading-snug line-clamp-2">
            {task.title}
          </h2>

          {task.description && (
            <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">
              {task.description}
            </p>
          )}
        </div>

        {/* Main Action Buttons */}
        <div className="space-y-2.5">
          {/* 1. Complete Task Button */}
          <button
            onClick={handleCompleteAction}
            className="w-full py-3.5 px-4 rounded-2xl text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 cursor-pointer"
            style={{
              backgroundColor: '#3B6CB4',
              boxShadow: '0 8px 24px -4px rgba(59, 108, 180, 0.45)',
            }}
          >
            <CheckCircle2 className="w-5 h-5 stroke-[2.3]" />
            <span>{isAr ? 'إكمال المهمة الآن' : 'Mark as Completed'}</span>
          </button>

          {/* Secondary Actions: Snooze 5 mins & Dismiss */}
          <div className="grid grid-cols-2 gap-2">
            {/* Snooze 5 Mins */}
            <button
              onClick={() => handleSnoozeAction(5)}
              className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Timer className="w-4 h-4 text-slate-500" />
              <span>{isAr ? 'غفوة 5 دقائق' : 'Snooze 5m'}</span>
            </button>

            {/* Dismiss Alarm */}
            <button
              onClick={handleDismissAction}
              className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4 text-slate-500" />
              <span>{isAr ? 'إيقاف المنبه' : 'Dismiss'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
