import React from 'react';
import { Home, CheckSquare, Settings, Plus, HeartPulse } from 'lucide-react';
import { MainTab, Language } from '../types';

interface BottomNavBarProps {
  currentTab: MainTab;
  onTabChange: (tab: MainTab) => void;
  onOpenAddTask: () => void;
  language: Language;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  currentTab,
  onTabChange,
  onOpenAddTask,
  language,
}) => {
  const isAr = language === 'ar';

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="sticky bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-100/90 shadow-[0_-6px_25px_rgba(59,108,180,0.06)] px-3 py-1.5"
    >
      <div className="flex items-center justify-around relative max-w-md mx-auto">
        {/* Tab 1: Home (الرئيسية) */}
        <button
          onClick={() => onTabChange('home')}
          className={`flex flex-col items-center justify-center py-1.5 px-3.5 rounded-2xl transition-all duration-200 min-h-[46px] cursor-pointer ${
            currentTab === 'home'
              ? 'text-[#2563EB] bg-[#EBF3FC] shadow-2xs font-bold scale-102'
              : 'text-slate-400 hover:text-slate-600 hover:bg-slate-50'
          }`}
          aria-label={isAr ? 'الرئيسية' : 'Home'}
        >
          <Home className="w-5 h-5 stroke-[2.3]" />
          <span className="text-[10px] font-semibold mt-0.5">
            {isAr ? 'الرئيسية' : 'Home'}
          </span>
        </button>

        {/* Tab 2: Tasks (المهام) */}
        <button
          onClick={() => onTabChange('tasks')}
          className={`flex flex-col items-center justify-center py-1.5 px-3.5 rounded-2xl transition-all duration-200 min-h-[46px] cursor-pointer ${
            currentTab === 'tasks'
              ? 'text-[#2563EB] bg-[#EBF3FC] shadow-2xs font-bold scale-102'
              : 'text-slate-400 hover:text-slate-600 hover:bg-slate-50'
          }`}
          aria-label={isAr ? 'المهام' : 'Tasks'}
        >
          <CheckSquare className="w-5 h-5 stroke-[2.3]" />
          <span className="text-[10px] font-semibold mt-0.5">
            {isAr ? 'المهام' : 'Tasks'}
          </span>
        </button>

        {/* Center Elevated Floating '+' Button with "إضافة مهمة" text underneath */}
        <div className="flex flex-col items-center justify-center px-1 -mt-5">
          <button
            onClick={onOpenAddTask}
            className="w-13 h-13 rounded-full text-white flex items-center justify-center transition-all duration-200 active:scale-95 hover:scale-105 cursor-pointer ring-4 ring-white"
            style={{
              backgroundColor: '#1E40AF',
              boxShadow: '0 8px 22px -2px rgba(30, 64, 175, 0.45), 0 2px 8px 0 rgba(30, 64, 175, 0.2)',
            }}
            aria-label={isAr ? 'إضافة مهمة جديدة' : 'Add new task'}
            title={isAr ? 'إضافة مهمة' : 'Add Task'}
          >
            <Plus className="w-6 h-6 stroke-[3]" />
          </button>
          <span className="text-[10px] font-bold text-slate-500 mt-1">
            {isAr ? 'إضافة مهمة' : 'Add Task'}
          </span>
        </div>

        {/* Tab 3: Health (الصحة) - Dedicated Health & AI Nutrition Tab replacing Reports */}
        <button
          onClick={() => onTabChange('health')}
          className={`flex flex-col items-center justify-center py-1.5 px-3.5 rounded-2xl transition-all duration-200 min-h-[46px] cursor-pointer ${
            currentTab === 'health'
              ? 'text-[#2563EB] bg-[#EBF3FC] shadow-2xs font-bold scale-102'
              : 'text-slate-400 hover:text-slate-600 hover:bg-slate-50'
          }`}
          aria-label={isAr ? 'الصحة' : 'Health'}
        >
          <HeartPulse className="w-5 h-5 stroke-[2.3]" />
          <span className="text-[10px] font-semibold mt-0.5">
            {isAr ? 'الصحة' : 'Health'}
          </span>
        </button>

        {/* Tab 4: Settings (الإعدادات) */}
        <button
          onClick={() => onTabChange('settings')}
          className={`flex flex-col items-center justify-center py-1.5 px-3.5 rounded-2xl transition-all duration-200 min-h-[46px] cursor-pointer ${
            currentTab === 'settings'
              ? 'text-[#2563EB] bg-[#EBF3FC] shadow-2xs font-bold scale-102'
              : 'text-slate-400 hover:text-slate-600 hover:bg-slate-50'
          }`}
          aria-label={isAr ? 'الإعدادات' : 'Settings'}
        >
          <Settings className="w-5 h-5 stroke-[2.3]" />
          <span className="text-[10px] font-semibold mt-0.5">
            {isAr ? 'الإعدادات' : 'Settings'}
          </span>
        </button>
      </div>
    </div>
  );
};
