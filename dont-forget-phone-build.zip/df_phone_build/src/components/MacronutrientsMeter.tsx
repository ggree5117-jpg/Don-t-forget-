import React from 'react';
import { Language } from '../types';

interface MacronutrientsMeterProps {
  protein: { consumed: number; target: number };
  carbs: { consumed: number; target: number };
  fats: { consumed: number; target: number };
  language: Language;
}

export const MacronutrientsMeter: React.FC<MacronutrientsMeterProps> = ({
  protein,
  carbs,
  fats,
  language,
}) => {
  const isAr = language === 'ar';

  const macros = [
    {
      key: 'protein',
      nameAr: 'البروتين',
      nameEn: 'Protein',
      consumed: protein.consumed,
      target: protein.target,
      color: '#3498DB',       // Vibrant Blue
      bgTint: '#EAF5FF',      // Soft pastel light blue
      borderColor: 'rgba(52, 152, 219, 0.25)',
      unitAr: 'غرام',
      unitEn: 'g',
    },
    {
      key: 'carbs',
      nameAr: 'الكربوهيدرات',
      nameEn: 'Carbs',
      consumed: carbs.consumed,
      target: carbs.target,
      color: '#E5A83B',       // Soft Champagne/Amber Gold
      bgTint: '#FFF9E8',      // Soft pastel warm cream
      borderColor: 'rgba(229, 168, 59, 0.25)',
      unitAr: 'غرام',
      unitEn: 'g',
    },
    {
      key: 'fats',
      nameAr: 'الدهون الصحية',
      nameEn: 'Fats',
      consumed: fats.consumed,
      target: fats.target,
      color: '#E47B83',       // Soft Coral/Pink
      bgTint: '#FCE9E7',      // Soft pastel coral tint
      borderColor: 'rgba(228, 123, 131, 0.25)',
      unitAr: 'غرام',
      unitEn: 'g',
    },
  ];

  return (
    <div className="space-y-3.5">
      {macros.map((m) => {
        const hasTarget = m.target > 0;
        const percentage = hasTarget ? Math.min(100, Math.round((m.consumed / m.target) * 100)) : 0;
        const remaining = hasTarget ? Math.max(0, m.target - m.consumed) : 0;

        return (
          <div
            key={m.key}
            className="p-3.5 rounded-2xl border transition-all duration-200"
            style={{
              backgroundColor: m.bgTint,
              borderColor: m.borderColor,
            }}
          >
            {/* Header: Label, Consumed vs Target, and Percentage */}
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: m.color }}
                />
                <span className="text-xs font-bold text-[#354052]">
                  {isAr ? m.nameAr : m.nameEn}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-extrabold text-[#354052]">
                  {m.consumed}
                  <span className="text-[10px] text-slate-400 font-medium">
                    /{hasTarget ? m.target : '—'} {isAr ? m.unitAr : m.unitEn}
                  </span>
                </span>
                {hasTarget && (
                  <span
                    className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-white shadow-2xs"
                    style={{ color: m.color }}
                  >
                    {percentage}%
                  </span>
                )}
              </div>
            </div>

            {/* Linear Progress Bar */}
            <div className="w-full h-2.5 bg-white/80 rounded-full overflow-hidden p-0.5 shadow-inner">
              <div
                className="h-full rounded-full transition-all duration-700 ease-out"
                style={{
                  width: `${percentage}%`,
                  backgroundColor: m.color,
                }}
              />
            </div>

            {/* Bottom Footer Info */}
            <div className="flex items-center justify-between mt-1.5 text-[10px] font-medium text-slate-400">
              <span>
                {hasTarget
                  ? isAr
                    ? `متبقي ${remaining} ${m.unitAr}`
                    : `${remaining} ${m.unitEn} remaining`
                  : isAr
                  ? 'الهدف غير محدد'
                  : 'Target not set'}
              </span>
              {hasTarget && (
                <span>
                  {percentage >= 100
                    ? isAr
                      ? 'تم الوصول للهدف ✓'
                      : 'Target reached ✓'
                    : isAr
                    ? 'ضمن الخطة'
                    : 'On track'}
                </span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};
