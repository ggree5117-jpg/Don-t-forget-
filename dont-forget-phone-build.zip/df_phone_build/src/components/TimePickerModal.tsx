import React, { useState } from 'react';
import { Clock, X, Check } from 'lucide-react';
import { Language } from '../types';
import { playChimeSound } from '../utils/audio';

interface TimePickerModalProps {
  isOpen: boolean;
  initialTime: string;
  onClose: () => void;
  onConfirm: (formattedTime: string) => void;
  language: Language;
}

export const TimePickerModal: React.FC<TimePickerModalProps> = ({
  isOpen,
  initialTime,
  onClose,
  onConfirm,
  language,
}) => {
  const isAr = language === 'ar';

  // Parse initial time string, e.g. "09:00 ص" or "08:30 PM" or "04:30 م"
  const parseInitialTime = () => {
    try {
      const parts = initialTime.trim().split(' ');
      const timePart = parts[0] || '09:00';
      const periodPart = parts[1] || (isAr ? 'ص' : 'AM');

      const [hStr, mStr] = timePart.split(':');
      let hour = parseInt(hStr, 10) || 9;
      let minute = parseInt(mStr, 10) || 0;
      let period = periodPart.includes('م') || periodPart.toUpperCase().includes('PM') ? 'PM' : 'AM';

      return { hour, minute, period };
    } catch {
      return { hour: 9, minute: 0, period: 'AM' };
    }
  };

  const initial = parseInitialTime();
  const [selectedHour, setSelectedHour] = useState<number>(initial.hour);
  const [selectedMinute, setSelectedMinute] = useState<number>(initial.minute);
  const [selectedPeriod, setSelectedPeriod] = useState<string>(initial.period);

  if (!isOpen) return null;

  const hoursList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
  const minutesList = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55];

  const quickPresets = [
    { labelAr: 'الصباح الباكر (07:00 ص)', labelEn: 'Early Morning (07:00 AM)', h: 7, m: 0, p: 'AM' },
    { labelAr: 'بداية العمل (09:00 ص)', labelEn: 'Work Start (09:00 AM)', h: 9, m: 0, p: 'AM' },
    { labelAr: 'منتصف النهار (12:30 م)', labelEn: 'Midday (12:30 PM)', h: 12, m: 30, p: 'PM' },
    { labelAr: 'المساء (08:00 م)', labelEn: 'Evening (08:00 PM)', h: 8, m: 0, p: 'PM' },
  ];

  const handleHourChange = (h: number) => {
    setSelectedHour(h);
    playChimeSound();
  };

  const handleMinuteChange = (m: number) => {
    setSelectedMinute(m);
    playChimeSound();
  };

  const handlePeriodChange = (p: string) => {
    setSelectedPeriod(p);
    playChimeSound();
  };

  const handleConfirm = () => {
    playChimeSound();
    const hStr = selectedHour.toString().padStart(2, '0');
    const mStr = selectedMinute.toString().padStart(2, '0');
    const periodStr = isAr
      ? selectedPeriod === 'AM' ? 'ص' : 'م'
      : selectedPeriod;

    onConfirm(`${hStr}:${mStr} ${periodStr}`);
    onClose();
  };

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="fixed inset-0 z-60 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4 animate-in fade-in duration-150"
    >
      <div
        className="w-full max-w-sm bg-white rounded-2xl p-5 shadow-2xl border border-slate-100 animate-in zoom-in-95 duration-150"
        style={{
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#EBF2FA] text-[#3B6CB4] flex items-center justify-center">
              <Clock className="w-4.5 h-4.5 stroke-[2.2]" />
            </div>
            <h3 className="text-base font-bold text-[#354052]">
              {isAr ? 'تحديد الوقت' : 'Select Time'}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Display Banner with current time selection */}
        <div className="my-4 p-4 rounded-2xl bg-[#EBF2FA] border border-[#3B6CB4]/25 flex items-center justify-center gap-3">
          <span className="text-3xl font-extrabold text-[#354052] tracking-wider font-mono">
            {selectedHour.toString().padStart(2, '0')}:{selectedMinute.toString().padStart(2, '0')}
          </span>

          <div className="flex flex-col gap-1">
            <button
              type="button"
              onClick={() => handlePeriodChange('AM')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                selectedPeriod === 'AM'
                  ? 'bg-[#3B6CB4] text-white shadow-xs'
                  : 'bg-white/80 text-slate-500 hover:text-slate-800'
              }`}
            >
              {isAr ? 'صباحاً (ص)' : 'AM'}
            </button>
            <button
              type="button"
              onClick={() => handlePeriodChange('PM')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                selectedPeriod === 'PM'
                  ? 'bg-[#3B6CB4] text-white shadow-xs'
                  : 'bg-white/80 text-slate-500 hover:text-slate-800'
              }`}
            >
              {isAr ? 'مساءً (م)' : 'PM'}
            </button>
          </div>
        </div>

        {/* Hours Selector */}
        <div className="mb-3">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-bold text-[#354052]">
              {isAr ? 'الساعات' : 'Hour'}
            </span>
            <span className="text-[11px] text-slate-400 font-medium">
              (1 - 12)
            </span>
          </div>
          <div className="grid grid-cols-6 gap-1.5">
            {hoursList.map((h) => {
              const isSelected = selectedHour === h;
              return (
                <button
                  key={h}
                  type="button"
                  onClick={() => handleHourChange(h)}
                  className={`h-9 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#3B6CB4] text-white shadow-md shadow-[#3B6CB4]/30 scale-105'
                      : 'bg-slate-50 text-[#354052] hover:bg-slate-100 border border-slate-100'
                  }`}
                >
                  {h}
                </button>
              );
            })}
          </div>
        </div>

        {/* Minutes Selector */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-bold text-[#354052]">
              {isAr ? 'الدقائق' : 'Minute'}
            </span>
            <span className="text-[11px] text-slate-400 font-medium">
              (00 - 55)
            </span>
          </div>
          <div className="grid grid-cols-6 gap-1.5">
            {minutesList.map((m) => {
              const isSelected = selectedMinute === m;
              return (
                <button
                  key={m}
                  type="button"
                  onClick={() => handleMinuteChange(m)}
                  className={`h-9 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#3B6CB4] text-white shadow-md shadow-[#3B6CB4]/30 scale-105'
                      : 'bg-slate-50 text-[#354052] hover:bg-slate-100 border border-slate-100'
                  }`}
                >
                  {m.toString().padStart(2, '0')}
                </button>
              );
            })}
          </div>
        </div>

        {/* Quick Presets */}
        <div className="mb-4 pt-3 border-t border-slate-100">
          <span className="text-[11px] font-bold text-slate-400 block mb-2">
            {isAr ? 'أوقات سريعة مقترحة' : 'Quick Presets'}
          </span>
          <div className="grid grid-cols-2 gap-1.5">
            {quickPresets.map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setSelectedHour(preset.h);
                  setSelectedMinute(preset.m);
                  setSelectedPeriod(preset.p);
                  playChimeSound();
                }}
                className="py-1.5 px-2 rounded-xl text-[11px] font-medium text-slate-600 bg-slate-50 hover:bg-[#EBF2FA] hover:text-[#3B6CB4] border border-slate-100 transition-colors text-center cursor-pointer"
              >
                {isAr ? preset.labelAr : preset.labelEn}
              </button>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 h-11 rounded-2xl text-xs font-semibold text-slate-500 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            {isAr ? 'إلغاء' : 'Cancel'}
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            className="flex-1 h-11 rounded-2xl text-xs font-bold text-white bg-[#3B6CB4] hover:brightness-105 shadow-md shadow-[#3B6CB4]/35 flex items-center justify-center gap-1.5 transition-all active:scale-98 cursor-pointer"
          >
            <Check className="w-4 h-4 stroke-[2.5]" />
            <span>{isAr ? 'تأكيد الوقت' : 'Confirm Time'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
