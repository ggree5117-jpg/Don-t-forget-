import React, { useEffect } from 'react';
import { Language } from '../types';
import { ADS_CONFIG, PLACEHOLDER_CREATIVE } from '../utils/adsConfig';
import { isStartioAvailable, showBanner } from '../utils/startioBridge';

interface BannerAdProps {
  language: Language;
  slot?: 1 | 2;
  className?: string;
  /** يُستدعى بعد معرفة أن البانر الأصلي ظهر — لنحجز مساحته في التخطيط */
  onNativeHeight?: (px: number) => void;
}

/**
 * بانر سفلي — Start.io
 * ===================
 * ① داخل الأندرويد: يطلب بانراً أصلياً من Start.io ويعرضه أسفل الشاشة،
 *    ويُبلّغ الأب بالارتفاع (dp → px) لحجز المساحة فلا يغطي شريط التنقل.
 * ② في المتصفح: يعرض نفس المساحة بتصميم تجريبي مُعلَّم بكلمة «إعلان».
 */
export const BannerAd: React.FC<BannerAdProps> = ({
  language,
  slot = 1,
  className = '',
  onNativeHeight,
}) => {
  const isAr = language === 'ar';
  const [nativeShown, setNativeShown] = React.useState(false);

  useEffect(() => {
    if (!ADS_CONFIG.enabled) return;
    if (slot === 2 && ADS_CONFIG.banner.slots < 2) return;
    if (!isStartioAvailable()) return;

    let cancelled = false;

    showBanner(ADS_CONFIG.startio.bannerAdTag, ADS_CONFIG.banner.heightDp).then((shown) => {
      if (cancelled || !shown) return;
      setNativeShown(true);

      // تحويل dp إلى بكسل فعلي للجهاز
      const dpr = typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1;
      const cssPx = Math.round(ADS_CONFIG.banner.heightDp * Math.min(dpr, 3));
      onNativeHeight?.(cssPx);
    });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!ADS_CONFIG.enabled) return null;
  if (slot === 2 && ADS_CONFIG.banner.slots < 2) return null;

  // داخل الأندرويد: الإعلان الأصلي يرسم نفسه — لا نرسم شيئاً هنا
  if (nativeShown) return null;

  return (
    <div
      id={`banner-ad-slot-${slot}`}
      className={`relative w-full shrink-0 bg-[#EEF3F9] border-t border-slate-200/80 ${className}`}
      dir={isAr ? 'rtl' : 'ltr'}
      role="complementary"
      aria-label={isAr ? 'مساحة إعلانية' : 'Ad space'}
    >
      <span className="absolute top-0.5 start-1 z-10 px-1.5 py-[1px] rounded bg-black/35 text-white text-[8px] font-bold">
        {isAr ? 'إعلان' : 'AD'}
      </span>

      <div className="h-[54px] flex items-center justify-center gap-2 px-2">
        <div className="flex-1 h-[46px] rounded-lg bg-gradient-to-r from-[#DCE7F4] to-[#CBDCEF] border border-dashed border-[#9DB9D8] flex items-center justify-center gap-2">
          <span className="text-[10px] font-bold text-[#2C5282]/80">
            {isAr ? PLACEHOLDER_CREATIVE.titleAr : PLACEHOLDER_CREATIVE.titleEn}
          </span>
          <span className="text-[8.5px] text-[#2C5282]/50 font-mono truncate max-w-[120px]">
            Start.io · {slot === 2 ? 'banner-2' : 'banner-1'}
          </span>
        </div>
      </div>
    </div>
  );
};
