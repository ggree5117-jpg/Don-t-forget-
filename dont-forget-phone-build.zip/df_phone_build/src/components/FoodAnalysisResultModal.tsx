import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Flame,
  Sparkles,
  Check,
  AlertTriangle,
  Heart,
  Scale,
  Plus,
  Minus,
  Trash2,
  Edit3,
  RotateCcw,
  SlidersHorizontal,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { Language } from '../types';
import { FoodAnalysisResult, FoodIngredientItem, MealType } from '../types/health';
import confetti from 'canvas-confetti';
import { playChimeSound } from '../utils/audio';
import {
  calculateDishTotals,
  POPULAR_QUICK_ADD_ITEMS,
  NutritionReferenceItem,
} from '../utils/nutritionDatabase';

type PortionChoice = 'small' | 'medium' | 'large' | 'custom';

interface FoodAnalysisResultModalProps {
  isOpen: boolean;
  result: FoodAnalysisResult | null;
  onClose: () => void;
  onAddMeal: (mealData: {
    name: string;
    nameAr: string;
    calories: number;
    protein: number;
    carbs: number;
    fats: number;
    fiber?: number;
    mealType: MealType;
    portionSize?: string;
    portionSizeAr?: string;
    portionChoice?: PortionChoice;
    imageUrl?: string;
    healthTip?: string;
    healthTipAr?: string;
    healthInsightAr?: string;
    healthInsightEn?: string;
    confidence?: string;
    ingredients?: FoodIngredientItem[];
    totalWeightGrams?: number;
  }) => void;
  language: Language;
  targetCalories?: number;
}

export const FoodAnalysisResultModal: React.FC<FoodAnalysisResultModalProps> = ({
  isOpen,
  result,
  onClose,
  onAddMeal,
  language,
  targetCalories = 0,
}) => {
  const isAr = language === 'ar';
  const [selectedMealType, setSelectedMealType] = useState<MealType>('lunch');
  const [portionChoice, setPortionChoice] = useState<PortionChoice>('medium');
  const [isAdding, setIsAdding] = useState(false);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [customFoodName, setCustomFoodName] = useState('');
  const [customFoodNameAr, setCustomFoodNameAr] = useState('');
  const [showIngredientsPanel, setShowIngredientsPanel] = useState(true);
  const [showAddMenu, setShowAddMenu] = useState(false);

  // Editable ingredients list
  const [ingredients, setIngredients] = useState<FoodIngredientItem[]>([]);
  // Baseline copy to allow portion scaling or reset
  const [baselineIngredients, setBaselineIngredients] = useState<FoodIngredientItem[]>([]);

  // Synchronize when a new analysis result arrives
  useEffect(() => {
    if (!result) return;

    setCustomFoodName(result.foodName || 'Meal');
    setCustomFoodNameAr(result.foodNameAr || 'وجبة طعام');
    setIsEditingTitle(false);
    setPortionChoice('medium');

    let initialIngredients: FoodIngredientItem[] = [];

    if (result.ingredients && result.ingredients.length > 0) {
      initialIngredients = result.ingredients.map((item, idx) => ({
        id: item.id || `comp_${idx + 1}_${Date.now()}`,
        name: item.name,
        nameAr: item.nameAr,
        weightGrams: Math.max(5, Math.round(item.weightGrams || 100)),
        caloriesPer100g: item.caloriesPer100g,
        proteinPer100g: item.proteinPer100g,
        carbsPer100g: item.carbsPer100g,
        fatsPer100g: item.fatsPer100g,
        fiberPer100g: item.fiberPer100g || 0,
      }));
    } else {
      // Fallback single item matching overall dish
      const g = result.totalWeightGrams || 250;
      initialIngredients = [
        {
          id: `dish_base_${Date.now()}`,
          name: result.foodName || 'Main Dish',
          nameAr: result.foodNameAr || 'طبق رئيسي',
          weightGrams: g,
          caloriesPer100g: Math.round((result.calories / g) * 100),
          proteinPer100g: Math.round((result.protein / g) * 100 * 10) / 10,
          carbsPer100g: Math.round((result.carbs / g) * 100 * 10) / 10,
          fatsPer100g: Math.round((result.fats / g) * 100 * 10) / 10,
          fiberPer100g: result.fiber ? Math.round((result.fiber / g) * 100 * 10) / 10 : 1.5,
        },
      ];
    }

    setIngredients(initialIngredients);
    setBaselineIngredients(initialIngredients);
  }, [result]);

  // Strict Atwater & Component Formula Calculation:
  // Dynamically computes total Calories, Proteins, Carbs, Fats, and Fiber whenever ingredients change.
  const totals = useMemo(() => {
    return calculateDishTotals(ingredients);
  }, [ingredients]);

  if (!isOpen || !result) return null;

  // Handle portion preset scaling (Small 0.75x, Medium 1.0x, Large 1.35x)
  const applyPortionPreset = (choice: 'small' | 'medium' | 'large') => {
    setPortionChoice(choice);
    const multiplier = choice === 'small' ? 0.75 : choice === 'large' ? 1.35 : 1.0;

    const scaled = baselineIngredients.map((item) => ({
      ...item,
      weightGrams: Math.max(5, Math.round(item.weightGrams * multiplier)),
    }));

    setIngredients(scaled);
  };

  // Adjust ingredient weight in grams directly
  const handleUpdateWeight = (id: string, deltaGrams: number) => {
    setPortionChoice('custom');
    setIngredients((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newWeight = Math.max(5, item.weightGrams + deltaGrams);
          return { ...item, weightGrams: newWeight };
        }
        return item;
      })
    );
  };

  // Set explicit weight via input
  const handleSetExplicitWeight = (id: string, weight: number) => {
    setPortionChoice('custom');
    const safeGrams = Math.max(5, Math.min(2000, Math.round(weight) || 5));
    setIngredients((prev) =>
      prev.map((item) => (item.id === id ? { ...item, weightGrams: safeGrams } : item))
    );
  };

  // Remove an ingredient
  const handleRemoveIngredient = (id: string) => {
    setPortionChoice('custom');
    setIngredients((prev) => prev.filter((item) => item.id !== id));
  };

  // Add a standard preset ingredient from popular extras (e.g. Bread, Salad, Olive oil, Yogurt, etc.)
  const handleAddPresetItem = (preset: NutritionReferenceItem) => {
    setPortionChoice('custom');
    const newItem: FoodIngredientItem = {
      id: `added_${preset.id}_${Date.now()}`,
      name: preset.nameEn,
      nameAr: preset.nameAr,
      weightGrams: preset.typicalServingGrams,
      caloriesPer100g: preset.caloriesPer100g,
      proteinPer100g: preset.proteinPer100g,
      carbsPer100g: preset.carbsPer100g,
      fatsPer100g: preset.fatsPer100g,
      fiberPer100g: preset.fiberPer100g,
    };
    setIngredients((prev) => [...prev, newItem]);
    setShowAddMenu(false);
  };

  // Reset to original detected ingredients
  const handleResetToBaseline = () => {
    setPortionChoice('medium');
    setIngredients(baselineIngredients);
  };

  const mealTypes: { type: MealType; labelAr: string; labelEn: string }[] = [
    { type: 'breakfast', labelAr: 'فطور', labelEn: 'Breakfast' },
    { type: 'lunch', labelAr: 'غداء', labelEn: 'Lunch' },
    { type: 'dinner', labelAr: 'عشاء', labelEn: 'Dinner' },
    { type: 'snack', labelAr: 'سناك', labelEn: 'Snack' },
  ];

  const handleConfirmAdd = () => {
    setIsAdding(true);
    playChimeSound();

    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.75 },
      colors: ['#3B6CB4', '#62B5F6', '#F3D58A', '#3498DB'],
    });

    const portionDescAr =
      portionChoice === 'small'
        ? `حصة خفيفة (~${totals.totalWeightGrams} جم)`
        : portionChoice === 'large'
        ? `حصة مشبعة (~${totals.totalWeightGrams} جم)`
        : `حصة قياسية (~${totals.totalWeightGrams} جم)`;

    const portionDescEn =
      portionChoice === 'small'
        ? `Light portion (~${totals.totalWeightGrams}g)`
        : portionChoice === 'large'
        ? `Hearty portion (~${totals.totalWeightGrams}g)`
        : `Standard portion (~${totals.totalWeightGrams}g)`;

    onAddMeal({
      name: customFoodName.trim() || result.foodName,
      nameAr: customFoodNameAr.trim() || result.foodNameAr,
      calories: totals.calories,
      protein: totals.protein,
      carbs: totals.carbs,
      fats: totals.fats,
      fiber: totals.fiber,
      totalWeightGrams: totals.totalWeightGrams,
      mealType: selectedMealType,
      portionSize: portionDescEn,
      portionSizeAr: portionDescAr,
      portionChoice,
      imageUrl: result.imageUrl,
      healthTip: result.healthTip,
      healthTipAr: result.healthTipAr,
      healthInsightAr: result.healthTipAr || result.healthInsightAr,
      healthInsightEn: result.healthTip || result.healthInsightEn,
      confidence: result.confidence,
      ingredients: totals.ingredients,
    });

    setTimeout(() => {
      setIsAdding(false);
      onClose();
    }, 350);
  };

  const confidenceDisplay = result.confidence || (isAr ? 'مرتفع' : 'High');

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-sm p-4 select-none animate-fadeIn"
    >
      <div
        className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-slate-100"
        style={{ backgroundColor: '#FFFFFF' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 bg-white shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-[#EBF2FA] flex items-center justify-center text-[#3B6CB4]">
              <Sparkles className="w-4 h-4" />
            </span>
            <div className="flex flex-col">
              <h2 className="text-base font-bold text-[#354052]">
                {isAr ? 'التحليل الغذائي الدقيق' : 'Nutritional Analysis'}
              </h2>
              <span className="text-[10px] text-slate-400 font-medium">
                {isAr ? 'معادلة حسابية دقيقة مبنية على المكونات والأوزان' : 'Component-based formula calculation'}
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-[#354052] hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label={isAr ? 'إغلاق' : 'Close'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {/* Top: Captured Meal Image Card */}
          <div className="relative w-full h-40 rounded-2xl overflow-hidden shadow-xs border border-slate-100 bg-slate-100">
            {result.imageUrl ? (
              <img
                src={result.imageUrl}
                alt={result.foodName}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-slate-400 text-sm">
                {isAr ? 'صورة الوجبة الملتقطة' : 'Captured Meal'}
              </div>
            )}

            {/* Confidence Tag */}
            <div className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-full bg-black/65 backdrop-blur-md text-white text-[10px] font-bold flex items-center gap-1.5 shadow-sm">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>
                {isAr ? `دقة التقدير: ${confidenceDisplay}` : `Confidence: ${confidenceDisplay}`}
              </span>
            </div>

            {/* Total Weight Tag */}
            <div className="absolute bottom-2.5 right-2.5 px-2.5 py-1 rounded-full bg-black/65 backdrop-blur-md text-white text-[10px] font-bold flex items-center gap-1 shadow-sm">
              <Scale className="w-3 h-3 text-[#62B5F6]" />
              <span>
                {totals.totalWeightGrams} {isAr ? 'جم إجمالي' : 'g total'}
              </span>
            </div>
          </div>

          {/* Dish Title & Editable controls */}
          <div className="p-3.5 rounded-2xl bg-slate-50/80 border border-slate-200/60">
            {!isEditingTitle ? (
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-base font-extrabold text-[#354052] leading-snug">
                    {isAr ? customFoodNameAr || customFoodName : customFoodName}
                  </h3>
                  {customFoodName && customFoodName !== customFoodNameAr && (
                    <p className="text-xs text-slate-500 font-medium mt-0.5">
                      {isAr ? customFoodName : customFoodNameAr}
                    </p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => setIsEditingTitle(true)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-[#3B6CB4] hover:bg-white transition-all cursor-pointer"
                  title={isAr ? 'تعديل اسم الوجبة' : 'Edit meal name'}
                >
                  <Edit3 className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-500">
                    {isAr ? 'تعديل اسم الوجبة:' : 'Edit Meal Name:'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setIsEditingTitle(false)}
                    className="text-[11px] font-bold text-[#3B6CB4] hover:underline cursor-pointer"
                  >
                    {isAr ? 'تم' : 'Done'}
                  </button>
                </div>
                <input
                  type="text"
                  value={isAr ? customFoodNameAr : customFoodName}
                  onChange={(e) => {
                    if (isAr) {
                      setCustomFoodNameAr(e.target.value);
                    } else {
                      setCustomFoodName(e.target.value);
                    }
                  }}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-[#3B6CB4]/30"
                  placeholder={isAr ? 'اسم الوجبة بالعربية...' : 'Meal name in English...'}
                />
              </div>
            )}
          </div>

          {/* Calorie Estimation Card (Computed Strictly from Components Formula) */}
          <div
            className="p-4 rounded-2xl border flex items-center justify-between"
            style={{
              backgroundColor: '#EBF2FA',
              borderColor: 'rgba(59, 108, 180, 0.25)',
              boxShadow: '0 4px 16px -2px rgba(59, 108, 180, 0.12)',
            }}
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center text-[#3B6CB4] shadow-xs">
                <Flame className="w-6 h-6 fill-current animate-pulse text-[#3B6CB4]" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  {isAr ? 'السعرات المحسوبة بدقة من المكونات' : 'Calculated Formula Calories'}
                </span>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-black text-[#354052] tracking-tight">
                    {totals.calories.toLocaleString()}
                  </span>
                  <span className="text-xs font-bold text-slate-500">
                    {isAr ? 'سعرة حرارية (Kcal)' : 'Kcal'}
                  </span>
                </div>
              </div>
            </div>

            {targetCalories > 0 && (
              <div className="text-right">
                <span className="text-[10px] font-bold px-2 py-1 rounded-md bg-white text-[#3B6CB4] shadow-2xs border border-[#3B6CB4]/20">
                  {Math.round((totals.calories / targetCalories) * 100)}% {isAr ? 'من الهدف اليومي' : 'of daily target'}
                </span>
              </div>
            )}
          </div>

          {/* 4 Macronutrients Grid (Protein, Carbs, Fats, AND Fiber) */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-[#354052]">
                {isAr ? 'العناصر الغذائية المحسوبة (الماكروز والألياف):' : 'Macronutrients & Fiber Breakdown:'}
              </span>
              <span className="text-[10px] text-slate-400 font-medium">
                {totals.totalWeightGrams} {isAr ? 'جم إجمالي' : 'g total'}
              </span>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {/* Protein */}
              <div className="p-2.5 rounded-2xl bg-[#EAF5FF] border border-[#3498DB]/25 text-center">
                <span className="text-[10px] font-bold text-[#3498DB] block mb-0.5">
                  {isAr ? 'البروتين' : 'Protein'}
                </span>
                <span className="text-base font-black text-[#354052]">
                  {totals.protein}
                </span>
                <span className="text-[9px] text-slate-400 font-bold ml-0.5">
                  {isAr ? 'جم' : 'g'}
                </span>
              </div>

              {/* Carbs */}
              <div className="p-2.5 rounded-2xl bg-[#FFF9E8] border border-[#E5A83B]/25 text-center">
                <span className="text-[10px] font-bold text-[#D97706] block mb-0.5">
                  {isAr ? 'الكارب' : 'Carbs'}
                </span>
                <span className="text-base font-black text-[#354052]">
                  {totals.carbs}
                </span>
                <span className="text-[9px] text-slate-400 font-bold ml-0.5">
                  {isAr ? 'جم' : 'g'}
                </span>
              </div>

              {/* Fats */}
              <div className="p-2.5 rounded-2xl bg-[#FCE9E7] border border-[#E47B83]/25 text-center">
                <span className="text-[10px] font-bold text-[#E47B83] block mb-0.5">
                  {isAr ? 'الدهون' : 'Fats'}
                </span>
                <span className="text-base font-black text-[#354052]">
                  {totals.fats}
                </span>
                <span className="text-[9px] text-slate-400 font-bold ml-0.5">
                  {isAr ? 'جم' : 'g'}
                </span>
              </div>

              {/* Fiber (Explicit requirement) */}
              <div className="p-2.5 rounded-2xl bg-[#EAFBF3] border border-emerald-400/30 text-center">
                <span className="text-[10px] font-bold text-emerald-700 block mb-0.5">
                  {isAr ? 'الألياف' : 'Fiber'}
                </span>
                <span className="text-base font-black text-[#354052]">
                  {totals.fiber}
                </span>
                <span className="text-[9px] text-slate-400 font-bold ml-0.5">
                  {isAr ? 'جم' : 'g'}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Portion Presets */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/70">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5">
                <Scale className="w-3.5 h-3.5 text-[#3B6CB4]" />
                <span className="text-xs font-bold text-[#354052]">
                  {isAr ? 'الحجم العام للطبق:' : 'Overall Plate Portion:'}
                </span>
              </div>
              <span className="text-[10px] font-bold text-[#3B6CB4] bg-[#EBF2FA] px-2 py-0.5 rounded-full">
                {portionChoice === 'small'
                  ? isAr ? 'خفيفة (0.75x)' : 'Light (0.75x)'
                  : portionChoice === 'large'
                  ? isAr ? 'مشبعة (1.35x)' : 'Large (1.35x)'
                  : portionChoice === 'custom'
                  ? isAr ? 'مخصص ومعدل' : 'Custom Weights'
                  : isAr ? 'قياسية (1.0x)' : 'Standard (1.0x)'}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => applyPortionPreset('small')}
                className={`py-2 px-1 rounded-xl text-xs font-bold transition-all cursor-pointer flex flex-col items-center gap-0.5 ${
                  portionChoice === 'small'
                    ? 'bg-[#3B6CB4] text-white shadow-xs scale-102 ring-2 ring-[#3B6CB4]/30'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                <span>{isAr ? 'خفيفة' : 'Small'}</span>
                <span className="text-[9px] opacity-80">0.75x</span>
              </button>

              <button
                type="button"
                onClick={() => applyPortionPreset('medium')}
                className={`py-2 px-1 rounded-xl text-xs font-bold transition-all cursor-pointer flex flex-col items-center gap-0.5 ${
                  portionChoice === 'medium'
                    ? 'bg-[#3B6CB4] text-white shadow-xs scale-102 ring-2 ring-[#3B6CB4]/30'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                <span>{isAr ? 'قياسية' : 'Standard'}</span>
                <span className="text-[9px] opacity-80">1.0x</span>
              </button>

              <button
                type="button"
                onClick={() => applyPortionPreset('large')}
                className={`py-2 px-1 rounded-xl text-xs font-bold transition-all cursor-pointer flex flex-col items-center gap-0.5 ${
                  portionChoice === 'large'
                    ? 'bg-[#3B6CB4] text-white shadow-xs scale-102 ring-2 ring-[#3B6CB4]/30'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                <span>{isAr ? 'مشبعة' : 'Large'}</span>
                <span className="text-[9px] opacity-80">1.35x</span>
              </button>
            </div>
          </div>

          {/* USER CONTROL SECTION: Review, Edit, or Adjust Ingredient Portions Manually */}
          <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <button
                type="button"
                onClick={() => setShowIngredientsPanel(!showIngredientsPanel)}
                className="flex items-center gap-1.5 text-xs font-bold text-[#354052] hover:text-[#3B6CB4] transition-colors cursor-pointer"
              >
                <SlidersHorizontal className="w-3.5 h-3.5 text-[#3B6CB4]" />
                <span>
                  {isAr
                    ? `مكونات الطبق وأوزانها (${ingredients.length})`
                    : `Meal Components & Weights (${ingredients.length})`}
                </span>
                {showIngredientsPanel ? (
                  <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
                ) : (
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                )}
              </button>

              <div className="flex items-center gap-1.5">
                {portionChoice === 'custom' && (
                  <button
                    type="button"
                    onClick={handleResetToBaseline}
                    className="text-[10px] font-bold text-slate-400 hover:text-slate-600 flex items-center gap-0.5 cursor-pointer"
                    title={isAr ? 'إعادة ضبط المكونات للحالة الأصلية' : 'Reset to original detection'}
                  >
                    <RotateCcw className="w-2.5 h-2.5" />
                    <span>{isAr ? 'إعادة ضبط' : 'Reset'}</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setShowAddMenu(!showAddMenu)}
                  className="px-2 py-1 rounded-lg bg-[#EBF2FA] hover:bg-[#dbe9f8] text-[#3B6CB4] text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                >
                  <Plus className="w-3 h-3" />
                  <span>{isAr ? 'إضافة صنف' : 'Add Item'}</span>
                </button>
              </div>
            </div>

            {/* Quick Add Menu Dropdown */}
            {showAddMenu && (
              <div className="mb-3 p-2.5 rounded-xl bg-slate-50 border border-slate-200 animate-fadeIn">
                <span className="text-[10px] font-bold text-slate-500 block mb-1.5">
                  {isAr ? 'اختر صنفاً أو مقبلات إضافية لإضافتها:' : 'Select extra side or condiment to add:'}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {POPULAR_QUICK_ADD_ITEMS.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleAddPresetItem(item)}
                      className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-[#3B6CB4] hover:text-white hover:border-[#3B6CB4] text-[11px] font-semibold transition-all cursor-pointer flex items-center gap-1"
                    >
                      <Plus className="w-2.5 h-2.5" />
                      <span>{isAr ? item.nameAr : item.nameEn}</span>
                      <span className="text-[9px] opacity-70">({item.typicalServingGrams}g)</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* List of Ingredients */}
            {showIngredientsPanel && (
              <div className="space-y-2.5">
                {ingredients.map((ing) => {
                  const factor = ing.weightGrams / 100;
                  const itemCals = Math.round(ing.caloriesPer100g * factor);
                  const itemProt = Math.round(ing.proteinPer100g * factor * 10) / 10;
                  const itemCarbs = Math.round(ing.carbsPer100g * factor * 10) / 10;
                  const itemFats = Math.round(ing.fatsPer100g * factor * 10) / 10;

                  return (
                    <div
                      key={ing.id}
                      className="p-2.5 rounded-xl bg-slate-50/90 border border-slate-200/80 flex items-center justify-between gap-2 transition-all hover:border-slate-300"
                    >
                      {/* Name & Macro summary */}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-800 truncate">
                            {isAr ? ing.nameAr || ing.name : ing.name}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-medium flex items-center gap-1.5 mt-0.5">
                          <span className="font-bold text-[#3B6CB4]">{itemCals} {isAr ? 'سعرة' : 'kcal'}</span>
                          <span>•</span>
                          <span>P: {itemProt}g</span>
                          <span>•</span>
                          <span>C: {itemCarbs}g</span>
                          <span>•</span>
                          <span>F: {itemFats}g</span>
                        </div>
                      </div>

                      {/* Weight Controller: [-] input [+] & Delete */}
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleUpdateWeight(ing.id, -20)}
                          disabled={ing.weightGrams <= 10}
                          className="w-7 h-7 rounded-lg bg-white hover:bg-slate-200 border border-slate-200 flex items-center justify-center text-slate-600 disabled:opacity-30 cursor-pointer active:scale-95 transition-all"
                          title="-20g"
                        >
                          <Minus className="w-3 h-3" />
                        </button>

                        <div className="flex items-center bg-white border border-slate-200 rounded-lg px-1 py-0.5">
                          <input
                            type="number"
                            min="5"
                            max="1500"
                            step="5"
                            value={ing.weightGrams}
                            onChange={(e) => handleSetExplicitWeight(ing.id, Number(e.target.value))}
                            className="w-10 text-center text-xs font-black text-slate-800 bg-transparent focus:outline-none"
                          />
                          <span className="text-[9px] font-bold text-slate-400">
                            {isAr ? 'جم' : 'g'}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleUpdateWeight(ing.id, 20)}
                          className="w-7 h-7 rounded-lg bg-white hover:bg-slate-200 border border-slate-200 flex items-center justify-center text-slate-600 cursor-pointer active:scale-95 transition-all"
                          title="+20g"
                        >
                          <Plus className="w-3 h-3" />
                        </button>

                        {/* Remove Ingredient button (only if more than 1 item) */}
                        {ingredients.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveIngredient(ing.id)}
                            className="w-7 h-7 rounded-lg hover:bg-rose-50 text-slate-300 hover:text-rose-500 flex items-center justify-center transition-colors cursor-pointer ml-0.5"
                            title={isAr ? 'حذف هذا المكون' : 'Remove component'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Meal Type Selector */}
          <div>
            <span className="text-xs font-bold text-[#354052] mb-2 block">
              {isAr ? 'تسجيل الوجبة كـ:' : 'Log meal as:'}
            </span>
            <div className="grid grid-cols-4 gap-2">
              {mealTypes.map((m) => {
                const isSelected = selectedMealType === m.type;
                return (
                  <button
                    key={m.type}
                    type="button"
                    onClick={() => setSelectedMealType(m.type)}
                    className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#3B6CB4] text-white shadow-xs scale-102'
                        : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-100'
                    }`}
                  >
                    {isAr ? m.labelAr : m.labelEn}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Short Health Tip from Gemini */}
          {(result.healthTipAr || result.healthTip || result.healthInsightAr || result.healthInsightEn) && (
            <div className="p-3.5 rounded-2xl bg-emerald-50/80 border border-emerald-200/80 flex items-start gap-2.5">
              <Heart className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div className="text-xs text-emerald-950 leading-relaxed font-medium">
                <span className="font-bold block mb-0.5 text-emerald-800">
                  {isAr ? 'نصيحة غذائية ذكية:' : 'Smart Nutrition Tip:'}
                </span>
                {isAr
                  ? result.healthTipAr || result.healthTip || result.healthInsightAr
                  : result.healthTip || result.healthTipAr || result.healthInsightEn}
              </div>
            </div>
          )}
        </div>

        {/* Footer Action Button: Confirm & Log Meal with calculated values */}
        <div className="px-5 py-4 border-t border-slate-100 bg-white shrink-0">
          <button
            onClick={handleConfirmAdd}
            disabled={isAdding}
            className="w-full py-3.5 rounded-2xl text-white font-bold text-sm flex items-center justify-center gap-2 transition-all duration-200 cursor-pointer active:scale-98 shadow-md"
            style={{
              backgroundColor: '#3B6CB4',
              boxShadow: '0 8px 24px -2px rgba(59, 108, 180, 0.45)',
            }}
          >
            {isAdding ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>{isAr ? 'جارٍ الحفظ والخصم...' : 'Saving meal...'}</span>
              </span>
            ) : (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>
                  {isAr
                    ? `إضافة الوجبة (${totals.calories} سعرة) بدقة`
                    : `Add Meal (${totals.calories} Kcal) Accurately`}
                </span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
