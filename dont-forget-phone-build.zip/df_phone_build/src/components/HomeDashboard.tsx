import React, { useState, useEffect } from 'react';
import {
  Bell,
  User,
  Star,
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Utensils,
  Dumbbell,
  Activity,
  Smile,
  Brain,
  CheckCircle2,
  Check,
  Clock,
  Search,
  X,
  ClipboardList,
  Trophy,
  Rocket,
  Compass,
  Zap,
  AlertTriangle,
  Target,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  ShoppingBag,
  BookOpen,
  Droplets,
  Plus,
} from 'lucide-react';
import { TaskItem, CategoryType, Language } from '../types';
import { CategoryIcon } from './CategoryIcon';
import { CATEGORY_STYLES, PRIORITY_STYLES } from '../utils/data';
import { getMotivationState, MotivationStateConfig } from '../utils/motivation';
import { playChimeSound } from '../utils/audio';
import { parseTaskDueDate } from '../utils/reminders';

interface HomeDashboardProps {
  tasks: TaskItem[];
  onToggleTask: (id: string) => void;
  onAddTask?: (taskData: Omit<TaskItem, 'id' | 'completed'>) => void;
  onOpenSettings: () => void;
  onSelectCategory: (cat: CategoryType) => void;
  onViewAllCategories: () => void;
  onOpenHealthDashboard?: () => void;
  language: Language;
}

/**
 * Motivation Visual: Checks if a custom image exists in public/images/motivation/.
 * If not, falls back seamlessly to the clean Lucide icon with matching theme styling.
 */
const MotivationVisual: React.FC<{ state: MotivationStateConfig; isAr: boolean }> = ({ state, isAr }) => {
  const [hasCustomImage, setHasCustomImage] = useState<boolean | null>(null);

  useEffect(() => {
    let active = true;
    const testImg = new Image();
    testImg.src = state.imagePathWebp;
    testImg.onload = () => {
      if (active) setHasCustomImage(true);
    };
    testImg.onerror = () => {
      const fallbackImg = new Image();
      fallbackImg.src = state.imagePathPng;
      fallbackImg.onload = () => {
        if (active) setHasCustomImage(true);
      };
      fallbackImg.onerror = () => {
        if (active) setHasCustomImage(false);
      };
    };

    return () => {
      active = false;
    };
  }, [state.key, state.imagePathWebp, state.imagePathPng]);

  const renderIcon = () => {
    switch (state.iconName) {
      case 'trophy':
        return <Trophy className="w-7 h-7 stroke-[2.2]" />;
      case 'rocket':
        return <Rocket className="w-7 h-7 stroke-[2.2]" />;
      case 'compass':
        return <Compass className="w-7 h-7 stroke-[2.2]" />;
      case 'zap':
        return <Zap className="w-7 h-7 stroke-[2.2] fill-current" />;
      case 'alert':
        return <AlertTriangle className="w-7 h-7 stroke-[2.4]" />;
      case 'clipboard':
      default:
        return <ClipboardList className="w-7 h-7 stroke-[2.2]" />;
    }
  };

  if (hasCustomImage) {
    return (
      <div className="shrink-0 flex items-center justify-center relative">
        <picture>
          <source srcSet={state.imagePathWebp} type="image/webp" />
          <img
            src={state.imagePathPng}
            alt={isAr ? state.titleAr : state.titleEn}
            className="w-16 h-16 object-contain drop-shadow-md transition-all duration-500"
          />
        </picture>
      </div>
    );
  }

  return (
    <div
      className={`w-13 h-13 rounded-2xl flex items-center justify-center transition-all duration-500 shrink-0 ${state.theme.iconContainerBg}`}
    >
      {renderIcon()}
    </div>
  );
};

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  tasks,
  onToggleTask,
  onAddTask,
  onOpenSettings,
  onSelectCategory,
  onViewAllCategories,
  onOpenHealthDashboard,
  language,
}) => {
  const isAr = language === 'ar';
  const [searchQuery, setSearchQuery] = useState('');

  // Quick Action Feedback State
  const [recentlyAddedAction, setRecentlyAddedAction] = useState<string | null>(null);

  // Focus Mode State & Timer
  const [isFocusMode, setIsFocusMode] = useState(false);
  const [focusDurationMinutes, setFocusDurationMinutes] = useState(25);
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  // Countdown Timer effect for Focus Mode
  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | null = null;
    if (isFocusMode && isTimerRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            setIsTimerRunning(false);
            playChimeSound();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isFocusMode, isTimerRunning, timeLeft]);

  const handleResetTimer = () => {
    setIsTimerRunning(false);
    setTimeLeft(focusDurationMinutes * 60);
  };

  const handleSelectPreset = (mins: number) => {
    setFocusDurationMinutes(mins);
    setTimeLeft(mins * 60);
    setIsTimerRunning(true);
  };

  const formatMinutesSeconds = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const pendingCount = tasks.filter((t) => !t.completed).length;
  const completedCount = tasks.filter((t) => t.completed).length;
  const totalCount = tasks.length;

  // Motivation state dynamically determined from real tasks count & percentage
  const { state: motivationState, percentage: completionPercentage } = getMotivationState(
    totalCount,
    completedCount
  );

  // Real today and upcoming counts calculated exclusively from user's actual tasks
  const todayStr = new Date().toISOString().split('T')[0];
  const todayTasksCount = tasks.filter((t) => t.date === todayStr && !t.completed).length;
  const upcomingTasksCount = pendingCount;

  // Real earliest pending tasks if available
  const upcomingTasks = tasks.filter((t) => !t.completed).slice(0, 3);

  // Focus Mode Task Selection: "المهمة ذات الأولوية القصوى والموعد الأقرب"
  const pendingTasks = tasks.filter((t) => !t.completed);
  const priorityWeight = (p?: string): number => {
    if (p === 'high') return 3;
    if (p === 'medium') return 2;
    return 1;
  };
  const getDueDateMs = (t: TaskItem): number => {
    const parsed = parseTaskDueDate(t);
    return parsed ? parsed.getTime() : Number.MAX_SAFE_INTEGER;
  };

  const sortedByPriorityAndDate = [...pendingTasks].sort((a, b) => {
    const pDiff = priorityWeight(b.priority) - priorityWeight(a.priority);
    if (pDiff !== 0) return pDiff;
    return getDueDateMs(a) - getDueDateMs(b);
  });

  const focusTask = sortedByPriorityAndDate[0] || null;

  // Search filtering logic (filters by title or content/description)
  const isSearching = searchQuery.trim().length > 0;
  const displayTasks = isSearching
    ? tasks.filter((t) => {
        const q = searchQuery.toLowerCase().trim();
        const matchTitle = t.title.toLowerCase().includes(q);
        const matchDesc = Boolean(t.description && t.description.toLowerCase().includes(q));
        return matchTitle || matchDesc;
      })
    : upcomingTasks;

  // Quick Actions: one-tap tasks for instant addition without filling full form
  const QUICK_ACTION_TEMPLATES = [
    {
      id: 'grocery',
      titleEn: 'Grocery Shopping',
      titleAr: 'شراء البقالة والتموين',
      descEn: 'Pantry & Food',
      descAr: 'بقالة وتسوق',
      category: 'personal' as CategoryType,
      priority: 'medium' as const,
      icon: <ShoppingBag className="w-4 h-4 stroke-[2.2]" />,
      iconBg: 'bg-emerald-50 text-emerald-600',
      borderColor: 'border-emerald-100 hover:border-emerald-300',
      defaultMinutes: 90,
    },
    {
      id: 'workout',
      titleEn: 'Daily Workout',
      titleAr: 'تمرين رياضي يومي',
      descEn: 'Fitness & Health',
      descAr: 'لياقة وصحة',
      category: 'health' as CategoryType,
      priority: 'high' as const,
      icon: <Dumbbell className="w-4 h-4 stroke-[2.2]" />,
      iconBg: 'bg-rose-50 text-rose-600',
      borderColor: 'border-rose-100 hover:border-rose-300',
      defaultMinutes: 60,
    },
    {
      id: 'reading',
      titleEn: 'Read 10 mins',
      titleAr: 'قراءة 10 دقائق',
      descEn: 'Mind & Focus',
      descAr: 'تطوير وقراءة',
      category: 'mind' as CategoryType,
      priority: 'medium' as const,
      icon: <BookOpen className="w-4 h-4 stroke-[2.2]" />,
      iconBg: 'bg-purple-50 text-purple-600',
      borderColor: 'border-purple-100 hover:border-purple-300',
      defaultMinutes: 30,
    },
    {
      id: 'water',
      titleEn: 'Drink Water',
      titleAr: 'شرب كوب ماء',
      descEn: 'Healthy Habit',
      descAr: 'عادة صحية',
      category: 'habits' as CategoryType,
      priority: 'low' as const,
      icon: <Droplets className="w-4 h-4 stroke-[2.2]" />,
      iconBg: 'bg-blue-50 text-blue-600',
      borderColor: 'border-blue-100 hover:border-blue-300',
      defaultMinutes: 15,
    },
  ];

  const handleTriggerQuickAction = (template: typeof QUICK_ACTION_TEMPLATES[0]) => {
    if (!onAddTask) return;

    const now = new Date();
    const targetDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

    const futureTime = new Date(now.getTime() + (template.defaultMinutes || 60) * 60 * 1000);
    const hours = futureTime.getHours();
    const mins = futureTime.getMinutes();
    const period = hours >= 12 ? (isAr ? 'م' : 'PM') : (isAr ? 'ص' : 'AM');
    const displayHours = hours % 12 || 12;
    const formattedTime = `${String(displayHours).padStart(2, '0')}:${String(mins).padStart(2, '0')} ${period}`;

    onAddTask({
      title: isAr ? template.titleAr : template.titleEn,
      description: isAr ? `مهمة سريعة بنقرة واحدة: ${template.descAr}` : `One-tap quick task: ${template.descEn}`,
      category: template.category,
      date: targetDate,
      time: formattedTime,
      repeat: 'once',
      priority: template.priority,
    });

    playChimeSound();
    setRecentlyAddedAction(template.id);
    setTimeout(() => {
      setRecentlyAddedAction((curr) => (curr === template.id ? null : curr));
    }, 2200);
  };

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="flex-1 flex flex-col bg-[#F3F7FD] text-[#354052] px-5 py-3 overflow-y-auto select-none pb-24"
    >
      {/* 1. Top Section: Notification, App Title "لاتنسّ", and Profile Avatar */}
      <div className="flex items-center justify-between pt-1 pb-2">
        {/* Left: Notification Bell with Red Badge Dot */}
        <button
          className="relative min-h-[44px] min-w-[44px] rounded-full flex items-center justify-center text-[#1E3A8A] hover:bg-white/80 transition-colors cursor-pointer"
          aria-label={isAr ? 'الإشعارات' : 'Notifications'}
          title={isAr ? 'الإشعارات' : 'Notifications'}
        >
          <Bell className="w-6 h-6 stroke-[2.2]" />
          <span className="absolute top-2.5 right-2.5 w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-white" />
        </button>

        {/* Center: App Title & Subtitle */}
        <div className="flex flex-col items-center text-center">
          <h1 className="text-2xl font-black text-[#1E3A8A] tracking-tight leading-none">
            {isAr ? 'لاتنسّ' : "DON'T FORGET"}
          </h1>
          <span className="text-xs text-slate-500 font-semibold mt-1">
            {isAr ? 'خطوتك نحو حياة أفضل' : 'Your step towards a better life'}
          </span>
        </div>

        {/* Right: Profile Avatar Icon with Soft Blue Circle */}
        <button
          onClick={onOpenSettings}
          className="min-h-[44px] min-w-[44px] rounded-full bg-[#DCEBFB] flex items-center justify-center text-[#1E3A8A] hover:bg-[#c9e1fa] transition-colors cursor-pointer shadow-2xs"
          aria-label={isAr ? 'الملف الشخصي' : 'Profile'}
          title={isAr ? 'الملف الشخصي' : 'Profile'}
        >
          <User className="w-6 h-6 fill-current text-[#1E3A8A]" />
        </button>
      </div>

      {/* Search Bar & Focus Mode Toggle */}
      <div className="mt-1 flex items-center gap-2">
        <div className="relative flex-1 flex items-center">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isAr ? 'ابحث في المهام بالعنوان أو المحتوى...' : 'Search tasks by title or content...'}
            className="w-full h-11 px-4 ps-10 pe-10 bg-white border border-slate-200/90 rounded-2xl text-xs font-semibold text-[#1E293B] placeholder:text-slate-400 focus:outline-none focus:border-[#2563EB] focus:ring-2 focus:ring-[#2563EB]/15 transition-all shadow-2xs"
          />
          <div className="absolute inset-y-0 start-0 ps-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 end-0 pe-3 flex items-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
              aria-label={isAr ? 'مسح البحث' : 'Clear search'}
            >
              <div className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center">
                <X className="w-3 h-3" />
              </div>
            </button>
          )}
        </div>

        {/* Focus Mode Toggle Button */}
        <button
          onClick={() => {
            const next = !isFocusMode;
            setIsFocusMode(next);
            if (next && !isTimerRunning) {
              setIsTimerRunning(true);
            }
          }}
          className={`h-11 px-3.5 rounded-2xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shrink-0 border ${
            isFocusMode
              ? 'bg-[#1E3A8A] text-white border-[#1E3A8A] shadow-md shadow-blue-900/20 ring-2 ring-blue-400/40'
              : 'bg-white text-[#1E3A8A] border-slate-200/90 hover:bg-[#EBF3FC]'
          }`}
          title={isAr ? 'تفعيل وضع التركيز على أهم مهمة' : 'Toggle Focus Mode'}
        >
          <Target className={`w-4 h-4 ${isFocusMode ? 'text-amber-300 animate-pulse' : 'text-[#1E3A8A]'}`} />
          <span>{isAr ? 'التركيز' : 'Focus'}</span>
        </button>
      </div>

      {/* 2. Hero Motivation Card: Dynamic message, colors, and visual based on completion state */}
      <section className="mt-3">
        <div
          className={`p-4 rounded-3xl border transition-all duration-500 ease-out relative overflow-hidden flex items-center justify-between gap-3 ${motivationState.theme.cardBg} ${motivationState.theme.cardBorder}`}
          style={{
            boxShadow: motivationState.theme.cardShadow,
          }}
        >
          {/* Circular Completion Ring & Badge */}
          <div className="flex flex-col items-center shrink-0 z-10">
            <div className="relative w-20 h-20 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                {/* Background Ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke={motivationState.theme.ringTrackColor}
                  strokeWidth="8"
                  className="transition-colors duration-500"
                />
                {/* Progress Arc */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke={motivationState.theme.ringProgressColor}
                  strokeWidth="8"
                  strokeDasharray="238.76"
                  strokeDashoffset={238.76 * (1 - completionPercentage / 100)}
                  strokeLinecap="round"
                  className="transition-all duration-700 ease-out"
                />
              </svg>

              {/* Inner Percentage */}
              <div className="absolute inset-0 flex items-center justify-center">
                <span className={`text-xl font-black tracking-tight transition-colors duration-500 ${motivationState.theme.percentageColor}`}>
                  {completionPercentage}%
                </span>
              </div>
            </div>

            {/* Status Pill Badge */}
            <div className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold mt-1 transition-all duration-500 shadow-2xs ${motivationState.theme.badgeBg} ${motivationState.theme.badgeText}`}>
              <span>{isAr ? motivationState.badgeAr : motivationState.badgeEn}</span>
            </div>
          </div>

          {/* Heading and Subtitle */}
          <div className="flex-1 min-w-0 flex flex-col justify-center text-right z-10">
            <h2 className={`text-base font-black leading-snug transition-colors duration-500 ${motivationState.theme.titleColor}`}>
              {isAr ? motivationState.titleAr : motivationState.titleEn}
            </h2>
            <p className={`text-xs font-semibold mt-1 transition-colors duration-500 leading-relaxed ${motivationState.theme.descColor}`}>
              {isAr ? motivationState.descAr : motivationState.descEn}
            </p>
          </div>

          {/* Motivation Visual: Custom image from public/images/motivation/ or clean icon fallback */}
          <div className="z-10 shrink-0">
            <MotivationVisual state={motivationState} isAr={isAr} />
          </div>
        </div>
      </section>

      {/* 3. Two Quick Stat Cards Row: "مهام اليوم" and "مهام قادمة" */}
      <section className="grid grid-cols-2 gap-3.5 mt-3.5">
        {/* Right Card: مهام اليوم (Today's Tasks) */}
        <button
          onClick={onViewAllCategories}
          className="p-3.5 rounded-2xl bg-white border border-blue-50/80 transition-all flex items-center justify-between cursor-pointer active:scale-98 text-right hover:border-blue-100"
          style={{
            boxShadow: '0 6px 18px -4px rgba(37, 99, 235, 0.06), 0 2px 6px -2px rgba(0, 0, 0, 0.02)',
          }}
        >
          <div className="flex items-center gap-1 text-slate-400">
            {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </div>

          <div className="flex items-center gap-3">
            <div className="flex flex-col text-right">
              <span className="text-xl font-black text-[#1E293B] leading-none">
                {todayTasksCount}
              </span>
              <span className="text-xs font-bold text-slate-500 mt-1">
                {isAr ? 'مهام اليوم' : "Today's Tasks"}
              </span>
            </div>

            {/* Golden Star Icon in warm container */}
            <div className="w-10 h-10 rounded-2xl bg-[#FEF7EC] flex items-center justify-center text-[#F59E0B] shadow-2xs">
              <Star className="w-5 h-5 fill-[#F59E0B] text-[#F59E0B]" />
            </div>
          </div>
        </button>

        {/* Left Card: مهام قادمة (Upcoming Tasks) */}
        <button
          onClick={onViewAllCategories}
          className="p-3.5 rounded-2xl bg-white border border-blue-50/80 transition-all flex items-center justify-between cursor-pointer active:scale-98 text-right hover:border-blue-100"
          style={{
            boxShadow: '0 6px 18px -4px rgba(37, 99, 235, 0.06), 0 2px 6px -2px rgba(0, 0, 0, 0.02)',
          }}
        >
          <div className="flex items-center gap-1 text-slate-400">
            {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </div>

          <div className="flex items-center gap-3">
            <div className="flex flex-col text-right">
              <span className="text-xl font-black text-[#1E293B] leading-none">
                {upcomingTasksCount}
              </span>
              <span className="text-xs font-bold text-slate-500 mt-1">
                {isAr ? 'مهام قادمة' : 'Upcoming'}
              </span>
            </div>

            {/* Blue Calendar Icon in soft container */}
            <div className="w-10 h-10 rounded-2xl bg-[#EBF3FC] flex items-center justify-center text-[#2563EB] shadow-2xs">
              <CalendarIcon className="w-5 h-5 stroke-[2.3]" />
            </div>
          </div>
        </button>
      </section>

      {/* Quick Actions: One-tap instant task addition without filling full form */}
      <section className="mt-4">
        <div className="flex items-center justify-between mb-2.5 px-0.5">
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-bold text-[#2563EB] bg-[#EBF3FC] px-2 py-0.5 rounded-full">
              {isAr ? 'بنقرة واحدة' : '1-Tap'}
            </span>
            {recentlyAddedAction && (
              <span className="text-[11px] font-bold text-emerald-600 flex items-center gap-1 animate-fadeIn">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>{isAr ? 'تمت إضافة المهمة بنجاح!' : 'Task added instantly!'}</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5">
            <h3 className="text-sm font-black text-[#1E293B]">
              {isAr ? 'إجراءات سريعة' : 'Quick Actions'}
            </h3>
            <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          </div>
        </div>

        {/* 4 One-tap Quick Action buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {QUICK_ACTION_TEMPLATES.map((action) => {
            const isJustAdded = recentlyAddedAction === action.id;
            return (
              <button
                key={action.id}
                type="button"
                onClick={() => handleTriggerQuickAction(action)}
                className={`p-3 rounded-2xl bg-white border transition-all duration-200 flex flex-col justify-between cursor-pointer active:scale-95 text-right relative overflow-hidden group shadow-2xs hover:shadow-xs ${
                  isJustAdded
                    ? 'border-emerald-400 bg-emerald-50/50 ring-2 ring-emerald-300/40'
                    : action.borderColor
                }`}
                title={isAr ? `إضافة سريعة: ${action.titleAr}` : `Instant add: ${action.titleEn}`}
              >
                {/* Top: Category Icon + (+) Plus / Check icon */}
                <div className="flex items-center justify-between w-full mb-2">
                  <div
                    className={`w-7 h-7 rounded-xl ${action.iconBg} flex items-center justify-center transition-transform group-hover:scale-105`}
                  >
                    {action.icon}
                  </div>
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                      isJustAdded
                        ? 'bg-emerald-500 text-white scale-110 shadow-xs'
                        : 'bg-slate-100 text-slate-500 group-hover:bg-[#2563EB] group-hover:text-white'
                    }`}
                  >
                    {isJustAdded ? (
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    ) : (
                      <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                    )}
                  </div>
                </div>

                {/* Bottom: Title & Subtitle */}
                <div className="w-full text-right">
                  <span className="text-xs font-bold text-[#1E293B] block leading-snug group-hover:text-[#2563EB] transition-colors truncate">
                    {isAr ? action.titleAr : action.titleEn}
                  </span>
                  <span className="text-[10px] font-semibold text-slate-400 mt-0.5 block truncate">
                    {isJustAdded
                      ? isAr
                        ? '✓ تمت الإضافة'
                        : '✓ Added'
                      : isAr
                      ? action.descAr
                      : action.descEn}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* 4. Section: «أقرب التذكيرات والمهام» (or Focus Mode / Search Results) */}
      <section className="mt-5">
        <div className="flex items-center justify-between mb-2.5 px-0.5">
          {/* Left Action Button */}
          {isFocusMode ? (
            <button
              onClick={() => setIsFocusMode(false)}
              className="text-xs font-bold text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200/80 px-3 py-1 rounded-full transition-all cursor-pointer flex items-center gap-1 shadow-2xs"
            >
              <span>{isAr ? 'إلغاء التركيز' : 'Exit Focus'}</span>
              <X className="w-3.5 h-3.5" />
            </button>
          ) : isSearching ? (
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs font-bold text-slate-500 bg-slate-100 hover:bg-slate-200 px-3 py-1 rounded-full transition-all cursor-pointer flex items-center gap-1 shadow-2xs"
            >
              <span>{isAr ? 'إلغاء البحث' : 'Clear search'}</span>
              <X className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={onViewAllCategories}
              className="text-xs font-bold text-[#2563EB] bg-[#EBF3FC] hover:bg-[#DCEBFB] px-3.5 py-1 rounded-full transition-all cursor-pointer flex items-center gap-1 shadow-2xs"
            >
              <span>{isAr ? 'عرض الكل' : 'View All'}</span>
              {isAr ? <ChevronLeft className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
          )}

          {/* Right Header */}
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-black text-[#1E293B]">
              {isFocusMode
                ? isAr
                  ? 'وضع التركيز (المهمة الأهم)'
                  : 'Focus Mode (Top Priority)'
                : isSearching
                ? isAr
                  ? `نتائج البحث (${displayTasks.length})`
                  : `Search Results (${displayTasks.length})`
                : isAr
                ? 'أقرب المهام والتذكيرات'
                : 'Upcoming Tasks & Reminders'}
            </h3>
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                isFocusMode ? 'bg-[#1E3A8A] animate-ping' : 'bg-[#EAB308]'
              }`}
            />
          </div>
        </div>

        {/* When Focus Mode is Active: All other tasks are hidden, only top priority & nearest task is displayed */}
        {isFocusMode ? (
          focusTask ? (
            <div className="space-y-3">
              {/* Focus Task Card with countdown timer */}
              <div
                className="p-4 rounded-3xl bg-white border border-slate-200/90 transition-all relative overflow-hidden"
                style={{
                  borderInlineStart: `5px solid ${PRIORITY_STYLES[focusTask.priority || 'medium'].accentBorderColor}`,
                  boxShadow: '0 12px 28px -4px rgba(30, 58, 138, 0.12), 0 2px 8px -2px rgba(0, 0, 0, 0.04)',
                }}
              >
                {/* Header: Focus Task Badge */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-xl bg-blue-50 text-[#1E3A8A] flex items-center justify-center">
                      <Target className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-black text-[#1E3A8A]">
                      {isAr ? 'المهمة ذات الأولوية القصوى والموعد الأقرب' : 'Top Priority & Nearest Task'}
                    </span>
                  </div>

                  {/* Priority Chip */}
                  {(() => {
                    const pStyle = PRIORITY_STYLES[focusTask.priority || 'medium'];
                    return (
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-md border flex items-center gap-1 ${pStyle.badgeBg} ${pStyle.badgeText} ${pStyle.badgeBorder}`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: pStyle.dotColor }} />
                        <span>{isAr ? pStyle.labelAr : pStyle.labelEn}</span>
                      </span>
                    );
                  })()}
                </div>

                {/* Task Details */}
                <div className="py-3 flex items-start gap-3">
                  <CategoryIcon
                    category={focusTask.category}
                    iconOverride={focusTask.iconType}
                    size="md"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-base font-black text-[#1E293B] leading-snug">
                      {focusTask.title}
                    </h4>
                    {focusTask.description && (
                      <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                        {focusTask.description}
                      </p>
                    )}
                    <div className="flex items-center gap-2 mt-2 text-xs text-slate-400 font-medium">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>{focusTask.time || focusTask.date}</span>
                    </div>
                  </div>
                </div>

                {/* Countdown Timer Display */}
                <div className="mt-2 p-3.5 rounded-2xl bg-gradient-to-br from-[#F8FAFC] to-[#EFF6FF] border border-blue-100 flex flex-col items-center justify-center">
                  <div className="flex items-center justify-between w-full mb-2 px-1">
                    <span className="text-[11px] font-bold text-slate-500 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      <span>{isAr ? 'عداد جلسة التركيز' : 'Focus Session Timer'}</span>
                    </span>

                    {/* Presets */}
                    <div className="flex items-center gap-1">
                      {[15, 25, 45].map((mins) => (
                        <button
                          key={mins}
                          type="button"
                          onClick={() => handleSelectPreset(mins)}
                          className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                            focusDurationMinutes === mins
                              ? 'bg-[#1E3A8A] text-white shadow-2xs'
                              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          {mins} {isAr ? 'د' : 'm'}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Digital Clock Display */}
                  <div className="flex items-center gap-4 my-1">
                    <div className="text-3xl font-black font-mono tracking-wider text-[#1E3A8A]">
                      {formatMinutesSeconds(timeLeft)}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setIsTimerRunning(!isTimerRunning)}
                        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all cursor-pointer shadow-xs ${
                          isTimerRunning
                            ? 'bg-amber-500 text-white hover:bg-amber-600'
                            : 'bg-[#1E3A8A] text-white hover:bg-[#1E40AF]'
                        }`}
                        title={isTimerRunning ? (isAr ? 'إيقاف مؤقت' : 'Pause') : (isAr ? 'تشغيل' : 'Start')}
                      >
                        {isTimerRunning ? (
                          <Pause className="w-4 h-4 fill-current" />
                        ) : (
                          <Play className="w-4 h-4 fill-current ml-0.5" />
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={handleResetTimer}
                        className="w-9 h-9 rounded-xl bg-white border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-50 flex items-center justify-center transition-all cursor-pointer shadow-2xs"
                        title={isAr ? 'إعادة ضبط' : 'Reset'}
                      >
                        <RotateCcw className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {timeLeft === 0 && (
                    <p className="text-[11px] font-bold text-emerald-600 mt-1 animate-bounce">
                      {isAr ? '🎉 أحسنت! انتهت جلسة التركيز' : '🎉 Well done! Focus session completed'}
                    </p>
                  )}
                </div>

                {/* Mark Complete Action Button */}
                <button
                  type="button"
                  onClick={() => {
                    onToggleTask(focusTask.id);
                    playChimeSound();
                  }}
                  className="w-full mt-3 py-3 rounded-2xl bg-[#1E3A8A] hover:bg-[#1E40AF] text-white text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm active:scale-98"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>{isAr ? 'إنجاز هذه المهمة الآن' : 'Complete This Task Now'}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="p-8 rounded-3xl bg-white border border-slate-100 text-center shadow-xs">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center mb-3">
                <Trophy className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-[#1E293B]">
                {isAr ? 'رائع! لا توجد مهام معلقة للتركيز عليها' : 'Awesome! No pending tasks to focus on'}
              </h4>
              <p className="text-xs text-slate-400 mt-1 max-w-[240px] mx-auto">
                {isAr ? 'أتممت جميع مهامك بنجاح' : "You've completed all your tasks"}
              </p>
              <button
                type="button"
                onClick={() => setIsFocusMode(false)}
                className="mt-4 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer"
              >
                {isAr ? 'العودة للمهام العادية' : 'Back to normal view'}
              </button>
            </div>
          )
        ) : displayTasks.length > 0 ? (
          <div className="space-y-2.5">
            {displayTasks.map((task) => {
              const priorityStyle = PRIORITY_STYLES[task.priority || 'medium'];
              const catStyle = CATEGORY_STYLES[task.category] || CATEGORY_STYLES.other;

              return (
                <div
                  key={task.id}
                  onClick={() => onToggleTask(task.id)}
                  className="p-3 rounded-2xl bg-white border border-slate-100/90 transition-all duration-200 flex items-center justify-between cursor-pointer active:scale-99 hover:-translate-y-0.5 group"
                  style={{
                    borderInlineStart: `4px solid ${priorityStyle.accentBorderColor}`,
                    boxShadow: priorityStyle.glowShadow,
                  }}
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    {/* Category Icon */}
                    <CategoryIcon
                      category={task.category}
                      iconOverride={task.iconType}
                      size="md"
                    />

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-bold text-[#1E293B] truncate group-hover:text-[#2563EB] transition-colors">
                          {task.title}
                        </span>

                        {/* Color-coded Priority Badge (Red for high, Yellow for medium, Blue for low) */}
                        <span
                          className={`shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-md border flex items-center gap-1.5 shadow-2xs ${priorityStyle.badgeBg} ${priorityStyle.badgeText} ${priorityStyle.badgeBorder}`}
                          title={isAr ? priorityStyle.labelAr : priorityStyle.labelEn}
                        >
                          <span
                            className="w-1.5 h-1.5 rounded-full shrink-0"
                            style={{ backgroundColor: priorityStyle.dotColor }}
                          />
                          <span>{isAr ? priorityStyle.labelAr : priorityStyle.labelEn}</span>
                        </span>
                      </div>

                      {task.description && (
                        <p className="text-[11px] text-slate-500 truncate mt-0.5">
                          {task.description}
                        </p>
                      )}

                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
                          <Clock className="w-3 h-3 text-slate-400" />
                          <span>{task.time || task.date}</span>
                        </span>
                        <span className="text-slate-200 text-xs">·</span>
                        <span
                          className="text-[10px] font-bold px-2 py-0.5 rounded-md"
                          style={{
                            backgroundColor: catStyle.bgTint,
                            color: catStyle.iconColor,
                          }}
                        >
                          {isAr ? catStyle.titleAr : catStyle.titleEn}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Toggle Checkbox Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleTask(task.id);
                    }}
                    className={`w-6 h-6 rounded-full border-2 transition-all shrink-0 mr-1 cursor-pointer flex items-center justify-center ${
                      task.completed
                        ? 'bg-[#2563EB] border-[#2563EB] text-white'
                        : 'border-slate-300 hover:border-[#2563EB] bg-white'
                    }`}
                    title={
                      isAr
                        ? task.completed
                          ? 'مكتملة'
                          : 'تحديد كمنجزة'
                        : task.completed
                        ? 'Completed'
                        : 'Mark completed'
                    }
                  >
                    {task.completed && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </button>
                </div>
              );
            })}
          </div>
        ) : isSearching ? (
          <div className="p-6 rounded-2xl bg-white border border-slate-100 text-center">
            <Search className="w-6 h-6 text-slate-300 mx-auto mb-2" />
            <p className="text-xs font-bold text-[#354052]">
              {isAr ? `لا توجد نتائج مطابقة لـ "${searchQuery}"` : `No tasks matching "${searchQuery}"`}
            </p>
            <p className="text-[11px] text-slate-400 mt-1">
              {isAr ? 'جرّب البحث بعنوان آخر أو تفاصيل مختلفة' : 'Try searching with different terms'}
            </p>
          </div>
        ) : (
          <div
            onClick={onViewAllCategories}
            className="p-3.5 rounded-2xl bg-white border border-slate-100 transition-all flex items-center justify-between cursor-pointer text-slate-400 hover:bg-slate-50"
          >
            <div className="text-slate-400">
              {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </div>
            <div className="flex items-center gap-3">
              <div className="flex flex-col text-right">
                <span className="text-xs font-bold text-[#354052]">
                  {isAr ? 'لا توجد مهام أو تذكيرات قادمة' : 'No upcoming tasks or reminders'}
                </span>
                <span className="text-[11px] text-slate-400 mt-0.5">
                  {isAr ? 'اضغط + في الأسفل لإضافة مهمتك الأولى' : 'Tap + below to add your first task'}
                </span>
              </div>
              <div className="w-10 h-10 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-center text-slate-400 shadow-2xs">
                <Bell className="w-5 h-5 stroke-[2]" />
              </div>
            </div>
          </div>
        )}
      </section>

      {/* 5. Section: «أقسام التطبيق» (App Categories Grid) 2x2 Grid */}
      <section className="mt-5">
        <div className="flex items-center justify-end mb-2.5 px-0.5">
          <h3 className="text-sm font-black text-[#1E293B]">
            {isAr ? 'أقسام التطبيق' : 'App Categories'}
          </h3>
        </div>

        <div className="grid grid-cols-2 gap-3.5">
          {/* 1. Top-Right: العادات اليومية (Daily Habits) - Blue Dumbbell icon */}
          <button
            onClick={() => onSelectCategory('habits')}
            className="p-3.5 rounded-2xl bg-[#EBF3FC] border border-[#D4E5FA] transition-all flex items-center justify-between cursor-pointer active:scale-98 text-right hover:shadow-xs group"
          >
            <div className="flex flex-col text-right">
              <span className="text-xs font-black text-[#1E293B]">
                {isAr ? 'العادات اليومية' : 'Daily Habits'}
              </span>
              <span className="text-[11px] font-bold text-[#2563EB] mt-1">
                {tasks.filter((t) => t.category === 'habits').length} {isAr ? 'مهام' : 'tasks'}
              </span>
            </div>

            <div className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center text-[#2563EB] shadow-2xs">
              <Dumbbell className="w-5 h-5 stroke-[2.3]" />
            </div>
          </button>

          {/* 2. Top-Left: الصحة والرياضة (Health & Sports) - Green Sneaker/Activity icon */}
          <button
            onClick={onOpenHealthDashboard || (() => onSelectCategory('health'))}
            className="p-3.5 rounded-2xl bg-[#EBF9F1] border border-[#C8F0D9] transition-all flex items-center justify-between cursor-pointer active:scale-98 text-right hover:shadow-xs group"
          >
            <div className="flex flex-col text-right">
              <span className="text-xs font-black text-[#1E293B]">
                {isAr ? 'الصحة والرياضة' : 'Health & Sports'}
              </span>
              <span className="text-[11px] font-bold text-[#16A34A] mt-1">
                {tasks.filter((t) => t.category === 'health').length} {isAr ? 'مهام' : 'tasks'}
              </span>
            </div>

            <div className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center text-[#16A34A] shadow-2xs">
              <Activity className="w-5 h-5 stroke-[2.3]" />
            </div>
          </button>

          {/* 3. Bottom-Right: الشخصية وتطوير (Personal & Development) - Orange Smiley Face icon */}
          <button
            onClick={() => onSelectCategory('personal')}
            className="p-3.5 rounded-2xl bg-[#FEF4E8] border border-[#FDE2C6] transition-all flex items-center justify-between cursor-pointer active:scale-98 text-right hover:shadow-xs group"
          >
            <div className="flex flex-col text-right">
              <span className="text-xs font-black text-[#1E293B]">
                {isAr ? 'الشخصية وتطوير' : 'Personal & Growth'}
              </span>
              <span className="text-[11px] font-bold text-[#D97706] mt-1">
                {tasks.filter((t) => t.category === 'personal').length} {isAr ? 'مهام' : 'tasks'}
              </span>
            </div>

            <div className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center text-[#D97706] shadow-2xs">
              <Smile className="w-5 h-5 stroke-[2.3]" />
            </div>
          </button>

          {/* 4. Bottom-Left: العقل والإنتاجية (Mind & Productivity) - Purple Brain icon */}
          <button
            onClick={() => onSelectCategory('mind')}
            className="p-3.5 rounded-2xl bg-[#F3EEFD] border border-[#E3D8FB] transition-all flex items-center justify-between cursor-pointer active:scale-98 text-right hover:shadow-xs group"
          >
            <div className="flex flex-col text-right">
              <span className="text-xs font-black text-[#1E293B]">
                {isAr ? 'العقل والإنتاجية' : 'Mind & Focus'}
              </span>
              <span className="text-[11px] font-bold text-[#7C3AED] mt-1">
                {tasks.filter((t) => t.category === 'mind' || t.category === 'study').length} {isAr ? 'مهام' : 'tasks'}
              </span>
            </div>

            <div className="w-10 h-10 rounded-2xl bg-white flex items-center justify-center text-[#7C3AED] shadow-2xs">
              <Brain className="w-5 h-5 stroke-[2.3]" />
            </div>
          </button>
        </div>
      </section>
    </div>
  );
};
