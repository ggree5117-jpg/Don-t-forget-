import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Check, Plus, Clock, ChevronRight, ChevronLeft, Sparkles, FolderOpen, AlertCircle } from 'lucide-react';
import { TaskItem, CategoryType, Language } from '../types';
import { CATEGORY_STYLES } from '../utils/data';
import { isTaskOverdue } from '../utils/dateUtils';
import { CategoryIcon } from './CategoryIcon';

interface CategoriesScreenProps {
  tasks: TaskItem[];
  onToggleTask: (id: string) => void;
  onBack: () => void;
  onOpenAddTask: () => void;
  onSelectCategory: (cat: CategoryType) => void;
  language: Language;
}

export const CategoriesScreen: React.FC<CategoriesScreenProps> = ({
  tasks,
  onToggleTask,
  onBack,
  onOpenAddTask,
  onSelectCategory,
  language,
}) => {
  const isAr = language === 'ar';
  const categoryList: CategoryType[] = ['habits', 'health', 'personal', 'mind', 'work', 'study', 'home', 'other'];

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="flex-1 flex flex-col bg-white text-[#354052] px-5 py-4 overflow-y-auto select-none pb-24"
      style={{ backgroundColor: '#FFFFFF' }}
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <button
          onClick={onBack}
          className="min-h-[44px] min-w-[44px] rounded-full flex items-center justify-center text-[#718096] hover:bg-slate-50 hover:text-[#354052] transition-colors cursor-pointer"
          aria-label={isAr ? 'رجوع' : 'Back'}
          title={isAr ? 'رجوع' : 'Back'}
        >
          {isAr ? <ArrowRight className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
        </button>

        <div className="flex items-center gap-1.5">
          <h1 className="text-xl font-bold text-[#354052]">
            {isAr ? 'أقسام المهام' : 'Categories'}
          </h1>
          <span className="w-1.5 h-1.5 rounded-full bg-[#F3D58A]" />
        </div>

        <button
          onClick={onOpenAddTask}
          className="w-10 h-10 rounded-2xl flex items-center justify-center transition-all shadow-xs cursor-pointer active:scale-95 text-white"
          style={{
            backgroundColor: '#3B6CB4',
            boxShadow: '0 4px 14px -2px rgba(59, 108, 180, 0.35)',
          }}
          title={isAr ? 'إضافة مهمة' : 'Add Task'}
          aria-label={isAr ? 'إضافة مهمة' : 'Add Task'}
        >
          <Plus className="w-5 h-5 stroke-[2.5]" />
        </button>
      </div>

      {/* Categories Guide Note */}
      <div className="mt-4 px-3.5 py-2.5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FolderOpen className="w-4 h-4 text-[#3B6CB4]" />
          <span className="text-xs font-semibold text-[#354052]">
            {isAr ? 'اضغط على أي قسم لعرض مهامه وتفاصيله' : 'Tap any category to open its detailed tasks'}
          </span>
        </div>
        <span className="text-[11px] font-bold text-slate-400">
          {categoryList.length} {isAr ? 'أقسام' : 'folders'}
        </span>
      </div>

      {/* 2-column Categories Grid with Soft-Vibrant Colors & Tints */}
      <div className="grid grid-cols-2 gap-3.5 mt-3.5">
        {categoryList.map((catKey) => {
          const cat = CATEGORY_STYLES[catKey];
          const catTasks = tasks.filter((t) => t.category === catKey);
          const totalCount = catTasks.length;
          const completedCount = catTasks.filter((t) => t.completed).length;

          return (
            <button
              key={catKey}
              onClick={() => onSelectCategory(catKey)}
              className="p-4 rounded-2xl flex flex-col items-center justify-center transition-all duration-200 cursor-pointer text-center relative group active:scale-98 hover:-translate-y-0.5"
              style={{
                backgroundColor: cat.bgTint,
                border: `1px solid ${cat.borderColor}`,
                boxShadow: `0 8px 24px -4px ${cat.glowColor}`,
              }}
              title={isAr ? `فتح قسم ${cat.titleAr}` : `Open ${cat.titleEn}`}
            >
              {/* White rounded container holding the vibrant category icon */}
              <div className="w-13 h-13 rounded-2xl bg-white flex items-center justify-center mb-2 shadow-xs border border-white">
                <CategoryIcon category={catKey} size="md" className="!bg-transparent !border-0 !shadow-none" />
              </div>

              <span className="text-sm font-bold text-[#354052]">
                {isAr ? cat.titleAr : cat.titleEn}
              </span>

              <div className="flex items-center gap-1.5 mt-1">
                <span
                  className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-white/80"
                  style={{ color: cat.iconColor }}
                >
                  {totalCount} {isAr ? 'مهام' : 'tasks'}
                </span>
                {completedCount > 0 && (
                  <span className="text-[10px] font-semibold text-emerald-600 bg-white/80 px-1.5 py-0.5 rounded-full">
                    {completedCount} ✓
                  </span>
                )}
              </div>

              {/* Subtle open indicator chevron */}
              <div
                className="absolute top-2.5 right-2.5 w-6 h-6 rounded-full bg-white/80 flex items-center justify-center transition-transform group-hover:scale-110 shadow-2xs"
                style={{ color: cat.iconColor }}
              >
                {isAr ? <ChevronLeft className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
              </div>
            </button>
          );
        })}
      </div>

      {/* Quick All Tasks Summary List */}
      <div className="mt-8">
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-[#354052]">
              {isAr ? 'جميع المهام والتذكيرات' : 'All Tasks & Reminders'}
            </h2>
            <span className="text-xs text-slate-400 font-normal">
              ({tasks.length})
            </span>
            {tasks.some((t) => !t.completed && isTaskOverdue(t)) && (
              <span className="text-[11px] font-bold text-rose-600 bg-rose-50 border border-rose-200/80 px-2 py-0.5 rounded-full flex items-center gap-1">
                <AlertCircle className="w-3 h-3 text-rose-500 stroke-[2.8]" />
                <span>{tasks.filter((t) => !t.completed && isTaskOverdue(t)).length} {isAr ? 'متأخرة' : 'overdue'}</span>
              </span>
            )}
          </div>
        </div>

        <div className="space-y-3">
          {tasks.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs bg-slate-50 rounded-3xl border border-slate-100">
              <p className="font-semibold text-slate-500">
                {isAr ? 'لا توجد مهام حالياً' : 'No tasks currently'}
              </p>
              <button
                onClick={onOpenAddTask}
                className="mt-2 text-[#3B6CB4] font-semibold hover:underline inline-flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isAr ? 'إضافة مهمة جديدة' : 'Add new task'}</span>
              </button>
            </div>
          ) : (
            tasks.map((task) => {
              const isCompleted = task.completed;
              const isOverdue = !isCompleted && isTaskOverdue(task);
              const catStyle = CATEGORY_STYLES[task.category] || CATEGORY_STYLES.other;

              return (
                <div
                  key={task.id}
                  onClick={() => onToggleTask(task.id)}
                  className={`p-4 rounded-2xl border transition-all duration-200 flex items-center justify-between cursor-pointer ${
                    isCompleted
                      ? 'bg-slate-50/60 border-slate-100 opacity-60'
                      : isOverdue
                      ? 'bg-rose-50/20 border-rose-200 hover:border-rose-300 hover:-translate-y-0.5'
                      : 'bg-white border-slate-100/90 hover:border-[#3B6CB4]/40 hover:-translate-y-0.5'
                  }`}
                  style={{
                    boxShadow: isCompleted
                      ? 'none'
                      : isOverdue
                      ? '0 6px 18px -4px rgba(225, 29, 72, 0.08), 0 2px 6px -2px rgba(225, 29, 72, 0.04)'
                      : '0 6px 18px -4px rgba(0, 0, 0, 0.04), 0 2px 6px -2px rgba(59, 108, 180, 0.08)',
                  }}
                >
                  <div className="flex items-center gap-3.5 min-w-0 flex-1">
                    <CategoryIcon
                      category={task.category}
                      iconOverride={task.iconType}
                      size="md"
                    />

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3
                          className={`text-sm font-bold truncate transition-colors ${
                            isCompleted ? 'line-through text-slate-400' : 'text-[#354052]'
                          }`}
                        >
                          {task.title}
                        </h3>

                        {/* Overdue visual indicator badge with small red exclamation icon */}
                        {isOverdue && (
                          <span
                            className="shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-md bg-rose-50 text-rose-600 border border-rose-200/90 flex items-center gap-1 shadow-2xs"
                            title={isAr ? 'مهمة تجاوزت وقتها المحدد أو تاريخ استحقاقها' : 'Overdue task - deadline passed'}
                          >
                            <AlertCircle className="w-3 h-3 text-rose-500 stroke-[2.8]" />
                            <span>{isAr ? 'فات موعدها' : 'Overdue'}</span>
                          </span>
                        )}

                        {/* High priority gold badge */}
                        {task.priority === 'high' && !isCompleted && !isOverdue && (
                          <span className="shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#F3D58A]/30 text-[#8C6D1F] border border-[#F3D58A]/60 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#e2be67]" />
                            <span>{isAr ? 'هام' : 'Priority'}</span>
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 mt-1">
                        <span className={`text-[11px] font-medium flex items-center gap-1 ${isOverdue ? 'text-rose-600 font-bold' : 'text-slate-400'}`}>
                          <Clock className={`w-3 h-3 ${isOverdue ? 'text-rose-500' : 'text-slate-400'}`} />
                          <span>{task.time}</span>
                        </span>
                        <span className="text-slate-200 text-xs">·</span>
                        <span
                          className="text-[10px] font-bold px-2 py-0.5 rounded-md"
                          style={{
                            backgroundColor: catStyle.bgTint,
                            color: catStyle.iconColor,
                          }}
                        >
                          {isAr ? catStyle.titleAr : catStyle.titleEn}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleTask(task.id);
                    }}
                    className={`w-6 h-6 rounded-full flex items-center justify-center transition-all shrink-0 mr-1 cursor-pointer ${
                      isCompleted
                        ? 'bg-[#3B6CB4] text-white shadow-xs shadow-[#3B6CB4]/40'
                        : isOverdue
                        ? 'border-2 border-rose-300 hover:border-rose-500 bg-white'
                        : 'border-2 border-slate-300 hover:border-[#3B6CB4] bg-white'
                    }`}
                  >
                    {isCompleted && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </button>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
