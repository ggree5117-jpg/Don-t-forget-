import React, { useState } from 'react';
import { playChimeSound } from '../utils/audio';

interface WelcomeScreenProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onGetStarted,
  onSignIn,
}) => {
  const [isRinging, setIsRinging] = useState(false);

  const handleBellClick = () => {
    setIsRinging(true);
    playChimeSound();
    setTimeout(() => {
      setIsRinging(false);
    }, 700);
  };

  return (
    <div
      className="min-h-full flex flex-col justify-between items-center bg-white text-[#354052] px-6 sm:px-8 py-10 select-none relative"
      style={{ backgroundColor: '#FFFFFF' }}
    >
      {/* Centered Main Section with Generous Whitespace */}
      <div className="flex-1 flex flex-col items-center justify-center max-w-sm mx-auto w-full text-center my-auto">
        
        {/* Centered Minimalist Reminder Bell Logo (with subtle Champagne Gold accent #F3D58A) */}
        <div className="mb-8">
          <button
            onClick={handleBellClick}
            className={`relative w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-white border border-[#F3D58A]/40 shadow-sm flex items-center justify-center transition-all duration-300 active:scale-95 cursor-pointer ${
              isRinging ? 'scale-105 border-[#F3D58A]' : 'hover:border-[#F3D58A]'
            }`}
            style={{
              boxShadow: '0 8px 24px -6px rgba(243, 213, 138, 0.25)',
            }}
            aria-label="Reminder bell"
          >
            {/* Subtle soft ambient gold aura */}
            <div
              className="absolute inset-2 rounded-full opacity-35 pointer-events-none"
              style={{
                background: 'radial-gradient(circle at 40% 35%, #F3D58A 0%, rgba(255,255,255,0) 70%)',
              }}
            />

            {/* Elegant SVG Bell with Champagne Gold accent */}
            <div className={`transition-transform duration-300 ${isRinging ? 'rotate-12' : ''}`}>
              <svg
                className="w-12 h-12 sm:w-14 sm:h-14"
                viewBox="0 0 48 48"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                {/* Bell contour & body */}
                <path
                  d="M24 7C22.3431 7 21 8.34315 21 10C21 10.3562 21.0622 10.698 21.176 11.0147C16.5912 12.2335 13 16.3409 13 21.3333V29.5L9.5 33V35H38.5V33L35 29.5V21.3333C35 16.3409 31.4088 12.2335 26.824 11.0147C26.9378 10.698 27 10.3562 27 10C27 8.34315 25.6569 7 24 7Z"
                  fill="#F3D58A"
                  fillOpacity="0.28"
                  stroke="#354052"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />

                {/* Subtle Champagne Gold Accent stripe detail on bell */}
                <path
                  d="M17 27C19.2 26 28.8 26 31 27"
                  stroke="#F3D58A"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                />

                {/* Bell Clapper */}
                <path
                  d="M20.5 36.5C20.9 38.6 22.25 40 24 40C25.75 40 27.1 38.6 27.5 36.5"
                  stroke="#354052"
                  strokeWidth="2"
                  strokeLinecap="round"
                />

                {/* Subtle Champagne Gold highlight dot */}
                <circle cx="28" cy="17" r="1.5" fill="#F3D58A" />
              </svg>
            </div>
          </button>
        </div>

        {/* App Name: 'DON'T FORGET' (and Arabic text 'لا تنسَ') */}
        <div className="mb-6 flex flex-col items-center gap-1.5">
          <h2 className="text-sm font-semibold tracking-widest uppercase text-[#354052]">
            DON&apos;T FORGET
          </h2>
          <span className="text-sm font-medium text-[#718096]">
            لا تنسَ
          </span>
        </div>

        {/* Main Headline: 'Never Forget What Matters.' */}
        <h1
          className="text-2xl sm:text-3xl font-bold tracking-tight text-[#354052] mb-4"
          style={{ color: '#354052', textWrap: 'balance' }}
        >
          Never Forget What Matters.
        </h1>

        {/* Subtitle / Supporting Text */}
        <p
          className="text-base text-[#718096] leading-relaxed max-w-xs mb-10 font-normal"
          style={{ color: '#718096' }}
        >
          Keep your tasks, reminders, and important moments organized in one simple place.
        </p>

        {/* Action Buttons Section */}
        <div className="w-full max-w-xs space-y-3.5">
          {/* Primary Button: 'Get Started' (Deep Muted Navy Blue #3B6CB4) */}
          <button
            onClick={onGetStarted}
            className="w-full h-13 rounded-2xl text-white font-semibold text-base flex items-center justify-center transition-all duration-200 active:scale-[0.98] cursor-pointer shadow-md hover:brightness-105"
            style={{
              backgroundColor: '#3B6CB4',
              boxShadow: '0 6px 20px -4px rgba(59, 108, 180, 0.42)',
            }}
            aria-label="Get Started"
          >
            Get Started
          </button>

          {/* Secondary Button / Link: 'I already have an account' */}
          <button
            onClick={onSignIn}
            className="w-full h-11 text-sm font-medium text-[#718096] hover:text-[#354052] transition-colors duration-150 cursor-pointer flex items-center justify-center active:underline"
            aria-label="I already have an account"
          >
            I already have an account
          </button>
        </div>

      </div>
    </div>
  );
};
