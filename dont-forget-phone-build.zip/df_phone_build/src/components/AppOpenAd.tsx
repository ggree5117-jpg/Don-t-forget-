import React, { useEffect, useRef, useState } from 'react';
import { X, Sparkles, Info, Loader2 } from 'lucide-react';
import { Language } from '../types';
import { ADS_CONFIG, PLACEHOLDER_CREATIVE } from '../utils/adsConfig';
import { markAppOpenAdShown, shouldShowAppOpenAd } from '../utils/adManager';
import { isStartioAvailable, showInterstitial } from '../utils/startioBridge';

interface AppOpenAdProps {
  language: Language;
  onDismissed?: () => void;
}

/**
 * إعلان الفتح الكامل (App Open)
 * ============================
 * سلوكان حسب البيئة:
 *
 * ① داخل تطبيق أندرويد (Start.io متاح):
 *    → يُطلب إعلان حقيقي من SDK ويُعرض ملء الشاشة.
 *    → لا يُرسم أي غلاف HTML (لتفادي حجب SDK).
 *
 * ② في المتصفح (معاينة التصميم):
 *    → يُعرض تصميم تجريبي بنفس المقاسات مع زر تخطي بعد 5 ثوانٍ،
 *      حتى ترى الشكل النهائي بدون الحاجة لجهاز.
 *
 * في الحالتين: قرار الظهور والتكرار من adManager (2/يوم، 4 ساعات، لا أول تشغيل).
 */
export const AppOpenAd: React.FC<AppOpenAdProps> = ({ language, onDismissed }) => {
  const isAr = language === 'ar';

  const [visible, setVisible] = useState(false);
  const [canSkip, setCanSkip] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(Math.ceil(ADS_CONFIG.appOpen.skipAfterMs / 1000));
  const [nativeLoading, setNativeLoading] = useState(false);

  const dismissedRef = useRef(false);
  const decidedRef = useRef(false);

  const finish = () => {
    if (dismissedRef.current) return;
    dismissedRef.current = true;
    setVisible(false);
    setNativeLoading(false);
    onDismissed?.();
  };

  // قرار واحد فقط عند التحميل
  useEffect(() => {
    if (decidedRef.current) return;
    decidedRef.current = true;

    const decision = shouldShowAppOpenAd();
    if (!decision.show) {
      onDismissed?.();
      return;
    }

    // ① إعلان Start.io الحقيقي
    if (isStartioAvailable()) {
      setNativeLoading(true);
      showInterstitial(ADS_CONFIG.startio.interstitialAdTag).then((shown) => {
        if (shown) {
          markAppOpenAdShown();
        }
        // الإغلاق هنا لا يتطلب تدخل المستخدم — SDK يدير واجهته
        finish();
      });
      return;
    }

    // ② تصميم تجريبي للمتصفح
    setVisible(true);
    markAppOpenAdShown();

    const skipTimer = setTimeout(() => setCanSkip(true), ADS_CONFIG.appOpen.skipAfterMs);
    const autoClose = setTimeout(() => finish(), ADS_CONFIG.appOpen.autoCloseAfterMs);
    const tick = setInterval(() => setSecondsLeft((s) => (s > 0 ? s - 1 : 0)), 1000);

    return () => {
      clearTimeout(skipTimer);
      clearTimeout(autoClose);
      clearInterval(tick);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // مؤشر تحميل خفيف أثناء جلب إعلان Start.io (بدون حجب الشاشة)
  if (nativeLoading && !visible) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-sm">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 text-white/70 animate-spin" />
          <span className="text-white/60 text-[11px] font-bold">
            {isAr ? 'جارٍ تحميل الإعلان...' : 'Loading ad...'}
          </span>
        </div>
      </div>
    );
  }

  if (!visible) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/85 backdrop-blur-sm animate-fadeIn"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <div className="relative w-full max-w-md h-full max-h-[844px] flex flex-col bg-[#0F1723] sm:rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
        {/* شريط علوي: وسم "إعلان" + التخطي */}
        <div className="flex items-center justify-between px-4 pt-5 pb-3">
          <span className="px-2 py-0.5 rounded-md bg-white/15 text-white/80 text-[10px] font-bold tracking-wide">
            {isAr ? 'إعلان' : 'AD'}
          </span>

          {canSkip ? (
            <button
              onClick={finish}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/95 text-slate-900 text-xs font-black active:scale-95 transition-all cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              <span>{isAr ? 'تخطي' : 'Skip'}</span>
            </button>
          ) : (
            <span className="px-3 py-1.5 rounded-full bg-white/10 text-white/70 text-[11px] font-bold tabular-nums">
              {isAr ? `تخطي بعد ${secondsLeft}` : `Skip in ${secondsLeft}`}
            </span>
          )}
        </div>

        {/* مساحة الإعلان */}
        <div id="app-open-ad-slot" className="flex-1 mx-4 mb-3 rounded-3xl overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-br from-[#1B3A5C] via-[#24507E] to-[#123048] flex flex-col items-center justify-center p-6 text-center">
            <div className="w-16 h-16 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center mb-4">
              <Sparkles className="w-8 h-8 text-[#F3D58A]" />
            </div>
            <h3 className="text-white font-black text-lg mb-1.5">
              {isAr ? PLACEHOLDER_CREATIVE.titleAr : PLACEHOLDER_CREATIVE.titleEn}
            </h3>
            <p className="text-white/60 text-xs leading-relaxed max-w-[240px]">
              {isAr ? PLACEHOLDER_CREATIVE.subAr : PLACEHOLDER_CREATIVE.subEn}
            </p>

            <div className="mt-5 px-3 py-1.5 rounded-lg bg-black/25 border border-white/10">
              <p className="text-[10px] text-white/50 font-mono">
                Start.io · App ID {ADS_CONFIG.startio.appId}
              </p>
            </div>

            <div className="absolute bottom-3 inset-x-3 flex items-start gap-1.5 text-white/35">
              <Info className="w-3 h-3 mt-0.5 shrink-0" />
              <p className="text-[9px] leading-relaxed text-start">
                {isAr
                  ? 'تصميم تجريبي في المتصفح فقط — داخل تطبيق الأندرويد يظهر إعلان Start.io الحقيقي.'
                  : 'Browser preview only — the real Start.io ad is served inside the Android app.'}
              </p>
            </div>
          </div>
        </div>

        <div className="px-4 pb-5">
          <p className="text-center text-[9.5px] text-white/30 leading-relaxed">
            {isAr
              ? `يظهر بحد أقصى ${ADS_CONFIG.appOpen.maxPerDay} مرات يومياً وبفاصل ${Math.round(
                  ADS_CONFIG.appOpen.minIntervalMs / 3600000
                )} ساعات`
              : `Max ${ADS_CONFIG.appOpen.maxPerDay}×/day, ${Math.round(
                  ADS_CONFIG.appOpen.minIntervalMs / 3600000
                )}h apart`}
          </p>
        </div>
      </div>
    </div>
  );
};
