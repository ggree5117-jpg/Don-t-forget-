import React from 'react';
import { Flame } from 'lucide-react';
import { Language } from '../types';

interface CalorieArcGaugeProps {
  consumed: number;
  target: number;
  language: Language;
  onOpenTargetSetup?: () => void;
}

export const CalorieArcGauge: React.FC<CalorieArcGaugeProps> = ({
  consumed,
  target,
  language,
  onOpenTargetSetup,
}) => {
  const isAr = language === 'ar';
  const hasTarget = target > 0;
  const remaining = hasTarget ? Math.max(0, target - consumed) : 0;
  const progressFraction = hasTarget ? Math.min(1, Math.max(0, consumed / target)) : 0;

  // SVG semicircular geometry
  // Radius = 80, Center = (100, 95)
  // Left point: (20, 95), Top: (100, 15), Right point: (180, 95)
  const radius = 80;
  const strokeWidth = 14;
  const arcLength = Math.PI * radius; // ~251.327
  const strokeDashoffset = arcLength * (1 - progressFraction);

  return (
    <div className="relative flex flex-col items-center justify-center pt-2 pb-1">
      {/* SVG Arc Container */}
      <div className="relative w-64 h-36 flex items-center justify-center">
        <svg
          viewBox="0 0 200 120"
          className="w-full h-full overflow-visible"
        >
          <defs>
            <linearGradient id="calorieArcGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3498DB" />
              <stop offset="50%" stopColor="#3B6CB4" />
              <stop offset="100%" stopColor="#2C5282" />
            </linearGradient>

            <filter id="arcGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#3B6CB4" floodOpacity="0.25" />
            </filter>
          </defs>

          {/* Background Track Arc */}
          <path
            d="M 20 95 A 80 80 0 0 1 180 95"
            fill="none"
            stroke="#EEF2F6"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
          />

          {/* Foreground Progress Arc */}
          {hasTarget && progressFraction > 0 && (
            <path
              d="M 20 95 A 80 80 0 0 1 180 95"
              fill="none"
              stroke="url(#calorieArcGradient)"
              strokeWidth={strokeWidth}
              strokeDasharray={arcLength}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              filter="url(#arcGlow)"
              className="transition-all duration-700 ease-out"
            />
          )}
        </svg>

        {/* Center Numbers and Labels inside the Arc */}
        <div className="absolute top-10 flex flex-col items-center justify-center text-center">
          <div className="flex items-center gap-1 text-[#3B6CB4] mb-0.5">
            <Flame className="w-4 h-4 fill-current text-[#3B6CB4]" />
            <span className="text-[11px] font-bold tracking-wider uppercase text-slate-500">
              {isAr ? 'المستهلك اليوم' : 'Consumed'}
            </span>
          </div>

          <div className="flex items-baseline justify-center gap-1">
            <span className="text-3xl font-extrabold text-[#354052] tracking-tight">
              {consumed.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-slate-400">
              {isAr ? 'سعرة' : 'Kcal'}
            </span>
          </div>

          {hasTarget ? (
            <span className="text-[11px] font-medium text-slate-400 mt-0.5">
              {isAr ? `من أصل ${target.toLocaleString()} سعرة` : `of ${target.toLocaleString()} target`}
            </span>
          ) : (
            <button
              onClick={onOpenTargetSetup}
              className="text-[11px] font-bold text-[#3B6CB4] hover:underline mt-0.5 cursor-pointer"
            >
              {isAr ? 'اضغط لتحديد الهدف' : 'Tap to set target'}
            </button>
          )}
        </div>
      </div>

      {/* Arc Base Endpoints and Remaining Badge */}
      <div className="w-full flex items-center justify-between px-6 -mt-3">
        <span className="text-[10px] font-bold text-slate-400">0</span>

        {/* Remaining Tag in soft pill */}
        <div
          onClick={hasTarget ? undefined : onOpenTargetSetup}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EBF2FA] border border-[#3B6CB4]/20 shadow-2xs ${
            !hasTarget ? 'cursor-pointer hover:bg-blue-100 transition-colors' : ''
          }`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#3B6CB4]" />
          <span className="text-[11px] font-bold text-[#3B6CB4]">
            {hasTarget
              ? isAr
                ? `المتبقي: ${remaining.toLocaleString()} سعرة`
                : `${remaining.toLocaleString()} Kcal left`
              : isAr
              ? 'الهدف اليومي: —'
              : 'Daily Target: —'}
          </span>
        </div>

        <span className="text-[10px] font-bold text-slate-400">
          {hasTarget ? target.toLocaleString() : '—'}
        </span>
      </div>
    </div>
  );
};
