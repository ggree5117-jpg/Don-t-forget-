import React from 'react';
import { resolveMealImageUrl } from '../utils/mealImages';

interface MealImageProps {
  nameAr?: string | null;
  nameEn?: string | null;
  slot?: string | null;
  /** ارتفاع المنطقة أو نسبة العرض */
  className?: string;
  /** شارة صغيرة في الزاوية (مثل: وقت الوجبة) */
  badge?: string;
  /** شارة ثانية بألوان مختلفة */
  secondaryBadge?: string;
  /** زاوية الميلان للأسفل عند العرض كغلاف */
  rounded?: string;
  priority?: boolean;
  overlay?: React.ReactNode;
}

/**
 * صورة طبق احترافية: تغطية كاملة + تدرّج داكن أسفل الصورة
 * ليظهر النص فوقها بقراءة مريحة، مع تحميل تدريجي وبديل لوني.
 */
export const MealImage: React.FC<MealImageProps> = ({
  nameAr,
  nameEn,
  slot,
  className = 'h-32',
  badge,
  secondaryBadge,
  rounded = 'rounded-2xl',
  priority = false,
  overlay,
}) => {
  const src = resolveMealImageUrl(nameAr, nameEn, slot);

  return (
    <div className={`relative w-full overflow-hidden ${rounded} bg-gradient-to-br from-[#E8EEF7] to-[#D7E3F1] ${className}`}>
      <img
        src={src}
        alt={nameAr || nameEn || 'meal'}
        loading={priority ? 'eager' : 'lazy'}
        decoding="async"
        className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
        onError={(e) => {
          (e.currentTarget as HTMLImageElement).style.opacity = '0';
        }}
      />

      {/* تدرّج لقراءة النص فوق الصورة */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/10 to-transparent pointer-events-none" />

      {/* الشارات */}
      <div className="absolute top-2 inset-x-2 flex items-center gap-1.5 justify-between">
        {badge ? (
          <span className="px-2 py-0.5 rounded-full bg-white/95 text-[#2C5282] text-[9.5px] font-black shadow-sm backdrop-blur-xs">
            {badge}
          </span>
        ) : (
          <span />
        )}
        {secondaryBadge && (
          <span className="px-2 py-0.5 rounded-full bg-black/45 text-white text-[9.5px] font-bold backdrop-blur-xs">
            {secondaryBadge}
          </span>
        )}
      </div>

      {overlay}
    </div>
  );
};
