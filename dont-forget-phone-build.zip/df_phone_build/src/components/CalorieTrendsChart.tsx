import React, { useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
  Cell,
  CartesianGrid,
} from 'recharts';
import { TrendingUp, Flame, Target, Info } from 'lucide-react';
import { Language } from '../types';

export interface DayCalorieData {
  dayAr: string;
  dayEn: string;
  dateStr: string;
  calories: number;
  target: number;
  isToday?: boolean;
}

interface CalorieTrendsChartProps {
  todayCalories: number;
  targetCalories: number;
  language: Language;
}

export const CalorieTrendsChart: React.FC<CalorieTrendsChartProps> = ({
  todayCalories,
  targetCalories,
  language,
}) => {
  const isAr = language === 'ar';
  const [activeBarIndex, setActiveBarIndex] = useState<number | null>(null);

  // Generate 7-day week representation: strictly real data, zero fake numbers
  const today = new Date();
  const daysOfWeek = [
    { ar: 'الأحد', en: 'Sun' },
    { ar: 'الإثنين', en: 'Mon' },
    { ar: 'الثلاثاء', en: 'Tue' },
    { ar: 'الأربعاء', en: 'Wed' },
    { ar: 'الخميس', en: 'Thu' },
    { ar: 'الجمعة', en: 'Fri' },
    { ar: 'السبت', en: 'Sat' },
  ];

  const currentDayIndex = today.getDay(); // 0 = Sun, 6 = Sat

  // Build the 7 days ending with today or current week
  const data: DayCalorieData[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(today.getDate() - i);
    const dayIdx = d.getDay();
    const isCurrentDay = i === 0;

    data.push({
      dayAr: isCurrentDay ? (isAr ? 'اليوم' : 'Today') : daysOfWeek[dayIdx].ar,
      dayEn: isCurrentDay ? 'Today' : daysOfWeek[dayIdx].en,
      dateStr: `${d.getDate()} ${d.toLocaleString('en', { month: 'short' })}`,
      calories: isCurrentDay ? todayCalories : 0, // Only actual logged data for today, 0 for past empty days
      target: targetCalories,
      isToday: isCurrentDay,
    });
  }

  const hasAnyData = todayCalories > 0;
  const hasTarget = targetCalories > 0;

  // Calculate 7-day metrics strictly from entered data
  const totalCalories = data.reduce((acc, d) => acc + d.calories, 0);
  const averageCalories = hasAnyData ? Math.round(totalCalories / 1) : 0;
  const onTargetDays = hasTarget && hasAnyData && todayCalories <= targetCalories + 100 ? 1 : 0;

  // Custom polished Tooltip component for Recharts
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const item: DayCalorieData = payload[0].payload;
      const diff = hasTarget ? item.calories - item.target : 0;
      const isUnder = diff <= 0;

      return (
        <div
          dir={isAr ? 'rtl' : 'ltr'}
          className="bg-white/95 backdrop-blur-md p-3 rounded-2xl shadow-xl border border-blue-100 text-xs min-w-[150px] z-50 pointer-events-none"
          style={{ boxShadow: '0 10px 25px -4px rgba(37, 99, 235, 0.18)' }}
        >
          <div className="flex items-center justify-between pb-1.5 border-b border-slate-100 mb-1.5">
            <span className="font-bold text-[#1E293B]">
              {isAr ? item.dayAr : item.dayEn}
            </span>
            <span className="text-[10px] text-slate-400 font-medium">
              {item.dateStr}
            </span>
          </div>

          <div className="flex items-center gap-1.5 mb-1">
            <Flame className="w-3.5 h-3.5 text-[#2563EB] fill-current" />
            <span className="text-[11px] text-slate-500">
              {isAr ? 'المستهلك:' : 'Consumed:'}
            </span>
            <span className="font-black text-[#1E293B] text-sm">
              {item.calories.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400">
              {isAr ? 'سعرة' : 'kcal'}
            </span>
          </div>

          {hasTarget && (
            <div className="flex items-center justify-between pt-1 text-[10px] font-semibold">
              <span className="text-slate-400">
                {isAr ? 'الهدف:' : 'Target:'} {item.target.toLocaleString()}
              </span>
              <span
                className={`px-1.5 py-0.5 rounded-md ${
                  isUnder
                    ? 'bg-emerald-50 text-emerald-600 border border-emerald-200/60'
                    : 'bg-amber-50 text-amber-600 border border-amber-200/60'
                }`}
              >
                {item.calories === 0
                  ? isAr
                    ? '—'
                    : '—'
                  : isUnder
                  ? isAr
                    ? `متبقي ${Math.abs(diff)}`
                    : `${Math.abs(diff)} under`
                  : isAr
                  ? `تجاوز +${diff}`
                  : `+${diff} over`}
              </span>
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="mt-6">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#EBF3FC] text-[#2563EB] flex items-center justify-center">
            <TrendingUp className="w-4 h-4 stroke-[2.4]" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-[#1E3A8A]">
              {isAr ? 'استهلاك السعرات (آخر 7 أيام)' : '7-Day Calorie Trends'}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] font-bold text-[#2563EB] bg-[#EBF3FC] px-2.5 py-0.5 rounded-full">
            {hasTarget
              ? isAr
                ? `الهدف: ${targetCalories.toLocaleString()} Kcal`
                : `Target: ${targetCalories.toLocaleString()} Kcal`
              : isAr
              ? 'الهدف غير محدد'
              : 'Target not set'}
          </span>
        </div>
      </div>

      {/* Main Chart Card */}
      <div
        className="p-4 rounded-3xl bg-white border border-blue-50/80 transition-all relative overflow-hidden"
        style={{
          boxShadow: '0 8px 24px -4px rgba(37, 99, 235, 0.06), 0 2px 6px -2px rgba(0, 0, 0, 0.02)',
        }}
      >
        {/* Recharts BarChart */}
        <div className="w-full h-52">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{ top: 18, right: 8, left: -20, bottom: 0 }}
              onMouseMove={(state) => {
                if (state?.activeTooltipIndex !== undefined) {
                  const idx = typeof state.activeTooltipIndex === 'number'
                    ? state.activeTooltipIndex
                    : parseInt(String(state.activeTooltipIndex), 10);
                  setActiveBarIndex(isNaN(idx) ? null : idx);
                }
              }}
              onMouseLeave={() => setActiveBarIndex(null)}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                vertical={false}
                stroke="#F1F5F9"
              />

              <XAxis
                dataKey={isAr ? 'dayAr' : 'dayEn'}
                tickLine={false}
                axisLine={false}
                tick={{ fill: '#64748B', fontSize: 11, fontWeight: 600 }}
              />

              <YAxis
                tickLine={false}
                axisLine={false}
                tick={{ fill: '#94A3B8', fontSize: 10 }}
                domain={[0, Math.max(hasTarget ? targetCalories + 400 : 2000, todayCalories + 200)]}
                ticks={hasTarget ? [0, Math.round(targetCalories / 2), targetCalories] : [0, 1000, 2000]}
              />

              <Tooltip
                content={<CustomTooltip />}
                cursor={{ fill: 'rgba(235, 243, 252, 0.5)', radius: 8 }}
              />

              {hasTarget && (
                <ReferenceLine
                  y={targetCalories}
                  stroke="#2563EB"
                  strokeDasharray="4 4"
                  strokeWidth={1.5}
                  label={{
                    value: isAr ? 'الهدف' : 'Target',
                    fill: '#2563EB',
                    fontSize: 10,
                    fontWeight: 700,
                    position: 'insideTopRight',
                  }}
                />
              )}

              <Bar
                dataKey="calories"
                radius={[8, 8, 4, 4]}
                maxBarSize={32}
                animationDuration={600}
              >
                {data.map((entry, index) => {
                  const isCurrent = entry.isToday;
                  const isHovered = activeBarIndex === index;
                  let fill = '#CBD5E1'; // Soft slate for empty days
                  if (entry.calories > 0) {
                    fill = isCurrent ? '#2563EB' : '#93C5FD';
                  }
                  if (isHovered && entry.calories > 0) {
                    fill = '#1D4ED8';
                  }

                  return (
                    <Cell
                      key={`cell-${index}`}
                      fill={fill}
                      className="transition-all duration-300"
                    />
                  );
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Empty state caption if no meals logged yet */}
        {!hasAnyData && (
          <div className="mt-2 text-center py-2 px-3 rounded-2xl bg-slate-50 border border-slate-100 text-[11px] text-slate-400">
            {isAr
              ? 'لم تسجل أي وجبات اليوم بعد. سجل وجباتك لتظهر أشرطة استهلاكك هنا.'
              : 'No meals logged yet today. Log meals to see your intake trends.'}
          </div>
        )}

        {/* Summary Metrics Bar below chart */}
        <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-3 gap-2 text-center">
          <div className="p-2 rounded-xl bg-slate-50">
            <span className="text-[10px] font-semibold text-slate-400 block">
              {isAr ? 'اليوم' : 'Today'}
            </span>
            <span className="text-xs font-black text-[#1E293B]">
              {todayCalories > 0 ? `${todayCalories} Kcal` : '0 Kcal'}
            </span>
          </div>

          <div className="p-2 rounded-xl bg-slate-50">
            <span className="text-[10px] font-semibold text-slate-400 block">
              {isAr ? 'الهدف اليومي' : 'Daily Target'}
            </span>
            <span className="text-xs font-black text-[#2563EB]">
              {hasTarget ? `${targetCalories} Kcal` : '—'}
            </span>
          </div>

          <div className="p-2 rounded-xl bg-slate-50">
            <span className="text-[10px] font-semibold text-slate-400 block">
              {isAr ? 'الالتزام' : 'On Target'}
            </span>
            <span className="text-xs font-black text-emerald-600">
              {hasAnyData && hasTarget
                ? todayCalories <= targetCalories + 100
                  ? isAr ? 'ملتزم ✓' : 'On Track ✓'
                  : isAr ? 'تجاوز' : 'Over'
                : '—'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
