import React, { useState } from 'react';
import { ArrowLeft, User, Mail, Lock, CheckCircle2 } from 'lucide-react';

interface CreateAccountScreenProps {
  onBack: () => void;
  onGoToLogin: () => void;
  onSuccess: (name: string) => void;
}

export const CreateAccountScreen: React.FC<CreateAccountScreenProps> = ({
  onBack,
  onGoToLogin,
  onSuccess,
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password !== confirmPassword) {
      setError('Passwords do not match. Please re-enter.');
      return;
    }

    if (password.length < 6) {
      setError('Password should be at least 6 characters.');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onSuccess(fullName.trim() || 'User');
    }, 400);
  };

  return (
    <div
      className="min-h-full flex flex-col justify-between bg-white text-[#354052] px-6 py-6 select-none relative"
      style={{ backgroundColor: '#FFFFFF' }}
    >
      {/* Top Header with Back Arrow and App Title */}
      <div className="flex items-center justify-between pb-2">
        <button
          type="button"
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#718096] hover:text-[#354052] hover:bg-slate-50 transition-colors -ml-2"
          aria-label="Back to Welcome screen"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-1.5">
          <span className="text-xs font-bold tracking-wider uppercase text-[#354052]">
            DON&apos;T FORGET
          </span>
          <span className="text-xs font-semibold text-[#F3D58A]">لا تنسَ</span>
        </div>

        <div className="w-10" />
      </div>

      {/* Main Content Form */}
      <div className="flex-1 flex flex-col justify-center max-w-sm mx-auto w-full my-auto py-4">
        {/* Title */}
        <div className="mb-6 text-center">
          <h1 className="text-2xl font-bold tracking-tight text-[#354052] mb-1.5">
            Create Account
          </h1>
          <p className="text-sm text-[#718096]">
            Sign up to keep your tasks and reminders organized.
          </p>
        </div>

        {/* Error message */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-100 text-rose-600 text-xs">
            {error}
          </div>
        )}

        {/* Clean Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* Full Name */}
          <div>
            <label className="block text-xs font-semibold text-[#354052] mb-1">
              Full Name
            </label>
            <div className="relative">
              <User className="absolute left-3.5 top-3.5 w-4 h-4 text-[#718096]" />
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Sarah Jenkins"
                className="w-full h-12 pl-10 pr-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-[#354052] placeholder:text-slate-400 focus:outline-none focus:border-[#3B6CB4] focus:bg-white transition-all"
              />
            </div>
          </div>

          {/* Email Address */}
          <div>
            <label className="block text-xs font-semibold text-[#354052] mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-3.5 w-4 h-4 text-[#718096]" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="sarah@example.com"
                className="w-full h-12 pl-10 pr-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-[#354052] placeholder:text-slate-400 focus:outline-none focus:border-[#3B6CB4] focus:bg-white transition-all"
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="block text-xs font-semibold text-[#354052] mb-1">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-[#718096]" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="w-full h-12 pl-10 pr-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-[#354052] placeholder:text-slate-400 focus:outline-none focus:border-[#3B6CB4] focus:bg-white transition-all"
              />
            </div>
          </div>

          {/* Confirm Password */}
          <div>
            <label className="block text-xs font-semibold text-[#354052] mb-1">
              Confirm Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-[#718096]" />
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter password"
                className="w-full h-12 pl-10 pr-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-[#354052] placeholder:text-slate-400 focus:outline-none focus:border-[#3B6CB4] focus:bg-white transition-all"
              />
            </div>
          </div>

          {/* Primary Button: 'Create Account' (Deep Muted Navy Blue #3B6CB4) */}
          <button
            type="submit"
            disabled={loading}
            className="w-full h-13 rounded-2xl text-white font-semibold text-base flex items-center justify-center transition-all duration-200 active:scale-[0.98] cursor-pointer shadow-md hover:brightness-105 mt-5"
            style={{
              backgroundColor: '#3B6CB4',
              boxShadow: '0 6px 20px -4px rgba(59, 108, 180, 0.4)',
            }}
          >
            {loading ? (
              <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              'Create Account'
            )}
          </button>
        </form>

        {/* Link at the bottom: 'Already have an account? Log in' */}
        <div className="mt-6 text-center">
          <button
            type="button"
            onClick={onGoToLogin}
            className="text-sm text-[#718096] hover:text-[#354052] transition-colors cursor-pointer"
          >
            Already have an account?{' '}
            <span className="font-semibold text-[#3B6CB4] hover:underline">
              Log in
            </span>
          </button>
        </div>
      </div>

      {/* Subtle bottom note */}
      <div className="text-center pt-2">
        <p className="text-[11px] text-[#718096]/60">
          Pure private storage · No AI telemetry · No ads
        </p>
      </div>
    </div>
  );
};
