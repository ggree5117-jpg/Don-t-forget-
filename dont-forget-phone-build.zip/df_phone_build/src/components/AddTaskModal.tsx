import React, { useState, useEffect } from 'react';
import { X, Check, Clock, Calendar, Flag, Tag, Edit3, ChevronRight, ChevronLeft, Sparkles, Repeat } from 'lucide-react';
import { TaskItem, CategoryType, PriorityType, Language, CustomAudioRecord } from '../types';
import {
  playChimeSound,
  startRingtone,
  stopRingtone,
  BUILT_IN_RINGTONES,
  getCurrentlyPlayingRingtoneId,
} from '../utils/audio';
import { CATEGORY_STYLES } from '../utils/data';
import { TimePickerModal } from './TimePickerModal';
import { DatePickerModal } from './DatePickerModal';
import { Music, Play, Square, Volume2 } from 'lucide-react';

interface AddTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (task: Omit<TaskItem, 'id' | 'completed'>) => void;
  defaultCategory?: CategoryType;
  defaultRingtoneId?: string;
  customRingtones?: CustomAudioRecord[];
  language: Language;
}

export const AddTaskModal: React.FC<AddTaskModalProps> = ({
  isOpen,
  onClose,
  onSave,
  defaultCategory,
  defaultRingtoneId = 'chime',
  customRingtones = [],
  language,
}) => {
  const isAr = language === 'ar';

  const [title, setTitle] = useState('');
  const [time, setTime] = useState('09:00 ص');
  const [date, setDate] = useState('2026-11-06');
  const [repeat, setRepeat] = useState<'once' | 'daily' | 'weekly' | 'monthly'>('once');
  const [priority, setPriority] = useState<PriorityType>('high');
  const [category, setCategory] = useState<CategoryType>(defaultCategory || 'work');
  const [ringtoneId, setRingtoneId] = useState<string>(''); // '' = Default from settings
  const [description, setDescription] = useState('');
  const [previewingRingtoneId, setPreviewingRingtoneId] = useState<string | null>(null);

  // Sync category if defaultCategory changes or modal opens
  useEffect(() => {
    if (defaultCategory) {
      setCategory(defaultCategory);
    }
  }, [defaultCategory, isOpen]);

  // Interactive Pickers Visibility
  const [isTimePickerOpen, setIsTimePickerOpen] = useState(false);
  const [isDatePickerOpen, setIsDatePickerOpen] = useState(false);

  // Stop preview on modal close or unmount
  useEffect(() => {
    if (!isOpen) {
      stopRingtone();
      setPreviewingRingtoneId(null);
    }
    return () => {
      stopRingtone();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const defaultBuiltIn = BUILT_IN_RINGTONES.find((r) => r.id === defaultRingtoneId);
  const defaultCustom = customRingtones.find((c) => c.id === defaultRingtoneId);
  const defaultRingtoneLabel = defaultBuiltIn
    ? (isAr ? defaultBuiltIn.nameAr : defaultBuiltIn.nameEn)
    : defaultCustom
    ? defaultCustom.name
    : (isAr ? 'جرس هادئ' : 'Calm Chime');

  const handleTogglePreview = (targetId: string) => {
    if (previewingRingtoneId === targetId) {
      stopRingtone();
      setPreviewingRingtoneId(null);
    } else {
      const customMatch = customRingtones.find((c) => c.id === targetId);
      startRingtone(targetId, customMatch?.blob).catch(() => {});
      setPreviewingRingtoneId(targetId);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    stopRingtone();
    setPreviewingRingtoneId(null);

    onSave({
      title: title.trim(),
      description: description.trim() || undefined,
      category,
      date,
      time,
      repeat,
      priority,
      ringtoneId: ringtoneId || undefined,
    });

    playChimeSound();
    onClose();
  };

  const handleTimeConfirm = (newTime: string) => {
    setTime(newTime);
  };

  const handleDateConfirm = (newDate: string, newRepeat: 'once' | 'daily' | 'weekly' | 'monthly') => {
    setDate(newDate);
    setRepeat(newRepeat);
  };

  // Format date display label for the interactive button
  const formatDateLabel = () => {
    const parts = date.split('-');
    const day = parts[2] || '06';
    const month = parts[1] || '11';
    const monthNamesAr = ['', 'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    const monthNum = parseInt(month, 10);
    const monthStr = isAr ? monthNamesAr[monthNum] || 'نوفمبر' : 'Nov';

    const repeatLabel =
      repeat === 'once'
        ? isAr ? 'مرة واحدة' : 'Once'
        : repeat === 'daily'
        ? isAr ? 'يومياً' : 'Daily'
        : repeat === 'weekly'
        ? isAr ? 'أسبوعياً' : 'Weekly'
        : isAr ? 'شهرياً' : 'Monthly';

    return `${day} ${monthStr} · ${repeatLabel}`;
  };

  const categoriesOrder: CategoryType[] = ['habits', 'health', 'personal', 'mind', 'work', 'study', 'home', 'other'];

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-200"
    >
      <div
        className="w-full sm:max-w-md bg-white rounded-t-2xl sm:rounded-2xl p-6 shadow-2xl border border-slate-100 max-h-[92vh] overflow-y-auto"
        style={{
          boxShadow: '0 20px 40px -10px rgba(0, 0, 0, 0.25)',
        }}
      >
        {/* Top Header Bar */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5 stroke-[2.2]" />
          </button>

          <div className="flex items-center gap-1.5">
            <h2 className="text-base font-bold text-[#354052]">
              {isAr ? 'إضافة مهمة جديدة' : 'Add New Task'}
            </h2>
            <span className="w-1.5 h-1.5 rounded-full bg-[#F3D58A]" />
          </div>

          <button
            type="button"
            onClick={handleSave}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#3B6CB4] hover:bg-[#EBF2FA] transition-colors cursor-pointer"
            aria-label="Save"
          >
            <Check className="w-5 h-5 stroke-[2.8]" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="mt-4 space-y-4">
          {/* Title Input with pencil icon */}
          <div className="relative">
            <div className={`absolute top-3.5 text-slate-400 ${isAr ? 'left-3.5' : 'right-3.5'}`}>
              <Edit3 className="w-4 h-4 text-[#3B6CB4]" />
            </div>
            <input
              type="text"
              required
              autoFocus
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={isAr ? 'اكتب ما تريد تذكيره...' : 'Type what you want to remember...'}
              className="w-full h-12 px-4 bg-slate-50 border border-slate-200/90 rounded-2xl text-sm text-[#354052] placeholder:text-slate-400 focus:outline-none focus:border-[#3B6CB4] focus:bg-white transition-all font-semibold shadow-2xs"
            />
          </div>

          {/* 1. Time Field (الوقت) - Interactive Trigger */}
          <button
            type="button"
            onClick={() => {
              playChimeSound();
              setIsTimePickerOpen(true);
            }}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 border border-slate-100 hover:border-[#3B6CB4]/40 hover:bg-[#EBF2FA]/30 transition-all shadow-2xs text-left cursor-pointer group"
          >
            <div className="flex items-center gap-2.5 text-xs font-bold text-[#354052]">
              <div className="w-8 h-8 rounded-xl bg-white border border-slate-200/80 flex items-center justify-center text-[#3B6CB4] group-hover:border-[#3B6CB4] transition-colors shadow-2xs">
                <Clock className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span>{isAr ? 'الوقت والتنبيه' : 'Time & Alert'}</span>
                <span className="text-[10px] text-slate-400 font-normal">
                  {isAr ? 'انقر لتغيير التوقيت' : 'Tap to set time'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-[#3B6CB4] bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs font-mono">
                {time}
              </span>
              {isAr ? (
                <ChevronLeft className="w-4 h-4 text-slate-400 group-hover:text-[#3B6CB4] transition-colors" />
              ) : (
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-[#3B6CB4] transition-colors" />
              )}
            </div>
          </button>

          {/* 2. Date / Schedule Field (التاريخ والجدولة) - Interactive Trigger */}
          <button
            type="button"
            onClick={() => {
              playChimeSound();
              setIsDatePickerOpen(true);
            }}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 border border-slate-100 hover:border-[#3B6CB4]/40 hover:bg-[#EBF2FA]/30 transition-all shadow-2xs text-left cursor-pointer group"
          >
            <div className="flex items-center gap-2.5 text-xs font-bold text-[#354052]">
              <div className="w-8 h-8 rounded-xl bg-white border border-slate-200/80 flex items-center justify-center text-[#3B6CB4] group-hover:border-[#3B6CB4] transition-colors shadow-2xs">
                <Calendar className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span>{isAr ? 'التاريخ والجدولة' : 'Date & Schedule'}</span>
                <span className="text-[10px] text-slate-400 font-normal">
                  {isAr ? 'انقر لفتح التقويم' : 'Tap to open calendar'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-[#354052] bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
                {formatDateLabel()}
              </span>
              {isAr ? (
                <ChevronLeft className="w-4 h-4 text-slate-400 group-hover:text-[#3B6CB4] transition-colors" />
              ) : (
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-[#3B6CB4] transition-colors" />
              )}
            </div>
          </button>

          {/* Priority Row with Champagne Gold Accent for High Priority */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 border border-slate-100 shadow-2xs">
            <div className="flex items-center gap-2.5 text-xs font-bold text-[#354052]">
              <Flag className="w-4 h-4 text-[#3B6CB4]" />
              <span>{isAr ? 'الأولوية' : 'Priority'}</span>
            </div>
            <div className="flex items-center gap-2">
              {(['high', 'medium', 'low'] as PriorityType[]).map((p) => {
                const isSelected = priority === p;
                const isHigh = p === 'high';
                const label =
                  p === 'high'
                    ? isAr
                      ? 'عالية'
                      : 'High'
                    : p === 'medium'
                    ? isAr
                      ? 'متوسطة'
                      : 'Medium'
                    : isAr
                    ? 'منخفضة'
                    : 'Low';

                return (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPriority(p)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      isSelected
                        ? isHigh
                          ? 'bg-[#F3D58A] text-[#5C450A] shadow-xs ring-1 ring-[#e2be67]'
                          : 'bg-[#3B6CB4] text-white shadow-xs'
                        : 'bg-white border border-slate-200 text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Category Selector with Exact Soft-Vibrant Color Chips */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 shadow-2xs">
            <div className="flex items-center justify-between text-xs font-bold text-[#354052] mb-3">
              <div className="flex items-center gap-2">
                <Tag className="w-4 h-4 text-[#3B6CB4]" />
                <span>{isAr ? 'اختر الفئة' : 'Select Category'}</span>
              </div>
              <span className="text-[11px] font-normal text-slate-400">
                {isAr ? 'ألوان مميزة لكل مجال' : 'Distinct colors'}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {categoriesOrder.map((catKey) => {
                const cat = CATEGORY_STYLES[catKey];
                const isSelected = category === catKey;

                return (
                  <button
                    key={catKey}
                    type="button"
                    onClick={() => setCategory(catKey)}
                    className={`py-2 px-2 rounded-xl text-xs font-bold text-center transition-all cursor-pointer border ${
                      isSelected
                        ? 'ring-2 ring-[#3B6CB4] shadow-sm scale-102 font-extrabold'
                        : 'hover:opacity-90'
                    }`}
                    style={{
                      backgroundColor: cat.bgTint,
                      color: isSelected ? '#1E293B' : cat.iconColor,
                      borderColor: isSelected ? cat.iconColor : cat.borderColor,
                    }}
                  >
                    {isAr ? cat.titleAr : cat.titleEn}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Ringtone Field for this Task (اختياري لكل مهمة: نغمة هذه المهمة) */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 shadow-2xs">
            <div className="flex items-center justify-between text-xs font-bold text-[#354052] mb-2">
              <div className="flex items-center gap-2">
                <Music className="w-4 h-4 text-[#3B6CB4]" />
                <span>{isAr ? 'نغمة هذه المهمة' : 'Task Ringtone'}</span>
              </div>
              <span className="text-[10px] text-slate-400 font-normal">
                {ringtoneId ? (isAr ? 'مخصصة لهذه المهمة' : 'Custom for task') : (isAr ? 'الافتراضية من الإعدادات' : 'Default from Settings')}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={ringtoneId}
                onChange={(e) => {
                  const val = e.target.value;
                  setRingtoneId(val);
                  stopRingtone();
                  setPreviewingRingtoneId(null);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-white border border-slate-200 text-xs font-semibold text-[#354052] focus:outline-none focus:border-[#3B6CB4] truncate"
              >
                <option value="">
                  {isAr
                    ? `نغمة الإعدادات الافتراضية (${defaultRingtoneLabel})`
                    : `Settings Default (${defaultRingtoneLabel})`}
                </option>

                <optgroup label={isAr ? 'النغمات الجاهزة' : 'Built-in Ringtones'}>
                  {BUILT_IN_RINGTONES.map((r) => (
                    <option key={r.id} value={r.id}>
                      {isAr ? r.nameAr : r.nameEn}
                    </option>
                  ))}
                </optgroup>

                {customRingtones.length > 0 && (
                  <optgroup label={isAr ? 'نغمات من هاتفي' : 'Phone Custom Ringtones'}>
                    {customRingtones.map((c) => (
                      <option key={c.id} value={c.id}>
                        🎵 {c.name}
                      </option>
                    ))}
                  </optgroup>
                )}
              </select>

              <button
                type="button"
                onClick={() => handleTogglePreview(ringtoneId || defaultRingtoneId)}
                className={`h-9 px-3 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shrink-0 ${
                  previewingRingtoneId
                    ? 'bg-rose-50 text-rose-600 border border-rose-200 animate-pulse'
                    : 'bg-white border border-slate-200 text-[#3B6CB4] hover:bg-[#EBF2FA]'
                }`}
                title={previewingRingtoneId ? (isAr ? 'إيقاف' : 'Stop') : (isAr ? 'تجربة النغمة' : 'Preview')}
              >
                {previewingRingtoneId ? (
                  <Square className="w-3.5 h-3.5 fill-current" />
                ) : (
                  <Play className="w-3.5 h-3.5 fill-current" />
                )}
                <span>{previewingRingtoneId ? (isAr ? 'إيقاف' : 'Stop') : (isAr ? 'سماع' : 'Hear')}</span>
              </button>
            </div>
          </div>

          {/* Description / Notes */}
          <div className="relative">
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={isAr ? 'إضافة ملاحظة أو تفاصيل (اختياري)...' : 'Add note or details (optional)...'}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200/90 rounded-2xl text-xs text-[#354052] placeholder:text-slate-400 focus:outline-none focus:border-[#3B6CB4] focus:bg-white transition-all resize-none shadow-2xs"
            />
          </div>

          {/* Full-width 'Save Task' Action Button */}
          <button
            type="submit"
            className="w-full h-13 rounded-2xl text-white font-bold text-sm flex items-center justify-center transition-all active:scale-[0.98] cursor-pointer mt-2"
            style={{
              backgroundColor: '#3B6CB4',
              boxShadow: '0 8px 24px -4px rgba(59, 108, 180, 0.45), 0 2px 6px 0 rgba(59, 108, 180, 0.2)',
            }}
          >
            <span>{isAr ? 'حفظ المهمة' : 'Save Task'}</span>
          </button>
        </form>

        {/* 1. Interactive Time Picker Modal */}
        <TimePickerModal
          isOpen={isTimePickerOpen}
          initialTime={time}
          onClose={() => setIsTimePickerOpen(false)}
          onConfirm={handleTimeConfirm}
          language={language}
        />

        {/* 2. Interactive Calendar Date Picker Modal */}
        <DatePickerModal
          isOpen={isDatePickerOpen}
          selectedDate={date}
          selectedRepeat={repeat}
          onClose={() => setIsDatePickerOpen(false)}
          onConfirm={handleDateConfirm}
          language={language}
        />
      </div>
    </div>
  );
};
