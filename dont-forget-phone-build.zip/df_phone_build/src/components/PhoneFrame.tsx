import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor, Sparkles, Volume2 } from 'lucide-react';
import { playChimeSound } from '../utils/audio';

interface PhoneFrameProps {
  children: React.ReactNode;
  activeScreenName?: string;
}

export const PhoneFrame: React.FC<PhoneFrameProps> = ({ children }) => {
  const [deviceMode, setDeviceMode] = useState<'phone' | 'fluid'>('phone');
  const [currentTime, setCurrentTime] = useState('9:41');

  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      let hours = d.getHours();
      const mins = d.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${mins}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col justify-between">
      {/* Desktop Top Toolbar (Hidden on actual mobile screens < 768px) */}
      <div className="hidden md:flex items-center justify-between px-6 py-3 bg-white/80 backdrop-blur-md border-b border-slate-200/80 sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-lg bg-[#354052] flex items-center justify-center text-white">
            <span className="text-xs font-bold text-[#F3D58A]">لا</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-[#354052] tracking-tight">
                DON&apos;T FORGET
              </span>
              <span className="text-xs text-[#718096] font-medium">· لا تنسَ</span>
            </div>
            <p className="text-[11px] text-[#718096]">
              Mobile Productivity & Reminder App · Don&apos;t Forget
            </p>
          </div>
        </div>

        {/* Viewport switch and Bell Chime Trigger */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => playChimeSound()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-[#354052] bg-slate-50 hover:bg-[#F3D58A]/20 border border-slate-200 transition-colors"
            title="Test golden bell chime"
          >
            <Volume2 className="w-3.5 h-3.5 text-[#bfa04a]" />
            <span>Test Chime</span>
          </button>

          <div className="flex items-center p-1 bg-slate-100 rounded-lg border border-slate-200/70">
            <button
              onClick={() => setDeviceMode('phone')}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-all ${
                deviceMode === 'phone'
                  ? 'bg-white text-[#354052] shadow-xs'
                  : 'text-[#718096] hover:text-[#354052]'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Mobile Mockup</span>
            </button>
            <button
              onClick={() => setDeviceMode('fluid')}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-all ${
                deviceMode === 'fluid'
                  ? 'bg-white text-[#354052] shadow-xs'
                  : 'text-[#718096] hover:text-[#354052]'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Fluid Responsive</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Canvas Container */}
      <main className="flex-1 flex items-center justify-center p-0 md:p-6 lg:p-8">
        {deviceMode === 'phone' ? (
          /* Phone Mockup Frame on Desktop / Native Fullscreen on Mobile */
          <div className="w-full h-screen md:h-[844px] md:max-w-[390px] bg-white md:rounded-[48px] md:border-[10px] md:border-[#C4DCF6] md:shadow-[0_25px_60px_-15px_rgba(59,108,180,0.35)] md:ring-1 md:ring-blue-200/50 flex flex-col overflow-hidden relative">
            
            {/* Phone Top Bezel / Dynamic Island / Status Bar */}
            <div className="w-full pt-3 px-6 pb-2 flex items-center justify-between text-xs text-[#354052] font-semibold select-none z-30 shrink-0 bg-[#F4F8FD]/90 backdrop-blur-md">
              <span className="text-[13px] tracking-tight">{currentTime}</span>

              {/* Dynamic Island pill */}
              <div className="w-24 h-5 bg-black rounded-full flex items-center justify-center gap-2">
                <div className="w-2 h-2 rounded-full bg-slate-900" />
                <div className="w-2.5 h-2.5 rounded-full bg-slate-900 ring-1 ring-slate-800" />
              </div>

              {/* Battery & Signal icons */}
              <div className="flex items-center gap-1.5 text-[11px]">
                <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 3c-4.97 0-9 4.03-9 9 0 2.12.74 4.07 1.97 5.61L12 22l7.03-4.39C20.26 16.07 21 14.12 21 12c0-4.97-4.03-9-9-9z" opacity="0.3"/>
                  <path d="M12 6c-3.31 0-6 2.69-6 6 0 1.41.49 2.71 1.32 3.74L12 18.5l4.68-2.76C17.51 14.71 18 13.41 18 12c0-3.31-2.69-6-6-6z"/>
                </svg>
                <div className="w-5 h-2.5 border border-current rounded-xs p-0.5 flex items-center">
                  <div className="h-full w-full bg-current rounded-2xs" />
                </div>
              </div>
            </div>

            {/* Inner App Content Screen */}
            <div className="flex-1 flex flex-col overflow-y-auto relative">
              {children}
            </div>

            {/* iOS Bottom Home Bar */}
            <div className="w-full py-2 bg-white flex justify-center shrink-0 z-30">
              <div className="w-32 h-1 bg-slate-300 rounded-full" />
            </div>
          </div>
        ) : (
          /* Fluid responsive container */
          <div className="w-full max-w-2xl min-h-[640px] bg-white rounded-3xl shadow-xl border border-slate-200/80 overflow-hidden flex flex-col my-4">
            {children}
          </div>
        )}
      </main>
    </div>
  );
};
