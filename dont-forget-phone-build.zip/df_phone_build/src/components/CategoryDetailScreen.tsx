import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Check, Plus, Clock, Calendar, Repeat, Sparkles, Filter, CheckCircle2, AlertCircle, Camera, ChevronLeft, ChevronRight } from 'lucide-react';
import { TaskItem, CategoryType, Language } from '../types';
import { CATEGORY_STYLES } from '../utils/data';
import { CategoryIcon } from './CategoryIcon';
import { isTaskOverdue } from '../utils/dateUtils';

interface CategoryDetailScreenProps {
  category: CategoryType;
  tasks: TaskItem[];
  onToggleTask: (id: string) => void;
  onBack: () => void;
  onOpenAddTask: (defaultCategory?: CategoryType) => void;
  onOpenHealthDashboard?: () => void;
  language: Language;
}

export const CategoryDetailScreen: React.FC<CategoryDetailScreenProps> = ({
  category,
  tasks,
  onToggleTask,
  onBack,
  onOpenAddTask,
  onOpenHealthDashboard,
  language,
}) => {
  const isAr = language === 'ar';
  const catStyle = CATEGORY_STYLES[category] || CATEGORY_STYLES.other;

  // Filter within this category: 'all' | 'pending' | 'completed'
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'completed'>('all');

  // Filter tasks specifically belonging to this category
  const categoryTasks = tasks.filter((t) => t.category === category);
  const totalCount = categoryTasks.length;
  const completedCount = categoryTasks.filter((t) => t.completed).length;
  const pendingCount = totalCount - completedCount;
  const completionPercentage = totalCount === 0 ? 0 : Math.round((completedCount / totalCount) * 100);

  const displayedTasks = categoryTasks.filter((t) => {
    if (filterStatus === 'pending') return !t.completed;
    if (filterStatus === 'completed') return t.completed;
    return true;
  });

  // Category subtitles / descriptions
  const categoryDescriptions: Record<CategoryType, { ar: string; en: string }> = {
    habits: {
      ar: 'بناء وتتبع العادات اليومية الإيجابية والمستمرة',
      en: 'Build and track consistent daily positive habits',
    },
    mind: {
      ar: 'جلسات التركيز العميق، التخطيط، والإنتاجية الذهنية',
      en: 'Deep focus sessions, planning, and mental productivity',
    },
    work: {
      ar: 'متابعة مشاريع العمل والاجتماعات والمهام اليومية',
      en: 'Track work projects, meetings, and daily deliverables',
    },
    study: {
      ar: 'مراجعة الدروس والتحضير للاختبارات والأبحاث',
      en: 'Review lectures, prepare for exams, and research',
    },
    health: {
      ar: 'العناية باللياقة، التغذية، ومواعيد الأطباء',
      en: 'Fitness sessions, hydration, and doctor appointments',
    },
    home: {
      ar: 'مستلزمات المنزل، الصيانة، والفواتير الأسرية',
      en: 'Home errands, maintenance, and family bills',
    },
    personal: {
      ar: 'الأهداف الخاصة، التواصل مع الأصدقاء، والهوايات',
      en: 'Personal goals, catching up with friends, and hobbies',
    },
    other: {
      ar: 'تذكيرات متنوعة وملاحظات عامة',
      en: 'Miscellaneous reminders and general notes',
    },
  };

  const currentDesc = categoryDescriptions[category] || categoryDescriptions.other;

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="flex-1 flex flex-col bg-white text-[#354052] px-5 py-4 overflow-y-auto select-none pb-24"
      style={{ backgroundColor: '#FFFFFF' }}
    >
      {/* Top Header with Clean Back Button and Category Action */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <button
          onClick={onBack}
          className="min-h-[44px] min-w-[44px] rounded-full flex items-center justify-center text-[#718096] hover:bg-slate-50 hover:text-[#354052] transition-colors cursor-pointer"
          aria-label={isAr ? 'العودة إلى قائمة الفئات' : 'Back to categories'}
          title={isAr ? 'العودة إلى الفئات' : 'Back to categories'}
        >
          {isAr ? <ArrowRight className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
        </button>

        <div className="flex items-center gap-2">
          <div
            className="w-7 h-7 rounded-lg flex items-center justify-center"
            style={{ backgroundColor: catStyle.bgTint }}
          >
            <CategoryIcon category={category} size="sm" className="!bg-transparent !border-0 !shadow-none !p-0" />
          </div>
          <h1 className="text-lg font-bold text-[#354052]">
            {isAr ? catStyle.titleAr : catStyle.titleEn}
          </h1>
        </div>

        <button
          onClick={() => onOpenAddTask(category)}
          className="w-10 h-10 rounded-2xl flex items-center justify-center transition-all shadow-xs cursor-pointer active:scale-95 text-white"
          style={{
            backgroundColor: '#3B6CB4',
            boxShadow: '0 4px 14px -2px rgba(59, 108, 180, 0.35)',
          }}
          title={isAr ? 'إضافة مهمة جديدة في هذا القسم' : 'Add task in this category'}
          aria-label={isAr ? 'إضافة مهمة' : 'Add task'}
        >
          <Plus className="w-5 h-5 stroke-[2.5]" />
        </button>
      </div>

      {/* Category Hero / Progress Card */}
      <div
        className="mt-4 p-4.5 rounded-3xl transition-all relative overflow-hidden"
        style={{
          backgroundColor: catStyle.bgTint,
          border: `1px solid ${catStyle.borderColor}`,
          boxShadow: `0 10px 28px -6px ${catStyle.glowColor}`,
        }}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3.5">
            <div className="w-13 h-13 rounded-2xl bg-white flex items-center justify-center shadow-xs border border-white shrink-0">
              <CategoryIcon category={category} size="lg" className="!bg-transparent !border-0 !shadow-none" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base font-bold text-[#354052]">
                  {isAr ? `قسم ${catStyle.titleAr}` : `${catStyle.titleEn} Category`}
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#F3D58A]" />
              </div>
              <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                {isAr ? currentDesc.ar : currentDesc.en}
              </p>
            </div>
          </div>
        </div>

        {/* Progress & Metrics Strip */}
        <div className="mt-4 pt-3.5 border-t border-black/5">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-semibold text-[#354052]">
              {isAr ? 'نسبة الإنجاز' : 'Completion Rate'}
            </span>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold text-slate-500">
                {completedCount}/{totalCount} {isAr ? 'مكتملة' : 'done'}
              </span>
              <span
                className="font-extrabold px-2 py-0.5 rounded-full text-[11px]"
                style={{
                  backgroundColor: '#FFFFFF',
                  color: catStyle.iconColor,
                }}
              >
                {completionPercentage}%
              </span>
            </div>
          </div>

          {/* Linear Progress Bar */}
          <div className="w-full h-2 rounded-full bg-white/70 overflow-hidden p-0.5">
            <div
              className="h-full rounded-full transition-all duration-700 ease-out"
              style={{
                width: `${completionPercentage}%`,
                backgroundColor: catStyle.iconColor,
              }}
            />
          </div>
        </div>
      </div>

      {/* Health & Calorie Dashboard Callout (Exclusive for Health category) */}
      {category === 'health' && onOpenHealthDashboard && (
        <div
          onClick={onOpenHealthDashboard}
          className="mt-4 p-4 rounded-3xl border transition-all duration-200 cursor-pointer flex items-center justify-between group active:scale-98"
          style={{
            backgroundColor: '#EBF2FA',
            borderColor: 'rgba(59, 108, 180, 0.3)',
            boxShadow: '0 8px 24px -4px rgba(59, 108, 180, 0.16)',
          }}
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#3B6CB4] text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
              <Camera className="w-6 h-6 stroke-[2.3]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold text-[#354052]">
                  {isAr ? 'لوحة السعرات والماكروز اليومية' : 'Calorie & Macros Dashboard'}
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#F3D58A]" />
              </div>
              <p className="text-xs text-[#3B6CB4] font-medium mt-0.5">
                {isAr
                  ? 'مقياس قوسي للسعرات + ماسح الوجبات بالكاميرا'
                  : 'Semi-circular arc gauge + AI camera food scanner'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 text-[#3B6CB4] font-bold text-xs bg-white px-3 py-1.5 rounded-xl shadow-2xs">
            <span>{isAr ? 'فتح' : 'Open'}</span>
            {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </div>
        </div>
      )}

      {/* Status Filter Segmented Controls */}
      <div className="mt-6 flex items-center justify-between gap-1.5 p-1 bg-slate-50 rounded-2xl border border-slate-100">
        <button
          type="button"
          onClick={() => setFilterStatus('all')}
          className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
            filterStatus === 'all'
              ? 'bg-white text-[#3B6CB4] shadow-xs'
              : 'text-slate-500 hover:text-[#354052]'
          }`}
        >
          {isAr ? `الكل (${totalCount})` : `All (${totalCount})`}
        </button>

        <button
          type="button"
          onClick={() => setFilterStatus('pending')}
          className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
            filterStatus === 'pending'
              ? 'bg-white text-[#3B6CB4] shadow-xs'
              : 'text-slate-500 hover:text-[#354052]'
          }`}
        >
          {isAr ? `قيد الإنجاز (${pendingCount})` : `Pending (${pendingCount})`}
        </button>

        <button
          type="button"
          onClick={() => setFilterStatus('completed')}
          className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
            filterStatus === 'completed'
              ? 'bg-white text-[#3B6CB4] shadow-xs'
              : 'text-slate-500 hover:text-[#354052]'
          }`}
        >
          {isAr ? `المكتملة (${completedCount})` : `Done (${completedCount})`}
        </button>
      </div>

      {/* Filtered Tasks List */}
      <div className="mt-4">
        {displayedTasks.length === 0 ? (
          <div className="py-12 px-4 text-center bg-slate-50/80 rounded-3xl border border-slate-100 mt-2">
            <div
              className="w-12 h-12 rounded-2xl mx-auto flex items-center justify-center mb-2.5"
              style={{ backgroundColor: catStyle.bgTint }}
            >
              <CategoryIcon category={category} size="md" className="!bg-transparent !border-0 !shadow-none" />
            </div>
            <p className="font-bold text-sm text-[#354052]">
              {filterStatus === 'completed'
                ? isAr
                  ? 'لم تكتمل أي مهام في هذا القسم بعد'
                  : 'No completed tasks in this category yet'
                : filterStatus === 'pending'
                ? isAr
                  ? 'رائع! لا توجد مهام معلقة في هذا القسم'
                  : 'Great! No pending tasks in this category'
                : isAr
                ? 'لا توجد مهام مضافة في هذا القسم'
                : 'No tasks added in this category yet'}
            </p>
            <p className="text-xs text-slate-400 mt-1">
              {isAr ? 'ابدأ بتنظيم وتدوين مهامك ومواعيدك هنا' : 'Start organizing and scheduling your reminders here'}
            </p>
            <button
              onClick={() => onOpenAddTask(category)}
              className="mt-4 px-4 py-2 rounded-2xl text-xs font-bold text-white transition-all inline-flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
              style={{
                backgroundColor: '#3B6CB4',
                boxShadow: '0 4px 14px -2px rgba(59, 108, 180, 0.35)',
              }}
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>{isAr ? `إضافة مهمة في قسم ${catStyle.titleAr}` : `Add ${catStyle.titleEn} Task`}</span>
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {displayedTasks.map((task) => {
              const isCompleted = task.completed;
              const isOverdue = !isCompleted && isTaskOverdue(task);

              return (
                <div
                  key={task.id}
                  onClick={() => onToggleTask(task.id)}
                  className={`p-4 rounded-2xl border transition-all duration-200 flex items-start justify-between cursor-pointer gap-3 ${
                    isCompleted
                      ? 'bg-slate-50/70 border-slate-100 opacity-65'
                      : isOverdue
                      ? 'bg-rose-50/20 border-rose-200/90 hover:border-rose-300 hover:-translate-y-0.5'
                      : 'bg-white border-slate-100/90 hover:border-[#3B6CB4]/40 hover:-translate-y-0.5'
                  }`}
                  style={{
                    boxShadow: isCompleted
                      ? 'none'
                      : isOverdue
                      ? '0 6px 18px -4px rgba(225, 29, 72, 0.08), 0 2px 6px -2px rgba(225, 29, 72, 0.04)'
                      : '0 6px 18px -4px rgba(0, 0, 0, 0.04), 0 2px 6px -2px rgba(59, 108, 180, 0.08)',
                  }}
                >
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <div className="mt-0.5 shrink-0">
                      <CategoryIcon
                        category={task.category}
                        iconOverride={task.iconType}
                        size="md"
                      />
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3
                          className={`text-sm font-bold truncate transition-colors ${
                            isCompleted ? 'line-through text-slate-400' : 'text-[#354052]'
                          }`}
                        >
                          {task.title}
                        </h3>

                        {/* Overdue visual indicator badge with small red exclamation icon */}
                        {isOverdue && (
                          <span
                            className="shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-md bg-rose-50 text-rose-600 border border-rose-200/90 flex items-center gap-1 shadow-2xs"
                            title={isAr ? 'مهمة تجاوزت وقتها المحدد أو تاريخ استحقاقها' : 'Overdue task - deadline passed'}
                          >
                            <AlertCircle className="w-3 h-3 text-rose-500 stroke-[2.8]" />
                            <span>{isAr ? 'فات موعدها' : 'Overdue'}</span>
                          </span>
                        )}

                        {/* Champagne Gold priority badge */}
                        {task.priority === 'high' && !isCompleted && !isOverdue && (
                          <span className="shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#F3D58A]/30 text-[#8C6D1F] border border-[#F3D58A]/60 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#e2be67]" />
                            <span>{isAr ? 'هام' : 'Priority'}</span>
                          </span>
                        )}
                      </div>

                      {/* Optional task description / notes */}
                      {task.description && (
                        <p className={`text-xs mt-1 line-clamp-2 ${isCompleted ? 'text-slate-400 line-through' : 'text-slate-500'}`}>
                          {task.description}
                        </p>
                      )}

                      {/* Metadata Row: time, date, recurrence */}
                      <div className="flex items-center gap-2 mt-2 flex-wrap">
                        <span className={`text-[11px] font-medium flex items-center gap-1 ${isOverdue ? 'text-rose-600 font-bold' : 'text-slate-400'}`}>
                          <Clock className={`w-3 h-3 ${isOverdue ? 'text-rose-500' : 'text-slate-400'}`} />
                          <span>{task.time}</span>
                        </span>

                        <span className="text-slate-200 text-xs">·</span>

                        <span className={`text-[11px] font-medium flex items-center gap-1 ${isOverdue ? 'text-rose-600 font-bold' : 'text-slate-400'}`}>
                          <Calendar className={`w-3 h-3 ${isOverdue ? 'text-rose-500' : 'text-slate-400'}`} />
                          <span>{task.date}</span>
                        </span>

                        {task.repeat !== 'once' && (
                          <>
                            <span className="text-slate-200 text-xs">·</span>
                            <span className="text-[10px] font-semibold text-slate-500 flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-slate-100">
                              <Repeat className="w-2.5 h-2.5 text-slate-400" />
                              <span>
                                {task.repeat === 'daily'
                                  ? isAr ? 'يومياً' : 'Daily'
                                  : task.repeat === 'weekly'
                                  ? isAr ? 'أسبوعياً' : 'Weekly'
                                  : isAr ? 'شهرياً' : 'Monthly'}
                              </span>
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Circular Checkbox */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleTask(task.id);
                    }}
                    className={`w-6 h-6 rounded-full flex items-center justify-center transition-all shrink-0 mt-1 cursor-pointer ${
                      isCompleted
                        ? 'bg-[#3B6CB4] text-white shadow-xs shadow-[#3B6CB4]/40'
                        : isOverdue
                        ? 'border-2 border-rose-300 hover:border-rose-500 bg-white'
                        : 'border-2 border-slate-300 hover:border-[#3B6CB4] bg-white'
                    }`}
                    aria-label={isCompleted ? 'Mark incomplete' : 'Mark complete'}
                  >
                    {isCompleted && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
