import React, { useState } from 'react';
import { Calendar as CalendarIcon, X, Check, ChevronLeft, ChevronRight, Repeat } from 'lucide-react';
import { Language } from '../types';
import { playChimeSound } from '../utils/audio';

interface DatePickerModalProps {
  isOpen: boolean;
  selectedDate: string; // e.g. "2026-11-06"
  selectedRepeat: 'once' | 'daily' | 'weekly' | 'monthly';
  onClose: () => void;
  onConfirm: (formattedDate: string, repeat: 'once' | 'daily' | 'weekly' | 'monthly') => void;
  language: Language;
}

export const DatePickerModal: React.FC<DatePickerModalProps> = ({
  isOpen,
  selectedDate,
  selectedRepeat,
  onClose,
  onConfirm,
  language,
}) => {
  const isAr = language === 'ar';

  // Parse initial date, e.g. "2026-11-06"
  const parseDate = () => {
    try {
      const parts = selectedDate.split('-');
      const y = parseInt(parts[0], 10) || 2026;
      const m = parseInt(parts[1], 10) || 11;
      const d = parseInt(parts[2], 10) || 6;
      return { y, m, d };
    } catch {
      return { y: 2026, m: 11, d: 6 };
    }
  };

  const initial = parseDate();
  const [activeYear, setActiveYear] = useState<number>(initial.y);
  const [activeMonth, setActiveMonth] = useState<number>(initial.m); // 1-12
  const [activeDay, setActiveDay] = useState<number>(initial.d);
  const [repeat, setRepeat] = useState<'once' | 'daily' | 'weekly' | 'monthly'>(selectedRepeat || 'once');

  if (!isOpen) return null;

  // Month names
  const monthNamesAr = ['', 'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  const monthNamesEn = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  const monthLabel = isAr
    ? `${monthNamesAr[activeMonth]} ${activeYear}`
    : `${monthNamesEn[activeMonth]} ${activeYear}`;

  // Days of week header matching the concept image
  const daysOfWeekAr = ['الجمعة', 'الخميس', 'الأربعاء', 'الثلاثاء', 'الاثنين', 'الأحد', 'السبت'];
  const daysOfWeekEn = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const daysHeader = isAr ? daysOfWeekAr : daysOfWeekEn;

  // Calendar dates matrix for November 2026
  const calendarDays = [
    [null, null, 1, 2, 3, 4, 5],
    [6, 7, 8, 9, 10, 11, 12],
    [13, 14, 15, 16, 17, 18, 19],
    [20, 21, 22, 23, 24, 25, 26],
    [27, 28, 29, 30, null, null, null],
  ];

  const handlePrevMonth = () => {
    if (activeMonth === 1) {
      setActiveMonth(12);
      setActiveYear((prev) => prev - 1);
    } else {
      setActiveMonth((prev) => prev - 1);
    }
    playChimeSound();
  };

  const handleNextMonth = () => {
    if (activeMonth === 12) {
      setActiveMonth(1);
      setActiveYear((prev) => prev + 1);
    } else {
      setActiveMonth((prev) => prev + 1);
    }
    playChimeSound();
  };

  const handleSelectDay = (day: number) => {
    setActiveDay(day);
    playChimeSound();
  };

  const handleQuickPreset = (dayOffset: number, presetRepeat: 'once' | 'daily' | 'weekly') => {
    setActiveDay(6 + dayOffset);
    setRepeat(presetRepeat);
    playChimeSound();
  };

  const handleConfirm = () => {
    playChimeSound();
    const formatted = `${activeYear}-${activeMonth.toString().padStart(2, '0')}-${activeDay.toString().padStart(2, '0')}`;
    onConfirm(formatted, repeat);
    onClose();
  };

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="fixed inset-0 z-60 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4 animate-in fade-in duration-150"
    >
      <div
        className="w-full max-w-sm bg-white rounded-2xl p-5 shadow-2xl border border-slate-100 animate-in zoom-in-95 duration-150 max-h-[92vh] overflow-y-auto"
        style={{
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#EBF2FA] text-[#3B6CB4] flex items-center justify-center">
              <CalendarIcon className="w-4.5 h-4.5 stroke-[2.2]" />
            </div>
            <h3 className="text-base font-bold text-[#354052]">
              {isAr ? 'تحديد التاريخ والجدولة' : 'Select Date & Repeat'}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Date Presets */}
        <div className="my-3.5 flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <button
            type="button"
            onClick={() => handleQuickPreset(0, 'once')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeDay === 6
                ? 'bg-[#3B6CB4] text-white shadow-xs'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-100'
            }`}
          >
            {isAr ? 'اليوم (6 نوفمبر)' : 'Today (Nov 6)'}
          </button>
          <button
            type="button"
            onClick={() => handleQuickPreset(1, 'once')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeDay === 7
                ? 'bg-[#3B6CB4] text-white shadow-xs'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-100'
            }`}
          >
            {isAr ? 'غداً' : 'Tomorrow'}
          </button>
          <button
            type="button"
            onClick={() => handleQuickPreset(2, 'weekly')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              activeDay === 8
                ? 'bg-[#3B6CB4] text-white shadow-xs'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-100'
            }`}
          >
            {isAr ? 'عطلة نهاية الأسبوع' : 'Weekend'}
          </button>
        </div>

        {/* Month Navigator */}
        <div className="flex items-center justify-between p-2 rounded-2xl bg-slate-50 border border-slate-100 mb-3">
          <button
            type="button"
            onClick={handlePrevMonth}
            className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-500 hover:bg-white hover:text-[#3B6CB4] transition-colors cursor-pointer"
            aria-label="Previous month"
          >
            {isAr ? <ChevronRight className="w-4.5 h-4.5" /> : <ChevronLeft className="w-4.5 h-4.5" />}
          </button>

          <span className="text-xs font-bold text-[#354052]">
            {monthLabel}
          </span>

          <button
            type="button"
            onClick={handleNextMonth}
            className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-500 hover:bg-white hover:text-[#3B6CB4] transition-colors cursor-pointer"
            aria-label="Next month"
          >
            {isAr ? <ChevronLeft className="w-4.5 h-4.5" /> : <ChevronRight className="w-4.5 h-4.5" />}
          </button>
        </div>

        {/* Days of Week Header */}
        <div className="grid grid-cols-7 text-center mb-1.5">
          {daysHeader.map((d, i) => (
            <span key={i} className="text-[10px] font-bold text-slate-400">
              {d}
            </span>
          ))}
        </div>

        {/* Calendar Matrix */}
        <div className="space-y-1 mb-4">
          {calendarDays.map((week, wIdx) => (
            <div key={wIdx} className="grid grid-cols-7 text-center">
              {week.map((day, dIdx) => {
                if (!day) return <div key={dIdx} className="h-8 w-8 mx-auto" />;
                const isSelected = activeDay === day;
                const isToday = day === 6;

                return (
                  <button
                    key={dIdx}
                    type="button"
                    onClick={() => handleSelectDay(day)}
                    className={`h-8 w-8 mx-auto rounded-full text-xs font-bold flex flex-col items-center justify-center transition-all cursor-pointer relative ${
                      isSelected
                        ? 'bg-[#3B6CB4] text-white shadow-md shadow-[#3B6CB4]/40 scale-105'
                        : isToday
                        ? 'bg-[#EBF2FA] text-[#3B6CB4] border border-[#3B6CB4]/40 font-extrabold'
                        : 'text-[#354052] hover:bg-slate-100'
                    }`}
                  >
                    <span>{day}</span>
                    {isToday && !isSelected && (
                      <span className="w-1 h-1 rounded-full bg-[#F3D58A] absolute bottom-0.5" />
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        {/* Recurrence Selector */}
        <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 mb-4">
          <div className="flex items-center gap-2 mb-2 text-xs font-bold text-[#354052]">
            <Repeat className="w-3.5 h-3.5 text-[#3B6CB4]" />
            <span>{isAr ? 'تكرار المهمة' : 'Recurrence'}</span>
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { id: 'once', labelAr: 'مرة واحدة', labelEn: 'Once' },
              { id: 'daily', labelAr: 'يومياً', labelEn: 'Daily' },
              { id: 'weekly', labelAr: 'أسبوعياً', labelEn: 'Weekly' },
            ].map((opt) => {
              const isSelected = repeat === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setRepeat(opt.id as any)}
                  className={`py-1.5 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#3B6CB4] text-white shadow-xs'
                      : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {isAr ? opt.labelAr : opt.labelEn}
                </button>
              );
            })}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 h-11 rounded-2xl text-xs font-semibold text-slate-500 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            {isAr ? 'إلغاء' : 'Cancel'}
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            className="flex-1 h-11 rounded-2xl text-xs font-bold text-white bg-[#3B6CB4] hover:brightness-105 shadow-md shadow-[#3B6CB4]/35 flex items-center justify-center gap-1.5 transition-all active:scale-98 cursor-pointer"
          >
            <Check className="w-4 h-4 stroke-[2.5]" />
            <span>{isAr ? 'تأكيد التاريخ' : 'Confirm Date'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
