import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Check, Clock, Sparkles, AlertCircle } from 'lucide-react';
import { TaskItem, Language } from '../types';
import { playChimeSound } from '../utils/audio';
import { CategoryIcon } from './CategoryIcon';
import { CATEGORY_STYLES, PRIORITY_STYLES } from '../utils/data';
import { isTaskOverdue } from '../utils/dateUtils';

interface CalendarScreenProps {
  tasks: TaskItem[];
  onToggleTask: (id: string) => void;
  language: Language;
}

export const CalendarScreen: React.FC<CalendarScreenProps> = ({
  tasks,
  onToggleTask,
  language,
}) => {
  const isAr = language === 'ar';
  const today = new Date();
  const [selectedDay, setSelectedDay] = useState<number>(today.getDate());
  const currentMonth = today.toLocaleDateString(isAr ? 'ar-EG' : 'en-US', { month: 'long', year: 'numeric' });
  const todayFormatted = today.toLocaleDateString(isAr ? 'ar-EG' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric' });

  // Days of week header matching the concept image
  const daysOfWeekAr = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
  const daysOfWeekEn = ['Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  const daysHeader = isAr ? daysOfWeekAr : daysOfWeekEn;

  // Calendar dates matrix
  const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
  const firstDayIndex = new Date(today.getFullYear(), today.getMonth(), 1).getDay();
  // Build calendar weeks
  const calendarDays: (number | null)[][] = [];
  let currentWeek: (number | null)[] = [];
  for (let i = 0; i < (firstDayIndex + 1) % 7; i++) {
    currentWeek.push(null);
  }
  for (let d = 1; d <= daysInMonth; d++) {
    currentWeek.push(d);
    if (currentWeek.length === 7) {
      calendarDays.push(currentWeek);
      currentWeek = [];
    }
  }
  if (currentWeek.length > 0) {
    while (currentWeek.length < 7) {
      currentWeek.push(null);
    }
    calendarDays.push(currentWeek);
  }

  const handleSelectDay = (day: number) => {
    setSelectedDay(day);
    playChimeSound();
  };

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="flex-1 flex flex-col bg-white text-[#354052] px-5 py-4 overflow-y-auto select-none pb-24"
      style={{ backgroundColor: '#FFFFFF' }}
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-bold text-[#354052]">
            {isAr ? 'التقويم' : 'Calendar'}
          </h1>
          <span className="w-1.5 h-1.5 rounded-full bg-[#F3D58A]" />
        </div>

        <div className="w-10 h-10 rounded-2xl bg-[#EBF2FA] border border-[#3B6CB4]/30 flex items-center justify-center text-[#3B6CB4] shadow-xs">
          <CalendarIcon className="w-5 h-5 stroke-[2.2]" />
        </div>
      </div>

      {/* Month Navigator */}
      <div className="flex items-center justify-between mt-4 px-2">
        <button
          onClick={() => playChimeSound()}
          className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          aria-label="Previous month"
        >
          {isAr ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
        </button>
        <div className="flex items-center gap-1.5">
          <span className="text-sm font-bold text-[#354052] tracking-wide">
            {currentMonth}
          </span>
          <span className="w-1 h-1 rounded-full bg-[#F3D58A]" />
        </div>
        <button
          onClick={() => playChimeSound()}
          className="w-8 h-8 rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          aria-label="Next month"
        >
          {isAr ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
        </button>
      </div>

      {/* Calendar Grid Container with Subtle Floating Layer Shadow */}
      <div
        className="mt-4 p-4 rounded-2xl bg-white border border-slate-100 transition-all"
        style={{
          boxShadow: '0 10px 28px -6px rgba(59, 108, 180, 0.1), 0 2px 8px -2px rgba(0, 0, 0, 0.02)',
        }}
      >
        {/* Days of Week Row */}
        <div className="grid grid-cols-7 text-center mb-3">
          {daysHeader.map((d, i) => (
            <span key={i} className="text-[11px] font-bold text-slate-400">
              {d}
            </span>
          ))}
        </div>

        {/* Days matrix */}
        <div className="space-y-1.5">
          {calendarDays.map((week, wIdx) => (
            <div key={wIdx} className="grid grid-cols-7 text-center">
              {week.map((day, dIdx) => {
                if (!day) {
                  return <div key={dIdx} className="h-9 w-9 mx-auto" />;
                }
                const isSelected = selectedDay === day;
                const isToday = day === today.getDate();
                return (
                  <button
                    key={dIdx}
                    onClick={() => handleSelectDay(day)}
                    className={`h-9 w-9 mx-auto rounded-full text-xs font-bold flex flex-col items-center justify-center transition-all cursor-pointer relative ${
                      isSelected
                        ? 'bg-[#3B6CB4] text-white shadow-md shadow-[#3B6CB4]/45 scale-105'
                        : isToday
                        ? 'text-[#3B6CB4] bg-[#EBF2FA] hover:bg-[#3B6CB4]/20'
                        : 'text-[#354052] hover:bg-slate-100'
                    }`}
                  >
                    <span>{day}</span>
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Scheduled Tasks for Selected Day */}
      <div className="mt-7">
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-[#354052]">
              {isAr ? `مهام اليوم (${tasks.length})` : `Tasks for Today (${tasks.length})`}
            </h2>
            <span className="w-1.5 h-1.5 rounded-full bg-[#F3D58A]" />
            {tasks.some((t) => !t.completed && isTaskOverdue(t)) && (
              <span className="text-[11px] font-bold text-rose-600 bg-rose-50 border border-rose-200/80 px-2 py-0.5 rounded-full flex items-center gap-1">
                <AlertCircle className="w-3 h-3 text-rose-500 stroke-[2.8]" />
                <span>{tasks.filter((t) => !t.completed && isTaskOverdue(t)).length} {isAr ? 'متأخرة' : 'overdue'}</span>
              </span>
            )}
          </div>
          <span className="text-xs font-semibold text-[#3B6CB4] bg-[#EBF2FA] px-3 py-1 rounded-full">
            {todayFormatted}
          </span>
        </div>

        <div className="space-y-3">
          {tasks.length === 0 ? (
            <div className="py-12 px-4 text-center rounded-2xl border border-dashed border-slate-200 bg-slate-50/50">
              <div className="w-12 h-12 rounded-2xl bg-[#EBF2FA] text-[#3B6CB4] mx-auto flex items-center justify-center mb-3">
                <CalendarIcon className="w-6 h-6 stroke-[1.8]" />
              </div>
              <h3 className="text-sm font-bold text-[#354052]">
                {isAr ? 'لا توجد مهام بعد' : 'No tasks scheduled yet'}
              </h3>
              <p className="text-xs text-slate-400 mt-1 max-w-[240px] mx-auto">
                {isAr ? 'اضغط على زر + بالأسفل لإضافة مهمتك الأولى' : 'Tap the + button below to add your first task'}
              </p>
            </div>
          ) : (
            tasks.map((task) => {
              const isCompleted = task.completed;
              const isOverdue = !isCompleted && isTaskOverdue(task);
              const catStyle = CATEGORY_STYLES[task.category] || CATEGORY_STYLES.other;
              const priorityStyle = PRIORITY_STYLES[task.priority || 'medium'];

              return (
                <div
                  key={task.id}
                  onClick={() => onToggleTask(task.id)}
                  className={`p-3.5 rounded-2xl border transition-all duration-200 flex items-center justify-between cursor-pointer ${
                    isCompleted
                      ? 'bg-slate-50/60 border-slate-100 opacity-60'
                      : isOverdue
                      ? 'bg-rose-50/20 border-rose-200 hover:border-rose-300 hover:-translate-y-0.5'
                      : 'bg-white border-slate-100/90 hover:-translate-y-0.5'
                  }`}
                  style={{
                    borderInlineStart: isCompleted
                      ? '4px solid #CBD5E1'
                      : `4px solid ${priorityStyle.accentBorderColor}`,
                    boxShadow: isCompleted
                      ? 'none'
                      : isOverdue
                      ? '0 6px 18px -4px rgba(225, 29, 72, 0.08), 0 2px 6px -2px rgba(225, 29, 72, 0.04)'
                      : priorityStyle.glowShadow,
                  }}
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    {/* Category / type icon with distinct color & light background */}
                    <CategoryIcon
                      category={task.category}
                      iconOverride={task.iconType}
                      size="md"
                    />

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3
                          className={`text-sm font-bold truncate transition-colors ${
                            isCompleted ? 'line-through text-slate-400' : 'text-[#354052]'
                          }`}
                        >
                          {task.title}
                        </h3>

                        {/* Overdue visual indicator badge */}
                        {isOverdue && (
                          <span
                            className="shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-md bg-rose-50 text-rose-600 border border-rose-200/90 flex items-center gap-1 shadow-2xs"
                            title={isAr ? 'مهمة تجاوزت وقتها المحدد أو تاريخ استحقاقها' : 'Overdue task - deadline passed'}
                          >
                            <AlertCircle className="w-3 h-3 text-rose-500 stroke-[2.8]" />
                            <span>{isAr ? 'فات موعدها' : 'Overdue'}</span>
                          </span>
                        )}

                        {/* Color-coded priority badge (Red for high, Yellow for medium, Blue for low) */}
                        {!isCompleted && !isOverdue && (
                          <span
                            className={`shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-md border flex items-center gap-1.5 shadow-2xs ${priorityStyle.badgeBg} ${priorityStyle.badgeText} ${priorityStyle.badgeBorder}`}
                            title={isAr ? priorityStyle.labelAr : priorityStyle.labelEn}
                          >
                            <span
                              className="w-1.5 h-1.5 rounded-full shrink-0"
                              style={{ backgroundColor: priorityStyle.dotColor }}
                            />
                            <span>{isAr ? priorityStyle.labelAr : priorityStyle.labelEn}</span>
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 mt-1">
                        <span className={`text-[11px] font-medium flex items-center gap-1 ${isOverdue ? 'text-rose-600 font-bold' : 'text-slate-400'}`}>
                          <Clock className={`w-3 h-3 ${isOverdue ? 'text-rose-500' : 'text-slate-400'}`} />
                          <span>{task.time}</span>
                        </span>
                        <span className="text-slate-200 text-xs">·</span>
                        <span
                          className="text-[10px] font-bold px-2 py-0.5 rounded-md"
                          style={{
                            backgroundColor: catStyle.bgTint,
                            color: catStyle.iconColor,
                          }}
                        >
                          {isAr ? catStyle.titleAr : catStyle.titleEn}
                        </span>
                      </div>
                    </div>
                  </div>

                {/* Check status indicator */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleTask(task.id);
                  }}
                  className={`w-6 h-6 rounded-full flex items-center justify-center transition-all shrink-0 mr-1 cursor-pointer ${
                    isCompleted
                      ? 'bg-[#3B6CB4] text-white shadow-xs shadow-[#3B6CB4]/40'
                      : isOverdue
                      ? 'border-2 border-rose-300 hover:border-rose-500 bg-white'
                      : 'border-2 border-slate-300 hover:border-[#3B6CB4] bg-white'
                  }`}
                >
                  {isCompleted && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </button>
              </div>
            );
          })
          )}
        </div>
      </div>
    </div>
  );
};
