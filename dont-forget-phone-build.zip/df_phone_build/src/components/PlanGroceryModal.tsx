import React, { useState } from 'react';
import { X, Check, ShoppingBag, Copy, Share2, CheckCircle2 } from 'lucide-react';
import { DailyHealthMealPlan } from '../types/health';
import { getGroceryListFromPlan } from '../utils/dailyPlanData';

interface PlanGroceryModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: DailyHealthMealPlan;
  language: 'ar' | 'en';
}

export const PlanGroceryModal: React.FC<PlanGroceryModalProps> = ({
  isOpen,
  onClose,
  plan,
  language,
}) => {
  const isAr = language === 'ar';
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const categories = getGroceryListFromPlan(plan);

  const toggleItem = (itemKey: string) => {
    setCheckedItems((prev) => ({
      ...prev,
      [itemKey]: !prev[itemKey],
    }));
  };

  const handleCopy = () => {
    let text = isAr ? `🛒 قائمة مشتريات الخطة الغذائية اليومية:\n\n` : `🛒 Daily Meal Plan Grocery List:\n\n`;
    categories.forEach((cat) => {
      const items = isAr ? cat.itemsAr : cat.itemsEn;
      if (items.length > 0) {
        text += `🔹 ${isAr ? cat.categoryAr : cat.categoryEn}:\n`;
        items.forEach((item) => {
          text += `  • ${item}\n`;
        });
        text += '\n';
      }
    });

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div
        className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[85vh] flex flex-col overflow-hidden border border-slate-100"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-[#2C5282]/10 text-[#2C5282] flex items-center justify-center shadow-xs">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-800">
                {isAr ? 'قائمة مشتريات الخطة' : 'Plan Grocery List'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {isAr
                  ? 'مستخلصة تلقائياً من مكونات وجباتك المخططة'
                  : 'Automatically derived from your planned meal ingredients'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200/60 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {categories.map((cat, catIdx) => {
            const items = isAr ? cat.itemsAr : cat.itemsEn;
            if (!items || items.length === 0) return null;

            return (
              <div key={catIdx} className="bg-slate-50/80 rounded-2xl p-3.5 border border-slate-100">
                <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-slate-200/60">
                  <span className="text-xs font-bold text-[#2C5282]">
                    {isAr ? cat.categoryAr : cat.categoryEn}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-white text-slate-600 font-semibold border border-slate-200">
                    {items.length} {isAr ? 'عنصر' : 'items'}
                  </span>
                </div>

                <div className="space-y-1.5">
                  {items.map((item, itemIdx) => {
                    const key = `${catIdx}_${itemIdx}`;
                    const isChecked = !!checkedItems[key];

                    return (
                      <button
                        key={itemIdx}
                        onClick={() => toggleItem(key)}
                        className={`w-full text-right flex items-center gap-2.5 p-2 rounded-xl transition-all cursor-pointer ${
                          isChecked
                            ? 'bg-emerald-50 text-emerald-800 opacity-60 line-through'
                            : 'bg-white hover:bg-slate-100/70 text-slate-700 shadow-2xs'
                        }`}
                        dir={isAr ? 'rtl' : 'ltr'}
                      >
                        <div
                          className={`w-4 h-4 rounded-md flex items-center justify-center border transition-colors ${
                            isChecked
                              ? 'bg-emerald-500 border-emerald-500 text-white'
                              : 'border-slate-300 bg-white'
                          }`}
                        >
                          {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                        <span className="text-xs font-medium flex-1">{item}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-slate-100 bg-white flex items-center gap-2.5">
          <button
            onClick={handleCopy}
            className="flex-1 py-3 px-4 rounded-2xl bg-[#2C5282] hover:bg-[#1E3A5F] active:scale-98 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
          >
            {copied ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                <span>{isAr ? 'تم النسخ للحافظة!' : 'Copied to Clipboard!'}</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>{isAr ? 'نسخ القائمة للمشاركة' : 'Copy Grocery List'}</span>
              </>
            )}
          </button>

          <button
            onClick={onClose}
            className="py-3 px-5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
          >
            {isAr ? 'إغلاق' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
