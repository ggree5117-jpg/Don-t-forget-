import React from 'react';
import { Briefcase, GraduationCap, HeartPulse, Home, User, LayoutGrid, Clock, Phone, FileText, Gift, Dumbbell, Activity, Smile, Brain } from 'lucide-react';
import { CategoryType } from '../types';
import { CATEGORY_STYLES } from '../utils/data';

interface CategoryIconProps {
  category: CategoryType | string;
  size?: 'sm' | 'md' | 'lg';
  iconOverride?: string;
  className?: string;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({
  category,
  size = 'md',
  iconOverride,
  className = '',
}) => {
  const catKey = (category in CATEGORY_STYLES ? category : 'other') as CategoryType;
  const style = CATEGORY_STYLES[catKey] || CATEGORY_STYLES.other;

  const sizeClasses = {
    sm: 'w-7 h-7 rounded-xl',
    md: 'w-10 h-10 rounded-2xl',
    lg: 'w-12 h-12 rounded-2xl',
  };

  const iconSizes = {
    sm: 'w-3.5 h-3.5',
    md: 'w-5 h-5',
    lg: 'w-6 h-6',
  };

  const renderIcon = () => {
    if (iconOverride === 'phone') return <Phone className={`${iconSizes[size]} stroke-[2.2]`} />;
    if (iconOverride === 'document') return <FileText className={`${iconSizes[size]} stroke-[2.2]`} />;
    if (iconOverride === 'gift') return <Gift className={`${iconSizes[size]} stroke-[2.2]`} />;

    switch (catKey) {
      case 'habits':
        return <Dumbbell className={`${iconSizes[size]} stroke-[2.2]`} />;
      case 'health':
        return <Activity className={`${iconSizes[size]} stroke-[2.2]`} />;
      case 'personal':
        return <Smile className={`${iconSizes[size]} stroke-[2.2]`} />;
      case 'mind':
        return <Brain className={`${iconSizes[size]} stroke-[2.2]`} />;
      case 'study':
        return <GraduationCap className={`${iconSizes[size]} stroke-[2.2]`} />;
      case 'work':
        return <Briefcase className={`${iconSizes[size]} stroke-[2.2]`} />;
      case 'home':
        return <Home className={`${iconSizes[size]} stroke-[2.2]`} />;
      default:
        return <LayoutGrid className={`${iconSizes[size]} stroke-[2.2]`} />;
    }
  };

  return (
    <div
      className={`flex items-center justify-center shrink-0 transition-transform ${sizeClasses[size]} ${className}`}
      style={{
        backgroundColor: style.bgTint,
        color: style.iconColor,
        border: `1px solid ${style.borderColor}`,
        boxShadow: `0 4px 12px -2px ${style.glowColor}`,
      }}
    >
      {renderIcon()}
    </div>
  );
};
