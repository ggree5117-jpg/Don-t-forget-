import React, { useState, useEffect } from 'react';
import {
  Settings,
  Globe,
  Bell,
  Volume2,
  Shield,
  LogOut,
  ArrowLeft,
  ArrowRight,
  Sparkles,
  RefreshCw,
  Target,
  User,
  Scale,
  Edit2,
  Music,
  Plus,
  Trash2,
  Play,
  Square,
  CheckCircle2,
  AlertTriangle,
  Check,
  X,
} from 'lucide-react';
import { Language, CustomAudioRecord } from '../types';
import { UserHealthProfile, HealthGoal } from '../types/health';
import {
  playChimeSound,
  startRingtone,
  stopRingtone,
  BUILT_IN_RINGTONES,
} from '../utils/audio';
import { getApiUrl } from '../config';
import type { AiSavingsStats } from '../utils/foodCache';
import { clearFoodCache, getFoodCacheSize, getSavingsStats } from '../utils/foodCache';
import { hasRemovedAds, setAdsRemoved } from '../utils/adManager';

interface SettingsScreenProps {
  language: Language;
  userProfile: UserHealthProfile;
  defaultRingtoneId?: string;
  customRingtones?: CustomAudioRecord[];
  onSelectDefaultRingtone?: (ringtoneId: string) => void;
  onAddCustomRingtone?: (file: File) => Promise<void>;
  onDeleteCustomRingtone?: (id: string) => Promise<void>;
  onUpdateProfile: (updates: Partial<UserHealthProfile>) => void;
  onLanguageChange: (lang: Language) => void;
  onBackToWelcome: () => void;
  onResetData: () => void;
  onTestAlarm?: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  language,
  userProfile,
  defaultRingtoneId = 'chime',
  customRingtones = [],
  onSelectDefaultRingtone,
  onAddCustomRingtone,
  onDeleteCustomRingtone,
  onUpdateProfile,
  onLanguageChange,
  onBackToWelcome,
  onResetData,
  onTestAlarm,
}) => {
  const isAr = language === 'ar';
  const [isConfirmResetOpen, setIsConfirmResetOpen] = useState(false);
  const [resetSuccessMessage, setResetSuccessMessage] = useState(false);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [userNameInput, setUserNameInput] = useState(userProfile.name || '');

  // Health targets editing in settings
  const [isEditingHealth, setIsEditingHealth] = useState(false);
  const [targetWeightInput, setTargetWeightInput] = useState(userProfile.targetWeight ? userProfile.targetWeight.toString() : '');
  const [currentWeightInput, setCurrentWeightInput] = useState(userProfile.currentWeight ? userProfile.currentWeight.toString() : '');
  const [startWeightInput, setStartWeightInput] = useState(userProfile.startWeight ? userProfile.startWeight.toString() : '');
  const [heightInput, setHeightInput] = useState(userProfile.heightCm ? userProfile.heightCm.toString() : '');
  const [caloriesInput, setCaloriesInput] = useState(userProfile.targetCalories ? userProfile.targetCalories.toString() : '');
  const [proteinInput, setProteinInput] = useState(userProfile.targetProtein ? userProfile.targetProtein.toString() : '');
  const [carbsInput, setCarbsInput] = useState(userProfile.targetCarbs ? userProfile.targetCarbs.toString() : '');
  const [fatsInput, setFatsInput] = useState(userProfile.targetFats ? userProfile.targetFats.toString() : '');
  const [goalInput, setGoalInput] = useState<HealthGoal | ''>(userProfile.goal || '');

  // Ringtone preview & upload state
  const [previewingRingtoneId, setPreviewingRingtoneId] = useState<string | null>(null);
  const [audioUploadError, setAudioUploadError] = useState<string | null>(null);
  const [isUploadingAudio, setIsUploadingAudio] = useState(false);
  const customAudioInputRef = React.useRef<HTMLInputElement | null>(null);

  // Stop ringtone on unmount
  useEffect(() => {
    return () => {
      stopRingtone();
    };
  }, []);

  const handleTogglePreview = (targetId: string, customBlob?: Blob) => {
    if (previewingRingtoneId === targetId) {
      stopRingtone();
      setPreviewingRingtoneId(null);
    } else {
      startRingtone(targetId, customBlob).catch(() => {});
      setPreviewingRingtoneId(targetId);
    }
  };

  const handleAudioUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setAudioUploadError(null);
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      const sizeInMB = (file.size / (1024 * 1024)).toFixed(1);
      setAudioUploadError(
        isAr
          ? `حجم الملف (${sizeInMB} ميجابايت) يتجاوز الحد الأقصى المسموح به وهو 5 ميجابايت. يرجى اختيار ملف صوتي أصغر.`
          : `File size (${sizeInMB}MB) exceeds the maximum allowed limit of 5MB. Please choose a smaller audio file.`
      );
      e.target.value = '';
      return;
    }

    try {
      setIsUploadingAudio(true);
      if (onAddCustomRingtone) {
        await onAddCustomRingtone(file);
      }
    } catch (err: any) {
      setAudioUploadError(err?.message || (isAr ? 'تعذر حفظ الملف الصوتي' : 'Failed to save audio file'));
    } finally {
      setIsUploadingAudio(false);
      e.target.value = '';
    }
  };

  const [aiStatus, setAiStatus] = useState<{ loading: boolean; connected: boolean }>({
    loading: true,
    connected: false,
  });

  const checkAiHealth = () => {
    setAiStatus((prev) => ({ ...prev, loading: true }));
    fetch(getApiUrl('/api/health'))
      .then((res) => res.json())
      .then((data) => {
        setAiStatus({
          loading: false,
          connected: Boolean(data?.aiConnected),
        });
      })
      .catch(() => {
        setAiStatus({ loading: false, connected: false });
      });
  };

  useEffect(() => {
    checkAiHealth();
  }, []);

  // ===== موفّر طلبات الذكاء الاصطناعي (تحليل محلي بدون سيرفر) =====
  const [savings, setSavings] = useState<AiSavingsStats>(() => getSavingsStats());
  const [cacheSize, setCacheSize] = useState<number>(() => getFoodCacheSize());
  const [adsRemoved, setAdsRemovedState] = useState<boolean>(() => hasRemovedAds());

  const toggleAdsRemoved = () => {
    const next = !adsRemoved;
    setAdsRemoved(next);
    setAdsRemovedState(next);
    playChimeSound();
  };

  const refreshSavings = () => {
    setSavings(getSavingsStats());
    setCacheSize(getFoodCacheSize());
  };

  const handleClearFoodCache = () => {
    clearFoodCache();
    refreshSavings();
    playChimeSound();
  };

  const savedAiCalls =
    (savings.cacheHits || 0) + (savings.localHits || 0) + (savings.barcodeHits || 0);
  const totalAnalyses = savedAiCalls + (savings.aiCalls || 0);
  const savingsPercent = totalAnalyses > 0 ? Math.round((savedAiCalls / totalAnalyses) * 100) : 0;

  const handleSaveProfile = () => {
    onUpdateProfile({ name: userNameInput.trim() || undefined });
    setIsEditingProfile(false);
    playChimeSound();
  };

  const handleSaveHealthSettings = () => {
    const curW = parseFloat(currentWeightInput);
    const tarW = parseFloat(targetWeightInput);
    const stW = parseFloat(startWeightInput);
    const h = parseFloat(heightInput);
    const cal = parseInt(caloriesInput, 10);
    const prot = parseInt(proteinInput, 10);
    const c = parseInt(carbsInput, 10);
    const f = parseInt(fatsInput, 10);

    onUpdateProfile({
      currentWeight: !isNaN(curW) && curW > 0 ? curW : null,
      targetWeight: !isNaN(tarW) && tarW > 0 ? tarW : null,
      startWeight: !isNaN(stW) && stW > 0 ? stW : null,
      heightCm: !isNaN(h) && h > 0 ? h : null,
      targetCalories: !isNaN(cal) && cal > 0 ? cal : null,
      targetProtein: !isNaN(prot) && prot > 0 ? prot : null,
      targetCarbs: !isNaN(c) && c > 0 ? c : null,
      targetFats: !isNaN(f) && f > 0 ? f : null,
      goal: goalInput || null,
    });

    setIsEditingHealth(false);
    playChimeSound();
  };

  const handleConfirmReset = () => {
    onResetData();
    setIsConfirmResetOpen(false);
    setResetSuccessMessage(true);
    setTimeout(() => {
      setResetSuccessMessage(false);
    }, 3000);
  };

  const displayName = userProfile.name || (isAr ? 'مستخدم التطبيق' : 'App User');
  const avatarLetter = (displayName.charAt(0) || 'U').toUpperCase();

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="flex-1 flex flex-col bg-white text-[#354052] px-5 py-4 overflow-y-auto select-none pb-20 relative"
      style={{ backgroundColor: '#FFFFFF' }}
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <h1 className="text-xl font-bold text-[#354052]">
          {isAr ? 'الإعدادات' : 'Settings'}
        </h1>
        <div className="w-9 h-9 rounded-xl bg-[#EBF2FA] text-[#3B6CB4] flex items-center justify-center">
          <Settings className="w-5 h-5 stroke-[2.2]" />
        </div>
      </div>

      {/* Reset success feedback toast */}
      {resetSuccessMessage && (
        <div className="mt-3 p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-between animate-fadeIn">
          <span>
            {isAr
              ? '✓ تم تفريغ وإعادة ضبط كافة البيانات بالكامل'
              : '✓ All application data has been completely wiped and reset'}
          </span>
        </div>
      )}

      {/* User Profile Card (Real name or clean fallback, no fake name/email) */}
      <div
        className="mt-5 p-4 rounded-3xl bg-[#EBF2FA] border border-[#3B6CB4]/25 flex items-center justify-between"
        style={{
          boxShadow: '0 8px 24px -4px rgba(59, 108, 180, 0.18)',
        }}
      >
        <div className="flex items-center gap-3.5 min-w-0 flex-1">
          <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center shadow-xs text-[#3B6CB4] font-black text-lg ring-2 ring-white shrink-0">
            {avatarLetter}
          </div>
          <div className="min-w-0 flex-1">
            {isEditingProfile ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={userNameInput}
                  onChange={(e) => setUserNameInput(e.target.value)}
                  placeholder={isAr ? 'اسمك الشخصي' : 'Your name'}
                  className="py-1 px-2.5 rounded-lg border border-[#3B6CB4] text-xs font-bold bg-white text-[#354052] focus:outline-none w-36"
                  autoFocus
                />
                <button
                  onClick={handleSaveProfile}
                  className="p-1 rounded-lg bg-[#3B6CB4] text-white hover:bg-[#3B6CB4]/90 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setIsEditingProfile(false)}
                  className="p-1 rounded-lg bg-slate-200 text-slate-600 hover:bg-slate-300 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div>
                <div className="flex items-center gap-1.5">
                  <h2 className="text-base font-bold text-[#354052] truncate">
                    {displayName}
                  </h2>
                  <span className="w-1.5 h-1.5 rounded-full bg-[#F3D58A]" />
                </div>
                <p className="text-xs text-slate-500">
                  {isAr ? 'البيانات محفوظة محلياً على هذا الجهاز' : 'Locally stored on this device'}
                </p>
              </div>
            )}
          </div>
        </div>

        {!isEditingProfile && (
          <button
            onClick={() => {
              setUserNameInput(userProfile.name || '');
              setIsEditingProfile(true);
            }}
            className="w-8 h-8 rounded-xl bg-white/80 hover:bg-white text-[#3B6CB4] flex items-center justify-center shadow-2xs cursor-pointer shrink-0"
            title={isAr ? 'تعديل الاسم' : 'Edit Name'}
          >
            <Edit2 className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Settings Options */}
      <div className="mt-6 space-y-3">
        {/* Health Targets and Goals Configuration Card */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#EBF2FA] text-[#3B6CB4] flex items-center justify-center">
                <Target className="w-4.5 h-4.5" />
              </div>
              <div>
                <p className="text-sm font-bold text-[#354052]">
                  {isAr ? 'أهداف الصحة والوزن والسعرات' : 'Health & Calorie Goals'}
                </p>
                <p className="text-[11px] text-slate-400">
                  {userProfile.targetCalories
                    ? isAr ? `الهدف: ${userProfile.targetCalories} سعرة يومياً` : `Target: ${userProfile.targetCalories} kcal/day`
                    : isAr ? 'لم يتم تحديد أهداف بعد' : 'No targets set yet'}
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                setTargetWeightInput(userProfile.targetWeight ? userProfile.targetWeight.toString() : '');
                setCurrentWeightInput(userProfile.currentWeight ? userProfile.currentWeight.toString() : '');
                setStartWeightInput(userProfile.startWeight ? userProfile.startWeight.toString() : '');
                setHeightInput(userProfile.heightCm ? userProfile.heightCm.toString() : '');
                setCaloriesInput(userProfile.targetCalories ? userProfile.targetCalories.toString() : '');
                setProteinInput(userProfile.targetProtein ? userProfile.targetProtein.toString() : '');
                setCarbsInput(userProfile.targetCarbs ? userProfile.targetCarbs.toString() : '');
                setFatsInput(userProfile.targetFats ? userProfile.targetFats.toString() : '');
                setGoalInput(userProfile.goal || '');
                setIsEditingHealth(!isEditingHealth);
              }}
              className="text-xs font-bold text-[#3B6CB4] bg-white border border-slate-200 px-3 py-1.5 rounded-xl hover:bg-slate-50 cursor-pointer"
            >
              {isEditingHealth ? (isAr ? 'إغلاق' : 'Close') : (isAr ? 'تعديل' : 'Edit')}
            </button>
          </div>

          {/* Quick summary of current metrics */}
          {!isEditingHealth && (
            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-200/60 text-center">
              <div className="p-2 rounded-xl bg-white border border-slate-100">
                <span className="text-[10px] text-slate-400 block">{isAr ? 'الوزن' : 'Weight'}</span>
                <span className="text-xs font-bold text-[#354052]">
                  {userProfile.currentWeight ? `${userProfile.currentWeight} kg` : '—'}
                </span>
              </div>
              <div className="p-2 rounded-xl bg-white border border-slate-100">
                <span className="text-[10px] text-slate-400 block">{isAr ? 'الهدف' : 'Target Wt'}</span>
                <span className="text-xs font-bold text-[#354052]">
                  {userProfile.targetWeight ? `${userProfile.targetWeight} kg` : '—'}
                </span>
              </div>
              <div className="p-2 rounded-xl bg-white border border-slate-100">
                <span className="text-[10px] text-slate-400 block">{isAr ? 'السعرات' : 'Calories'}</span>
                <span className="text-xs font-bold text-[#3B6CB4]">
                  {userProfile.targetCalories ? `${userProfile.targetCalories}` : '—'}
                </span>
              </div>
            </div>
          )}

          {/* Form when editing is active */}
          {isEditingHealth && (
            <div className="pt-3 border-t border-slate-200/80 space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-semibold text-slate-500 block mb-1">
                    {isAr ? 'الوزن الحالي (كجم)' : 'Current Weight (kg)'}
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={currentWeightInput}
                    onChange={(e) => setCurrentWeightInput(e.target.value)}
                    placeholder="—"
                    className="w-full py-1.5 px-2.5 rounded-lg border border-slate-200 text-xs font-bold bg-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-semibold text-slate-500 block mb-1">
                    {isAr ? 'الوزن المستهدف (كجم)' : 'Target Weight (kg)'}
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={targetWeightInput}
                    onChange={(e) => setTargetWeightInput(e.target.value)}
                    placeholder="—"
                    className="w-full py-1.5 px-2.5 rounded-lg border border-slate-200 text-xs font-bold bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-semibold text-slate-500 block mb-1">
                    {isAr ? 'الطول (سم)' : 'Height (cm)'}
                  </label>
                  <input
                    type="number"
                    value={heightInput}
                    onChange={(e) => setHeightInput(e.target.value)}
                    placeholder="—"
                    className="w-full py-1.5 px-2.5 rounded-lg border border-slate-200 text-xs font-bold bg-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-semibold text-slate-500 block mb-1">
                    {isAr ? 'سعرات اليوم (Kcal)' : 'Target Calories'}
                  </label>
                  <input
                    type="number"
                    value={caloriesInput}
                    onChange={(e) => setCaloriesInput(e.target.value)}
                    placeholder="—"
                    className="w-full py-1.5 px-2.5 rounded-lg border border-slate-200 text-xs font-bold bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-semibold text-slate-500 block mb-1">
                  {isAr ? 'الماكروز المستهدفة (بروتين / كارب / دهون بالجرام)' : 'Target Macros (P / C / F grams)'}
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  <input
                    type="number"
                    value={proteinInput}
                    onChange={(e) => setProteinInput(e.target.value)}
                    placeholder={isAr ? 'بروتين' : 'Protein'}
                    className="w-full py-1.5 px-2 rounded-lg border border-slate-200 text-xs text-center font-bold bg-white"
                  />
                  <input
                    type="number"
                    value={carbsInput}
                    onChange={(e) => setCarbsInput(e.target.value)}
                    placeholder={isAr ? 'كارب' : 'Carbs'}
                    className="w-full py-1.5 px-2 rounded-lg border border-slate-200 text-xs text-center font-bold bg-white"
                  />
                  <input
                    type="number"
                    value={fatsInput}
                    onChange={(e) => setFatsInput(e.target.value)}
                    placeholder={isAr ? 'دهون' : 'Fats'}
                    className="w-full py-1.5 px-2 rounded-lg border border-slate-200 text-xs text-center font-bold bg-white"
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={handleSaveHealthSettings}
                className="w-full py-2 rounded-xl bg-[#3B6CB4] text-white font-bold text-xs shadow-xs hover:bg-[#3B6CB4]/90 cursor-pointer"
              >
                {isAr ? 'حفظ الأهداف الصحية' : 'Save Health Goals'}
              </button>
            </div>
          )}
        </div>

        {/* AI Status Indicator Card */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
                aiStatus.connected
                  ? 'bg-emerald-50 text-emerald-600'
                  : 'bg-rose-50 text-rose-500'
              }`}
            >
              <Sparkles className="w-4.5 h-4.5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span
                  className={`w-2 h-2 rounded-full ${
                    aiStatus.loading
                      ? 'bg-slate-300 animate-ping'
                      : aiStatus.connected
                      ? 'bg-emerald-500 animate-pulse'
                      : 'bg-rose-500'
                  }`}
                />
                <p className="text-xs font-bold text-[#354052]">
                  {aiStatus.loading
                    ? isAr
                      ? 'جارٍ فحص الاتصال بالذكاء الاصطناعي...'
                      : 'Checking AI connection...'
                    : aiStatus.connected
                    ? isAr
                      ? 'الذكاء الاصطناعي متصل'
                      : 'AI Connected'
                    : isAr
                    ? 'غير متصل (المفتاح غير مضبوط)'
                    : 'Disconnected (Key not configured)'}
                </p>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {aiStatus.connected
                  ? isAr
                    ? 'Gemini 3.8 Flash جاهز لفحص الوجبات وحساب السعرات'
                    : 'Gemini 3.8 Flash ready for meal vision analysis'
                  : isAr
                  ? 'يرجى ضبط GEMINI_API_KEY لتفعيل التحليل'
                  : 'Please configure GEMINI_API_KEY in environment'}
              </p>
            </div>
          </div>

          <button
            onClick={checkAiHealth}
            title={isAr ? 'إعادة الفحص' : 'Re-check status'}
            className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${aiStatus.loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* AI Saver Card — إحصائيات التوفير المحلي */}
        <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-100">
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <Sparkles className="w-4.5 h-4.5" />
              </div>
              <div>
                <p className="text-xs font-bold text-[#354052]">
                  {isAr ? 'موفّر طلبات الذكاء الاصطناعي' : 'AI Request Saver'}
                </p>
                <p className="text-[11px] text-slate-500">
                  {isAr
                    ? 'تحليلات تمت محلياً على جهازك بدون سيرفر'
                    : 'Analyses resolved on-device, no server call'}
                </p>
              </div>
            </div>
            <button
              onClick={refreshSavings}
              title={isAr ? 'تحديث' : 'Refresh'}
              className="w-8 h-8 rounded-lg bg-white border border-emerald-200 flex items-center justify-center text-emerald-600 hover:text-emerald-800 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2 mb-2.5">
            <div className="bg-white rounded-xl py-2 text-center border border-emerald-100">
              <p className="text-base font-black text-emerald-700">{savedAiCalls}</p>
              <p className="text-[9px] text-slate-500 font-semibold">
                {isAr ? 'طلب تم توفيره' : 'calls saved'}
              </p>
            </div>
            <div className="bg-white rounded-xl py-2 text-center border border-slate-100">
              <p className="text-base font-black text-[#3B6CB4]">{savings.aiCalls || 0}</p>
              <p className="text-[9px] text-slate-500 font-semibold">
                {isAr ? 'طلب AI فعلي' : 'real AI calls'}
              </p>
            </div>
            <div className="bg-white rounded-xl py-2 text-center border border-slate-100">
              <p className="text-base font-black text-slate-700">{savingsPercent}%</p>
              <p className="text-[9px] text-slate-500 font-semibold">
                {isAr ? 'نسبة التوفير' : 'saved ratio'}
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] text-slate-500">
              {isAr
                ? `${cacheSize} وجبة محفوظة في ذاكرة الجهاز`
                : `${cacheSize} meals cached on device`}
            </span>
            <button
              onClick={handleClearFoodCache}
              className="px-2.5 py-1.5 rounded-lg bg-white border border-rose-200 text-rose-600 text-[10px] font-bold flex items-center gap-1 hover:bg-rose-50 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3 h-3" />
              {isAr ? 'مسح الذاكرة' : 'Clear cache'}
            </button>
          </div>
        </div>

        {/* Ads Removal (Premium) — تجريبي */}
        <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-100 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
              <Shield className="w-4.5 h-4.5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-[#354052]">
                {isAr ? 'إزالة الإعلانات' : 'Remove ads'}
              </p>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                {adsRemoved
                  ? isAr
                    ? 'الإعلانات مخفية (محاكاة اشتراك مدفوع)'
                    : 'Ads hidden (simulated paid tier)'
                  : isAr
                  ? 'محاكاة لزر «ترقية بدون إعلانات»'
                  : 'Simulate the "go ad-free" upgrade'}
              </p>
            </div>
          </div>

          <button
            onClick={toggleAdsRemoved}
            className={`shrink-0 w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
              adsRemoved ? 'bg-indigo-600' : 'bg-slate-300'
            }`}
            aria-pressed={adsRemoved}
          >
            <span
              className={`absolute top-0.5 w-5.5 h-5.5 rounded-full bg-white shadow-sm transition-all ${
                adsRemoved ? 'start-6' : 'start-0.5'
              }`}
            />
          </button>
        </div>

        {/* Language Switcher */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Globe className="w-5 h-5 text-[#3B6CB4]" />
            <div>
              <p className="text-sm font-semibold text-[#354052]">
                {isAr ? 'لغة التطبيق' : 'App Language'}
              </p>
              <p className="text-[11px] text-slate-400">
                {isAr ? 'التبديل بين العربية والإنجليزية' : 'Switch between Arabic & English'}
              </p>
            </div>
          </div>

          <div className="flex items-center p-1 bg-white rounded-xl border border-slate-200">
            <button
              onClick={() => onLanguageChange('ar')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                isAr
                  ? 'bg-[#3B6CB4] text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              العربية
            </button>
            <button
              onClick={() => onLanguageChange('en')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                !isAr
                  ? 'bg-[#3B6CB4] text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              English
            </button>
          </div>
        </div>

        {/* Alarm Ringtone Section */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-[#F3D58A]/30 text-[#bfa04a] flex items-center justify-center">
                <Music className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#354052]">
                  {isAr ? 'نغمة المنبه والتنبيه' : 'Alarm Ringtone'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {isAr ? 'اختر النغمة الافتراضية للمنبه أو ارفع نغمة من هاتفك' : 'Choose default alarm ringtone or upload from your device'}
                </p>
              </div>
            </div>

            {onTestAlarm && (
              <button
                onClick={onTestAlarm}
                className="px-2.5 py-1.5 rounded-xl bg-[#EBF2FA] text-[#3B6CB4] border border-[#3B6CB4]/25 text-[11px] font-bold hover:bg-[#3B6CB4] hover:text-white transition-all flex items-center gap-1 cursor-pointer shadow-2xs"
                title={isAr ? 'اختبار شاشة المنبه الكاملة' : 'Test Full Alarm Screen'}
              >
                <Bell className="w-3.5 h-3.5" />
                <span>{isAr ? 'تجربة المنبه' : 'Test Alarm'}</span>
              </button>
            )}
          </div>

          {/* Error Message for upload */}
          {audioUploadError && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-start gap-2 animate-in fade-in">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <div className="flex-1">
                <span>{audioUploadError}</span>
              </div>
              <button
                onClick={() => setAudioUploadError(null)}
                className="text-rose-400 hover:text-rose-600 text-xs font-bold px-1"
              >
                ✕
              </button>
            </div>
          )}

          {/* Built-in Ringtones List */}
          <div className="space-y-1.5 pt-1">
            <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-1">
              {isAr ? 'النغمات الجاهزة' : 'Built-in Ringtones'}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {BUILT_IN_RINGTONES.map((tone) => {
                const isSelected = defaultRingtoneId === tone.id;
                const isPlaying = previewingRingtoneId === tone.id;

                return (
                  <div
                    key={tone.id}
                    onClick={() => onSelectDefaultRingtone?.(tone.id)}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-white border-[#3B6CB4] ring-2 ring-[#3B6CB4]/20 shadow-xs'
                        : 'bg-white/70 border-slate-200 hover:border-slate-300 hover:bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                          isSelected ? 'bg-[#3B6CB4] text-white' : 'border border-slate-300 bg-slate-50'
                        }`}
                      >
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                      </div>
                      <div className="min-w-0">
                        <p className={`text-xs font-semibold truncate ${isSelected ? 'text-[#3B6CB4]' : 'text-[#354052]'}`}>
                          {isAr ? tone.nameAr : tone.nameEn}
                        </p>
                        <p className="text-[10px] text-slate-400 truncate">
                          {isAr ? tone.descAr : tone.descEn}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleTogglePreview(tone.id);
                      }}
                      className={`p-1.5 rounded-lg border text-xs font-medium transition-all shrink-0 cursor-pointer ${
                        isPlaying
                          ? 'bg-rose-50 text-rose-600 border-rose-200 ring-2 ring-rose-200'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                      title={isPlaying ? (isAr ? 'إيقاف' : 'Stop') : (isAr ? 'تشغيل' : 'Play')}
                    >
                      {isPlaying ? <Square className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Custom Phone Ringtones List */}
          <div className="space-y-2 pt-2 border-t border-slate-200/60">
            <div className="flex items-center justify-between px-1">
              <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                {isAr ? 'نغماتك المخصصة من الهاتف' : 'Custom Device Ringtones'}
              </p>
              <span className="text-[10px] text-slate-400">
                {isAr ? 'الحد الأقصى 5 ميجابايت' : 'Max 5MB'}
              </span>
            </div>

            {/* Custom files */}
            {customRingtones && customRingtones.length > 0 ? (
              <div className="space-y-1.5">
                {customRingtones.map((custom) => {
                  const isSelected = defaultRingtoneId === custom.id;
                  const isPlaying = previewingRingtoneId === custom.id;
                  const sizeKb = Math.round(custom.size / 1024);

                  return (
                    <div
                      key={custom.id}
                      onClick={() => onSelectDefaultRingtone?.(custom.id)}
                      className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'bg-white border-[#3B6CB4] ring-2 ring-[#3B6CB4]/20 shadow-xs'
                          : 'bg-white/70 border-slate-200 hover:border-slate-300 hover:bg-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        <div
                          className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                            isSelected ? 'bg-[#3B6CB4] text-white' : 'border border-slate-300 bg-slate-50'
                          }`}
                        >
                          {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className={`text-xs font-semibold truncate ${isSelected ? 'text-[#3B6CB4]' : 'text-[#354052]'}`}>
                            {custom.name}
                          </p>
                          <p className="text-[10px] text-slate-400">
                            {sizeKb > 1024 ? `${(sizeKb / 1024).toFixed(1)} MB` : `${sizeKb} KB`}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleTogglePreview(custom.id, custom.blob);
                          }}
                          className={`p-1.5 rounded-lg border text-xs font-medium transition-all cursor-pointer ${
                            isPlaying
                              ? 'bg-rose-50 text-rose-600 border-rose-200 ring-2 ring-rose-200'
                              : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
                          }`}
                          title={isPlaying ? (isAr ? 'إيقاف' : 'Stop') : (isAr ? 'تشغيل' : 'Play')}
                        >
                          {isPlaying ? <Square className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5" />}
                        </button>

                        <button
                          type="button"
                          onClick={async (e) => {
                            e.stopPropagation();
                            if (previewingRingtoneId === custom.id) {
                              stopRingtone();
                              setPreviewingRingtoneId(null);
                            }
                            if (onDeleteCustomRingtone) {
                              await onDeleteCustomRingtone(custom.id);
                            }
                          }}
                          className="p-1.5 rounded-lg border border-transparent text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                          title={isAr ? 'حذف هذه النغمة' : 'Delete ringtone'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-slate-400 py-1 px-1">
                {isAr
                  ? 'لم تقم بإضافة أي نغمة مخصصة بعد. يمكنك رفع ملف صوتي من هاتفك بصيغة MP3 أو WAV أو OGG.'
                  : 'No custom ringtones added yet. You can upload any audio file from your device (MP3, WAV, OGG).'}
              </p>
            )}

            {/* Hidden file input & Add button */}
            <input
              ref={customAudioInputRef}
              type="file"
              accept="audio/*"
              className="hidden"
              onChange={handleAudioUpload}
            />

            <button
              type="button"
              disabled={isUploadingAudio}
              onClick={() => customAudioInputRef.current?.click()}
              className="w-full py-2.5 px-3 rounded-xl border border-dashed border-[#3B6CB4]/40 bg-[#EBF2FA]/50 hover:bg-[#EBF2FA] text-[#3B6CB4] text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              {isUploadingAudio ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{isAr ? 'جاري حفظ النغمة في الجهاز...' : 'Saving audio to device...'}</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  <span>{isAr ? 'إضافة نغمة من هاتفك (IndexedDB)' : 'Add ringtone from your phone'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Privacy & Local Storage Security */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-3">
          <Shield className="w-5 h-5 text-emerald-500 shrink-0" />
          <div>
            <p className="text-sm font-semibold text-[#354052]">
              {isAr ? 'خصوصية كاملة وحفظ محلي' : '100% Private & Local Storage'}
            </p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {isAr
                ? 'بياناتك ومهامك اليومية ووجباتك محفوظة فقط في ذاكرة جهازك دون خوادم خارجية'
                : 'Tasks and meals are strictly stored in your local browser storage.'}
            </p>
          </div>
        </div>

        {/* Reset All Data Button */}
        <button
          onClick={() => setIsConfirmResetOpen(true)}
          className="w-full p-4 rounded-2xl bg-rose-50/60 border border-rose-200/60 hover:bg-rose-100/60 flex items-center justify-between text-left transition-colors cursor-pointer group"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-100/80 text-rose-600 flex items-center justify-center group-hover:scale-105 transition-transform">
              <RefreshCw className="w-4.5 h-4.5" />
            </div>
            <div>
              <p className="text-sm font-bold text-rose-700">
                {isAr ? 'تفريغ وإعادة ضبط كافة البيانات' : 'Wipe & Reset All Data'}
              </p>
              <p className="text-[11px] text-rose-500/80 mt-0.5">
                {isAr
                  ? 'حذف كافة المهام والوجبات والأرقام والبدء بتطبيق فارغ تماماً'
                  : 'Clear all tasks, meals, and start completely fresh with 0 data'}
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-rose-600 px-2.5 py-1 rounded-lg bg-rose-100/80">
            {isAr ? 'تفريغ شامل' : 'Wipe Clean'}
          </span>
        </button>

        {/* Return to Welcome Screen */}
        <button
          onClick={onBackToWelcome}
          className="w-full p-4 rounded-2xl bg-slate-50 border border-slate-100 hover:bg-slate-100 flex items-center justify-between text-left transition-colors cursor-pointer mt-4"
        >
          <div className="flex items-center gap-3">
            <LogOut className="w-5 h-5 text-slate-400" />
            <span className="text-sm font-medium text-[#354052]">
              {isAr ? 'العودة إلى شاشة الترحيب الرئيسية' : 'Return to Welcome Screen'}
            </span>
          </div>
          {isAr ? <ArrowLeft className="w-4 h-4 text-slate-400" /> : <ArrowRight className="w-4 h-4 text-slate-400" />}
        </button>
      </div>

      {/* Confirmation Modal for Resetting Data */}
      {isConfirmResetOpen && (
        <div
          dir={isAr ? 'rtl' : 'ltr'}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 animate-fadeIn"
        >
          <div className="bg-white rounded-3xl p-6 w-full max-w-xs shadow-2xl border border-slate-100 text-center">
            <div className="w-14 h-14 rounded-2xl bg-rose-50 border border-rose-200 text-rose-500 flex items-center justify-center mx-auto mb-3">
              <RefreshCw className="w-7 h-7 stroke-[2.2]" />
            </div>

            <h3 className="text-base font-bold text-[#354052] mb-1.5">
              {isAr ? 'تفريغ كافة البيانات نهائياً؟' : 'Wipe & Reset Everything?'}
            </h3>

            <p className="text-xs text-slate-500 leading-relaxed mb-5">
              {isAr
                ? 'سيتم مسح جميع المهام والوجبات المسجلة وأهداف السعرات والوزن والبدء من الصفر تماماً. هل أنت متأكد؟'
                : 'All saved tasks, logged meals, calorie targets, and weight will be wiped clean. The app will restart completely empty. Are you sure?'}
            </p>

            <div className="flex items-center gap-2">
              <button
                onClick={handleConfirmReset}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md shadow-rose-600/30 transition-all cursor-pointer active:scale-95"
              >
                {isAr ? 'نعم، تفريغ شامل' : 'Yes, Wipe All'}
              </button>
              <button
                onClick={() => setIsConfirmResetOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-all cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
