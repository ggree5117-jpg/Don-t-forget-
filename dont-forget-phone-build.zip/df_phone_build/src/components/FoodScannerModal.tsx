import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  X,
  Camera,
  Zap,
  Image as ImageIcon,
  Sparkles,
  RefreshCw,
  AlertCircle,
  RotateCcw,
  Smartphone,
  ShieldAlert,
  ScanBarcode,
  Search,
  Check,
  WifiOff,
} from 'lucide-react';
import { Language } from '../types';
import { FoodAnalysisResult } from '../types/health';
import { playChimeSound } from '../utils/audio';
import { getApiUrl } from '../config';
import { lookupCachedImage, rememberAnalysis, recordStat } from '../utils/foodCache';
import type { QuickFoodHint } from '../utils/localFoodEngine';
import {
  QUICK_FOOD_HINTS,
  analyzeFoodTextLocally,
  buildQuickHintAnalysis,
  resolveLocalFallback,
} from '../utils/localFoodEngine';
import type { BarcodeProduct } from '../utils/openFoodFacts';
import { barcodeProductToAnalysis, fetchProductByBarcode } from '../utils/openFoodFacts';

interface ApiErrorInfo {
  title: string;
  messageAr: string;
  messageEn: string;
  isRateLimit?: boolean;
}

interface FoodScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanComplete: (result: FoodAnalysisResult, imageUrl: string) => void;
  onOpenAdvice?: () => void;
  language: Language;
  /** false = بدون إنترنت: كل التحليل يتم محلياً، ولا يُرسل أي طلب للـ AI */
  online?: boolean;
}

/**
 * Resizes an image or video frame to a maximum width/height of 800px,
 * outputting high quality JPEG at 0.72 quality to make uploads lightning fast
 * while retaining optimal visual resolution for AI vision recognition.
 */
function resizeImageElementToMax800(source: HTMLImageElement | HTMLVideoElement): string {
  const MAX_DIM = 800;
  let width = source instanceof HTMLVideoElement ? source.videoWidth : (source.naturalWidth || source.width);
  let height = source instanceof HTMLVideoElement ? source.videoHeight : (source.naturalHeight || source.height);

  if (!width || !height) {
    width = 640;
    height = 480;
  }

  if (width > MAX_DIM || height > MAX_DIM) {
    if (width > height) {
      height = Math.round((height * MAX_DIM) / width);
      width = MAX_DIM;
    } else {
      width = Math.round((width * MAX_DIM) / height);
      height = MAX_DIM;
    }
  }

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Canvas 2D context is unavailable');
  }

  ctx.drawImage(source, 0, 0, width, height);
  return canvas.toDataURL('image/jpeg', 0.72);
}

/**
 * Reads a File (from gallery or native camera capture) and resizes it to max 800px JPEG 0.72.
 */
function processAndResizeFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Failed to load image into element'));
      img.onload = () => {
        try {
          const resized = resizeImageElementToMax800(img);
          resolve(resized);
        } catch (err) {
          reject(err);
        }
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  });
}

export const FoodScannerModal: React.FC<FoodScannerModalProps> = ({
  isOpen,
  onClose,
  onScanComplete,
  onOpenAdvice,
  language,
  online = true,
}) => {
  const isAr = language === 'ar';
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const galleryInputRef = useRef<HTMLInputElement | null>(null);
  const nativeCameraInputRef = useRef<HTMLInputElement | null>(null);

  const [hasCamera, setHasCamera] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<{ title: string; descAr: string; descEn: string; isPermission?: boolean } | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analyzingStep, setAnalyzingStep] = useState<string>('');
  const [autoTriggerEnabled, setAutoTriggerEnabled] = useState<boolean>(false);
  const [autoCountdown, setAutoCountdown] = useState<number | null>(null);
  const [lastCapturedImage, setLastCapturedImage] = useState<string | null>(null);
  const [apiError, setApiError] = useState<ApiErrorInfo | null>(null);

  // === Zero-AI layer state ===
  const [userHint, setUserHint] = useState<string>('');
  const [economyMode, setEconomyMode] = useState<boolean>(() => {
    try {
      return localStorage.getItem('df_economy_mode') !== 'off';
    } catch {
      return true;
    }
  });

  // Barcode (Open Food Facts) state
  const [isBarcodeOpen, setIsBarcodeOpen] = useState<boolean>(false);
  const [barcodeValue, setBarcodeValue] = useState<string>('');
  const [barcodeLoading, setBarcodeLoading] = useState<boolean>(false);
  const [barcodeProduct, setBarcodeProduct] = useState<BarcodeProduct | null>(null);
  const [barcodeGrams, setBarcodeGrams] = useState<string>('100');
  const [barcodeError, setBarcodeError] = useState<string | null>(null);

  // Built-in AI Food Lens: captures & analyzes meal directly inside the app so food data is preserved and saved
  const triggerInternalLensAnalysis = () => {
    triggerCapture();
  };

  // Stop all camera tracks cleanly
  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {}
      });
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  // Start back camera with getUserMedia
  const startCamera = useCallback(async () => {
    setCameraError(null);
    stopCamera();

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setHasCamera(false);
        setCameraError({
          title: isAr ? 'الكاميرا غير مدعومة' : 'Camera Not Supported',
          descAr: 'المتصفح الحالي لا يدعم الوصول المباشر للكاميرا. يمكنك استخدام زر "التقاط بكاميرا الجوال" أدناه.',
          descEn: 'Live camera is not supported in this browser. Use the "Take Photo with Phone Camera" button below.',
        });
        return;
      }

      // Try environment (back) camera first
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setHasCamera(true);
    } catch (err: any) {
      console.warn('Live camera access error:', err?.name, err?.message);
      setHasCamera(false);

      const isPermissionDenied =
        err?.name === 'NotAllowedError' ||
        err?.name === 'PermissionDeniedError' ||
        err?.name === 'SecurityError';

      const isNotFound =
        err?.name === 'NotFoundError' ||
        err?.name === 'DevicesNotFoundError';

      if (isPermissionDenied) {
        setCameraError({
          title: isAr ? 'تم رفض إذن الكاميرا' : 'Camera Permission Denied',
          descAr: 'تم حظر الوصول إلى الكاميرا من قِبل المتصفح. يمكنك السماح بالإذن أو استخدام زر "التقاط بكاميرا الجوال" المباشر.',
          descEn: 'Camera access was blocked by browser permissions. You can allow it or use the "Take Photo with Phone" button.',
          isPermission: true,
        });
      } else if (isNotFound) {
        setCameraError({
          title: isAr ? 'لم يتم العثور على كاميرا' : 'No Camera Found',
          descAr: 'لم يتم العثور على جهاز كاميرا متصل. يمكنك التقاط صورة بكاميرا الجوال أو اختيار صورة من المعرض.',
          descEn: 'No connected camera found on this device. You can capture using phone camera or choose from gallery.',
        });
      } else {
        setCameraError({
          title: isAr ? 'تعذر تشغيل الكاميرا' : 'Could Not Start Camera',
          descAr: 'تعذر الاتصال بالكاميرا المباشرة. اضغط على "التقاط بكاميرا الجوال" لتصوير وجبتك مباشرة.',
          descEn: 'Could not connect to live camera stream. Tap "Take Photo with Phone" to snap your meal.',
        });
      }
    }
  }, [isAr, stopCamera]);

  // Manage camera lifecycle when modal opens / closes
  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      setIsAnalyzing(false);
      setAutoCountdown(null);
      setApiError(null);
      setLastCapturedImage(null);
      setIsBarcodeOpen(false);
      setBarcodeProduct(null);
      setBarcodeError(null);
      setBarcodeValue('');
      return;
    }

    startCamera();

    return () => {
      stopCamera();
    };
  }, [isOpen, startCamera, stopCamera]);

  // Capture frame from live video and scale down to 800px JPEG 0.72
  const captureFrameFromVideo = (): string | null => {
    if (!videoRef.current || !hasCamera) return null;
    try {
      return resizeImageElementToMax800(videoRef.current);
    } catch (err) {
      console.error('Frame capture error:', err);
      return null;
    }
  };

  // Process and analyze image strictly with Gemini API on the server
  const analyzeImageWithAi = async (imageBase64: string, retryCount = 0) => {
    setLastCapturedImage(imageBase64);
    setApiError(null);
    setIsAnalyzing(true);

    // ==========================================================
    // (0) طبقة "Zero-AI": كاش الصور المحلي ثم مطابقة الوصف محلياً
    // ==========================================================
    if (retryCount === 0) {
      try {
        const cached = await lookupCachedImage(imageBase64);
        if (cached) {
          setIsAnalyzing(false);
          onScanComplete({ ...cached, imageUrl: imageBase64 }, imageBase64);
          return;
        }
      } catch (err) {
        console.warn('[FoodScanner] image cache lookup failed:', err);
      }

      if (economyMode && userHint.trim()) {
        const local = analyzeFoodTextLocally(userHint, language);
        if (local && local.confidence === 'high') {
          recordStat('localHits');
          setIsAnalyzing(false);
          onScanComplete({ ...local.result, imageUrl: imageBase64 }, imageBase64);
          return;
        }
      }

      // بدون إنترنت: لا نحاول الاتصال إطلاقاً — تحليل محلي فوري
      if (!online) {
        recordStat('localHits');
        setIsAnalyzing(false);
        onScanComplete(
          { ...resolveLocalFallback(userHint, language), imageUrl: imageBase64 },
          imageBase64
        );
        return;
      }
    }
    setAnalyzingStep(
      retryCount > 0
        ? (isAr ? 'إعادة المحاولة التلقائية...' : 'Auto-retrying analysis...')
        : (isAr ? 'التعرف السريع على الطبق والمكونات...' : 'Rapidly identifying dish & components...')
    );
    if (retryCount === 0) playChimeSound();

    try {
      setTimeout(() => {
        setAnalyzingStep(isAr ? 'تطبيق معادلة الحساب الغذائي الدقيق...' : 'Applying accurate nutritional formula...');
      }, 400);

      const response = await fetch(getApiUrl('/api/analyze-food'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          imageBase64,
          mimeType: 'image/jpeg',
          userHint: userHint.trim() || undefined,
        }),
      });

      // If status is 503 (temporary high demand) and we have not retried yet, auto-retry once
      if (response.status === 503 && retryCount < 1) {
        console.warn('Temporary 503 encountered, auto-retrying in 800ms...');
        await new Promise((r) => setTimeout(r, 800));
        return analyzeImageWithAi(imageBase64, retryCount + 1);
      }

      // 3. Inspect Content-Type BEFORE calling response.json() to prevent HTML "<!doctype" parse crash
      const contentType = response.headers.get('content-type') || '';
      let errorData: any = null;

      if (contentType.includes('application/json')) {
        try {
          errorData = await response.json();
        } catch {
          errorData = null;
        }
      } else {
        // Response was not JSON (e.g. HTML 404 or 500 from server)
        const rawText = await response.text().catch(() => '');
        console.warn('Server returned non-JSON response:', rawText.slice(0, 120));
      }

      if (!response.ok) {
        let title = isAr ? 'تعذر تحليل الصورة' : 'Analysis Failed';
        let messageAr = isAr ? 'تعذر تحليل الصورة، يرجى المحاولة مرة أخرى' : 'Unable to analyze meal image';
        let messageEn = 'Unable to analyze meal image, please try again.';
        let isRateLimit = false;

        if (response.status === 413) {
          title = isAr ? 'حجم الصورة كبير جداً (413)' : 'Image Too Large (413)';
          messageAr = 'حجم الصورة كبير جداً. تم ضغط الصورة تلقائياً، يرجى إعادة المحاولة.';
          messageEn = 'The image file size is too large. Image was resized, please try again.';
        } else if (response.status === 429) {
          isRateLimit = true;
          title = isAr ? 'تجاوز حد الطلبات (429)' : 'Rate Limit Exceeded (429)';
          messageAr = errorData?.message || 'تم تجاوز الحد المسموح من الطلبات (10 طلبات في الدقيقة). يرجى الانتظار دقيقة والمحاولة لاحقاً.';
          messageEn = errorData?.messageEn || 'Rate limit exceeded (10 requests per minute). Please wait a minute and try again.';
        } else if (response.status === 503) {
          // Graceful auto-recovery: rather than blocking the user with 503 screen,
          // load balanced nutritional template so they can easily adjust ingredients and log their meal!
          console.warn('[FoodScanner] 503 → activating local nutrition database fallback');
          const fallbackMeal: FoodAnalysisResult = {
            ...resolveLocalFallback(userHint, language),
            imageUrl: imageBase64,
          };
          if (userHint.trim()) recordStat('localHits');
          setIsAnalyzing(false);
          onScanComplete(fallbackMeal, imageBase64);
          return;
        } else if (errorData?.message) {
          messageAr = errorData.message;
          messageEn = errorData.messageEn || errorData.message;
        } else if (!contentType.includes('application/json')) {
          messageAr = 'استجاب الخادم بصيغة غير متوقعة. يرجى إعادة المحاولة.';
          messageEn = 'Server returned an unexpected format. Please try again.';
        }

        setApiError({
          title,
          messageAr,
          messageEn,
          isRateLimit,
        });
        setIsAnalyzing(false);
        return;
      }

      if (!contentType.includes('application/json') || !errorData) {
        setApiError({
          title: isAr ? 'استجابة غير صالحة' : 'Invalid Response',
          messageAr: 'استجاب الخادم بصيغة غير صالحة. يرجى التحقق من اتصالك والمحاولة مجدداً.',
          messageEn: 'Server response was not in expected JSON format. Please retry.',
        });
        setIsAnalyzing(false);
        return;
      }

      const result: FoodAnalysisResult = errorData;
      result.imageUrl = imageBase64;

      recordStat('aiCalls');
      // نحفظ النتيجة محلياً حتى لا تُطلب نفس الوجبة من السيرفر مرة أخرى
      void rememberAnalysis(imageBase64, result);

      setIsAnalyzing(false);
      onScanComplete(result, imageBase64);
    } catch (error: any) {
      console.error('Food analysis network error:', error);

      // فشل الشبكة/السيرفر لا يعني طريقاً مسدوداً:
      // نحل الوجبة من الوصف المحلي إن وُجد، وإلا نعطي تقديراً محلياً قابلاً للتعديل.
      recordStat(userHint.trim() ? 'localHits' : 'cacheHits');
      setIsAnalyzing(false);
      onScanComplete(
        { ...resolveLocalFallback(userHint, language), imageUrl: imageBase64 },
        imageBase64
      );
      return;

      setIsAnalyzing(false);
      setApiError({
        title: isAr ? 'تعذر تحليل الصورة' : 'Unable to Analyze Image',
        messageAr: error?.message?.includes('JSON')
          ? (isAr ? 'حدث خطأ في قراءة استجابة الخادم. يرجى المحاولة مرة أخرى.' : 'Error reading server response. Please retry.')
          : (isAr ? 'تعذر الاتصال بخدمة التحليل، يرجى المحاولة مرة أخرى' : 'Unable to connect to analysis service, please try again.'),
        messageEn: 'Unable to connect to vision service, please try again.',
        isRateLimit: false,
      });
    }
  };

  // Trigger capture from live camera or native camera
  const triggerCapture = () => {
    setApiError(null);
    if (!hasCamera) {
      // Open native phone camera directly
      nativeCameraInputRef.current?.click();
      return;
    }
    const capturedImage = captureFrameFromVideo();
    if (!capturedImage) {
      nativeCameraInputRef.current?.click();
      return;
    }
    analyzeImageWithAi(capturedImage);
  };

  // Handle image selected from gallery OR captured with native phone camera
  const handleFilePicked = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setApiError(null);
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsAnalyzing(true);
      setAnalyzingStep(isAr ? 'جارٍ تحسين وتصغير حجم الصورة...' : 'Optimizing and resizing image...');
      const resizedBase64 = await processAndResizeFile(file);
      await analyzeImageWithAi(resizedBase64);
    } catch (err: any) {
      console.error('File resizing error:', err);
      setIsAnalyzing(false);
      setApiError({
        title: isAr ? 'خطأ في معالجة الصورة' : 'Image Processing Error',
        messageAr: 'تعذر معالجة وتصغير الصورة المحددة. يرجى اختيار صورة أخرى.',
        messageEn: 'Failed to process and resize the selected image.',
      });
    } finally {
      // Clear value so the user can re-capture or re-select
      e.target.value = '';
    }
  };

  // Handle auto-trigger scanning timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isOpen && autoTriggerEnabled && hasCamera && !isAnalyzing && autoCountdown === null && !apiError) {
      setAutoCountdown(3);
    }

    if (autoCountdown !== null && autoCountdown > 0) {
      timer = setTimeout(() => {
        setAutoCountdown(autoCountdown - 1);
      }, 1000);
    } else if (autoCountdown === 0 && !isAnalyzing && !apiError) {
      triggerCapture();
      setAutoCountdown(null);
    }

    return () => clearTimeout(timer);
  }, [isOpen, autoTriggerEnabled, hasCamera, autoCountdown, isAnalyzing, apiError]);

  // === Zero-AI helpers ===
  const toggleEconomyMode = () => {
    setEconomyMode((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('df_economy_mode', next ? 'on' : 'off');
      } catch {}
      return next;
    });
  };

  // تسجيل فوري لوجبة شائعة من قاعدة البيانات المحلية (بدون كاميرا وبدون AI)
  const handleQuickHint = (hint: QuickFoodHint) => {
    const analysis = buildQuickHintAnalysis(hint.id, language);
    if (!analysis) return;
    recordStat('localHits');
    stopCamera();
    onScanComplete(analysis.result, '');
  };

  const handleBarcodeLookup = async () => {
    setBarcodeLoading(true);
    setBarcodeError(null);
    setBarcodeProduct(null);

    const product = await fetchProductByBarcode(barcodeValue);

    setBarcodeLoading(false);
    if (!product) {
      setBarcodeError(
        isAr
          ? 'لم يتم العثور على المنتج. تأكد من الباركود أو جرّب منتجاً آخر.'
          : 'Product not found. Check the barcode or try another product.'
      );
      return;
    }
    setBarcodeProduct(product);
    setBarcodeGrams(String(product.servingGrams || 100));
  };

  const handleBarcodeConfirm = () => {
    if (!barcodeProduct) return;
    const grams = parseFloat(barcodeGrams);
    const result = barcodeProductToAnalysis(
      barcodeProduct,
      Number.isFinite(grams) && grams > 0 ? grams : barcodeProduct.servingGrams || 100,
      language
    );
    recordStat('barcodeHits');
    setIsBarcodeOpen(false);
    stopCamera();
    onScanComplete(result, '');
  };

  // Handle retry
  const handleRetry = () => {
    setApiError(null);
    if (lastCapturedImage) {
      analyzeImageWithAi(lastCapturedImage);
    } else {
      triggerCapture();
    }
  };

  if (!isOpen) return null;

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md transition-all select-none"
    >
      <div className="relative w-full max-w-md h-full max-h-[844px] bg-slate-950 flex flex-col overflow-hidden text-white sm:rounded-3xl shadow-2xl border border-slate-800">
        {/* Hidden File Inputs: Gallery & Native Phone Camera */}
        <input
          type="file"
          ref={galleryInputRef}
          accept="image/*"
          className="hidden"
          onChange={handleFilePicked}
        />
        <input
          type="file"
          ref={nativeCameraInputRef}
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={handleFilePicked}
        />

        {/* Top Header Bar */}
        <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between px-5 pt-6 pb-4 bg-gradient-to-b from-black/85 via-black/50 to-transparent">
          {/* Close button */}
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="w-10 h-10 rounded-full bg-white/15 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/25 active:scale-95 transition-all cursor-pointer"
            aria-label={isAr ? 'إغلاق' : 'Close'}
          >
            <X className="w-5 h-5 stroke-[2.5]" />
          </button>

          {/* Title & Status */}
          <div className="flex flex-col items-center text-center">
            <span className="text-sm font-bold text-white flex items-center gap-1.5">
              <Camera className="w-4 h-4 text-[#62B5F6]" />
              <span>{isAr ? 'ماسح الوجبات الذكي' : 'AI Food Scanner'}</span>
            </span>
            <span className="text-[10px] text-slate-300 font-medium">
              {isAr ? 'التقط صورة لطبقك لتحليله فورياً' : 'Snap your plate for instant analysis'}
            </span>
          </div>

          {/* Right actions: Google Lens & Auto-trigger toggle */}
          <div className="flex items-center gap-2">
            <button
              onClick={triggerInternalLensAnalysis}
              className="px-2.5 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer bg-white text-[#2C5282] hover:bg-slate-100 active:scale-95 shadow-xs border border-white/20"
              title={isAr ? 'عدسة تحليل الوجبة وحفظها داخل التطبيق' : 'Analyze & save meal internally'}
            >
              <svg className="w-3.5 h-3.5 stroke-current" viewBox="0 0 24 24" fill="none" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="3" />
                <path d="M3 7V5a2 2 0 0 1 2-2h2" />
                <path d="M17 3h2a2 2 0 0 1 2 2v2" />
                <path d="M21 17v2a2 2 0 0 1-2 2h-2" />
                <path d="M7 21H5a2 2 0 0 1-2-2v-2" />
              </svg>
              <span className="text-[11px] font-bold">Lens</span>
            </button>

            {/* Auto-trigger toggle */}
            <button
              onClick={() => setAutoTriggerEnabled(!autoTriggerEnabled)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                autoTriggerEnabled
                  ? 'bg-[#3B6CB4] text-white shadow-md shadow-[#3B6CB4]/50'
                  : 'bg-white/15 text-slate-300 hover:bg-white/25'
              }`}
              title={isAr ? 'تفعيل أو إلغاء الالتقاط التلقائي' : 'Toggle auto-capture'}
            >
              <Zap className={`w-3.5 h-3.5 ${autoTriggerEnabled ? 'fill-current' : ''}`} />
              <span className="text-[11px]">{isAr ? 'تلقائي' : 'Auto'}</span>
            </button>
          </div>
        </div>

        {/* Viewfinder Main Section */}
        <div className="relative flex-1 flex items-center justify-center overflow-hidden bg-slate-900">
          {/* Live Video Element */}
          <video
            ref={videoRef}
            playsInline
            autoPlay
            muted
            className={`w-full h-full object-cover ${hasCamera ? 'block' : 'hidden'}`}
          />

          {/* Clear, Helpful Fallback Card when Live Camera is not accessible */}
          {!hasCamera && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-b from-slate-900 via-slate-850 to-slate-950 p-6 text-center z-10">
              <div className="w-20 h-20 rounded-3xl bg-[#3B6CB4]/20 border border-[#3B6CB4]/35 flex items-center justify-center mb-4 text-[#62B5F6] shadow-xl">
                {cameraError?.isPermission ? (
                  <ShieldAlert className="w-10 h-10 text-amber-400 stroke-[1.8]" />
                ) : (
                  <Camera className="w-10 h-10 stroke-[1.8]" />
                )}
              </div>

              <h3 className="text-base font-bold text-white mb-1.5">
                {cameraError?.title || (isAr ? 'جاهز لتصوير الوجبة' : 'Ready to Snap Meal')}
              </h3>

              <p className="text-xs text-slate-300/90 max-w-xs mb-6 leading-relaxed">
                {isAr ? cameraError?.descAr : cameraError?.descEn}
              </p>

              {/* Action Buttons: Native Phone Camera + Google Lens + Gallery */}
              <div className="flex flex-col gap-2.5 w-full max-w-xs">
                {/* 1. Internal AI Food Lens: Snap Meal Directly & Save Internally */}
                <button
                  onClick={() => nativeCameraInputRef.current?.click()}
                  className="w-full py-3 px-4 rounded-2xl bg-white hover:bg-slate-100 text-[#2C5282] font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 cursor-pointer border border-[#2C5282]/30"
                >
                  <svg className="w-4.5 h-4.5 stroke-current" viewBox="0 0 24 24" fill="none" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="3" />
                    <path d="M3 7V5a2 2 0 0 1 2-2h2" />
                    <path d="M17 3h2a2 2 0 0 1 2 2v2" />
                    <path d="M21 17v2a2 2 0 0 1-2 2h-2" />
                    <path d="M7 21H5a2 2 0 0 1-2-2v-2" />
                  </svg>
                  <span>{isAr ? 'عدسة تصوير الوجبة وحفظها مباشرة' : 'Snap Meal & Save Directly'}</span>
                </button>

                {/* 2. Native Mobile Camera Trigger (opens phone native camera directly) */}
                <button
                  onClick={() => nativeCameraInputRef.current?.click()}
                  className="w-full py-2.5 px-4 rounded-2xl bg-[#3B6CB4] hover:bg-[#2C5282] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
                >
                  <Smartphone className="w-4.5 h-4.5" />
                  <span>{isAr ? 'التقاط بكاميرا الجوال' : 'Take Photo with Phone Camera'}</span>
                </button>

                {/* 3. Upload from gallery */}
                <button
                  onClick={() => galleryInputRef.current?.click()}
                  className="w-full py-2.5 px-4 rounded-2xl bg-white/15 hover:bg-white/20 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer border border-white/10"
                >
                  <ImageIcon className="w-4 h-4 text-slate-300" />
                  <span>{isAr ? 'اختيار صورة من الاستوديو' : 'Upload from Gallery'}</span>
                </button>

                {/* 3. Retry Live Stream button */}
                <button
                  onClick={startCamera}
                  className="text-[11px] font-semibold text-slate-400 hover:text-white pt-1 transition-colors cursor-pointer inline-flex items-center justify-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>{isAr ? 'إعادة محاولة تشغيل الكاميرا المباشرة' : 'Retry live camera access'}</span>
                </button>
              </div>
            </div>
          )}

          {/* Viewfinder Framing Overlay when live camera is working */}
          {hasCamera && !isAnalyzing && !apiError && (
            <div className="absolute inset-x-8 inset-y-24 pointer-events-none flex items-center justify-center">
              <div className="relative w-full aspect-square max-w-[280px] rounded-3xl border border-white/25 shadow-[0_0_0_9999px_rgba(0,0,0,0.55)]">
                {/* Corner brackets */}
                <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-[#62B5F6] rounded-tl-xl" />
                <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-[#62B5F6] rounded-tr-xl" />
                <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-[#62B5F6] rounded-bl-xl" />
                <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-[#62B5F6] rounded-br-xl" />

                {/* Animated Scanning Laser Line */}
                <div className="absolute inset-x-2 h-1 bg-gradient-to-r from-transparent via-[#62B5F6] to-transparent shadow-[0_0_15px_#62B5F6] animate-laser-scan" />

                {/* Center Target */}
                <div className="absolute inset-0 flex items-center justify-center opacity-30">
                  <div className="w-8 h-8 border border-white/60 rounded-full flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#62B5F6]" />
                  </div>
                </div>

                {/* Auto countdown overlay */}
                {autoCountdown !== null && autoCountdown > 0 && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-3xl backdrop-blur-xs">
                    <div className="w-16 h-16 rounded-full bg-[#3B6CB4] text-white flex items-center justify-center text-2xl font-black shadow-lg shadow-[#3B6CB4]/50 animate-bounce">
                      {autoCountdown}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* AI Analyzing Processing Overlay */}
          {isAnalyzing && (
            <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/85 backdrop-blur-md p-6 text-center animate-fadeIn">
              <div className="relative w-24 h-24 mb-5 flex items-center justify-center">
                <div className="absolute inset-0 rounded-full border-4 border-[#3B6CB4]/30 animate-ping" />
                <div className="w-20 h-20 rounded-full border-4 border-t-[#62B5F6] border-r-transparent border-b-[#3B6CB4] border-l-transparent animate-spin" />
                <Sparkles className="w-8 h-8 text-[#F3D58A] animate-pulse" />
              </div>

              <h4 className="text-lg font-bold text-white mb-1.5">
                {isAr ? 'جارٍ تحليل الوجبة بواسطة Gemini...' : 'Gemini Analyzing Meal...'}
              </h4>
              <p className="text-xs text-slate-300 max-w-xs transition-all">
                {analyzingStep}
              </p>

              <div className="w-48 h-1.5 bg-white/20 rounded-full overflow-hidden mt-6">
                <div className="h-full bg-gradient-to-r from-[#62B5F6] to-[#3B6CB4] animate-indeterminate" />
              </div>
            </div>
          )}

          {/* Clear Error Overlay with Specific Friendly Guidance */}
          {apiError && !isAnalyzing && (
            <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-black/92 backdrop-blur-md p-6 text-center animate-fadeIn">
              <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border border-amber-500/35 flex items-center justify-center text-amber-400 mb-3.5 shadow-lg">
                <Sparkles className="w-8 h-8 text-[#F3D58A] animate-pulse" />
              </div>

              <h3 className="text-base font-black text-white mb-2 leading-snug max-w-xs">
                {isAr ? 'ما رأيك باستشارة طبية أو استشارة ذكاء اصطناعي أفضل؟' : 'How about a medical consultation or better AI advice?'}
              </h3>

              <div className="max-w-xs mb-5 space-y-1.5 bg-white/10 p-3.5 rounded-2xl border border-white/15 text-center">
                <p className="text-xs font-semibold text-amber-200 leading-relaxed" dir="rtl">
                  {isAr
                    ? 'الذكاء الاصطناعي يواجه ضغطاً أو تعذر تحليل مكونات هذه الأكلة بدقة. يمكنك الآن الانتقال مباشرة لاستشارة الذكاء الاصطناعي الاستثنائية للحصول على أفكار صحية متكاملة للوجبات الثلاث (الإفطار، الغداء، والعشاء)!'
                    : 'AI service is under heavy load or unable to recognize this food. You can get an extraordinary AI medical & nutrition consultation with balanced 3-meal ideas (Breakfast, Lunch & Dinner)!'}
                </p>
                <p className="text-[11px] text-slate-300/80 leading-relaxed" dir="ltr">
                  {apiError.messageEn}
                </p>
              </div>

              <div className="flex flex-col gap-2.5 w-full max-w-xs">
                {/* 1. Primary Action: Jump straight to Extraordinary AI Consultation */}
                <button
                  onClick={() => {
                    setApiError(null);
                    onClose();
                    onOpenAdvice?.();
                  }}
                  className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-400 via-[#F3D58A] to-amber-400 hover:from-amber-300 hover:to-amber-400 text-slate-900 font-black text-xs flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 transition-all active:scale-95 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-amber-950" />
                  <span>{isAr ? 'استشارة الذكاء الاصطناعي الاستثنائية' : 'Get Extraordinary AI Advice'}</span>
                </button>

                {/* 2. Secondary Actions: Retry or Cancel */}
                <div className="flex items-center gap-2.5 w-full">
                  <button
                    onClick={handleRetry}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-white/15 hover:bg-white/25 active:scale-95 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer border border-white/10"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إعادة المحاولة' : 'Retry'}</span>
                  </button>
                  <button
                    onClick={() => setApiError(null)}
                    className="py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 text-slate-300 font-bold text-xs transition-all cursor-pointer"
                  >
                    {isAr ? 'إلغاء' : 'Cancel'}
                  </button>
                </div>

                {/* 3. Internal Food Lens Direct Re-analyze */}
                <button
                  onClick={triggerInternalLensAnalysis}
                  className="w-full py-2 px-3 rounded-xl bg-white/10 text-slate-200 hover:text-white hover:bg-white/15 font-semibold text-[11px] flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إعادة التصوير بعدسة الوجبات' : 'Snap & Analyze with Lens'}</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Shutter & Controls */}
        <div className="relative z-20 px-5 pt-4 pb-8 bg-gradient-to-t from-black via-black/95 to-transparent">
          {/* === تنبيه وضع عدم الاتصال === */}
          {!online && (
            <div className="mb-2 flex items-center gap-1.5 rounded-xl bg-amber-500/15 border border-amber-400/30 px-2.5 py-1.5">
              <WifiOff className="w-3.5 h-3.5 text-amber-300 shrink-0" />
              <p className="text-[10px] text-amber-200 font-semibold leading-relaxed">
                {isAr
                  ? 'بدون إنترنت: التصوير بالذكاء الاصطناعي غير متاح — استخدم التسجيل السريع أو اكتب وصف الوجبة.'
                  : 'Offline: AI photo analysis is unavailable — use quick log or type the meal name.'}
              </p>
            </div>
          )}

          {/* === Zero-AI Quick Log Bar (no camera, no AI request) === */}
          <div className="mb-3">
            <div className="flex items-center justify-between mb-1.5 gap-2">
              <span className="text-[10px] font-bold text-slate-300 flex items-center gap-1 truncate">
                <Sparkles className="w-3 h-3 text-[#F3D58A] shrink-0" />
                <span className="truncate">
                  {isAr ? 'تسجيل سريع — بدون تصوير وبدون استهلاك AI' : 'Quick log — no photo, no AI cost'}
                </span>
              </span>
              <button
                onClick={toggleEconomyMode}
                className={`shrink-0 px-2 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer border ${
                  economyMode
                    ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300'
                    : 'bg-white/10 border-white/15 text-slate-400'
                }`}
              >
                <Zap className={`w-3 h-3 ${economyMode ? 'fill-current' : ''}`} />
                <span>{isAr ? (economyMode ? 'وضع التوفير' : 'التوفير متوقف') : economyMode ? 'Saver on' : 'Saver off'}</span>
              </button>
            </div>

            <div className="flex items-center gap-1.5 mb-1.5">
              <input
                value={userHint}
                onChange={(e) => setUserHint(e.target.value)}
                placeholder={isAr ? 'اكتب وصف الوجبة (اختياري) لدقة أعلى' : 'Meal description (optional)'}
                className="flex-1 min-w-0 bg-white/10 border border-white/15 rounded-xl px-3 py-2 text-[11px] text-white placeholder:text-slate-400 focus:outline-none focus:border-[#62B5F6]"
              />
              <button
                onClick={() => setIsBarcodeOpen(true)}
                className="shrink-0 h-9 px-2.5 rounded-xl bg-white/10 border border-white/15 text-white flex items-center gap-1 text-[11px] font-bold hover:bg-white/20 active:scale-95 transition-all cursor-pointer"
              >
                <ScanBarcode className="w-3.5 h-3.5" />
                <span>{isAr ? 'باركود' : 'Barcode'}</span>
              </button>
            </div>

            <div
              className="flex gap-1.5 overflow-x-auto pb-1"
              dir={isAr ? 'rtl' : 'ltr'}
              style={{ scrollbarWidth: 'none' }}
            >
              {QUICK_FOOD_HINTS.map((hint) => (
                <button
                  key={hint.id}
                  onClick={() => handleQuickHint(hint)}
                  className="shrink-0 px-3 py-1.5 rounded-full bg-[#3B6CB4]/30 border border-[#62B5F6]/40 text-white text-[11px] font-bold hover:bg-[#3B6CB4]/55 active:scale-95 transition-all cursor-pointer"
                >
                  {isAr ? hint.labelAr : hint.labelEn}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-around">
            {/* Gallery Upload Button */}
            <button
              onClick={() => galleryInputRef.current?.click()}
              className="w-12 h-12 rounded-2xl bg-white/15 hover:bg-white/25 active:scale-95 flex flex-col items-center justify-center text-white transition-all cursor-pointer border border-white/10"
              title={isAr ? 'اختيار صورة من الاستوديو' : 'Upload from gallery'}
            >
              <ImageIcon className="w-4.5 h-4.5 text-slate-200" />
              <span className="text-[9px] font-medium text-slate-300 mt-0.5">
                {isAr ? 'الاستوديو' : 'Gallery'}
              </span>
            </button>

            {/* Central Main Capture Shutter Button */}
            <button
              onClick={triggerCapture}
              disabled={isAnalyzing}
              className="relative w-16 h-16 rounded-full flex items-center justify-center transition-all duration-200 active:scale-90 hover:scale-105 cursor-pointer ring-4 ring-white/30 hover:ring-white/50"
              style={{
                backgroundColor: '#2C5282',
                boxShadow: '0 8px 30px rgba(44, 82, 130, 0.6), 0 0 20px rgba(98, 181, 246, 0.4)',
              }}
              title={isAr ? 'التقاط وتحليل الوجبة' : 'Capture & analyze meal'}
            >
              <div className="w-13 h-13 rounded-full border-2 border-white flex items-center justify-center bg-white/20">
                <Camera className="w-6 h-6 text-white stroke-[2.3]" />
              </div>
            </button>

            {/* Native Mobile Camera Button (Always accessible) */}
            <button
              onClick={() => nativeCameraInputRef.current?.click()}
              className="w-12 h-12 rounded-2xl bg-white/15 hover:bg-white/25 active:scale-95 flex flex-col items-center justify-center text-white transition-all cursor-pointer border border-white/10"
              title={isAr ? 'التقاط بكاميرا الجوال' : 'Phone Camera'}
            >
              <Smartphone className="w-4.5 h-4.5 text-slate-200" />
              <span className="text-[9px] font-medium text-slate-300 mt-0.5">
                {isAr ? 'كاميرا الجوال' : 'Camera'}
              </span>
            </button>

            {/* Internal Food Lens Action Button (White & Muted Navy #2C5282) */}
            <button
              onClick={triggerInternalLensAnalysis}
              className="w-12 h-12 rounded-2xl bg-white text-[#2C5282] hover:bg-slate-100 active:scale-95 flex flex-col items-center justify-center transition-all cursor-pointer border border-[#2C5282]/30 shadow-md"
              title={isAr ? 'عدسة تحليل الوجبة وحفظها' : 'Analyze & save meal'}
            >
              <svg className="w-4.5 h-4.5 stroke-current" viewBox="0 0 24 24" fill="none" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="3" />
                <path d="M3 7V5a2 2 0 0 1 2-2h2" />
                <path d="M17 3h2a2 2 0 0 1 2 2v2" />
                <path d="M21 17v2a2 2 0 0 1-2 2h-2" />
                <path d="M7 21H5a2 2 0 0 1-2-2v-2" />
              </svg>
              <span className="text-[9px] font-bold text-[#2C5282] mt-0.5">
                Lens
              </span>
            </button>
          </div>
        </div>

        {/* === Barcode Lookup Sheet (Open Food Facts, zero AI) === */}
        {isBarcodeOpen && (
          <div className="absolute inset-0 z-40 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-4">
            <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-4 animate-fadeIn">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-bold text-white flex items-center gap-1.5">
                  <ScanBarcode className="w-4 h-4 text-[#62B5F6]" />
                  {isAr ? 'بحث بالباركود — بدون AI' : 'Barcode lookup — no AI'}
                </span>
                <button
                  onClick={() => setIsBarcodeOpen(false)}
                  className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex gap-2 mb-3">
                <input
                  value={barcodeValue}
                  onChange={(e) => setBarcodeValue(e.target.value)}
                  inputMode="numeric"
                  placeholder={isAr ? 'أدخل أرقام الباركود' : 'Enter barcode digits'}
                  className="flex-1 min-w-0 bg-white/10 border border-white/15 rounded-xl px-3 py-2.5 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:border-[#62B5F6]"
                />
                <button
                  onClick={handleBarcodeLookup}
                  disabled={barcodeLoading || barcodeValue.replace(/\D/g, '').length < 8}
                  className="px-3.5 rounded-xl bg-[#3B6CB4] hover:bg-[#2C5282] disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  {barcodeLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Search className="w-4 h-4" />
                  )}
                  <span>{isAr ? 'بحث' : 'Search'}</span>
                </button>
              </div>

              {barcodeError && (
                <p className="text-[11px] text-amber-300 bg-amber-500/10 border border-amber-500/25 rounded-xl p-2.5 mb-2 leading-relaxed">
                  {barcodeError}
                </p>
              )}

              {barcodeProduct && (
                <div className="bg-white/10 border border-white/15 rounded-2xl p-3 space-y-2.5">
                  <div>
                    <p className="text-xs font-bold text-white">
                      {isAr ? barcodeProduct.nameAr : barcodeProduct.name}
                    </p>
                    {barcodeProduct.brand && (
                      <p className="text-[10px] text-slate-400">{barcodeProduct.brand}</p>
                    )}
                  </div>

                  <div className="grid grid-cols-4 gap-1.5 text-center">
                    {[
                      { label: isAr ? 'سعرة' : 'kcal', value: barcodeProduct.caloriesPer100g },
                      { label: isAr ? 'بروتين' : 'P', value: barcodeProduct.proteinPer100g },
                      { label: isAr ? 'كارب' : 'C', value: barcodeProduct.carbsPer100g },
                      { label: isAr ? 'دهون' : 'F', value: barcodeProduct.fatsPer100g },
                    ].map((metric) => (
                      <div key={metric.label} className="bg-black/30 rounded-lg py-1.5">
                        <p className="text-[11px] font-black text-white">{Math.round(metric.value)}</p>
                        <p className="text-[8px] text-slate-400">{metric.label}/100g</p>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center gap-2">
                    <label className="text-[10px] text-slate-300 shrink-0">
                      {isAr ? 'الكمية (جم)' : 'Amount (g)'}
                    </label>
                    <input
                      value={barcodeGrams}
                      onChange={(e) => setBarcodeGrams(e.target.value)}
                      inputMode="decimal"
                      className="w-20 bg-white/10 border border-white/15 rounded-lg px-2 py-1.5 text-xs text-white text-center focus:outline-none focus:border-[#62B5F6]"
                    />
                    <button
                      onClick={handleBarcodeConfirm}
                      className="flex-1 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                      <span>{isAr ? 'إضافة الوجبة' : 'Add meal'}</span>
                    </button>
                  </div>
                </div>
              )}

              <p className="text-[9.5px] text-slate-500 leading-relaxed mt-2.5">
                {isAr
                  ? 'البيانات من Open Food Facts — قاعدة مفتوحة المصدر ومجانية، ولا تستهلك أي حصة ذكاء اصطناعي.'
                  : 'Data from Open Food Facts — free and open source, zero AI requests.'}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
