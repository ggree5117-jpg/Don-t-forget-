import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Calendar,
  Clock,
  CheckCircle2,
  Plus,
  RefreshCw,
  ShoppingBag,
  Flame,
  Dna,
  Wheat,
  Droplet,
  ChevronDown,
  ChevronUp,
  Sliders,
  UtensilsCrossed,
  Heart,
  Moon,
  Activity,
  GlassWater,
  Timer,
  Check,
  AlertCircle,
  Lightbulb,
} from 'lucide-react';
import {
  DailyHealthMealPlan,
  PlannedMealItem,
  CuisineStyle,
  HealthGoal,
  LoggedMeal,
  DailyNutritionTarget,
  UserHealthProfile,
} from '../types/health';
import {
  generateDailyPlan,
  MEAL_ALTERNATIVES_DATABASE,
  DEFAULT_HEALTH_HABITS,
} from '../utils/dailyPlanData';
import { PlanGroceryModal } from './PlanGroceryModal';
import { MealImage } from './MealImage';

interface DailyMealPlanSectionProps {
  language: 'ar' | 'en';
  /** false عندما يكون الجهاز بدون إنترنت — تُستخدم الخطة المحلية */
  online?: boolean;
  nutritionTarget: DailyNutritionTarget;
  userProfile: UserHealthProfile;
  waterGlasses: number;
  onUpdateWaterGlasses: (count: number) => void;
  onAddMeal: (meal: Omit<LoggedMeal, 'id' | 'time'>) => void;
}

const CUISINE_OPTIONS: { id: CuisineStyle; nameAr: string; nameEn: string; icon: string }[] = [
  { id: 'arabic_healthy', nameAr: 'يمني وعربي صحي', nameEn: 'Arabic & Yemeni Healthy', icon: '🇾🇪' },
  { id: 'mediterranean', nameAr: 'البحر الأبيض المتوسط', nameEn: 'Mediterranean', icon: '🫒' },
  { id: 'high_protein', nameAr: 'عالي البروتين للرياضيين', nameEn: 'High Protein', icon: '🥩' },
  { id: 'low_carb', nameAr: 'كيتو / قليل الكربوهيدرات', nameEn: 'Low Carb / Keto', icon: '🥑' },
  { id: 'vegetarian', nameAr: 'نباتي صحي متكامل', nameEn: 'Plant-Based', icon: '🥗' },
];

export const DailyMealPlanSection: React.FC<DailyMealPlanSectionProps> = ({
  language,
  online = true,
  nutritionTarget,
  userProfile,
  waterGlasses,
  onUpdateWaterGlasses,
  onAddMeal,
}) => {
  const isAr = language === 'ar';

  // Active Plan State with LocalStorage Persistence
  const [activePlan, setActivePlan] = useState<DailyHealthMealPlan>(() => {
    try {
      const saved = localStorage.getItem('dont_forget_daily_meal_plan');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Failed to load saved plan:', e);
    }
    const targetCals = nutritionTarget.targetCalories || 2000;
    return generateDailyPlan('arabic_healthy', targetCals, userProfile.goal || 'maintain');
  });

  // UI States
  const [selectedCuisine, setSelectedCuisine] = useState<CuisineStyle>(activePlan.cuisineStyle || 'arabic_healthy');
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [isGroceryOpen, setIsGroceryOpen] = useState(false);
  const [swapSlotModal, setSwapSlotModal] = useState<PlannedMealItem | null>(null);
  const [notificationMsg, setNotificationMsg] = useState<{ textAr: string; textEn: string } | null>(null);
  const [expandedMealId, setExpandedMealId] = useState<string | null>(null);

  // Sync to LocalStorage on changes
  useEffect(() => {
    try {
      localStorage.setItem('dont_forget_daily_meal_plan', JSON.stringify(activePlan));
    } catch (e) {
      console.warn('Failed to save plan to localStorage:', e);
    }
  }, [activePlan]);

  const showToast = (textAr: string, textEn: string) => {
    setNotificationMsg({ textAr, textEn });
    setTimeout(() => {
      setNotificationMsg(null);
    }, 3200);
  };

  // Change Cuisine Style and re-generate
  const handleCuisineChange = (cuisine: CuisineStyle) => {
    setSelectedCuisine(cuisine);
    const targetCals = nutritionTarget.targetCalories || 2000;
    const newPlan = generateDailyPlan(cuisine, targetCals, userProfile.goal || 'maintain');
    setActivePlan(newPlan);
    showToast(
      `تم تحديث الخطة لنمط ${CUISINE_OPTIONS.find((c) => c.id === cuisine)?.nameAr}`,
      `Plan switched to ${CUISINE_OPTIONS.find((c) => c.id === cuisine)?.nameEn}`
    );
  };

  // Log meal into actual loggedMeals and mark planned item complete
  const handleLogPlannedMeal = (meal: PlannedMealItem) => {
    // 1. Add to real logged meals via parent callback
    onAddMeal({
      name: meal.name,
      nameAr: meal.nameAr,
      calories: meal.calories,
      protein: meal.protein,
      carbs: meal.carbs,
      fats: meal.fats,
      fiber: meal.fiber,
      portionSize: `${meal.portionWeightGrams}g`,
      portionSizeAr: `${meal.portionWeightGrams} جم`,
      mealType: meal.slot.startsWith('snack') ? 'snack' : (meal.slot as any),
    });

    // 2. Mark completed in active plan
    setActivePlan((prev) => ({
      ...prev,
      meals: prev.meals.map((m) => (m.id === meal.id ? { ...m, isCompleted: true } : m)),
    }));

    showToast(
      `تم تسجيل وجبة "${meal.nameAr}" واحتساب ${meal.calories} سعرة بنجاح! ✓`,
      `Logged "${meal.name}" (${meal.calories} kcal) successfully! ✓`
    );
  };

  // Swap meal with an alternative
  const handleSelectAlternative = (originalMealId: string, alt: any) => {
    setActivePlan((prev) => {
      const updatedMeals = prev.meals.map((m) => {
        if (m.id !== originalMealId) return m;

        // Scale calories to match slot target
        const slotScale = m.calories / (alt.baseCalories || m.calories);

        return {
          ...m,
          name: alt.nameEn,
          nameAr: alt.nameAr,
          calories: Math.round(alt.baseCalories * slotScale),
          protein: Math.round(alt.baseProtein * slotScale * 10) / 10,
          carbs: Math.round(alt.baseCarbs * slotScale * 10) / 10,
          fats: Math.round(alt.baseFats * slotScale * 10) / 10,
          fiber: Math.round(alt.baseFiber * slotScale * 10) / 10,
          portionWeightGrams: Math.round(alt.portionWeightGrams * slotScale),
          ingredientsAr: alt.ingredientsAr,
          ingredientsEn: alt.ingredientsEn,
          healthBenefitAr: alt.healthBenefitAr,
          healthBenefitEn: alt.healthBenefitEn,
          isCompleted: false, // Reset completion for new dish
        };
      });

      const totalPlannedCalories = updatedMeals.reduce((acc, cur) => acc + cur.calories, 0);
      const totalPlannedProtein = Math.round(updatedMeals.reduce((acc, cur) => acc + cur.protein, 0));
      const totalPlannedCarbs = Math.round(updatedMeals.reduce((acc, cur) => acc + cur.carbs, 0));
      const totalPlannedFats = Math.round(updatedMeals.reduce((acc, cur) => acc + cur.fats, 0));

      return {
        ...prev,
        meals: updatedMeals,
        totalPlannedCalories,
        totalPlannedProtein,
        totalPlannedCarbs,
        totalPlannedFats,
      };
    });

    setSwapSlotModal(null);
    showToast(
      `تم استبدال الوجبة بـ "${alt.nameAr}" بنجاح!`,
      `Swapped with "${alt.nameEn}" successfully!`
    );
  };

  // Generate Plan via Gemini AI endpoint (/api/generate-meal-plan)
  const handleGenerateAIPlan = async () => {
    // بدون إنترنت: نولّد الخطة محلياً فوراً بدل محاولة فاشلة
    if (!online) {
      const localPlan = generateDailyPlan(
        selectedCuisine,
        nutritionTarget.targetCalories || 2000,
        userProfile.goal || 'maintain'
      );
      setActivePlan(localPlan);
      showToast(
        'بدون إنترنت — تم توليد خطتك من قاعدة البيانات المحلية',
        'Offline — plan generated from the local nutrition database'
      );
      return;
    }

    setIsGeneratingAI(true);
    try {
      const res = await fetch('/api/generate-meal-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cuisineStyle: selectedCuisine,
          targetCalories: nutritionTarget.targetCalories || 2000,
          goal: userProfile.goal || 'maintain',
          language,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const generatedData: DailyHealthMealPlan = await res.json();
      if (generatedData && Array.isArray(generatedData.meals) && generatedData.meals.length > 0) {
        setActivePlan(generatedData);
        showToast('تم ابتكار خطة غذائية ذكية مخصصة لك بواسطة Gemini! ✨', 'Custom AI Meal Plan generated by Gemini! ✨');
      } else {
        throw new Error('Invalid plan structure');
      }
    } catch (err) {
      console.warn('AI generation error, generating local smart plan:', err);
      // Seamless smart local fallback
      const fallbackPlan = generateDailyPlan(selectedCuisine, nutritionTarget.targetCalories || 2000, userProfile.goal || 'maintain');
      setActivePlan(fallbackPlan);
      showToast('تم توليد الخطة الصحية اليومية بنجاح عبر قاعدة البيانات الغذائية', 'Daily health plan generated via nutrition database');
    } finally {
      setIsGeneratingAI(false);
    }
  };

  // Toggle habit completion
  const handleToggleHabit = (habitId: string) => {
    setActivePlan((prev) => ({
      ...prev,
      habits: prev.habits.map((h) => {
        if (h.id === habitId) {
          const nextState = !h.isCompleted;
          if (h.iconType === 'water' && nextState) {
            onUpdateWaterGlasses(Math.min(8, waterGlasses + 1));
          }
          return { ...h, isCompleted: nextState };
        }
        return h;
      }),
    }));
  };

  // Toggle Fasting Window
  const handleToggleFasting = () => {
    setActivePlan((prev) => ({
      ...prev,
      fastingWindow: {
        type: prev.fastingWindow?.type || '16:8',
        startHour: prev.fastingWindow?.startHour ?? 12,
        endHour: prev.fastingWindow?.endHour ?? 20,
        enabled: !prev.fastingWindow?.enabled,
      },
    }));
  };

  // Calculate completion progress
  const completedMealsCount = activePlan.meals.filter((m) => m.isCompleted).length;
  const planProgressPct = Math.round((completedMealsCount / Math.max(1, activePlan.meals.length)) * 100);

  return (
    <div className="space-y-6 pb-6 animate-fadeIn" dir={isAr ? 'rtl' : 'ltr'}>
      {/* Toast Notification */}
      {notificationMsg && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 bg-[#2C5282] text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-3 border border-white/20 animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-bold">{isAr ? notificationMsg.textAr : notificationMsg.textEn}</span>
        </div>
      )}

      {/* Hero Header & Quick Controls Card */}
      <div className="bg-gradient-to-br from-[#2C5282] via-[#244268] to-[#1A365D] rounded-3xl p-5 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-2xl -mr-20 -mt-20 pointer-events-none" />

        <div className="relative z-10 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-[#F3D58A] shadow-inner">
                <UtensilsCrossed className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-black tracking-tight">
                  {isAr ? 'الخطة اليومية للأكل والصحة' : 'Daily Eating & Health Plan'}
                </h2>
                <p className="text-xs text-blue-100/80">
                  {isAr ? 'جدول متكامل بـ 5 وجبات متوازنة وعادات صحية' : '5 Balanced Meals & Daily Wellness Habits'}
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsGroceryOpen(true)}
              className="py-2 px-3 rounded-xl bg-white/15 hover:bg-white/25 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 backdrop-blur-xs transition-all cursor-pointer border border-white/20"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>{isAr ? 'المشتريات' : 'Groceries'}</span>
            </button>
          </div>

          {/* Cuisine Selector Bar */}
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between text-xs text-blue-100/90 font-medium">
              <span>{isAr ? 'نمط المطبخ والحمية:' : 'Cuisine & Diet Style:'}</span>
              <span className="text-[11px] text-[#F3D58A] font-bold">
                {CUISINE_OPTIONS.find((c) => c.id === selectedCuisine)?.[isAr ? 'nameAr' : 'nameEn']}
              </span>
            </div>

            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
              {CUISINE_OPTIONS.map((c) => {
                const isSelected = selectedCuisine === c.id;
                return (
                  <button
                    key={c.id}
                    onClick={() => handleCuisineChange(c.id)}
                    className={`py-1.5 px-3 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-white text-[#2C5282] shadow-md scale-102 font-black'
                        : 'bg-white/10 text-white/80 hover:bg-white/20'
                    }`}
                  >
                    <span>{c.icon}</span>
                    <span>{isAr ? c.nameAr : c.nameEn}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Calorie & Macro Target Progress Indicator */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold flex items-center gap-1.5 text-white">
                <Flame className="w-4 h-4 text-amber-300" />
                <span>{isAr ? 'السعرات المخططة لليوم' : 'Planned Calories'}</span>
              </span>
              <span className="font-black text-sm text-[#F3D58A]">
                {activePlan.totalPlannedCalories}{' '}
                <span className="text-[11px] font-normal text-white/70">
                  / {nutritionTarget.targetCalories || 2000} {isAr ? 'سعرة' : 'kcal'}
                </span>
              </span>
            </div>

            {/* Target Progress Bar */}
            <div className="w-full h-2 bg-black/20 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-400 via-[#F3D58A] to-amber-400 transition-all duration-500 rounded-full"
                style={{
                  width: `${Math.min(
                    100,
                    (activePlan.totalPlannedCalories / Math.max(1, nutritionTarget.targetCalories || 2000)) * 100
                  )}%`,
                }}
              />
            </div>

            {/* Macro Summary Chips */}
            <div className="grid grid-cols-3 gap-2 pt-1 text-center">
              <div className="bg-white/10 rounded-xl py-1.5 px-2 border border-white/5">
                <div className="text-[10px] text-blue-100/70 font-semibold">{isAr ? 'بروتين' : 'Protein'}</div>
                <div className="text-xs font-black text-white">{activePlan.totalPlannedProtein}g</div>
              </div>
              <div className="bg-white/10 rounded-xl py-1.5 px-2 border border-white/5">
                <div className="text-[10px] text-blue-100/70 font-semibold">{isAr ? 'كربوهيدرات' : 'Carbs'}</div>
                <div className="text-xs font-black text-white">{activePlan.totalPlannedCarbs}g</div>
              </div>
              <div className="bg-white/10 rounded-xl py-1.5 px-2 border border-white/5">
                <div className="text-[10px] text-blue-100/70 font-semibold">{isAr ? 'دهون صحية' : 'Fats'}</div>
                <div className="text-xs font-black text-white">{activePlan.totalPlannedFats}g</div>
              </div>
            </div>
          </div>

          {/* AI Plan Generation Action Button */}
          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={handleGenerateAIPlan}
              disabled={isGeneratingAI}
              className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-400 to-[#F3D58A] hover:from-amber-300 hover:to-amber-400 text-slate-900 font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all active:scale-98 disabled:opacity-70 cursor-pointer"
            >
              {isGeneratingAI ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-slate-900" />
                  <span>{isAr ? 'جارٍ ابتكار الخطة بالذكاء الاصطناعي...' : 'Gemini Crafting Plan...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-800" />
                  <span>{isAr ? 'توليد خطة ذكية بالذكاء الاصطناعي' : 'Generate AI Plan with Gemini'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Progress & Status Card */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 flex items-center justify-between">
        <div className="space-y-0.5">
          <span className="text-xs font-bold text-slate-700">
            {isAr ? 'إنجاز وجبات اليوم:' : "Today's Meal Completion:"}
          </span>
          <p className="text-[11px] text-slate-500">
            {completedMealsCount} {isAr ? 'من أصل' : 'of'} {activePlan.meals.length} {isAr ? 'وجبات تم تناولها' : 'meals consumed'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-base font-black text-[#2C5282]">{planProgressPct}%</span>
          </div>
          <div className="w-12 h-12 rounded-full border-4 border-slate-100 flex items-center justify-center relative">
            <svg className="w-12 h-12 -rotate-90">
              <circle
                cx="24"
                cy="24"
                r="18"
                stroke="currentColor"
                strokeWidth="4"
                className="text-slate-100"
                fill="none"
              />
              <circle
                cx="24"
                cy="24"
                r="18"
                stroke="currentColor"
                strokeWidth="4"
                className="text-emerald-500 transition-all duration-700"
                fill="none"
                strokeDasharray="113"
                strokeDashoffset={113 - (113 * planProgressPct) / 100}
                strokeLinecap="round"
              />
            </svg>
            <span className="absolute text-[10px] font-bold text-slate-700">{completedMealsCount}/5</span>
          </div>
        </div>
      </div>

      {/* 5-Meal Schedule Cards */}
      <div className="space-y-3.5">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-sm font-black text-slate-800 flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#2C5282]" />
            <span>{isAr ? 'جدول الوجبات المخططة لليوم' : "Today's 5 Planned Meals"}</span>
          </h3>
          <span className="text-[11px] font-semibold text-slate-500">
            {activePlan.meals.length} {isAr ? 'وجبات' : 'meals'}
          </span>
        </div>

        <div className="space-y-3">
          {activePlan.meals.map((meal, idx) => {
            const isCompleted = !!meal.isCompleted;
            const isExpanded = expandedMealId === meal.id;

            return (
              <div
                key={meal.id}
                className={`bg-white rounded-3xl p-4 sm:p-5 transition-all border ${
                  isCompleted
                    ? 'border-emerald-200 bg-emerald-50/20 shadow-xs'
                    : 'border-slate-100 hover:border-blue-200 shadow-sm'
                }`}
              >
                {/* صورة الطبق — احترافية وموحّدة */}
                <div className="group mb-3">
                  <MealImage
                    nameAr={meal.nameAr}
                    nameEn={meal.name}
                    slot={meal.slot}
                    className="h-32 sm:h-36"
                    rounded="rounded-2xl"
                    badge={isAr ? meal.slotNameAr : meal.slotNameEn}
                    secondaryBadge={meal.recommendedTime}
                  />
                </div>

                {/* Meal Header row */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <div
                      className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 transition-colors ${
                        isCompleted
                          ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20'
                          : 'bg-[#2C5282]/10 text-[#2C5282]'
                      }`}
                    >
                      {isCompleted ? (
                        <Check className="w-5 h-5 stroke-[3]" />
                      ) : (
                        <span className="text-xs font-black">{idx + 1}</span>
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="text-[11px] font-black px-2.5 py-0.5 rounded-full bg-slate-100 text-[#2C5282]">
                          {isAr ? meal.slotNameAr : meal.slotNameEn}
                        </span>
                        <span className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{meal.recommendedTime}</span>
                        </span>
                        {isCompleted && (
                          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                            {isAr ? 'تم التناول ✓' : 'Consumed ✓'}
                          </span>
                        )}
                      </div>

                      <h4 className="text-sm font-black text-slate-800 leading-snug truncate">
                        {isAr ? meal.nameAr : meal.name}
                      </h4>

                      <div className="flex items-center gap-3 mt-1 text-xs text-slate-600 font-semibold flex-wrap">
                        <span className="text-amber-600 font-bold flex items-center gap-1">
                          <Flame className="w-3.5 h-3.5" />
                          <span>{meal.calories} {isAr ? 'سعرة' : 'kcal'}</span>
                        </span>
                        <span>•</span>
                        <span>{isAr ? 'بروتين' : 'P'}: {meal.protein}g</span>
                        <span>•</span>
                        <span>{isAr ? 'كارب' : 'C'}: {meal.carbs}g</span>
                        <span>•</span>
                        <span>{isAr ? 'دهون' : 'F'}: {meal.fats}g</span>
                        {meal.portionWeightGrams > 0 && (
                          <>
                            <span>•</span>
                            <span className="text-slate-400 font-normal">~{meal.portionWeightGrams}g</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Toggle expand button */}
                  <button
                    onClick={() => setExpandedMealId(isExpanded ? null : meal.id)}
                    className="p-1.5 rounded-xl hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                  >
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                </div>

                {/* Expanded Details: Ingredients & Health Benefit */}
                {isExpanded && (
                  <div className="mt-4 pt-3.5 border-t border-slate-100 space-y-3 animate-fadeIn">
                    {/* Ingredients */}
                    <div>
                      <span className="text-[11px] font-bold text-slate-600 block mb-1.5">
                        {isAr ? 'المكونات الموزونة:' : 'Portioned Ingredients:'}
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {(isAr ? meal.ingredientsAr : meal.ingredientsEn).map((ing, iIdx) => (
                          <span
                            key={iIdx}
                            className="text-[11px] px-2.5 py-1 rounded-xl bg-slate-50 text-slate-700 border border-slate-100 font-medium"
                          >
                            {ing}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Health Tip / Benefit */}
                    <div className="p-2.5 rounded-2xl bg-blue-50/60 border border-blue-100 text-blue-900 flex items-start gap-2 text-xs leading-relaxed">
                      <Lightbulb className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold">{isAr ? 'الفائدة الصحية:' : 'Health Benefit:'} </span>
                        <span>{isAr ? meal.healthBenefitAr : meal.healthBenefitEn}</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Card Actions Footer */}
                <div className="mt-3.5 pt-3 border-t border-slate-100 flex items-center gap-2">
                  <button
                    onClick={() => handleLogPlannedMeal(meal)}
                    disabled={isCompleted}
                    className={`flex-1 py-2.5 px-3 rounded-2xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      isCompleted
                        ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                        : 'bg-[#2C5282] hover:bg-[#1E3A5F] active:scale-98 text-white shadow-sm'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>
                      {isCompleted
                        ? isAr
                          ? 'تم تسجيل هذه الوجبة'
                          : 'Meal Logged'
                        : isAr
                        ? 'تناولت هذه الوجبة (تسجيل)'
                        : 'I Ate This (Log Meal)'}
                    </span>
                  </button>

                  <button
                    onClick={() => setSwapSlotModal(meal)}
                    className="py-2.5 px-3 rounded-2xl bg-slate-100 hover:bg-slate-200 active:scale-98 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
                    <span>{isAr ? 'استبدال' : 'Swap'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Daily Health Habits & Wellness Checklist */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Heart className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-800">
                {isAr ? 'عادات الصحة والنشاط اليومية' : 'Daily Health & Activity Habits'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {isAr ? 'ركائز متكاملة تدعم خطتك الغذائية وصحتك العامة' : 'Essential pillars supporting your wellness'}
              </p>
            </div>
          </div>
        </div>

        {/* Hydration Tracker Row */}
        <div className="bg-sky-50/70 rounded-2xl p-3.5 border border-sky-100 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-sky-900 flex items-center gap-1.5">
              <Droplet className="w-4 h-4 text-sky-500 fill-sky-500" />
              <span>{isAr ? 'شرب الماء على مدار اليوم (8 أكواب):' : 'Hydration Timeline (8 Glasses):'}</span>
            </span>
            <span className="text-xs font-black text-sky-700">
              {waterGlasses} / 8 {isAr ? 'أكواب' : 'cups'}
            </span>
          </div>

          <div className="grid grid-cols-8 gap-1.5 pt-1">
            {Array.from({ length: 8 }).map((_, idx) => {
              const isFilled = idx < waterGlasses;
              return (
                <button
                  key={idx}
                  onClick={() => onUpdateWaterGlasses(isFilled && idx === waterGlasses - 1 ? idx : idx + 1)}
                  className={`h-9 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                    isFilled
                      ? 'bg-sky-500 text-white shadow-xs scale-102 font-bold'
                      : 'bg-white hover:bg-sky-100/50 text-slate-300 border border-sky-200/60'
                  }`}
                  title={`${isAr ? 'كوب' : 'Glass'} ${idx + 1}`}
                >
                  <GlassWater className={`w-4 h-4 ${isFilled ? 'stroke-[2.5]' : 'stroke-1'}`} />
                </button>
              );
            })}
          </div>
        </div>

        {/* Interactive Habits Checklist */}
        <div className="space-y-2">
          {activePlan.habits.map((habit) => {
            const isDone = habit.isCompleted;

            return (
              <button
                key={habit.id}
                onClick={() => handleToggleHabit(habit.id)}
                className={`w-full text-right p-3 rounded-2xl border transition-all flex items-center justify-between cursor-pointer ${
                  isDone
                    ? 'bg-emerald-50/40 border-emerald-200 text-emerald-950'
                    : 'bg-slate-50/60 hover:bg-slate-100/60 border-slate-100 text-slate-800'
                }`}
                dir={isAr ? 'rtl' : 'ltr'}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-colors ${
                      isDone
                        ? 'bg-emerald-500 border-emerald-500 text-white'
                        : 'border-slate-300 bg-white'
                    }`}
                  >
                    {isDone && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>

                  <div>
                    <h5 className={`text-xs font-bold ${isDone ? 'line-through opacity-70' : ''}`}>
                      {isAr ? habit.titleAr : habit.titleEn}
                    </h5>
                    <p className="text-[10px] text-slate-500">
                      {isAr ? habit.descAr : habit.descEn}
                    </p>
                  </div>
                </div>

                {habit.targetValue && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-white text-slate-600 font-semibold border border-slate-200">
                    {habit.targetValue}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Fasting Window Tracker Widget (16:8) */}
        <div className="p-3.5 rounded-2xl bg-purple-50/60 border border-purple-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
              <Timer className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-purple-900 block">
                {isAr ? 'نافذة الصيام المتقطع (16:8)' : '16:8 Fasting Window'}
              </span>
              <p className="text-[10px] text-purple-700/80">
                {activePlan.fastingWindow?.enabled
                  ? isAr
                    ? 'النافذة مفعلة: تناول الوجبات بين 12:00 م و 08:00 م'
                    : 'Active: Eating window 12:00 PM – 08:00 PM'
                  : isAr
                  ? 'غير مفعل حالياً'
                  : 'Currently Disabled'}
              </p>
            </div>
          </div>

          <button
            onClick={handleToggleFasting}
            className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activePlan.fastingWindow?.enabled
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-white text-purple-700 border border-purple-200 hover:bg-purple-100/50'
            }`}
          >
            {activePlan.fastingWindow?.enabled ? (isAr ? 'مفعل ✓' : 'Enabled ✓') : (isAr ? 'تفعيل' : 'Enable')}
          </button>
        </div>
      </div>

      {/* Meal Swap Modal */}
      {swapSlotModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div
            className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[80vh] flex flex-col overflow-hidden border border-slate-100"
            dir={isAr ? 'rtl' : 'ltr'}
          >
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
              <div>
                <h4 className="text-sm font-black text-slate-800">
                  {isAr ? 'استبدال وجبة' : 'Swap Meal'}: {isAr ? swapSlotModal.slotNameAr : swapSlotModal.slotNameEn}
                </h4>
                <p className="text-[11px] text-slate-500">
                  {isAr ? 'اختر بديلاً صحياً يطابق احتياجاتك الغذائية' : 'Choose a healthy alternative matching your target'}
                </p>
              </div>

              <button
                onClick={() => setSwapSlotModal(null)}
                className="w-8 h-8 rounded-full bg-slate-200/60 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
              {(
                MEAL_ALTERNATIVES_DATABASE[selectedCuisine]?.[swapSlotModal.slot] ||
                MEAL_ALTERNATIVES_DATABASE['arabic_healthy'][swapSlotModal.slot]
              ).map((alt, altIdx) => (
                <button
                  key={altIdx}
                  onClick={() => handleSelectAlternative(swapSlotModal.id, alt)}
                  className="w-full text-right rounded-2xl bg-white hover:bg-slate-50 border border-slate-200/80 hover:border-[#2C5282]/40 transition-all flex items-stretch gap-2.5 p-2 shadow-2xs cursor-pointer group overflow-hidden"
                  dir={isAr ? 'rtl' : 'ltr'}
                >
                  {/* صورة مصغّرة للبديل */}
                  <div className="w-20 h-20 shrink-0">
                    <MealImage
                      nameAr={alt.nameAr}
                      nameEn={alt.nameEn}
                      slot={swapSlotModal.slot}
                      className="h-20"
                      rounded="rounded-xl"
                      priority={altIdx < 2}
                    />
                  </div>

                  <div className="flex flex-col gap-1 justify-center min-w-0 flex-1 py-0.5">
                    <div className="flex items-start justify-between gap-2 w-full">
                      <span className="text-xs font-black text-slate-800 group-hover:text-[#2C5282] transition-colors leading-snug line-clamp-2">
                        {isAr ? alt.nameAr : alt.nameEn}
                      </span>
                      <span className="text-[11px] font-black text-amber-600 shrink-0">
                        {alt.baseCalories}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 text-[10px] text-slate-500 font-semibold">
                      <span>{isAr ? 'بروتين' : 'P'} {alt.baseProtein}g</span>
                      <span>•</span>
                      <span>{isAr ? 'كارب' : 'C'} {alt.baseCarbs}g</span>
                      <span>•</span>
                      <span>{isAr ? 'دهون' : 'F'} {alt.baseFats}g</span>
                    </div>

                    <p className="text-[9.5px] text-slate-400 line-clamp-1">
                      {isAr ? alt.healthBenefitAr : alt.healthBenefitEn}
                    </p>
                  </div>
                </button>
              ))}
            </div>

            <div className="p-3.5 border-t border-slate-100 bg-white">
              <button
                onClick={() => setSwapSlotModal(null)}
                className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Grocery List Modal */}
      <PlanGroceryModal
        isOpen={isGroceryOpen}
        onClose={() => setIsGroceryOpen(false)}
        plan={activePlan}
        language={language}
      />
    </div>
  );
};
