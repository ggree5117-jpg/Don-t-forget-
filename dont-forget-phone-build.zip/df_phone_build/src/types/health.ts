export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export interface MacroBreakdown {
  protein: number; // in grams
  carbs: number;   // in grams
  fats: number;    // in grams
}

export type HealthGoal = 'lose_weight' | 'maintain' | 'gain_muscle';

export interface UserHealthProfile {
  name?: string;
  currentWeight: number | null;
  targetWeight: number | null;
  startWeight: number | null;
  heightCm: number | null;
  goal: HealthGoal | null;
  targetCalories: number | null;
  targetProtein: number | null;
  targetCarbs: number | null;
  targetFats: number | null;
  waterGlasses?: number;
}

export interface DailyNutritionTarget {
  targetCalories: number;
  consumedCalories: number;
  targetProtein: number;
  consumedProtein: number;
  targetCarbs: number;
  consumedCarbs: number;
  targetFats: number;
  consumedFats: number;
}

export interface FoodIngredientItem {
  id: string;
  name: string;
  nameAr: string;
  weightGrams: number;
  caloriesPer100g: number;
  proteinPer100g: number;
  carbsPer100g: number;
  fatsPer100g: number;
  fiberPer100g?: number;
  calories?: number;
  protein?: number;
  carbs?: number;
  fats?: number;
  fiber?: number;
}

export interface LoggedMeal {
  id: string;
  name: string;
  nameAr: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber?: number;
  time: string;
  mealType: MealType;
  imageUrl?: string;
  portionSize?: string;
  portionSizeAr?: string;
  portionChoice?: 'small' | 'medium' | 'large' | 'custom';
  healthTip?: string;
  healthTipAr?: string;
  healthInsightEn?: string;
  healthInsightAr?: string;
  confidence?: string;
  ingredients?: FoodIngredientItem[];
  totalWeightGrams?: number;
}

export interface FoodAnalysisResult {
  foodName: string;
  foodNameAr: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber?: number;
  portionSize?: string;
  portionSizeAr?: string;
  healthTip?: string;
  healthTipAr?: string;
  healthInsightEn?: string;
  healthInsightAr?: string;
  confidence?: string;
  imageUrl?: string;
  source?: string;
  ingredients?: FoodIngredientItem[];
  totalWeightGrams?: number;
}

export interface SuggestedMealIdea {
  titleAr: string;
  titleEn: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber?: number;
  ingredientsAr: string[];
  ingredientsEn: string[];
  healthBenefitAr: string;
  healthBenefitEn: string;
}

export interface NutritionAdviceResult {
  headlineAr: string;
  headlineEn: string;
  summaryAr: string;
  summaryEn: string;
  overallScore: number; // 0 - 100
  overallGradeAr: string;
  overallGradeEn: string;
  goalStatusAr: string;
  goalStatusEn: string;
  strengthsAr: string[];
  strengthsEn: string[];
  improvementsAr: string[];
  improvementsEn: string[];
  nextMealSuggestionAr: string;
  nextMealSuggestionEn: string;
  hydrationFeedbackAr: string;
  hydrationFeedbackEn: string;
  macroFeedbackAr: string;
  macroFeedbackEn: string;
  medicalTipsAr?: string[];
  medicalTipsEn?: string[];
  threeMealsIdeas?: {
    breakfast: SuggestedMealIdea;
    lunch: SuggestedMealIdea;
    dinner: SuggestedMealIdea;
  };
}

export type CuisineStyle = 'arabic_healthy' | 'mediterranean' | 'high_protein' | 'low_carb' | 'vegetarian';

export interface PlannedMealItem {
  id: string;
  slot: 'breakfast' | 'snack_am' | 'lunch' | 'snack_pm' | 'dinner';
  slotNameAr: string;
  slotNameEn: string;
  recommendedTime: string;
  name: string;
  nameAr: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber?: number;
  portionWeightGrams: number;
  ingredientsAr: string[];
  ingredientsEn: string[];
  healthBenefitAr: string;
  healthBenefitEn: string;
  isCompleted?: boolean;
}

export interface HealthHabitItem {
  id: string;
  titleAr: string;
  titleEn: string;
  descAr: string;
  descEn: string;
  iconType: 'water' | 'activity' | 'sleep' | 'fasting';
  targetValue?: string;
  isCompleted: boolean;
}

export interface DailyHealthMealPlan {
  planId: string;
  dateStr: string;
  cuisineStyle: CuisineStyle;
  totalPlannedCalories: number;
  totalPlannedProtein: number;
  totalPlannedCarbs: number;
  totalPlannedFats: number;
  goalSummaryAr: string;
  goalSummaryEn: string;
  meals: PlannedMealItem[];
  habits: HealthHabitItem[];
  fastingWindow?: {
    enabled: boolean;
    type: string; // e.g. '16:8'
    startHour: number; // e.g. 12
    endHour: number; // e.g. 20
  };
}

