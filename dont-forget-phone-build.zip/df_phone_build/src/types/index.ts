export type Language = 'ar' | 'en';

export type MainTab = 'home' | 'tasks' | 'health' | 'calendar' | 'settings';

export type CategoryType = 'habits' | 'health' | 'personal' | 'mind' | 'work' | 'study' | 'home' | 'other';

export type PriorityType = 'low' | 'medium' | 'high';

export type BuiltInRingtoneId =
  | 'classic'
  | 'phone'
  | 'chime'
  | 'digital'
  | 'crescendo'
  | 'melody';

export interface RingtoneInfo {
  id: BuiltInRingtoneId;
  nameAr: string;
  nameEn: string;
  descAr?: string;
  descEn?: string;
}

export interface CustomAudioRecord {
  id: string;
  name: string;
  fileName: string;
  size: number;
  type: string;
  blob: Blob;
  createdAt: number;
}

export interface TaskItem {
  id: string;
  title: string;
  description?: string;
  category: CategoryType;
  date: string; // e.g. "2026-11-06"
  time: string; // e.g. "09:00 PM"
  repeat: 'once' | 'daily' | 'weekly' | 'monthly';
  priority: PriorityType;
  completed: boolean;
  isOverdue?: boolean;
  iconType?: 'phone' | 'document' | 'gift' | 'briefcase' | 'book' | 'heart' | 'home';
  ringtoneId?: string;
}

