/**
 * Application & API Configuration
 *
 * For web deployments, API_BASE_URL defaults to '' (empty string), which uses relative paths (/api/*).
 * When wrapped with Capacitor for Android or iOS, set VITE_API_BASE_URL in your environment or set it here
 * to point to your deployed backend (e.g. 'https://ais-pre-5fzpoutwpfsh3vdriqzypf-175056997554.europe-west3.run.app').
 */

export const API_BASE_URL: string =
  (import.meta.env.VITE_API_BASE_URL as string | undefined)?.trim() || '';

/**
 * Returns the fully qualified URL for an API endpoint.
 *
 * @param endpoint Relative API endpoint, e.g. '/api/analyze-food' or 'api/health'
 * @returns Fully qualified URL if API_BASE_URL is set, or clean relative path if empty
 */
export function getApiUrl(endpoint: string): string {
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  if (!API_BASE_URL) {
    return cleanEndpoint;
  }
  const cleanBase = API_BASE_URL.replace(/\/+$/, '');
  return `${cleanBase}${cleanEndpoint}`;
}
