import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(<App />);

// ============================================================
// Service Worker: يجعل التطبيق يفتح بدون إنترنت (المهام والتنبيهات)
// لا يُفعّل في وضع التطوير حتى لا يتعارض مع HMR
// ============================================================
if (import.meta.env.PROD && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => {
      console.warn('[SW] registration failed:', err);
    });
  });
}
