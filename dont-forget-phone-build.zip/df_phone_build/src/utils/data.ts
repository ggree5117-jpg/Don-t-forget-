import { TaskItem, CategoryType, PriorityType } from '../types';

export interface CategoryStyle {
  id: CategoryType;
  titleAr: string;
  titleEn: string;
  iconColor: string;
  bgTint: string;
  borderColor: string;
  hoverBorder: string;
  glowColor: string;
}

export const CATEGORY_STYLES: Record<CategoryType, CategoryStyle> = {
  habits: {
    id: 'habits',
    titleAr: 'العادات اليومية',
    titleEn: 'Daily Habits',
    iconColor: '#2563EB',
    bgTint: '#EBF3FC',
    borderColor: '#D4E5FA',
    hoverBorder: '#93C5FD',
    glowColor: 'rgba(37, 99, 235, 0.15)',
  },
  health: {
    id: 'health',
    titleAr: 'الصحة والرياضة',
    titleEn: 'Health & Sports',
    iconColor: '#16A34A',
    bgTint: '#EBF9F1',
    borderColor: '#C8F0D9',
    hoverBorder: '#86EFAC',
    glowColor: 'rgba(22, 163, 74, 0.15)',
  },
  personal: {
    id: 'personal',
    titleAr: 'الشخصية وتطوير',
    titleEn: 'Personal & Growth',
    iconColor: '#D97706',
    bgTint: '#FEF4E8',
    borderColor: '#FDE2C6',
    hoverBorder: '#FCD34D',
    glowColor: 'rgba(217, 119, 6, 0.15)',
  },
  mind: {
    id: 'mind',
    titleAr: 'العقل والإنتاجية',
    titleEn: 'Mind & Productivity',
    iconColor: '#7C3AED',
    bgTint: '#F3EEFD',
    borderColor: '#E3D8FB',
    hoverBorder: '#C4B5FD',
    glowColor: 'rgba(124, 58, 237, 0.15)',
  },
  work: {
    id: 'work',
    titleAr: 'العمل',
    titleEn: 'Work',
    iconColor: '#3498DB',
    bgTint: '#EAF5FF',
    borderColor: 'rgba(52, 152, 219, 0.22)',
    hoverBorder: 'rgba(52, 152, 219, 0.5)',
    glowColor: 'rgba(52, 152, 219, 0.16)',
  },
  study: {
    id: 'study',
    titleAr: 'الدراسة',
    titleEn: 'Study',
    iconColor: '#2980B9',
    bgTint: '#E0F7FA',
    borderColor: 'rgba(41, 128, 185, 0.22)',
    hoverBorder: 'rgba(41, 128, 185, 0.5)',
    glowColor: 'rgba(41, 128, 185, 0.16)',
  },
  home: {
    id: 'home',
    titleAr: 'المنزل',
    titleEn: 'Home',
    iconColor: '#9271CF',
    bgTint: '#F1EAFE',
    borderColor: 'rgba(146, 113, 207, 0.22)',
    hoverBorder: 'rgba(146, 113, 207, 0.5)',
    glowColor: 'rgba(146, 113, 207, 0.16)',
  },
  other: {
    id: 'other',
    titleAr: 'أخرى',
    titleEn: 'Other',
    iconColor: '#3B6CB4',
    bgTint: '#EBF2FA',
    borderColor: 'rgba(59, 108, 180, 0.22)',
    hoverBorder: 'rgba(59, 108, 180, 0.5)',
    glowColor: 'rgba(59, 108, 180, 0.16)',
  },
};

export interface PriorityStyle {
  id: PriorityType;
  labelAr: string;
  labelEn: string;
  shortLabelAr: string;
  shortLabelEn: string;
  dotColor: string;
  borderColor: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  cardBg: string;
  cardBorder: string;
  hoverBorder: string;
  accentBorderColor: string;
  glowShadow: string;
}

export const PRIORITY_STYLES: Record<PriorityType, PriorityStyle> = {
  high: {
    id: 'high',
    labelAr: 'أولوية عالية',
    labelEn: 'High Priority',
    shortLabelAr: 'عالية',
    shortLabelEn: 'High',
    dotColor: '#EF4444',
    borderColor: '#FCA5A5',
    badgeBg: 'bg-rose-50',
    badgeText: 'text-rose-700',
    badgeBorder: 'border-rose-200/90',
    cardBg: 'bg-white',
    cardBorder: 'border-rose-200/80',
    hoverBorder: 'hover:border-rose-400',
    accentBorderColor: '#EF4444',
    glowShadow: '0 6px 18px -4px rgba(239, 68, 68, 0.1), 0 2px 6px -2px rgba(239, 68, 68, 0.05)',
  },
  medium: {
    id: 'medium',
    labelAr: 'أولوية متوسطة',
    labelEn: 'Medium Priority',
    shortLabelAr: 'متوسطة',
    shortLabelEn: 'Medium',
    dotColor: '#F59E0B',
    borderColor: '#FCD34D',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-700',
    badgeBorder: 'border-amber-200/90',
    cardBg: 'bg-white',
    cardBorder: 'border-amber-200/80',
    hoverBorder: 'hover:border-amber-400',
    accentBorderColor: '#F59E0B',
    glowShadow: '0 6px 18px -4px rgba(245, 158, 11, 0.1), 0 2px 6px -2px rgba(245, 158, 11, 0.05)',
  },
  low: {
    id: 'low',
    labelAr: 'أولوية منخفضة',
    labelEn: 'Low Priority',
    shortLabelAr: 'منخفضة',
    shortLabelEn: 'Low',
    dotColor: '#3B82F6',
    borderColor: '#93C5FD',
    badgeBg: 'bg-blue-50',
    badgeText: 'text-blue-700',
    badgeBorder: 'border-blue-200/90',
    cardBg: 'bg-white',
    cardBorder: 'border-blue-200/80',
    hoverBorder: 'hover:border-blue-400',
    accentBorderColor: '#3B82F6',
    glowShadow: '0 6px 18px -4px rgba(59, 130, 246, 0.1), 0 2px 6px -2px rgba(59, 130, 246, 0.05)',
  },
};

export const INITIAL_TASKS: TaskItem[] = [];

