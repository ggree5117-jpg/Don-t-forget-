/**
 * Perceptual Image Fingerprint (dHash 64-bit)
 * ============================================
 * Purpose: recognize the SAME meal photo again without calling the AI server at all.
 *
 * Why dHash?
 * - It is computed 100% on the device (canvas), costs ~1ms, zero network, zero tokens.
 * - It survives JPEG re-compression, small brightness changes and minor rescaling,
 *   unlike a plain MD5 of the file bytes.
 *
 * Algorithm:
 * 1. Draw the image on a 9x8 grayscale canvas.
 * 2. For every row, compare each pixel with its right neighbour (9 -> 8 comparisons).
 * 3. 8 rows x 8 comparisons = 64 bits, stored as a 16 character hex string.
 */

const HASH_WIDTH = 9;
const HASH_HEIGHT = 8;

/** Maximum number of differing bits that still counts as "the same meal". */
export const SIMILARITY_THRESHOLD_BITS = 10;

function loadImageElement(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to decode image for hashing'));
    img.src = dataUrl;
  });
}

function toHex64(bits: number[]): string {
  let hex = '';
  for (let i = 0; i < 64; i += 4) {
    const nibble = (bits[i] << 3) | (bits[i + 1] << 2) | (bits[i + 2] << 1) | bits[i + 3];
    hex += nibble.toString(16);
  }
  return hex;
}

/**
 * Computes a 64-bit perceptual hash from a data URL (image/jpeg, image/png ...).
 * Returns null when running outside a browser or when the canvas is unavailable.
 */
export async function computePerceptualHash(dataUrl: string): Promise<string | null> {
  if (typeof document === 'undefined' || !dataUrl) return null;

  try {
    const img = await loadImageElement(dataUrl);

    const canvas = document.createElement('canvas');
    canvas.width = HASH_WIDTH;
    canvas.height = HASH_HEIGHT;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(img, 0, 0, HASH_WIDTH, HASH_HEIGHT);
    const { data } = ctx.getImageData(0, 0, HASH_WIDTH, HASH_HEIGHT);

    // Convert to grayscale luminance (Rec. 601)
    const gray: number[] = [];
    for (let i = 0; i < data.length; i += 4) {
      gray.push(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
    }

    const bits: number[] = [];
    for (let y = 0; y < HASH_HEIGHT; y++) {
      for (let x = 0; x < HASH_WIDTH - 1; x++) {
        const left = gray[y * HASH_WIDTH + x];
        const right = gray[y * HASH_WIDTH + x + 1];
        bits.push(left > right ? 1 : 0);
      }
    }

    return toHex64(bits);
  } catch (err) {
    console.warn('[foodImageHash] unable to compute hash:', err);
    return null;
  }
}

function popcount32(n: number): number {
  n = n - ((n >> 1) & 0x55555555);
  n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
  n = (n + (n >> 4)) & 0x0f0f0f0f;
  return (n * 0x01010101) >> 24;
}

/** Hamming distance between two 16-char hex hashes (0 = identical, 64 = opposite). */
export function hashDistance(a: string, b: string): number {
  if (!a || !b || a.length !== b.length || a.length !== 16) return 64;
  let distance = 0;
  for (let i = 0; i < 16; i += 8) {
    const chunkA = parseInt(a.slice(i, i + 8), 16);
    const chunkB = parseInt(b.slice(i, i + 8), 16);
    if (Number.isNaN(chunkA) || Number.isNaN(chunkB)) return 64;
    distance += popcount32((chunkA ^ chunkB) >>> 0);
  }
  return distance;
}

/** True when two hashes most likely describe the same meal photo. */
export function isSimilarImageHash(
  a: string,
  b: string,
  thresholdBits: number = SIMILARITY_THRESHOLD_BITS
): boolean {
  return hashDistance(a, b) <= thresholdBits;
}
