import { DailyHealthMealPlan, PlannedMealItem, CuisineStyle, HealthHabitItem, HealthGoal } from '../types/health';

/**
 * Meal preset templates for each diet and slot
 */
interface MealTemplate {
  nameAr: string;
  nameEn: string;
  baseCalories: number;
  baseProtein: number;
  baseCarbs: number;
  baseFats: number;
  baseFiber: number;
  portionWeightGrams: number;
  ingredientsAr: string[];
  ingredientsEn: string[];
  healthBenefitAr: string;
  healthBenefitEn: string;
}

export const MEAL_ALTERNATIVES_DATABASE: Record<
  CuisineStyle,
  Record<'breakfast' | 'snack_am' | 'lunch' | 'snack_pm' | 'dinner', MealTemplate[]>
> = {
  arabic_healthy: {
    breakfast: [
      {
        nameAr: 'شكشوكة بيض بالخضار مع رغيف بر',
        nameEn: 'Healthy Shakshuka with Whole Wheat Flatbread',
        baseCalories: 380,
        baseProtein: 22,
        baseCarbs: 38,
        baseFats: 14,
        baseFiber: 6,
        portionWeightGrams: 280,
        ingredientsAr: ['بيضتان طازجتان', 'طماطم مفرومة', 'بصل وفلفل رومي', 'ملعقة صغيرة زيت زيتون', 'رغيف خبز بر نخالة'],
        ingredientsEn: ['2 fresh eggs', 'Diced tomatoes', 'Onion and bell peppers', '1 tsp olive oil', 'Whole wheat pita'],
        healthBenefitAr: 'غني بالبروتين الكامل والكولين لتنشيط التركيز والبدء بيوم مفعم بالطاقة.',
        healthBenefitEn: 'Packed with complete protein and choline for cognitive focus and sustained energy.',
      },
      {
        nameAr: 'فول مدمس بزيت الزيتون والكمون مع خبز حب',
        nameEn: 'Spiced Fava Beans (Ful Medames) with Whole Grain Bread',
        baseCalories: 410,
        baseProtein: 18,
        baseCarbs: 56,
        baseFats: 11,
        baseFiber: 12,
        portionWeightGrams: 300,
        ingredientsAr: ['كوب فول مطهو ومهروس', 'ملعقة زيت زيتون بكر', 'عصير نصف ليمونة', 'كمون وثوم وطماطم', 'خبز بر أسمر'],
        ingredientsEn: ['1 cup cooked fava beans', '1 tbsp extra virgin olive oil', 'Lemon juice', 'Cumin, garlic, tomato', 'Whole wheat bread'],
        healthBenefitAr: 'ألياف نباتية بطيئة الامتصاص تمنح شبعاً يدوم حتى منتصف الظهيرة.',
        healthBenefitEn: 'High-viscosity dietary fiber promotes steady glucose levels and long satiety.',
      },
    ],
    snack_am: [
      {
        nameAr: 'تمر سكري مع قهوة قشر ولوز نيء',
        nameEn: 'Dates with Raw Almonds & Light Qishr Coffee',
        baseCalories: 170,
        baseProtein: 4,
        baseCarbs: 26,
        baseFats: 6,
        baseFiber: 3,
        portionWeightGrams: 70,
        ingredientsAr: ['3 حبات تمر', '10 حبات لوز نيء', 'فنجان قهوة قشر يمنية بالزنجبيل والقرنفل'],
        ingredientsEn: ['3 dates', '10 raw almonds', 'Traditional light ginger-infused coffee'],
        healthBenefitAr: 'طاقة طبيعية سريعة ومضادات أكسدة ومعادن أساسية كالمغنيسيوم والبوتاسيوم.',
        healthBenefitEn: 'Natural energy with healthy fats and magnesium to fuel brain performance.',
      },
      {
        nameAr: 'تفاحة مع ملعقة زبدة فول سوداني طبيعية',
        nameEn: 'Fresh Apple Slices with Natural Peanut Butter',
        baseCalories: 190,
        baseProtein: 5,
        baseCarbs: 24,
        baseFats: 9,
        baseFiber: 4.5,
        portionWeightGrams: 160,
        ingredientsAr: ['حبة تفاح متوسطة', 'ملعقة كبيرة زبدة فول سوداني صافية'],
        ingredientsEn: ['1 medium apple', '1 tbsp natural peanut butter'],
        healthBenefitAr: 'توازن رائع بين سكر الفاكهة الطبيعي والدهون الأحادية غير المشبعة.',
        healthBenefitEn: 'Crisp fiber combined with healthy monounsaturated fats.',
      },
    ],
    lunch: [
      {
        nameAr: 'صالونة دجاج صحية بالخضار مع أرز بسمتي بني',
        nameEn: 'Tender Chicken Vegetable Stew with Brown Basmati Rice',
        baseCalories: 560,
        baseProtein: 46,
        baseCarbs: 58,
        baseFats: 13,
        baseFiber: 7,
        portionWeightGrams: 390,
        ingredientsAr: ['صدر دجاج مشوي 160 جم', 'كوب خضار مشكلة (كوسا، جزر، بامية)', 'كوب أرز بسمتي بني مطهو على البخار', 'مرق صحي وبهارات عربية'],
        ingredientsEn: ['160g chicken breast', 'Zucchini, carrot, and okra', '1 cup steamed brown basmati rice', 'Aromatic broth & spices'],
        healthBenefitAr: 'وجبة غنية بالبروتين الصافي وخفيفة على الجهاز الهضمي بدون زيوت مهدرجة.',
        healthBenefitEn: 'Lean protein paired with complex carbohydrates and vibrant phytonutrients.',
      },
      {
        nameAr: 'مندي دجاج صحي مطهو بدون دهون مع سلطة سحاوق خضراء',
        nameEn: 'Healthy Spiced Mandi Chicken with Fresh Sahawiq Salad',
        baseCalories: 580,
        baseProtein: 48,
        baseCarbs: 62,
        baseFats: 12,
        baseFiber: 6,
        portionWeightGrams: 410,
        ingredientsAr: ['صدر دجاج متبل ببهارات المندي والزعفران', 'كوب أرز حبة طويلة خفيف الزيت', 'سلطة سحاوق طماطم وكزبرة وفلفل أخضر'],
        ingredientsEn: ['Herbed Mandi chicken breast', '1 cup seasoned long-grain rice', 'Fresh tomato-cilantro salsa (Sahawiq)'],
        healthBenefitAr: 'نكهة تقليدية أصيلة ومحبوبة مع الحفاظ على عجز السعرات وضبط الدهون.',
        healthBenefitEn: 'Authentic traditional taste engineered with low oil for clean body composition.',
      },
    ],
    snack_pm: [
      {
        nameAr: 'زبادي يوناني قليل الدسم بالعسل وبذور الشيا',
        nameEn: 'Greek Yogurt with Pure Honey & Chia Seeds',
        baseCalories: 180,
        baseProtein: 16,
        baseCarbs: 18,
        baseFats: 4,
        baseFiber: 3,
        portionWeightGrams: 180,
        ingredientsAr: ['كوب زبادي يوناني 150 جم', 'ملعقة صغيرة عسل نقي', 'نصف ملعقة بذور شيا'],
        ingredientsEn: ['150g Greek yogurt', '1 tsp pure honey', '1/2 tsp chia seeds'],
        healthBenefitAr: 'بروتين بطيء الهضم (كازين) وبروبيوتيك يعزز صحة الميكروبيوم المعوي.',
        healthBenefitEn: 'Casein protein and live probiotics supporting gastrointestinal health.',
      },
      {
        nameAr: 'حفنة مكسرات مشكلة مع خيار وجزر مقرمش',
        nameEn: 'Mixed Raw Nuts with Crunchy Cucumber & Carrots',
        baseCalories: 160,
        baseProtein: 5,
        baseCarbs: 10,
        baseFats: 12,
        baseFiber: 4,
        portionWeightGrams: 140,
        ingredientsAr: ['20 جم جوز ولوز', 'خيارة مقطعة', 'حبة جزر أصابع'],
        ingredientsEn: ['20g walnuts and almonds', '1 cucumber sliced', 'Carrot sticks'],
        healthBenefitAr: 'أوميغا 3 ودهون مفيدة للقلب ومضادة للالتهابات.',
        healthBenefitEn: 'Cardioprotective omega-3 fatty acids and refreshing hydration.',
      },
    ],
    dinner: [
      {
        nameAr: 'سلطة تونة بالليمون والخردل والجرجير مع قطعة توست حب',
        nameEn: 'Zesty Tuna Arugula Salad with Whole Wheat Toast',
        baseCalories: 340,
        baseProtein: 34,
        baseCarbs: 22,
        baseFats: 8,
        baseFiber: 5,
        portionWeightGrams: 260,
        ingredientsAr: ['علبة تونة مصفاة بالماء 120 جم', 'حزمتان جرجير وطماطم كرزية', 'عصير ليمون ونصف ملعقة زيت زيتون', 'شريحة خبز حب كامل'],
        ingredientsEn: ['120g water-packed tuna', 'Wild arugula & cherry tomatoes', 'Lemon vinaigrette', '1 slice whole grain bread'],
        healthBenefitAr: 'عشاء خفيف جداً يمنع عسر الهضم ويضمن نوماً عميقاً ومريحاً.',
        healthBenefitEn: 'Light, nutrient-dense dinner minimizing nighttime digestive load for deep sleep.',
      },
      {
        nameAr: 'شوربة عدس صحية مع عصرة ليمون وبقدونس طازج',
        nameEn: 'Hearty Lentil Soup with Fresh Lemon & Herbs',
        baseCalories: 320,
        baseProtein: 19,
        baseCarbs: 48,
        baseFats: 5,
        baseFiber: 11,
        portionWeightGrams: 320,
        ingredientsAr: ['كوب شوربة عدس أصفر مطهوة مع بصل وجزر وكمون', 'ليمون طازج وبقدونس', 'شريحة خبز محمص بالفرن'],
        ingredientsEn: ['1.5 cup yellow lentil soup with cumin & carrots', 'Fresh lemon & parsley', 'Baked croutons'],
        healthBenefitAr: 'وجبة دافئة غنية بمضادات الأكسدة والحديد والألياف المنقية للجسم.',
        healthBenefitEn: 'Warm, mineral-rich comforting bowl with plant iron and prebiotic fibers.',
      },
    ],
  },
  mediterranean: {
    breakfast: [
      {
        nameAr: 'أومليت بالسبانخ وجبن الفيتا قليل الدسم',
        nameEn: 'Spinach & Low-Fat Feta Herb Omelette',
        baseCalories: 360,
        baseProtein: 24,
        baseCarbs: 18,
        baseFats: 16,
        baseFiber: 4,
        portionWeightGrams: 250,
        ingredientsAr: ['بيضتان كاملتان + بياض بيضة', 'كوب سبانخ طازجة', '30 جم جبن فيتا لايت', 'شريحة خبز حبة كاملة'],
        ingredientsEn: ['2 eggs + 1 white', 'Fresh baby spinach', '30g light feta', '1 slice whole grain toast'],
        healthBenefitAr: 'حديد وبروتين وأملاح معدنية تبدأ بها صباحك بنشاط وتوازن.',
        healthBenefitEn: 'Iron and bioavailable proteins supporting vascular health.',
      },
    ],
    snack_am: [
      {
        nameAr: 'حمص حب متبل بالبابريكا مع شرائح فلفل ملون',
        nameEn: 'Roasted Chickpeas with Bell Pepper Slices',
        baseCalories: 160,
        baseProtein: 7,
        baseCarbs: 24,
        baseFats: 3.5,
        baseFiber: 6,
        portionWeightGrams: 120,
        ingredientsAr: ['نصف كوب حمص مسلوق ومتبل', 'شرائح فلفل حلو أصفر وأحمر'],
        ingredientsEn: ['1/2 cup roasted chickpeas', 'Bell pepper strips'],
        healthBenefitAr: 'مقرمشات صحية بديلة للرقائق الصناعية.',
        healthBenefitEn: 'Crunchy plant-powered snack rich in vitamin C.',
      },
    ],
    lunch: [
      {
        nameAr: 'فيليه سمك سلمون مشوي مع كينوا وسلطة يونانية',
        nameEn: 'Grilled Salmon with Fluffy Quinoa & Greek Salad',
        baseCalories: 580,
        baseProtein: 44,
        baseCarbs: 46,
        baseFats: 20,
        baseFiber: 6,
        portionWeightGrams: 370,
        ingredientsAr: ['150 جم سلمون مشوي', 'نصف كوب كينوا مطهوة', 'خيار، طماطم، زيتون، ملعقة زيت زيتون'],
        ingredientsEn: ['150g grilled salmon fillet', '1/2 cup cooked quinoa', 'Cucumber, tomato, olives, olive oil'],
        healthBenefitAr: 'أقوى مصدر لأحماض أوميغا 3 لحماية القلب وتقليل الالتهابات العضلية.',
        healthBenefitEn: 'Premium omega-3 EPA/DHA for cardiovascular protection and recovery.',
      },
    ],
    snack_pm: [
      {
        nameAr: 'حفنة توت مشكل مع لبن رايب طبيعي',
        nameEn: 'Mixed Berries with Probiotic Kefir',
        baseCalories: 150,
        baseProtein: 8,
        baseCarbs: 22,
        baseFats: 2,
        baseFiber: 4,
        portionWeightGrams: 200,
        ingredientsAr: ['كوب توت أزرق وفراولة', 'كوب لبن رايب قليل الدسم'],
        ingredientsEn: ['1 cup berries', '1 cup probiotic kefir'],
        healthBenefitAr: 'مضادات أكسدة قوية تحمي الخلايا وتدعم مناعة الجسم.',
        healthBenefitEn: 'Anthocyanins and live cultures enhancing immune defense.',
      },
    ],
    dinner: [
      {
        nameAr: 'صدر ديك رومي مشوي مع خضار سوتيه بزيت الزيتون',
        nameEn: 'Roasted Turkey Breast with Herb-Steamed Greens',
        baseCalories: 330,
        baseProtein: 36,
        baseCarbs: 18,
        baseFats: 8,
        baseFiber: 6,
        portionWeightGrams: 280,
        ingredientsAr: ['140 جم صدر تركي', 'بروكلي وكوسا وفاصوليا خضراء', 'ملعقة صغيرة زيت زيتون وأعشاب'],
        ingredientsEn: ['140g turkey breast', 'Broccoli, zucchini, green beans', 'Olive oil drizzle'],
        healthBenefitAr: 'بروتين نقي جداً ومغنيسيوم يساعد في استرخاء العضلات ليلاً.',
        healthBenefitEn: 'Lean poultry protein with magnesium-rich greens supporting muscle relaxation.',
      },
    ],
  },
  high_protein: {
    breakfast: [
      {
        nameAr: 'شوفان بروتيني بزبدة اللوز والموز وبياض البيض',
        nameEn: 'High-Protein Oatmeal with Almond Butter & Whey/Egg',
        baseCalories: 430,
        baseProtein: 35,
        baseCarbs: 48,
        baseFats: 10,
        baseFiber: 7,
        portionWeightGrams: 300,
        ingredientsAr: ['نصف كوب شوفان كامل', 'سكوب بروتين أو 3 بياض بيض مطهو معه', 'نصف موزة مقطعة', 'ملعقة زبدة لوز'],
        ingredientsEn: ['1/2 cup rolled oats', 'Protein booster', '1/2 sliced banana', '1 tbsp almond butter'],
        healthBenefitAr: 'تغذية عضلية فورية تحمي الكتلة العضلية وتمنع الهدم.',
        healthBenefitEn: 'Optimal muscle protein synthesis kickoff with sustained glycogen fuel.',
      },
    ],
    snack_am: [
      {
        nameAr: 'شيك بروتين مع ماء جوز الهند وحفنة لوز',
        nameEn: 'Isolate Protein Shake with Coconut Water & Almonds',
        baseCalories: 210,
        baseProtein: 28,
        baseCarbs: 12,
        baseFats: 6,
        baseFiber: 2,
        portionWeightGrams: 320,
        ingredientsAr: ['سكوب بروتين معزول 25 جم', 'كوب ماء أو ماء جوز هند', '8 حبات لوز'],
        ingredientsEn: ['25g whey isolate', 'Electrolyte water', '8 almonds'],
        healthBenefitAr: 'امتصاص فوري للأحماض الأمينية متفرعة السلسلة BCAA.',
        healthBenefitEn: 'Fast-digesting amino acids aiding immediate muscle tissue repair.',
      },
    ],
    lunch: [
      {
        nameAr: 'ستيك لحم بقري صافي مع بطاطا حلوة وبروكلي مشوي',
        nameEn: 'Lean Beef Tenderloin with Baked Sweet Potato & Broccoli',
        baseCalories: 620,
        baseProtein: 52,
        baseCarbs: 52,
        baseFats: 15,
        baseFiber: 8,
        portionWeightGrams: 380,
        ingredientsAr: ['180 جم فيليه لحم قليل الدهن', 'حبة بطاطا حلوة مشوية 150 جم', 'كوب بروكلي مطهو بالثوم'],
        ingredientsEn: ['180g lean tenderloin', '150g baked sweet potato', 'Garlic broccoli'],
        healthBenefitAr: 'حديد وزنك وكرياتين طبيعي لتعزيز القوة العضلية والتعافي الرياضي.',
        healthBenefitEn: 'Natural creatine and bioavailable heme iron enhancing athletic power.',
      },
    ],
    snack_pm: [
      {
        nameAr: 'جبن قريش (كوتج) مع أناناس وقرفة',
        nameEn: 'Cottage Cheese with Fresh Pineapple & Cinnamon',
        baseCalories: 190,
        baseProtein: 22,
        baseCarbs: 16,
        baseFats: 3,
        baseFiber: 2,
        portionWeightGrams: 200,
        ingredientsAr: ['كوب جبن قريش 160 جم', 'نصف كوب أناناس طازج', 'رشة قرفة'],
        ingredientsEn: ['160g cottage cheese', 'Fresh pineapple chunks', 'Pinch of cinnamon'],
        healthBenefitAr: 'إنزيم البروميلين في الأناناس يساعد في هضم البروتين وامتصاصه بكفاءة.',
        healthBenefitEn: 'Bromelain enzymes enhance proteolytic digestion and recovery.',
      },
    ],
    dinner: [
      {
        nameAr: 'صدر دجاج مشوي مع سلطة كينوا بالأفوكادو والطماطم',
        nameEn: 'Grilled Chicken Breasts over Quinoa Avocado Bowl',
        baseCalories: 450,
        baseProtein: 46,
        baseCarbs: 32,
        baseFats: 11,
        baseFiber: 6,
        portionWeightGrams: 320,
        ingredientsAr: ['160 جم صدر دجاج متبل بالليمون والأوريجانو', 'نصف كوب كينوا', 'ربع حبة أفوكادو وخضار مشكلة'],
        ingredientsEn: ['160g lemon chicken', '1/2 cup quinoa', '1/4 sliced avocado, mixed greens'],
        healthBenefitAr: 'ترميم الألياف العضلية خلال النوم مع دهون صحية لدعم الهرمونات.',
        healthBenefitEn: 'Nighttime muscular remodeling supported by hormone-optimizing fats.',
      },
    ],
  },
  low_carb: {
    breakfast: [
      {
        nameAr: 'بيض مخفوق بزيت الزيتون والأفوكادو والجرجير',
        nameEn: 'Scrambled Eggs with Avocado & Fresh Greens',
        baseCalories: 370,
        baseProtein: 20,
        baseCarbs: 8,
        baseFats: 28,
        baseFiber: 6,
        portionWeightGrams: 220,
        ingredientsAr: ['3 بيضات', 'نصف حبة أفوكادو', 'ملعقة صغيرة زيت زيتون', 'جرجير وطماطم كرزية'],
        ingredientsEn: ['3 eggs', '1/2 avocado', '1 tsp olive oil', 'Wild greens'],
        healthBenefitAr: 'استقرار تام في مستويات الإنسولين وتشغيل حرق الدهون كمصدر طاقة رئيسي.',
        healthBenefitEn: 'Minimizes insulin spikes, encouraging metabolic flexibility and fat oxidation.',
      },
    ],
    snack_am: [
      {
        nameAr: 'أصابع خيار مع غواكامولي أفوكادو',
        nameEn: 'Cucumber Slices with Zesty Guacamole',
        baseCalories: 140,
        baseProtein: 2,
        baseCarbs: 6,
        baseFats: 12,
        baseFiber: 4,
        portionWeightGrams: 150,
        ingredientsAr: ['خيارتان مقطعتان أصابع', 'ملعقتان غواكامولي مهروس بالليمون والكزبرة'],
        ingredientsEn: ['Cucumber sticks', '2 tbsp lime guacamole'],
        healthBenefitAr: 'سناك قليل الكربوهيدرات وغني بالألياف والبوتاسيوم.',
        healthBenefitEn: 'Hydrating low-glycemic crunch rich in natural potassium.',
      },
    ],
    lunch: [
      {
        nameAr: 'وعاء شاورما دجاج صحية مع أرز القرنبيط وسلطة طحينة',
        nameEn: 'Shawarma Spiced Chicken Bowl with Cauliflower Rice',
        baseCalories: 480,
        baseProtein: 42,
        baseCarbs: 12,
        baseFats: 24,
        baseFiber: 7,
        portionWeightGrams: 360,
        ingredientsAr: ['170 جم شاورما دجاج متبلة بالبهارات', 'كوب ونصف قرنبيط مبشور ومطهو', 'ملعقة طحينة سمسم وعصير ليمون'],
        ingredientsEn: ['170g seasoned chicken shawarma', '1.5 cups riced cauliflower', '1 tbsp sesame tahini & lemon'],
        healthBenefitAr: 'بديل رائع للأرز التقليدي يقلل الكارب بنسبة 80% مع شبع كامل.',
        healthBenefitEn: 'Delicious low-carb cauliflower base reducing carbohydrate load by over 80%.',
      },
    ],
    snack_pm: [
      {
        nameAr: 'مكسرات عين الجمل (جوز) مع قطعة جبن شيدر قديم',
        nameEn: 'Walnut Halves with Aged Cheddar Slice',
        baseCalories: 180,
        baseProtein: 7,
        baseCarbs: 3,
        baseFats: 16,
        baseFiber: 2,
        portionWeightGrams: 50,
        ingredientsAr: ['20 جم عين جمل', '25 جم جبن شيدر طبيعي'],
        ingredientsEn: ['20g walnuts', '25g aged cheddar'],
        healthBenefitAr: 'دهون نقية تمنح صفاء ذهنياً بدون هبوط طاقة ما بعد الظهيرة.',
        healthBenefitEn: 'Brain-boosting fats maintaining mental focus without post-prandial crashes.',
      },
    ],
    dinner: [
      {
        nameAr: 'سمك فيليه مشوي بالأعشاب مع سلطة تبولة القرنبيط',
        nameEn: 'Herb-Crusted Fish Fillet with Cauliflower Tabbouleh',
        baseCalories: 350,
        baseProtein: 38,
        baseCarbs: 10,
        baseFats: 16,
        baseFiber: 5,
        portionWeightGrams: 300,
        ingredientsAr: ['180 جم سمك فيليه أبيض', 'تبولة بالبقدونس والقرنفل وزيت الزيتون والليمون'],
        ingredientsEn: ['180g white fish fillet', 'Fresh parsley and cauliflower tabbouleh'],
        healthBenefitAr: 'وجبة غنية باليود والسيلينيوم تدعم وظائف الغدة الدرقية وتنظيم الحرق.',
        healthBenefitEn: 'Rich in iodine and selenium to nourish thyroid function and resting metabolism.',
      },
    ],
  },
  vegetarian: {
    breakfast: [
      {
        nameAr: 'توست الحبوب مع الأفوكادو والبيض المسلوق والطماطم',
        nameEn: 'Avocado Toast with Poached Egg & Tomatoes',
        baseCalories: 360,
        baseProtein: 16,
        baseCarbs: 36,
        baseFats: 16,
        baseFiber: 8,
        portionWeightGrams: 240,
        ingredientsAr: ['شريحة خبز قمح كامل', 'نصف حبة أفوكادو مهروسة', 'بيضة مسلوقة', 'طماطم كرزية وبذور سمسم'],
        ingredientsEn: ['1 whole grain bread slice', '1/2 mashed avocado', '1 poached egg', 'Cherry tomatoes & sesame'],
        healthBenefitAr: 'ألياف ودهون أحادية غير مشبعة تمنح شبعاً ومزاجاً مستقراً.',
        healthBenefitEn: 'Soluble fibers and wholesome fats sustaining mood and satiety.',
      },
    ],
    snack_am: [
      {
        nameAr: 'حفنة إدمامي (فول صويا أخضر) بالملح البحري',
        nameEn: 'Steamed Edamame Pods with Sea Salt',
        baseCalories: 150,
        baseProtein: 14,
        baseCarbs: 11,
        baseFats: 5,
        baseFiber: 6,
        portionWeightGrams: 150,
        ingredientsAr: ['كوب إدمامي مطهو على البخار', 'رشة ملح بحري'],
        ingredientsEn: ['1 cup steamed edamame pods', 'Pinch of sea salt'],
        healthBenefitAr: 'بروتين نباتي متكامل يحتوي على كافة الأحماض الأمينية الأساسية.',
        healthBenefitEn: 'Complete plant-based protein providing all nine essential amino acids.',
      },
    ],
    lunch: [
      {
        nameAr: 'طبق كينوا بالحمص والخضار المشوية وصوص الطحينة',
        nameEn: 'Mediterranean Quinoa Chickpea Bowl with Tahini Drizzle',
        baseCalories: 520,
        baseProtein: 22,
        baseCarbs: 68,
        baseFats: 17,
        baseFiber: 13,
        portionWeightGrams: 380,
        ingredientsAr: ['كوب كينوا مطهوة', 'نصف كوب حمص مسلوق', 'باذنجان وكوسا وفلفل مشوي', 'ملعقة طحينة سمسم وعصير ليمون'],
        ingredientsEn: ['1 cup cooked quinoa', '1/2 cup chickpeas', 'Grilled eggplant, zucchini & peppers', 'Lemon-tahini dressing'],
        healthBenefitAr: 'مزيج الكينوا والحمص يوفر بروتيناً نباتياً مثالياً يضاهي المصادر الحيوانية.',
        healthBenefitEn: 'Synergistic amino acid profile equivalent to complete animal proteins.',
      },
    ],
    snack_pm: [
      {
        nameAr: 'سموذي الموز بالتوت وحليب اللوز وبذور القنب',
        nameEn: 'Berry Banana Smoothie with Hemp Seeds & Almond Milk',
        baseCalories: 180,
        baseProtein: 8,
        baseCarbs: 26,
        baseFats: 5,
        baseFiber: 4.5,
        portionWeightGrams: 280,
        ingredientsAr: ['نصف موزة مجمدة', 'كوب توت مشكل', 'كوب حليب لوز غير محلى', 'ملعقة بذور قنب'],
        ingredientsEn: ['1/2 frozen banana', 'Mixed berries', 'Almond milk', '1 tbsp hemp hearts'],
        healthBenefitAr: 'مشروب منعش غني بمضادات الأكسدة ومجدد لطاقة الجسم.',
        healthBenefitEn: 'Refreshing cellular rejuvenation packed with flavonoids.',
      },
    ],
    dinner: [
      {
        nameAr: 'شوربة خضار غنية بالفاصوليا البيضاء وزيت الزيتون',
        nameEn: 'Hearty Tuscan White Bean & Kale Vegetable Soup',
        baseCalories: 330,
        baseProtein: 16,
        baseCarbs: 46,
        baseFats: 7,
        baseFiber: 12,
        portionWeightGrams: 340,
        ingredientsAr: ['كوب فاصوليا بيضاء مطهوة', 'خضروات موسمية وسلق أو سبانخ', 'مرق خضار وزيت زيتون بكر'],
        ingredientsEn: ['Cooked cannellini beans', 'Seasonal veggies, kale & carrots', 'Vegetable broth & olive oil'],
        healthBenefitAr: 'عشاء دافئ مريح للأمعاء يعزز نضارة البشرة والتخلص من السموم.',
        healthBenefitEn: 'Gentle, comforting digest-easy supper rich in detoxifying prebiotic fibers.',
      },
    ],
  },
};

/**
 * Standard Daily Health Habits Checklist
 */
export const DEFAULT_HEALTH_HABITS: HealthHabitItem[] = [
  {
    id: 'habit_water_morning',
    titleAr: 'كوبان من الماء عند الاستيقاظ',
    titleEn: '2 glasses of water upon waking',
    descAr: 'تنشيط الدورة الدموية والجهاز الهضمي وطرد الفضلات بعد ساعات النوم.',
    descEn: 'Rehydrate, ignite metabolism, and flush kidneys after night rest.',
    iconType: 'water',
    targetValue: '500 مل',
    isCompleted: false,
  },
  {
    id: 'habit_water_day',
    titleAr: 'توزيع شرب 6 أكواب ماء على مدار اليوم',
    titleEn: 'Distribute 6 glasses across the day',
    descAr: 'كوب قبل كل وجبة وكوب بينها للوصول للهدف الإجمالي (8 أكواب / 2 لتر).',
    descEn: 'One glass before each meal to enhance satiety and cellular hydration.',
    iconType: 'water',
    targetValue: '1.5 لتر',
    isCompleted: false,
  },
  {
    id: 'habit_movement',
    titleAr: 'نشاط حركي يومي (مشي أو تمرين 30 دقيقة)',
    titleEn: 'Daily Movement (30-min walk or workout)',
    descAr: 'المحافظة على معدل نبضات القلب وحرق الدهون وتحفيز النشاط الذهني.',
    descEn: 'Keep blood flowing, elevate daily expenditure, and reduce stress.',
    iconType: 'activity',
    targetValue: '30 دقيقة',
    isCompleted: false,
  },
  {
    id: 'habit_sleep',
    titleAr: 'نوم صحي ومبكر (7 إلى 8 ساعات)',
    titleEn: 'Deep restorative sleep (7-8 hours)',
    descAr: 'الاستشفاء العضلي العميق وتوازن هرمونات الشبع (اللبتين والجرلين).',
    descEn: 'Optimize hormone regulation, muscle recovery, and insulin sensitivity.',
    iconType: 'sleep',
    targetValue: '7-8 ساعات',
    isCompleted: false,
  },
  {
    id: 'habit_fasting',
    titleAr: 'نافذة الأكل المنظمة (صيام 14-16 ساعة اختيارياً)',
    titleEn: 'Time-Restricted Eating Window (14-16h fasting)',
    descAr: 'إراحة الجهاز الهضمي ليلاً وتحفيز الالتهام الذاتي والتجدد الخلوي.',
    descEn: 'Rest digestive tract overnight to stimulate cellular renewal and autophagy.',
    iconType: 'fasting',
    targetValue: '16:8',
    isCompleted: false,
  },
];

/**
 * Generates an optimized, calibrated daily plan matching the user's exact calorie target and diet preference
 */
export function generateDailyPlan(
  cuisineStyle: CuisineStyle = 'arabic_healthy',
  targetCalories = 2000,
  goal: HealthGoal = 'maintain'
): DailyHealthMealPlan {
  const templates = MEAL_ALTERNATIVES_DATABASE[cuisineStyle] || MEAL_ALTERNATIVES_DATABASE.arabic_healthy;

  // Calorie Distribution Weights
  // Breakfast: 25%, Snack AM: 10%, Lunch: 35%, Snack PM: 10%, Dinner: 20%
  const distribution = {
    breakfast: 0.25,
    snack_am: 0.10,
    lunch: 0.35,
    snack_pm: 0.10,
    dinner: 0.20,
  };

  const slots: Array<{
    slot: 'breakfast' | 'snack_am' | 'lunch' | 'snack_pm' | 'dinner';
    slotNameAr: string;
    slotNameEn: string;
    time: string;
  }> = [
    { slot: 'breakfast', slotNameAr: 'فطور الصباح', slotNameEn: 'Breakfast', time: '08:30 ص' },
    { slot: 'snack_am', slotNameAr: 'سناك الصباح والطاقة', slotNameEn: 'Morning Fuel', time: '11:30 ص' },
    { slot: 'lunch', slotNameAr: 'الغداء المتوازن', slotNameEn: 'Balanced Lunch', time: '02:30 م' },
    { slot: 'snack_pm', slotNameAr: 'سناك المساء الخفيف', slotNameEn: 'Afternoon Fuel', time: '05:30 م' },
    { slot: 'dinner', slotNameAr: 'العشاء الصحي', slotNameEn: 'Light Dinner', time: '08:30 م' },
  ];

  let calculatedMeals: PlannedMealItem[] = [];

  slots.forEach((s) => {
    const slotTemplates = templates[s.slot] || MEAL_ALTERNATIVES_DATABASE.arabic_healthy[s.slot];
    const picked = slotTemplates[0];

    const slotTargetKcal = Math.round(targetCalories * distribution[s.slot]);
    const scaleFactor = picked.baseCalories > 0 ? slotTargetKcal / picked.baseCalories : 1;

    calculatedMeals.push({
      id: `plan_meal_${s.slot}_${Date.now()}`,
      slot: s.slot,
      slotNameAr: s.slotNameAr,
      slotNameEn: s.slotNameEn,
      recommendedTime: s.time,
      name: picked.nameEn,
      nameAr: picked.nameAr,
      calories: slotTargetKcal,
      protein: Math.max(5, Math.round(picked.baseProtein * scaleFactor)),
      carbs: Math.max(5, Math.round(picked.baseCarbs * scaleFactor)),
      fats: Math.max(2, Math.round(picked.baseFats * scaleFactor)),
      fiber: Math.max(1, Math.round(picked.baseFiber * scaleFactor)),
      portionWeightGrams: Math.round(picked.portionWeightGrams * scaleFactor),
      ingredientsAr: picked.ingredientsAr,
      ingredientsEn: picked.ingredientsEn,
      healthBenefitAr: picked.healthBenefitAr,
      healthBenefitEn: picked.healthBenefitEn,
      isCompleted: false,
    });
  });

  const totalCalories = calculatedMeals.reduce((acc, m) => acc + m.calories, 0);
  const totalProtein = calculatedMeals.reduce((acc, m) => acc + m.protein, 0);
  const totalCarbs = calculatedMeals.reduce((acc, m) => acc + m.carbs, 0);
  const totalFats = calculatedMeals.reduce((acc, m) => acc + m.fats, 0);

  const goalSummaryAr =
    goal === 'lose_weight'
      ? 'خطة مصممة بعجز سعرات مدروس وغنية بالبروتين والألياف لضمان الشبع المستمر وحرق الدهون بكفاءة.'
      : goal === 'gain_muscle'
      ? 'خطة عالية البروتين والمغذيات الرياضية لتعزيز البناء العضلي والتعافي السريع.'
      : 'خطة متوازنة ومتكاملة للحفاظ على الوزن المثالي والطاقة المستدامة طوال اليوم.';

  const goalSummaryEn =
    goal === 'lose_weight'
      ? 'Calibrated with a precise deficit and high satiety fibers for optimal fat loss.'
      : goal === 'gain_muscle'
      ? 'High-protein athlete-tailored plan for hypertrophy and accelerated recovery.'
      : 'Harmonious macro split for sustainable energy, vitality, and weight maintenance.';

  return {
    planId: `plan_${Date.now()}`,
    dateStr: new Date().toISOString().split('T')[0],
    cuisineStyle,
    totalPlannedCalories: totalCalories,
    totalPlannedProtein: totalProtein,
    totalPlannedCarbs: totalCarbs,
    totalPlannedFats: totalFats,
    goalSummaryAr,
    goalSummaryEn,
    meals: calculatedMeals,
    habits: DEFAULT_HEALTH_HABITS.map((h) => ({ ...h })),
    fastingWindow: {
      enabled: false,
      type: '16:8',
      startHour: 12,
      endHour: 20,
    },
  };
}

/**
 * Generates an aggregated grocery shopping list from all planned meals
 */
export function getGroceryListFromPlan(plan: DailyHealthMealPlan): {
  categoryAr: string;
  categoryEn: string;
  itemsAr: string[];
  itemsEn: string[];
}[] {
  const allAr: string[] = [];
  const allEn: string[] = [];

  plan.meals.forEach((m) => {
    allAr.push(...m.ingredientsAr);
    allEn.push(...m.ingredientsEn);
  });

  // Group into clean pantry categories
  return [
    {
      categoryAr: 'البروتينات ومصادر التغذية',
      categoryEn: 'Proteins & Dairy',
      itemsAr: allAr.filter((i) => i.includes('بيض') || i.includes('دجاج') || i.includes('سمك') || i.includes('تونة') || i.includes('لحم') || i.includes('زبادي') || i.includes('جبن')),
      itemsEn: allEn.filter((i) => i.toLowerCase().includes('egg') || i.toLowerCase().includes('chicken') || i.toLowerCase().includes('salmon') || i.toLowerCase().includes('tuna') || i.toLowerCase().includes('beef') || i.toLowerCase().includes('yogurt') || i.toLowerCase().includes('cheese')),
    },
    {
      categoryAr: 'الخضروات الطازجة والفواكه',
      categoryEn: 'Fresh Produce & Fruits',
      itemsAr: allAr.filter((i) => i.includes('طماطم') || i.includes('خيار') || i.includes('جرجير') || i.includes('سبانخ') || i.includes('ليمون') || i.includes('تفاح') || i.includes('بصل') || i.includes('فلفل') || i.includes('بروكلي') || i.includes('جزر') || i.includes('تمر') || i.includes('أناناس')),
      itemsEn: allEn.filter((i) => i.toLowerCase().includes('tomato') || i.toLowerCase().includes('cucumber') || i.toLowerCase().includes('spinach') || i.toLowerCase().includes('apple') || i.toLowerCase().includes('onion') || i.toLowerCase().includes('broccoli') || i.toLowerCase().includes('carrot') || i.toLowerCase().includes('dates') || i.toLowerCase().includes('greens')),
    },
    {
      categoryAr: 'الكربوهيدرات الصحية والمكسرات',
      categoryEn: 'Whole Grains & Pantry',
      itemsAr: allAr.filter((i) => i.includes('خبز') || i.includes('أرز') || i.includes('شوفان') || i.includes('كينوا') || i.includes('لوز') || i.includes('جوز') || i.includes('فول') || i.includes('حمص') || i.includes('عدس') || i.includes('زيت')),
      itemsEn: allEn.filter((i) => i.toLowerCase().includes('bread') || i.toLowerCase().includes('rice') || i.toLowerCase().includes('oat') || i.toLowerCase().includes('quinoa') || i.toLowerCase().includes('almond') || i.toLowerCase().includes('oil') || i.toLowerCase().includes('beans') || i.toLowerCase().includes('chickpea') || i.toLowerCase().includes('lentil')),
    },
  ];
}
