import { TaskItem } from '../types';
import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

type ReminderCallback = (task: TaskItem) => void;
type TaskUpdateCallback = (updatedTask: TaskItem) => void;

// Active listeners for in-app alarm modal
const reminderListeners = new Set<ReminderCallback>();

// Active listeners for task updates (e.g. when repeating tasks advance date)
const taskUpdateListeners = new Set<TaskUpdateCallback>();

// Map of in-memory web timer IDs
const webTimers = new Map<string, ReturnType<typeof setTimeout>>();

// Map of task ID to last triggered timestamp to prevent rapid duplicate rings
const triggeredTaskTimestamps = new Map<string, number>();

/**
 * Converts a string ID into a stable 32-bit positive integer required by Capacitor LocalNotifications
 */
function getNumericNotificationId(id: string): number {
  let hash = 0;
  for (let i = 0; i < id.length; i++) {
    hash = (hash << 5) - hash + id.charCodeAt(i);
    hash |= 0; // Convert to 32bit integer
  }
  return Math.abs(hash) % 2147483647;
}

/**
 * Formats a Date object into 'YYYY-MM-DD'
 */
export function formatNextOccurrenceDateString(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Parses task date and time strings into a valid JavaScript Date object.
 * Examples: date="2026-11-06", time="09:00 PM" or "09:00 م"
 */
export function parseTaskDueDate(task: TaskItem): Date | null {
  if (!task.date) return null;

  try {
    const [yearStr, monthStr, dayStr] = task.date.split('-');
    const year = parseInt(yearStr, 10);
    const month = parseInt(monthStr, 10) - 1;
    const day = parseInt(dayStr, 10);

    let hour = 12;
    let minute = 0;

    if (task.time) {
      const parts = task.time.trim().split(' ');
      const timePart = parts[0] || '';
      const periodPart = parts[1] || '';

      const [hStr, mStr] = timePart.split(':');
      let h = parseInt(hStr, 10) || 0;
      const m = parseInt(mStr, 10) || 0;

      const isPM = periodPart.includes('م') || periodPart.toUpperCase().includes('PM');
      const isAM = periodPart.includes('ص') || periodPart.toUpperCase().includes('AM');

      if (isPM && h < 12) h += 12;
      if (isAM && h === 12) h = 0;

      hour = h;
      minute = m;
    }

    return new Date(year, month, day, hour, minute, 0);
  } catch (err) {
    console.warn('Failed to parse task due date:', task.title, err);
    return null;
  }
}

/**
 * Calculates the next occurrence Date for a task relative to referenceTime (default: now).
 * - For 'once': returns the parsed due date.
 * - For 'daily', 'weekly', 'monthly': if the base date is <= referenceTime,
 *   advances the date until it is strictly in the future.
 */
export function getNextOccurrenceDate(task: TaskItem, referenceTime: Date = new Date()): Date | null {
  const baseDate = parseTaskDueDate(task);
  if (!baseDate) return null;

  if (!task.repeat || task.repeat === 'once') {
    return baseDate;
  }

  const refMs = referenceTime.getTime();
  const next = new Date(baseDate.getTime());

  // If already in the future relative to referenceTime, use it
  if (next.getTime() > refMs) {
    return next;
  }

  if (task.repeat === 'daily') {
    const oneDayMs = 24 * 60 * 60 * 1000;
    const diffMs = refMs - next.getTime();
    const daysToAdd = Math.floor(diffMs / oneDayMs) + 1;
    next.setDate(next.getDate() + daysToAdd);
    while (next.getTime() <= refMs) {
      next.setDate(next.getDate() + 1);
    }
  } else if (task.repeat === 'weekly') {
    const oneWeekMs = 7 * 24 * 60 * 60 * 1000;
    const diffMs = refMs - next.getTime();
    const weeksToAdd = Math.floor(diffMs / oneWeekMs) + 1;
    next.setDate(next.getDate() + weeksToAdd * 7);
    while (next.getTime() <= refMs) {
      next.setDate(next.getDate() + 7);
    }
  } else if (task.repeat === 'monthly') {
    const originalDay = baseDate.getDate();
    while (next.getTime() <= refMs) {
      const curYear = next.getFullYear();
      const targetMonth = next.getMonth() + 1;
      next.setFullYear(curYear, targetMonth, 1);
      const maxDaysInMonth = new Date(curYear, targetMonth + 1, 0).getDate();
      next.setDate(Math.min(originalDay, maxDaysInMonth));
    }
  }

  return next;
}

/**
 * Dispatches an in-app alarm event to all registered UI listeners
 */
export function triggerInAppAlarm(task: TaskItem) {
  triggeredTaskTimestamps.set(task.id, Date.now());

  reminderListeners.forEach((callback) => {
    try {
      callback(task);
    } catch (err) {
      console.error('Error invoking reminder listener:', err);
    }
  });

  // وبعد كل رنين: جدول الموعد الذي يليه تلقائياً للمهام المتكررة
  if (task.repeat && task.repeat !== 'once') {
    scheduleNextOccurrenceAfterRing(task);
  }
}

/**
 * Subscribes a callback to be called whenever a reminder alarm triggers inside the open app
 */
export function subscribeToReminders(callback: ReminderCallback): () => void {
  reminderListeners.add(callback);
  return () => {
    reminderListeners.delete(callback);
  };
}

/**
 * Subscribes a callback to receive task updates (e.g. when repeating tasks advance their date)
 */
export function subscribeToTaskUpdates(callback: TaskUpdateCallback): () => void {
  taskUpdateListeners.add(callback);
  return () => {
    taskUpdateListeners.delete(callback);
  };
}

export function notifyTaskUpdated(updatedTask: TaskItem) {
  taskUpdateListeners.forEach((callback) => {
    try {
      callback(updatedTask);
    } catch (err) {
      console.warn('Error invoking task update listener:', err);
    }
  });
}

// Initialize Capacitor notification listener once if native
let isCapacitorListenerInitialized = false;

function initCapacitorListeners(getTaskById: (id: string) => TaskItem | undefined) {
  if (isCapacitorListenerInitialized) return;
  if (!Capacitor.isNativePlatform()) return;

  try {
    LocalNotifications.addListener('localNotificationReceived', (notification) => {
      const taskId = notification.extra?.taskId;
      if (taskId) {
        const task = getTaskById(taskId);
        if (task && (!task.completed || (task.repeat && task.repeat !== 'once'))) {
          triggerInAppAlarm(task);
        }
      }
    });

    LocalNotifications.addListener('localNotificationActionPerformed', (action) => {
      const taskId = action.notification.extra?.taskId;
      if (taskId) {
        const task = getTaskById(taskId);
        if (task && (!task.completed || (task.repeat && task.repeat !== 'once'))) {
          triggerInAppAlarm(task);
        }
      }
    });

    isCapacitorListenerInitialized = true;
  } catch (err) {
    console.warn('Could not register Capacitor notification listeners:', err);
  }
}

/**
 * Automatically schedules the subsequent occurrence of a repeating task after it rings.
 */
export function scheduleNextOccurrenceAfterRing(task: TaskItem): TaskItem | null {
  if (!task.repeat || task.repeat === 'once') return null;

  // Compute the next occurrence strictly after the current moment (+ 60 seconds)
  const refTime = new Date(Date.now() + 60000);
  const nextDate = getNextOccurrenceDate(task, refTime);
  if (!nextDate) return null;

  const nextDateStr = formatNextOccurrenceDateString(nextDate);
  const updatedTask: TaskItem = {
    ...task,
    date: nextDateStr,
    completed: false,
  };

  scheduleReminder(updatedTask).catch(() => {});
  notifyTaskUpdated(updatedTask);
  return updatedTask;
}

/**
 * Handles completing a task:
 * - If single-occurrence ('once'): cancels reminder and marks completed.
 * - If repeating ('daily' | 'weekly' | 'monthly'): schedules the subsequent occurrence and updates date.
 */
export function handleRepeatingTaskCompletion(task: TaskItem): { nextTask: TaskItem; isRepeating: boolean } {
  if (!task.repeat || task.repeat === 'once') {
    cancelReminder(task.id).catch(() => {});
    return { nextTask: { ...task, completed: true }, isRepeating: false };
  }

  const baseDueDate = parseTaskDueDate(task);
  const refTime = new Date(Math.max(Date.now(), baseDueDate ? baseDueDate.getTime() : Date.now()) + 60000);
  const nextDate = getNextOccurrenceDate(task, refTime);

  if (nextDate) {
    const nextDateStr = formatNextOccurrenceDateString(nextDate);
    const nextTask: TaskItem = {
      ...task,
      date: nextDateStr,
      completed: false, // Reset completed for the upcoming recurrence
    };
    scheduleReminder(nextTask).catch(() => {});
    notifyTaskUpdated(nextTask);
    return { nextTask, isRepeating: true };
  }

  cancelReminder(task.id).catch(() => {});
  return { nextTask: { ...task, completed: true }, isRepeating: false };
}

/**
 * Schedules a reminder for a task.
 * For repeating tasks (daily / weekly / monthly), automatically schedules for their next upcoming occurrence.
 * Automatically delegates to @capacitor/local-notifications if running on Capacitor Android/iOS,
 * or uses Web Timers and HTML5 Notifications in browser environments.
 */
export async function scheduleReminder(task: TaskItem): Promise<boolean> {
  const isRepeating = Boolean(task.repeat && task.repeat !== 'once');

  // If a non-repeating task is completed, cancel any existing reminder
  if (task.completed && !isRepeating) {
    await cancelReminder(task.id);
    return false;
  }

  // Determine the next upcoming due date:
  // For repeating tasks, calculate the next future occurrence
  const dueDate = isRepeating
    ? getNextOccurrenceDate(task, new Date())
    : parseTaskDueDate(task);

  if (!dueDate) return false;

  const now = Date.now();
  const delayMs = dueDate.getTime() - now;

  // 1. Cancel previous pending reminder for this task
  await cancelReminder(task.id);

  // 2. Check if running inside Capacitor Android/iOS
  const isCapacitor = Capacitor.isNativePlatform();

  if (isCapacitor) {
    try {
      const permStatus = await LocalNotifications.checkPermissions();
      if (permStatus.display !== 'granted') {
        const req = await LocalNotifications.requestPermissions();
        if (req.display !== 'granted') {
          console.warn('Capacitor local notification permission not granted');
        }
      }

      if (delayMs > 0) {
        const numId = getNumericNotificationId(task.id);

        type ScheduleEvery = 'year' | 'month' | 'two-weeks' | 'week' | 'day' | 'hour' | 'minute';
        let every: ScheduleEvery | undefined;
        if (task.repeat === 'daily') every = 'day';
        else if (task.repeat === 'weekly') every = 'week';
        else if (task.repeat === 'monthly') every = 'month';

        await LocalNotifications.schedule({
          notifications: [
            {
              id: numId,
              title: task.title,
              body: task.description || task.time || 'تذكير بموعد المهمة',
              schedule: {
                at: dueDate,
                every,
              },
              sound: 'chime.wav',
              actionTypeId: '',
              extra: {
                taskId: task.id,
                title: task.title,
                category: task.category,
                repeat: task.repeat,
              },
            },
          ],
        });
        return true;
      }
    } catch (err) {
      console.warn('Failed to schedule with Capacitor LocalNotifications:', err);
    }
  }

  // 3. Web & In-App Scheduling Logic
  // If the scheduled time is in the future and within the next 24 days
  if (delayMs > 0 && delayMs < 2147483647) {
    const timer = setTimeout(() => {
      webTimers.delete(task.id);

      // Trigger Web HTML5 Notification if permitted
      if (typeof window !== 'undefined' && 'Notification' in window) {
        if (Notification.permission === 'granted') {
          try {
            new Notification(task.title, {
              body: task.description || task.time || 'حان موعد هذه المهمة الآن',
              icon: '/favicon.ico',
            });
          } catch {}
        }
      }

      // Trigger Full In-App Alarm Modal
      triggerInAppAlarm(task);

      // وبعد كل رنين للمهام المتكررة: جدولة الموعد الذي يليه
      if (isRepeating) {
        scheduleNextOccurrenceAfterRing(task);
      }
    }, delayMs);

    webTimers.set(task.id, timer);
    return true;
  }

  return false;
}

/**
 * Cancels a scheduled reminder by task ID across Capacitor and Web
 */
export async function cancelReminder(taskId: string): Promise<boolean> {
  // Clear Web timer
  const existingTimer = webTimers.get(taskId);
  if (existingTimer) {
    clearTimeout(existingTimer);
    webTimers.delete(taskId);
  }

  // Clear Capacitor LocalNotification if native
  if (Capacitor.isNativePlatform()) {
    try {
      const numId = getNumericNotificationId(taskId);
      await LocalNotifications.cancel({
        notifications: [{ id: numId }],
      });
    } catch (err) {
      console.warn('Error cancelling Capacitor notification:', err);
    }
  }

  return true;
}

/**
 * Synchronizes all user tasks with the reminder system:
 * Schedules all pending tasks and checks periodically for due tasks.
 */
export function syncAllReminders(
  tasks: TaskItem[],
  getTaskById: (id: string) => TaskItem | undefined
): () => void {
  // Initialize Capacitor native listeners
  initCapacitorListeners(getTaskById);

  // Request browser Notification permission politely if not decided
  if (typeof window !== 'undefined' && 'Notification' in window) {
    if (Notification.permission === 'default') {
      try {
        Notification.requestPermission().catch(() => {});
      } catch {}
    }
  }

  // Schedule each active task (or repeating task even if completed previously)
  tasks.forEach((task) => {
    if (!task.completed || (task.repeat && task.repeat !== 'once')) {
      scheduleReminder(task).catch(() => {});
    }
  });

  // Background check every 15 seconds to catch reminders when the app is active
  const intervalId = setInterval(() => {
    const now = new Date();
    tasks.forEach((task) => {
      const isRepeating = Boolean(task.repeat && task.repeat !== 'once');
      if (task.completed && !isRepeating) return;

      const dueDate = isRepeating
        ? getNextOccurrenceDate(task, new Date(now.getTime() - 60000))
        : parseTaskDueDate(task);

      if (!dueDate) return;

      const diffMs = now.getTime() - dueDate.getTime();
      const lastTriggered = triggeredTaskTimestamps.get(task.id) || 0;
      const hasTriggeredRecently = now.getTime() - lastTriggered < 120000;

      // Check if due within the last 60 seconds or right now
      if (diffMs >= 0 && diffMs < 60000 && !hasTriggeredRecently) {
        triggerInAppAlarm(task);
      }
    });
  }, 15000);

  return () => {
    clearInterval(intervalId);
  };
}
