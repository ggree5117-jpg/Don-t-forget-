/**
 * Offline Food Cache + AI Savings Metrics
 * =======================================
 * - يخزّن نتائج التحليل الناجحة على الجهاز (localStorage) بدون أي صورة.
 * - عند تصوير نفس الوجبة مرة أخرى (أو حتى نفس الصورة) → تُرجع النتيجة فوراً
 *   بدون أي طلب شبكة وبدون استهلاك أي حصة AI.
 * - يجمع إحصائيات "كم طلب AI تم توفيره" لعرضها للمستخدم في الإعدادات.
 */

import { FoodAnalysisResult } from '../types/health';
import { computePerceptualHash, isSimilarImageHash } from './foodImageHash';
import { normalizeFoodText } from './localFoodEngine';

const CACHE_KEY = 'df_food_cache_v1';
const STATS_KEY = 'df_ai_savings_v1';
const MAX_ENTRIES = 80;
const TTL_MS = 90 * 24 * 60 * 60 * 1000; // 90 يوماً

export interface FoodCacheEntry {
  key: string;
  kind: 'image' | 'name';
  hash?: string;
  name?: string;
  result: FoodAnalysisResult;
  createdAt: number;
  hits: number;
}

export interface AiSavingsStats {
  aiCalls: number;
  cacheHits: number;
  localHits: number;
  barcodeHits: number;
  since: number;
}

/* ------------------------------------------------------------------ */
/* Storage helpers                                                     */
/* ------------------------------------------------------------------ */

function safeRead<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function safeWrite(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    // الحصة ممتلئة → نُفرّغ أقدم نصف ونحاول مرة أخرى
    try {
      const entries = readableCache();
      writeCache(entries.slice(Math.floor(entries.length / 2)));
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      console.warn('[foodCache] unable to persist cache:', err);
    }
  }
}

function readableCache(): FoodCacheEntry[] {
  const raw = safeRead<FoodCacheEntry[]>(CACHE_KEY, []);
  if (!Array.isArray(raw)) return [];
  const now = Date.now();
  return raw.filter((e) => e && e.result && now - e.createdAt < TTL_MS);
}

function writeCache(entries: FoodCacheEntry[]): void {
  safeWrite(CACHE_KEY, entries.slice(-MAX_ENTRIES));
}

/** يُزيل الصور من النتيجة قبل التخزين (الصور تُستهلك مساحة كبيرة جداً). */
function stripHeavyFields(result: FoodAnalysisResult): FoodAnalysisResult {
  const { imageUrl: _imageUrl, ...rest } = result;
  return rest as FoodAnalysisResult;
}

/* ------------------------------------------------------------------ */
/* Lookups                                                             */
/* ------------------------------------------------------------------ */

/** يبحث عن تحليل سابق بواسطة بصمة الصورة (dHash). */
export async function lookupCachedImage(imageBase64: string): Promise<FoodAnalysisResult | null> {
  const hash = await computePerceptualHash(imageBase64);
  if (!hash) return null;

  const entries = readableCache();
  const match = entries.find((e) => e.kind === 'image' && e.hash && isSimilarImageHash(e.hash, hash));
  if (!match) return null;

  match.hits += 1;
  writeCache(entries);
  recordStat('cacheHits');
  return { ...match.result };
}

/** يبحث عن تحليل سابق بواسطة اسم الوجبة (تطابق نصي مطبَّع). */
export function lookupCachedByName(name: string): FoodAnalysisResult | null {
  const q = normalizeFoodText(name);
  if (!q) return null;

  const entries = readableCache();
  const match = entries.find((e) => e.kind === 'name' && e.name && e.name === q);
  if (!match) return null;

  match.hits += 1;
  writeCache(entries);
  recordStat('cacheHits');
  return { ...match.result };
}

/** يحفظ نتيجة تحليل ناجحة في الذاكرة المحلية. */
export async function rememberAnalysis(
  imageBase64: string | null,
  result: FoodAnalysisResult
): Promise<void> {
  const entries = readableCache();
  const now = Date.now();
  const light = stripHeavyFields(result);

  if (imageBase64) {
    const hash = await computePerceptualHash(imageBase64);
    if (hash) {
      const existing = entries.find((e) => e.kind === 'image' && e.hash && e.hash === hash);
      if (existing) {
        existing.result = light;
        existing.createdAt = now;
        existing.hits += 1;
      } else {
        entries.push({
          key: `img_${hash}`,
          kind: 'image',
          hash,
          result: light,
          createdAt: now,
          hits: 1,
        });
      }
    }
  }

  const nameKey =
    normalizeFoodText(result.foodNameAr || '') || normalizeFoodText(result.foodName || '');
  if (nameKey) {
    const existing = entries.find((e) => e.kind === 'name' && e.name === nameKey);
    if (existing) {
      existing.result = light;
      existing.createdAt = now;
      existing.hits += 1;
    } else {
      entries.push({
        key: `name_${nameKey}`,
        kind: 'name',
        name: nameKey,
        result: light,
        createdAt: now,
        hits: 1,
      });
    }
  }

  writeCache(entries);
}

/* ------------------------------------------------------------------ */
/* Stats                                                               */
/* ------------------------------------------------------------------ */

export type SavingsCounter = 'aiCalls' | 'cacheHits' | 'localHits' | 'barcodeHits';

export function getSavingsStats(): AiSavingsStats {
  return safeRead<AiSavingsStats>(STATS_KEY, {
    aiCalls: 0,
    cacheHits: 0,
    localHits: 0,
    barcodeHits: 0,
    since: Date.now(),
  });
}

export function recordStat(counter: SavingsCounter, amount = 1): void {
  const stats = getSavingsStats();
  if (!stats.since) stats.since = Date.now();
  stats[counter] = (stats[counter] || 0) + amount;
  safeWrite(STATS_KEY, stats);
}

export function resetSavingsStats(): void {
  safeWrite(STATS_KEY, {
    aiCalls: 0,
    cacheHits: 0,
    localHits: 0,
    barcodeHits: 0,
    since: Date.now(),
  } satisfies AiSavingsStats);
}

/** عدد الطلبات التي لم تصل إلى السيرفر إطلاقاً. */
export function getSavedAiCalls(): number {
  const s = getSavingsStats();
  return s.cacheHits + s.localHits + s.barcodeHits;
}

export function clearFoodCache(): void {
  try {
    localStorage.removeItem(CACHE_KEY);
  } catch {
    /* ignore */
  }
}

export function getFoodCacheSize(): number {
  return readableCache().length;
}
