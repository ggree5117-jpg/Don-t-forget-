import { CustomAudioRecord } from '../types';

const DB_NAME = 'DontForgetAudioDB';
const DB_VERSION = 1;
const STORE_NAME = 'customRingtones';
export const MAX_AUDIO_FILE_SIZE_BYTES = 5 * 1024 * 1024; // 5MB

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return reject(new Error('IndexedDB is not supported in this environment'));
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error || new Error('Failed to open audio IndexedDB'));
    };
  });
}

/**
 * Validates and saves a user audio file into IndexedDB.
 * Enforces a strict 5MB file size limit.
 */
export async function saveCustomAudio(file: File): Promise<CustomAudioRecord> {
  if (!file) {
    throw new Error('No file provided');
  }

  // 1. File size check (Max 5MB)
  if (file.size > MAX_AUDIO_FILE_SIZE_BYTES) {
    const sizeInMB = (file.size / (1024 * 1024)).toFixed(1);
    throw new Error(
      `حجم الملف (${sizeInMB} ميجابايت) يتجاوز الحد الأقصى المسموح به وهو 5 ميجابايت.\nFile size (${sizeInMB}MB) exceeds the maximum allowed limit of 5MB.`
    );
  }

  // 2. Format validation check
  const isAudioType = file.type.startsWith('audio/');
  const hasAudioExtension = /\.(mp3|wav|m4a|aac|ogg|flac|weba)$/i.test(file.name);
  if (!isAudioType && !hasAudioExtension) {
    throw new Error(
      `صيغة الملف غير مدعومة. يرجى اختيار ملف صوتي صالح (مثل MP3، WAV، M4A).\nUnsupported file format. Please select a valid audio file (e.g. MP3, WAV, M4A).`
    );
  }

  const db = await openDB();
  const id = `custom-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
  const cleanName = file.name.replace(/\.[^/.]+$/, '').trim() || 'نغمة مخصصة';

  const record: CustomAudioRecord = {
    id,
    name: cleanName,
    fileName: file.name,
    size: file.size,
    type: file.type || 'audio/mpeg',
    blob: file,
    createdAt: Date.now(),
  };

  return new Promise((resolve, reject) => {
    try {
      const transaction = db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const putRequest = store.put(record);

      putRequest.onsuccess = () => resolve(record);
      putRequest.onerror = () => reject(putRequest.error || new Error('Failed to store audio file in IndexedDB'));
    } catch (err) {
      reject(err);
    }
  });
}

/**
 * Retrieves all stored custom ringtone records from IndexedDB.
 */
export async function getAllCustomAudios(): Promise<CustomAudioRecord[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll();

      request.onsuccess = () => {
        resolve((request.result as CustomAudioRecord[]) || []);
      };
      request.onerror = () => reject(request.error || new Error('Failed to fetch custom audios'));
    });
  } catch (err) {
    console.warn('Could not read custom audios from IndexedDB:', err);
    return [];
  }
}

/**
 * Retrieves a single custom audio record by its ID.
 */
export async function getCustomAudio(id: string): Promise<CustomAudioRecord | null> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.get(id);

      request.onsuccess = () => {
        resolve((request.result as CustomAudioRecord) || null);
      };
      request.onerror = () => reject(request.error || new Error('Failed to fetch custom audio'));
    });
  } catch (err) {
    console.warn('Could not fetch custom audio by ID:', id, err);
    return null;
  }
}

/**
 * Deletes a custom audio record from IndexedDB.
 */
export async function deleteCustomAudio(id: string): Promise<boolean> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.delete(id);

      request.onsuccess = () => resolve(true);
      request.onerror = () => reject(request.error || new Error('Failed to delete custom audio'));
    });
  } catch (err) {
    console.warn('Could not delete custom audio:', id, err);
    return false;
  }
}
