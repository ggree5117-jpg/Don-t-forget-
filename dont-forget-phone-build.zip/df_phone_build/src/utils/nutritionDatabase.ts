/**
 * Structured Nutritional Database & Standard Calculation Formula
 * Based on USDA FoodData Central and Regional Arab/Yemeni Food Composition tables.
 * Guaranteed Atwater formula consistency:
 * Calories = (Grams / 100) * Calories_Per_100g
 * Protein  = (Grams / 100) * Protein_Per_100g
 * Carbs    = (Grams / 100) * Carbs_Per_100g
 * Fats     = (Grams / 100) * Fats_Per_100g
 * Fiber    = (Grams / 100) * Fiber_Per_100g
 */

import { FoodIngredientItem } from '../types/health';

export interface NutritionReferenceItem {
  id: string;
  nameEn: string;
  nameAr: string;
  category: 'grain' | 'meat' | 'poultry' | 'fish' | 'stew' | 'vegetable' | 'dairy' | 'fat' | 'bread' | 'sweet' | 'legume';
  caloriesPer100g: number;
  proteinPer100g: number;
  carbsPer100g: number;
  fatsPer100g: number;
  fiberPer100g: number;
  typicalServingGrams: number;
}

export const NUTRITION_DATABASE: Record<string, NutritionReferenceItem> = {
  // Grains & Rice
  mandi_rice: {
    id: 'mandi_rice',
    nameEn: 'Mandi Basmati Rice',
    nameAr: 'أرز بسمتي مندي مدخن',
    category: 'grain',
    caloriesPer100g: 155,
    proteinPer100g: 3.2,
    carbsPer100g: 29.5,
    fatsPer100g: 2.8,
    fiberPer100g: 0.9,
    typicalServingGrams: 220,
  },
  kabsa_rice: {
    id: 'kabsa_rice',
    nameEn: 'Kabsa Spiced Rice',
    nameAr: 'أرز كبسة بالبهارات',
    category: 'grain',
    caloriesPer100g: 160,
    proteinPer100g: 3.5,
    carbsPer100g: 29.0,
    fatsPer100g: 3.4,
    fiberPer100g: 1.2,
    typicalServingGrams: 220,
  },
  white_rice: {
    id: 'white_rice',
    nameEn: 'Steamed White Rice',
    nameAr: 'أرز أبيض مسلوق',
    category: 'grain',
    caloriesPer100g: 130,
    proteinPer100g: 2.7,
    carbsPer100g: 28.2,
    fatsPer100g: 0.3,
    fiberPer100g: 0.4,
    typicalServingGrams: 200,
  },
  zurbian_rice: {
    id: 'zurbian_rice',
    nameEn: 'Zurbian Spiced Rice',
    nameAr: 'أرز زربيان بالزعفران واللبن',
    category: 'grain',
    caloriesPer100g: 170,
    proteinPer100g: 3.8,
    carbsPer100g: 28.0,
    fatsPer100g: 4.5,
    fiberPer100g: 1.1,
    typicalServingGrams: 220,
  },

  // Meats & Poultry
  mutton_lamb_roast: {
    id: 'mutton_lamb_roast',
    nameEn: 'Roasted Mandi/Haneeth Lamb',
    nameAr: 'لحم ضأن مندي / حنيذ محمر',
    category: 'meat',
    caloriesPer100g: 255,
    proteinPer100g: 25.5,
    carbsPer100g: 0,
    fatsPer100g: 16.8,
    fiberPer100g: 0,
    typicalServingGrams: 160,
  },
  chicken_roast: {
    id: 'chicken_roast',
    nameEn: 'Roasted Mandi Chicken',
    nameAr: 'دجاج مندي محمر',
    category: 'poultry',
    caloriesPer100g: 215,
    proteinPer100g: 24.2,
    carbsPer100g: 0,
    fatsPer100g: 13.0,
    fiberPer100g: 0,
    typicalServingGrams: 180,
  },
  chicken_breast_grilled: {
    id: 'chicken_breast_grilled',
    nameEn: 'Grilled Chicken Breast',
    nameAr: 'صدر دجاج مشوي',
    category: 'poultry',
    caloriesPer100g: 165,
    proteinPer100g: 31.0,
    carbsPer100g: 0,
    fatsPer100g: 3.6,
    fiberPer100g: 0,
    typicalServingGrams: 150,
  },
  fahsa_shredded_beef: {
    id: 'fahsa_shredded_beef',
    nameEn: 'Fahsa Shredded Beef in Clay Pot',
    nameAr: 'لحم فحسة يمنية في المدرة',
    category: 'meat',
    caloriesPer100g: 180,
    proteinPer100g: 21.0,
    carbsPer100g: 2.5,
    fatsPer100g: 9.5,
    fiberPer100g: 0.6,
    typicalServingGrams: 200,
  },

  // Traditional Yemeni & Regional Stews & Components
  saltah_meat_vegetable_stew: {
    id: 'saltah_meat_vegetable_stew',
    nameEn: 'Saltah Stew Base',
    nameAr: 'مرقة وخضار سلتة يمنية',
    category: 'stew',
    caloriesPer100g: 115,
    proteinPer100g: 9.2,
    carbsPer100g: 6.8,
    fatsPer100g: 5.5,
    fiberPer100g: 1.8,
    typicalServingGrams: 220,
  },
  hilbeh_fenugreek_foam: {
    id: 'hilbeh_fenugreek_foam',
    nameEn: 'Hilbeh Whipped Fenugreek Froth',
    nameAr: 'حلبة سلتة مخفوقة',
    category: 'vegetable',
    caloriesPer100g: 36,
    proteinPer100g: 2.6,
    carbsPer100g: 4.8,
    fatsPer100g: 0.6,
    fiberPer100g: 3.0,
    typicalServingGrams: 60,
  },
  maraq_broth: {
    id: 'maraq_broth',
    nameEn: 'Spiced Yemeni Broth (Maraq)',
    nameAr: 'مرق لحم / دجاج يمني متبل',
    category: 'stew',
    caloriesPer100g: 45,
    proteinPer100g: 3.8,
    carbsPer100g: 1.5,
    fatsPer100g: 2.6,
    fiberPer100g: 0.2,
    typicalServingGrams: 180,
  },
  sahawiq_salsa: {
    id: 'sahawiq_salsa',
    nameEn: 'Sahawiq Hot Salsa',
    nameAr: 'سحاوق طماطم وفلفل مع الجبن أو عادي',
    category: 'vegetable',
    caloriesPer100g: 32,
    proteinPer100g: 1.3,
    carbsPer100g: 5.6,
    fatsPer100g: 0.4,
    fiberPer100g: 1.6,
    typicalServingGrams: 45,
  },

  // Breads
  molawah_bread: {
    id: 'molawah_bread',
    nameEn: 'Yemeni Molawah Flaky Bread',
    nameAr: 'خبز ملوح يمني مورق',
    category: 'bread',
    caloriesPer100g: 295,
    proteinPer100g: 7.8,
    carbsPer100g: 49.0,
    fatsPer100g: 7.8,
    fiberPer100g: 2.5,
    typicalServingGrams: 120,
  },
  arabic_pita_bread: {
    id: 'arabic_pita_bread',
    nameEn: 'Arabic Pita / Khubz',
    nameAr: 'خبز عربي / رغيف بلدي',
    category: 'bread',
    caloriesPer100g: 265,
    proteinPer100g: 9.1,
    carbsPer100g: 53.5,
    fatsPer100g: 1.2,
    fiberPer100g: 2.7,
    typicalServingGrams: 80,
  },
  roti_tandoori: {
    id: 'roti_tandoori',
    nameEn: 'Tandoori Roti / Flatbread',
    nameAr: 'خبز تنور يمني',
    category: 'bread',
    caloriesPer100g: 250,
    proteinPer100g: 8.5,
    carbsPer100g: 51.0,
    fatsPer100g: 1.5,
    fiberPer100g: 3.2,
    typicalServingGrams: 90,
  },

  // Fish & Seafood
  fish_grilled: {
    id: 'fish_grilled',
    nameEn: 'Grilled Fish (Mufa / Sayadieh)',
    nameAr: 'سمك مشوي (موفى / صيادية)',
    category: 'fish',
    caloriesPer100g: 145,
    proteinPer100g: 22.0,
    carbsPer100g: 0,
    fatsPer100g: 5.8,
    fiberPer100g: 0,
    typicalServingGrams: 180,
  },
  fish_fried: {
    id: 'fish_fried',
    nameEn: 'Fried Fish Fillet',
    nameAr: 'سمك مقلي متبل',
    category: 'fish',
    caloriesPer100g: 210,
    proteinPer100g: 20.5,
    carbsPer100g: 5.2,
    fatsPer100g: 11.5,
    fiberPer100g: 0.3,
    typicalServingGrams: 160,
  },

  // Breakfast, Legumes & Eggs
  foul_mudammas: {
    id: 'foul_mudammas',
    nameEn: 'Foul Mudammas Fava Beans',
    nameAr: 'فول مدمس بالزيت والكمون',
    category: 'legume',
    caloriesPer100g: 115,
    proteinPer100g: 7.8,
    carbsPer100g: 17.5,
    fatsPer100g: 2.0,
    fiberPer100g: 5.8,
    typicalServingGrams: 180,
  },
  shakshouka: {
    id: 'shakshouka',
    nameEn: 'Shakshouka Eggs & Tomato',
    nameAr: 'شكشوكة بيض بالطماطم',
    category: 'meat',
    caloriesPer100g: 135,
    proteinPer100g: 8.8,
    carbsPer100g: 6.2,
    fatsPer100g: 8.2,
    fiberPer100g: 1.5,
    typicalServingGrams: 180,
  },
  falafel: {
    id: 'falafel',
    nameEn: 'Crispy Falafel Patties',
    nameAr: 'فلافل مقرمشة',
    category: 'legume',
    caloriesPer100g: 330,
    proteinPer100g: 13.2,
    carbsPer100g: 32.0,
    fatsPer100g: 17.8,
    fiberPer100g: 5.6,
    typicalServingGrams: 90,
  },
  hummus: {
    id: 'hummus',
    nameEn: 'Hummus with Tahini & Olive Oil',
    nameAr: 'حمص بالطحينة وزيت الزيتون',
    category: 'legume',
    caloriesPer100g: 175,
    proteinPer100g: 8.2,
    carbsPer100g: 14.5,
    fatsPer100g: 9.8,
    fiberPer100g: 6.0,
    typicalServingGrams: 100,
  },
  mutabbaq_meat: {
    id: 'mutabbaq_meat',
    nameEn: 'Mutabbaq Minced Meat Pastry',
    nameAr: 'مطبق باللحم المفروم والبيض',
    category: 'bread',
    caloriesPer100g: 260,
    proteinPer100g: 12.5,
    carbsPer100g: 24.0,
    fatsPer100g: 13.0,
    fiberPer100g: 1.8,
    typicalServingGrams: 180,
  },

  // Sweets & Specialties
  bint_al_sahn: {
    id: 'bint_al_sahn',
    nameEn: 'Bint Al-Sahn Yemeni Honey Cake',
    nameAr: 'بنت الصحن بالسمن والعسل',
    category: 'sweet',
    caloriesPer100g: 345,
    proteinPer100g: 7.2,
    carbsPer100g: 53.0,
    fatsPer100g: 12.0,
    fiberPer100g: 1.6,
    typicalServingGrams: 120,
  },
  aseed_dates: {
    id: 'aseed_dates',
    nameEn: 'Aseed Porridge with Broth/Honey',
    nameAr: 'عصيدة يمنية بالمرق أو العسل',
    category: 'grain',
    caloriesPer100g: 140,
    proteinPer100g: 3.6,
    carbsPer100g: 26.5,
    fatsPer100g: 2.2,
    fiberPer100g: 2.4,
    typicalServingGrams: 200,
  },

  // Condiments, Dairy & Extras
  olive_oil: {
    id: 'olive_oil',
    nameEn: 'Extra Virgin Olive Oil',
    nameAr: 'زيت زيتون بكر',
    category: 'fat',
    caloriesPer100g: 884,
    proteinPer100g: 0,
    carbsPer100g: 0,
    fatsPer100g: 100,
    fiberPer100g: 0,
    typicalServingGrams: 15,
  },
  samn_ghee: {
    id: 'samn_ghee',
    nameEn: 'Samn (Clarified Butter/Ghee)',
    nameAr: 'سمن بلدي',
    category: 'fat',
    caloriesPer100g: 890,
    proteinPer100g: 0.3,
    carbsPer100g: 0,
    fatsPer100g: 99.5,
    fiberPer100g: 0,
    typicalServingGrams: 12,
  },
  green_salad: {
    id: 'green_salad',
    nameEn: 'Fresh Mixed Garden Salad',
    nameAr: 'سلطة خضراء طازجة مشكلة',
    category: 'vegetable',
    caloriesPer100g: 25,
    proteinPer100g: 1.4,
    carbsPer100g: 4.2,
    fatsPer100g: 0.3,
    fiberPer100g: 2.2,
    typicalServingGrams: 120,
  },
  plain_yogurt: {
    id: 'plain_yogurt',
    nameEn: 'Plain Yogurt / Laban',
    nameAr: 'لبن زبادي طبيعي',
    category: 'dairy',
    caloriesPer100g: 62,
    proteinPer100g: 3.5,
    carbsPer100g: 4.7,
    fatsPer100g: 3.3,
    fiberPer100g: 0,
    typicalServingGrams: 150,
  },
  dates: {
    id: 'dates',
    nameEn: 'Fresh Dates (Rutab / Tamr)',
    nameAr: 'تمر رطب',
    category: 'sweet',
    caloriesPer100g: 280,
    proteinPer100g: 2.0,
    carbsPer100g: 75.0,
    fatsPer100g: 0.4,
    fiberPer100g: 7.0,
    typicalServingGrams: 50,
  },

  // ============================================================
  // INTERNATIONAL / EVERYDAY FOODS
  // Added to widen the fully-offline (zero-AI) detection coverage.
  // Values based on USDA FoodData Central (as-served / cooked basis).
  // ============================================================
  pizza_cheese: {
    id: 'pizza_cheese',
    nameEn: 'Cheese Pizza',
    nameAr: 'بيتزا بالجبن',
    category: 'grain',
    caloriesPer100g: 266,
    proteinPer100g: 11.0,
    carbsPer100g: 33.0,
    fatsPer100g: 10.0,
    fiberPer100g: 2.3,
    typicalServingGrams: 120,
  },
  beef_burger: {
    id: 'beef_burger',
    nameEn: 'Beef Burger',
    nameAr: 'برجر لحم',
    category: 'meat',
    caloriesPer100g: 250,
    proteinPer100g: 13.0,
    carbsPer100g: 27.0,
    fatsPer100g: 10.0,
    fiberPer100g: 1.5,
    typicalServingGrams: 180,
  },
  french_fries: {
    id: 'french_fries',
    nameEn: 'French Fries',
    nameAr: 'بطاطس مقلية',
    category: 'vegetable',
    caloriesPer100g: 312,
    proteinPer100g: 3.4,
    carbsPer100g: 41.0,
    fatsPer100g: 15.0,
    fiberPer100g: 3.8,
    typicalServingGrams: 120,
  },
  pasta_red_sauce: {
    id: 'pasta_red_sauce',
    nameEn: 'Pasta with Tomato Sauce',
    nameAr: 'مكرونة بصلصة الطماطم',
    category: 'grain',
    caloriesPer100g: 155,
    proteinPer100g: 5.5,
    carbsPer100g: 28.0,
    fatsPer100g: 3.2,
    fiberPer100g: 2.4,
    typicalServingGrams: 250,
  },
  chicken_shawarma: {
    id: 'chicken_shawarma',
    nameEn: 'Chicken Shawarma',
    nameAr: 'شاورما دجاج',
    category: 'poultry',
    caloriesPer100g: 210,
    proteinPer100g: 18.0,
    carbsPer100g: 16.0,
    fatsPer100g: 8.0,
    fiberPer100g: 1.0,
    typicalServingGrams: 220,
  },
  grilled_kebab: {
    id: 'grilled_kebab',
    nameEn: 'Grilled Kebab / Kofta',
    nameAr: 'كباب / كفتة مشوية',
    category: 'meat',
    caloriesPer100g: 250,
    proteinPer100g: 22.0,
    carbsPer100g: 3.0,
    fatsPer100g: 17.0,
    fiberPer100g: 0,
    typicalServingGrams: 120,
  },
  boiled_egg: {
    id: 'boiled_egg',
    nameEn: 'Boiled Egg',
    nameAr: 'بيضة مسلوقة',
    category: 'poultry',
    caloriesPer100g: 155,
    proteinPer100g: 13.0,
    carbsPer100g: 1.1,
    fatsPer100g: 11.0,
    fiberPer100g: 0,
    typicalServingGrams: 50,
  },
  fried_egg: {
    id: 'fried_egg',
    nameEn: 'Fried Egg',
    nameAr: 'بيضة مقلية',
    category: 'poultry',
    caloriesPer100g: 196,
    proteinPer100g: 13.6,
    carbsPer100g: 0.8,
    fatsPer100g: 14.8,
    fiberPer100g: 0,
    typicalServingGrams: 55,
  },
  milk_full_fat: {
    id: 'milk_full_fat',
    nameEn: 'Full-Fat Milk',
    nameAr: 'حليب كامل الدسم',
    category: 'dairy',
    caloriesPer100g: 61,
    proteinPer100g: 3.2,
    carbsPer100g: 4.8,
    fatsPer100g: 3.3,
    fiberPer100g: 0,
    typicalServingGrams: 200,
  },
  lentil_soup: {
    id: 'lentil_soup',
    nameEn: 'Lentil Soup',
    nameAr: 'شوربة عدس',
    category: 'legume',
    caloriesPer100g: 90,
    proteinPer100g: 5.5,
    carbsPer100g: 14.0,
    fatsPer100g: 1.2,
    fiberPer100g: 3.5,
    typicalServingGrams: 250,
  },
  oats_porridge: {
    id: 'oats_porridge',
    nameEn: 'Oatmeal Porridge',
    nameAr: 'شوفان مطبوخ',
    category: 'grain',
    caloriesPer100g: 71,
    proteinPer100g: 2.5,
    carbsPer100g: 12.0,
    fatsPer100g: 1.5,
    fiberPer100g: 1.7,
    typicalServingGrams: 250,
  },
  tuna_canned: {
    id: 'tuna_canned',
    nameEn: 'Canned Tuna (in water)',
    nameAr: 'تونة معلبة (بالماء)',
    category: 'fish',
    caloriesPer100g: 116,
    proteinPer100g: 25.5,
    carbsPer100g: 0,
    fatsPer100g: 0.8,
    fiberPer100g: 0,
    typicalServingGrams: 100,
  },
  banana: {
    id: 'banana',
    nameEn: 'Banana',
    nameAr: 'موز',
    category: 'sweet',
    caloriesPer100g: 89,
    proteinPer100g: 1.1,
    carbsPer100g: 22.8,
    fatsPer100g: 0.3,
    fiberPer100g: 2.6,
    typicalServingGrams: 120,
  },
  apple: {
    id: 'apple',
    nameEn: 'Apple',
    nameAr: 'تفاحة',
    category: 'sweet',
    caloriesPer100g: 52,
    proteinPer100g: 0.3,
    carbsPer100g: 13.8,
    fatsPer100g: 0.2,
    fiberPer100g: 2.4,
    typicalServingGrams: 180,
  },
  orange: {
    id: 'orange',
    nameEn: 'Orange',
    nameAr: 'برتقال',
    category: 'sweet',
    caloriesPer100g: 47,
    proteinPer100g: 0.9,
    carbsPer100g: 11.8,
    fatsPer100g: 0.1,
    fiberPer100g: 2.4,
    typicalServingGrams: 150,
  },
  watermelon: {
    id: 'watermelon',
    nameEn: 'Watermelon',
    nameAr: 'بطيخ',
    category: 'sweet',
    caloriesPer100g: 30,
    proteinPer100g: 0.6,
    carbsPer100g: 7.6,
    fatsPer100g: 0.2,
    fiberPer100g: 0.4,
    typicalServingGrams: 250,
  },
  boiled_potato: {
    id: 'boiled_potato',
    nameEn: 'Boiled Potato',
    nameAr: 'بطاطس مسلوقة',
    category: 'vegetable',
    caloriesPer100g: 87,
    proteinPer100g: 1.9,
    carbsPer100g: 20.0,
    fatsPer100g: 0.1,
    fiberPer100g: 1.8,
    typicalServingGrams: 150,
  },
  cucumber: {
    id: 'cucumber',
    nameEn: 'Cucumber',
    nameAr: 'خيار',
    category: 'vegetable',
    caloriesPer100g: 15,
    proteinPer100g: 0.7,
    carbsPer100g: 3.6,
    fatsPer100g: 0.1,
    fiberPer100g: 0.5,
    typicalServingGrams: 100,
  },
  tomato: {
    id: 'tomato',
    nameEn: 'Tomato',
    nameAr: 'طماطم',
    category: 'vegetable',
    caloriesPer100g: 18,
    proteinPer100g: 0.9,
    carbsPer100g: 3.9,
    fatsPer100g: 0.2,
    fiberPer100g: 1.2,
    typicalServingGrams: 120,
  },
  chocolate: {
    id: 'chocolate',
    nameEn: 'Chocolate',
    nameAr: 'شوكولاتة',
    category: 'sweet',
    caloriesPer100g: 546,
    proteinPer100g: 4.9,
    carbsPer100g: 61.0,
    fatsPer100g: 31.0,
    fiberPer100g: 3.4,
    typicalServingGrams: 30,
  },
  honey: {
    id: 'honey',
    nameEn: 'Honey',
    nameAr: 'عسل',
    category: 'sweet',
    caloriesPer100g: 304,
    proteinPer100g: 0.3,
    carbsPer100g: 82.4,
    fatsPer100g: 0,
    fiberPer100g: 0.2,
    typicalServingGrams: 20,
  },
};

/**
 * Common quick-add items for users who want to add extra sides or condiments
 */
export const POPULAR_QUICK_ADD_ITEMS: NutritionReferenceItem[] = [
  NUTRITION_DATABASE.arabic_pita_bread,
  NUTRITION_DATABASE.green_salad,
  NUTRITION_DATABASE.plain_yogurt,
  NUTRITION_DATABASE.sahawiq_salsa,
  NUTRITION_DATABASE.molawah_bread,
  NUTRITION_DATABASE.olive_oil,
  NUTRITION_DATABASE.dates,
];

/**
 * Accurately calculate nutritional values for a single component based on weight and 100g reference values.
 */
export function calculateComponentNutrition(
  grams: number,
  ref: {
    caloriesPer100g: number;
    proteinPer100g: number;
    carbsPer100g: number;
    fatsPer100g: number;
    fiberPer100g?: number;
  }
) {
  const g = Math.max(0, Number(grams) || 0);
  const factor = g / 100;

  const protein = Math.round(ref.proteinPer100g * factor * 10) / 10;
  const carbs = Math.round(ref.carbsPer100g * factor * 10) / 10;
  const fats = Math.round(ref.fatsPer100g * factor * 10) / 10;
  const fiber = Math.round((ref.fiberPer100g || 0) * factor * 10) / 10;

  // Use the standard Atwater factor calculation or direct calorie density
  const calories = Math.round(ref.caloriesPer100g * factor);

  return {
    weightGrams: g,
    calories,
    protein,
    carbs,
    fats,
    fiber,
  };
}

/**
 * Accurately compute total meal nutrition by strictly summing each ingredient component.
 * This completely avoids AI guessing/hallucination of calorie numbers.
 */
export function calculateDishTotals(ingredients: FoodIngredientItem[]) {
  let totalCals = 0;
  let totalProt = 0;
  let totalCarbs = 0;
  let totalFats = 0;
  let totalFiber = 0;
  let totalGrams = 0;

  const resolvedIngredients: FoodIngredientItem[] = ingredients.map((item, index) => {
    const computed = calculateComponentNutrition(item.weightGrams, {
      caloriesPer100g: item.caloriesPer100g,
      proteinPer100g: item.proteinPer100g,
      carbsPer100g: item.carbsPer100g,
      fatsPer100g: item.fatsPer100g,
      fiberPer100g: item.fiberPer100g ?? 0,
    });

    totalCals += computed.calories;
    totalProt += computed.protein;
    totalCarbs += computed.carbs;
    totalFats += computed.fats;
    totalFiber += computed.fiber;
    totalGrams += computed.weightGrams;

    return {
      ...item,
      id: item.id || `ing_${index}_${Date.now()}`,
      calories: computed.calories,
      protein: computed.protein,
      carbs: computed.carbs,
      fats: computed.fats,
      fiber: computed.fiber,
    };
  });

  return {
    ingredients: resolvedIngredients,
    totalWeightGrams: Math.round(totalGrams),
    calories: Math.max(0, Math.round(totalCals)),
    protein: Math.max(0, Math.round(totalProt * 10) / 10),
    carbs: Math.max(0, Math.round(totalCarbs * 10) / 10),
    fats: Math.max(0, Math.round(totalFats * 10) / 10),
    fiber: Math.max(0, Math.round(totalFiber * 10) / 10),
  };
}
