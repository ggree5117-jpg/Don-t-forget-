/**
 * جسر Start.io — Capacitor ↔ الإضافة الأصلية
 * ==========================================
 * لا توجد إضافة Capacitor رسمية لـ Start.io، لذلك كتبنا إضافة أصلية
 * في `native-android/` بنفس هذه الواجهة.
 *
 * كل الدوال تعمل في المتصفح أيضاً (no-op) حتى لا تتعطّل المعاينة،
 * وتُعيد `false` ليعرف التطبيق أنه يجب استخدام التصميم التجريبي.
 */

import { Capacitor, registerPlugin } from '@capacitor/core';

export interface StartioAdsPlugin {
  /** تهيئة SDK مرة واحدة */
  initialize(options: {
    appId: string;
    testAds: boolean;
  }): Promise<{ initialized: boolean }>;

  /** يعرض إعلاناً كاملاً (interstitial) ويُعاد بعد الإغلاق */
  showInterstitial(options: { adTag: string }): Promise<{ shown: boolean; reason?: string }>;

  /** يُحمّل مسبقاً حتى يظهر فوراً عند الطلب */
  preloadInterstitial(options: { adTag: string }): Promise<{ loaded: boolean }>;

  /** يعرض البانر أسفل الشاشة */
  showBanner(options: { adTag: string; heightDp: number }): Promise<{ shown: boolean }>;

  /** يخفي البانر */
  hideBanner(): Promise<{ hidden: boolean }>;
}

const StartioAds = registerPlugin<StartioAdsPlugin>('StartioAds');

/** هل نحن داخل تطبيق أندرويد أصلي؟ */
export function isNativeApp(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

/** هل يمكن استخدام Start.io الحقيقي الآن؟ */
export function isStartioAvailable(): boolean {
  return isNativeApp();
}

let initialized = false;

/** تهيئة SDK (آمنة للتكرار) */
export async function initStartio(): Promise<boolean> {
  if (!isStartioAvailable()) return false;
  if (initialized) return true;

  try {
    await StartioAds.initialize({
      appId: '210222499',
      testAds: true,
    });
    initialized = true;
    return true;
  } catch (err) {
    console.warn('[Start.io] initialize failed:', err);
    return false;
  }
}

/** تحميل إعلان كامل مسبقاً — يقلل وقت الانتظار عند الفتح */
export async function preloadInterstitial(adTag: string): Promise<boolean> {
  if (!isStartioAvailable()) return false;
  try {
    const res = await StartioAds.preloadInterstitial({ adTag });
    return Boolean(res?.loaded);
  } catch (err) {
    console.warn('[Start.io] preload failed:', err);
    return false;
  }
}

/** عرض إعلان كامل. يرجع false في المتصفح أو عند الفشل */
export async function showInterstitial(adTag: string): Promise<boolean> {
  if (!isStartioAvailable()) return false;
  try {
    const res = await StartioAds.showInterstitial({ adTag });
    return Boolean(res?.shown);
  } catch (err) {
    console.warn('[Start.io] showInterstitial failed:', err);
    return false;
  }
}

/** عرض بانر سفلي */
export async function showBanner(adTag: string, heightDp = 50): Promise<boolean> {
  if (!isStartioAvailable()) return false;
  try {
    const res = await StartioAds.showBanner({ adTag, heightDp });
    return Boolean(res?.shown);
  } catch (err) {
    console.warn('[Start.io] showBanner failed:', err);
    return false;
  }
}

/** إخفاء البانر */
export async function hideBanner(): Promise<void> {
  if (!isStartioAvailable()) return;
  try {
    await StartioAds.hideBanner();
  } catch (err) {
    console.warn('[Start.io] hideBanner failed:', err);
  }
}
