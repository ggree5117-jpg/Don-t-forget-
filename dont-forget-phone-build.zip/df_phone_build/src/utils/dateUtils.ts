import { TaskItem } from '../types';

/**
 * Checks whether an uncompleted task has passed its scheduled date and time.
 * If the task is completed, it is no longer considered overdue.
 */
export function isTaskOverdue(task: TaskItem, referenceDate: Date = new Date()): boolean {
  if (task.completed) return false;
  if (!task.date) return false;

  try {
    const [yearStr, monthStr, dayStr] = task.date.split('-');
    const year = parseInt(yearStr, 10);
    const month = parseInt(monthStr, 10) - 1; // 0-indexed month
    const day = parseInt(dayStr, 10);

    let hour = 23;
    let minute = 59;

    if (task.time) {
      const parts = task.time.trim().split(' ');
      const timePart = parts[0] || '';
      const periodPart = parts[1] || '';

      const [hStr, mStr] = timePart.split(':');
      let h = parseInt(hStr, 10) || 0;
      const m = parseInt(mStr, 10) || 0;

      const isPM = periodPart.includes('م') || periodPart.toUpperCase().includes('PM');
      const isAM = periodPart.includes('ص') || periodPart.toUpperCase().includes('AM');

      if (isPM && h < 12) h += 12;
      if (isAM && h === 12) h = 0;

      hour = h;
      minute = m;
    }

    const taskDueDate = new Date(year, month, day, hour, minute, 0);
    return taskDueDate.getTime() < referenceDate.getTime();
  } catch {
    return false;
  }
}
