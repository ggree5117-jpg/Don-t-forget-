import confetti from 'canvas-confetti';

/**
 * Triggers a joyful, vibrant confetti explosion when a user completes a task.
 * Launches a celebratory burst of colorful confetti particles.
 */
export function triggerTaskConfetti(clientCoords?: { x: number; y: number }) {
  // If coordinates provided, convert to normalized canvas-confetti coords (0 to 1)
  let originX = 0.5;
  let originY = 0.6;

  if (clientCoords && clientCoords.x > 0 && clientCoords.y > 0) {
    originX = Math.max(0.15, Math.min(0.85, clientCoords.x / window.innerWidth));
    originY = Math.max(0.15, Math.min(0.85, clientCoords.y / window.innerHeight));
  }

  const vibrantColors = [
    '#3B6CB4', // Deep Navy
    '#F3D58A', // Champagne Gold
    '#3498DB', // Bright Blue
    '#E74C3C', // Festive Coral/Red
    '#2ECC71', // Vibrant Emerald
    '#9B59B6', // Amethyst Purple
    '#F39C12', // Warm Orange
    '#1ABC9C', // Turquoise
    '#E91E63', // Rose Pink
  ];

  // Primary burst from click origin
  confetti({
    particleCount: 60,
    spread: 70,
    origin: { x: originX, y: originY },
    colors: vibrantColors,
    scalar: 1,
    ticks: 220,
    gravity: 1.1,
    startVelocity: 30,
    disableForReducedMotion: true,
  });

  // Dual side celebration cannons for extra reward
  setTimeout(() => {
    confetti({
      particleCount: 30,
      angle: 60,
      spread: 55,
      origin: { x: Math.max(0.05, originX - 0.25), y: originY },
      colors: ['#F3D58A', '#3B6CB4', '#2ECC71', '#E74C3C'],
      scalar: 0.85,
      ticks: 180,
      gravity: 1.2,
      disableForReducedMotion: true,
    });

    confetti({
      particleCount: 30,
      angle: 120,
      spread: 55,
      origin: { x: Math.min(0.95, originX + 0.25), y: originY },
      colors: ['#3498DB', '#9B59B6', '#F3D58A', '#E91E63'],
      scalar: 0.85,
      ticks: 180,
      gravity: 1.2,
      disableForReducedMotion: true,
    });
  }, 100);
}
