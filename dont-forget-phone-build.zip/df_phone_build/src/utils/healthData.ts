import { DailyNutritionTarget, LoggedMeal, UserHealthProfile } from '../types/health';

export const INITIAL_NUTRITION_TARGET: DailyNutritionTarget = {
  targetCalories: 0,
  consumedCalories: 0,
  targetProtein: 0,
  consumedProtein: 0,
  targetCarbs: 0,
  consumedCarbs: 0,
  targetFats: 0,
  consumedFats: 0,
};

export const INITIAL_LOGGED_MEALS: LoggedMeal[] = [];

export const INITIAL_USER_PROFILE: UserHealthProfile = {
  name: '',
  currentWeight: null,
  targetWeight: null,
  startWeight: null,
  heightCm: null,
  goal: null,
  targetCalories: null,
  targetProtein: null,
  targetCarbs: null,
  targetFats: null,
  waterGlasses: 0,
};
