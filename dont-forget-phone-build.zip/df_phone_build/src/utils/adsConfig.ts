/**
 * إعدادات الإعلانات — Start.io
 * =============================
 * مزوّد الإعلانات الحالي: Start.io (StartApp)
 * معرّف التطبيق: 210222499
 *
 * ⚠️ مهم جداً:
 *  - Start.io ليس له إضافة Capacitor رسمية، لذلك أرفقنا إضافة أصلية (Java)
 *    جاهزة في مجلد native-android/ — راجع STARTIO_SETUP.md.
 *  - الإعلانات الحقيقية تعمل فقط داخل تطبيق أندرويد مثبّت (APK).
 *    في المتصفح يظهر تصميم تجريبي (placeholder) حتى لا تتعطل المعاينة.
 */

export type AdsProvider = 'placeholder' | 'startio' | 'admob' | 'affiliate';

export interface AdsConfig {
  enabled: boolean;
  provider: AdsProvider;

  /** 🔴 Start.io */
  startio: {
    /** معرّف التطبيق من لوحة Start.io */
    appId: string;
    /** إعلان تجريبي أثناء التطوير — احذفه/اجعله false قبل النشر */
    testAds: boolean;
    /** وسم الإعلان (يظهر في تقارير Start.io لتمييز المواضع) */
    bannerAdTag: string;
    interstitialAdTag: string;
  };

  /** ~/ إعلان الفتح الكامل (Interstitial يظهر عند فتح التطبيق) */
  appOpen: {
    maxPerDay: number;
    minIntervalMs: number;
    neverOnFirstRun: boolean;
    /** مهلة انتظار تحميل الإعلان قبل التخلي عنه */
    loadTimeoutMs: number;
    /** بعد كم ثانية يصبح زر التخطي متاحاً (للتصميم التجريبي فقط) */
    skipAfterMs: number;
    /** إغلاق تلقائي للتصميم التجريبي */
    autoCloseAfterMs: number;
  };

  /** ~/ البانر السفلي */
  banner: {
    /** Start.io يدعم بانر واحد للشاشة — لا ترفعه إلى 2 */
    slots: 1 | 2;
    showOn: Array<'home' | 'tasks' | 'calendar' | 'health' | 'settings'>;
    /** ارتفاع البانر بالبكسل (يدل) لتخصيص مساحة أسفل الشاشة */
    heightDp: number;
  };

  /** مفتاح إزالة الإعلانات */
  premiumRemovalKey: string;
}

export const ADS_CONFIG: AdsConfig = {
  enabled: true,
  provider: 'startio',

  startio: {
    appId: '210222499',
    testAds: true, // ← اجعلها false قبل نشر التطبيق
    bannerAdTag: 'bottom_banner',
    interstitialAdTag: 'app_open',
  },

  appOpen: {
    maxPerDay: 2,
    minIntervalMs: 4 * 60 * 60 * 1000, // 4 ساعات
    neverOnFirstRun: true,
    loadTimeoutMs: 8000,
    skipAfterMs: 5000,
    autoCloseAfterMs: 20000,
  },

  banner: {
    slots: 1,
    showOn: ['home', 'tasks', 'calendar', 'health', 'settings'],
    heightDp: 50,
  },

  premiumRemovalKey: 'df_ads_removed',
};

/** نص الإعلان التجريبي في المتصفح */
export const PLACEHOLDER_CREATIVE = {
  titleAr: 'مساحة إعلانية',
  titleEn: 'Ad space',
  subAr: 'تظهر هنا إعلانات Start.io داخل تطبيق الأندرويد',
  subEn: 'Start.io ads render here inside the Android app',
};
