/**
 * Local Food Engine — "Zero-AI First" Recognition
 * ===============================================
 * يعمل هذا المحرك بالكامل على الجهاز، بدون إنترنت وبدون أي استدعاء لـ Gemini.
 *
 * الفكرة:
 *  1) المستخدم يختار وصفاً سريعاً (chip) أو يكتب اسم الوجبة.
 *  2) نطابق النص العربي/الإنجليزي مع قاعدة البيانات الغذائية المحلية
 *     (مع مراعاة التشكيل، الهمزات، التاء المربوطة، واللهجات: رز/أرز، عيش/خبز ...).
 *  3) نحسب القيم الغذائية بمعادلة Atwater الدقيقة (غرام × القيمة لكل 100غ)
 *     بدل تخمين الذكاء الاصطناعي.
 *
 * النتيجة: أغلب الوجبات الشائعة لا تُكلّف أي طلب AI مطلقاً.
 */

import { Language } from '../types';
import { FoodAnalysisResult, FoodIngredientItem } from '../types/health';
import {
  NUTRITION_DATABASE,
  NutritionReferenceItem,
  calculateDishTotals,
} from './nutritionDatabase';

/* ------------------------------------------------------------------ */
/* 1. Arabic / English normalization                                   */
/* ------------------------------------------------------------------ */

const ARABIC_DIACRITICS = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]/g;

/**
 * توحيد النص: إزالة التشكيل والتطويل، توحيد الهمزات والياء والتاء المربوطة،
 * وحذف علامات الترقيم — حتى يطابق "كَبْسَة" و"كبسه" و"Kabsa" نفس المدخل.
 */
export function normalizeFoodText(input: string): string {
  if (!input) return '';
  let s = String(input).toLowerCase().trim();
  s = s.replace(ARABIC_DIACRITICS, '');
  s = s.replace(/\u0640/g, ''); // tatweel ـــ
  s = s.replace(/[أإآٱ]/g, 'ا');
  s = s.replace(/ى/g, 'ي');
  s = s.replace(/ة/g, 'ه');
  s = s.replace(/ؤ/g, 'و');
  s = s.replace(/ئ/g, 'ي');
  s = s.replace(/[^\u0600-\u06FFa-z0-9\s]/g, ' ');
  s = s.replace(/\s+/g, ' ').trim();
  // إزالة أداة التعريف: "الرز" → "رز"، "السلطة" → "سلطه"
  s = s
    .split(' ')
    .map((token) => (token.length >= 4 && token.startsWith('ال') ? token.slice(2) : token))
    .join(' ');
  return s;
}

/* ------------------------------------------------------------------ */
/* 2. Keyword index (Arabic dialects + English)                        */
/* ------------------------------------------------------------------ */

const FOOD_KEYWORDS: Record<string, string[]> = {
  // Yemeni / Gulf
  mandi_rice: ['مندي', 'ارز مندي', 'رز مندي', 'مندي رز', 'mandi', 'mandi rice'],
  kabsa_rice: ['كبسه', 'كبسة', 'ارز كبسه', 'رز كبسه', 'kabsa', 'kabsa rice'],
  zurbian_rice: ['زربيان', 'ارز زربيان', 'zurbian'],
  white_rice: ['رز', 'ارز', 'رز ابيض', 'ارز ابيض', 'ارز مسلوق', 'rice', 'white rice', 'steamed rice'],
  mutton_lamb_roast: ['لحم', 'لحم ضان', 'حنيذ', 'لحم مندي', 'لحم مشوي', 'لحم محمر', 'mutton', 'lamb', 'roast lamb', 'haneeth'],
  chicken_roast: ['دجاج مندي', 'دجاج محمر', 'دجاج مشوي', 'فراخ', 'دجاج', 'chicken', 'roast chicken', 'grilled chicken'],
  chicken_breast_grilled: ['صدر دجاج', 'صدور دجاج', 'صدر فراخ', 'chicken breast', 'grilled chicken breast'],
  fahsa_shredded_beef: ['فحسه', 'فحسة', 'لحم فحسه', 'fahsa', 'fahsa beef'],
  saltah_meat_vegetable_stew: ['سلته', 'سلتة', 'saltah', 'saltah stew'],
  hilbeh_fenugreek_foam: ['حلبه', 'حلبة', 'حلبة سلتة', 'hilbeh', 'fenugreek'],
  maraq_broth: ['مرق', 'شوربه', 'شوربة', 'حساء', 'broth', 'soup', 'maraq'],
  sahawiq_salsa: ['سحاوق', 'سحوق', 'شطه', 'sahawiq', 'salsa', 'hot sauce'],
  molawah_bread: ['ملوح', 'خبز ملوح', 'ملوح يمني', 'molawah', 'malawah'],
  arabic_pita_bread: ['خبز', 'خبز عربي', 'عيش', 'رغيف', 'خبز بلدي', 'pita', 'bread', 'khubz', 'arabic bread'],
  roti_tandoori: ['خبز تنور', 'تنور', 'roti', 'tandoori', 'flatbread'],
  fish_grilled: ['سمك مشوي', 'سمك', 'موفي', 'موفى', 'صياديه', 'صيادية', 'fish', 'grilled fish', 'sayadieh'],
  fish_fried: ['سمك مقلي', 'fried fish', 'fish fillet'],
  foul_mudammas: ['فول', 'فول مدمس', 'فول بالزيت', 'foul', 'fava beans', 'ful medames'],
  shakshouka: ['شكشوكه', 'شكشوكة', 'بيض بالطماطم', 'shakshouka', 'eggs tomato'],
  falafel: ['فلافل', 'طعميه', 'طعمية', 'falafel', 'taamiya'],
  hummus: ['حمص', 'حمص بالطحينه', 'hummus', 'hummos'],
  mutabbaq_meat: ['مطبق', 'مطبق لحم', 'mutabbaq', 'mutabbaq meat'],
  bint_al_sahn: ['بنت الصحن', 'bint al sahn', 'honey cake'],
  aseed_dates: ['عصيده', 'عصيدة', 'عصيد', 'aseed', 'aseeda'],
  olive_oil: ['زيت زيتون', 'زيت', 'olive oil'],
  samn_ghee: ['سمن', 'سمنه', 'سمن بلدي', 'ghee', 'samn'],
  green_salad: ['سلطه', 'سلطة', 'سلطة خضراء', 'خضار', 'salad', 'green salad', 'vegetables'],
  plain_yogurt: ['زبادي', 'لبن', 'روب', 'yogurt', 'laban'],
  dates: ['تمر', 'رطب', 'بلح', 'dates', 'date'],

  // Everyday / international
  pizza_cheese: ['بيتزا', 'بيتزا جبن', 'pizza', 'cheese pizza'],
  beef_burger: ['برجر', 'همبرجر', 'burger', 'hamburger', 'beef burger'],
  french_fries: ['بطاطس مقلية', 'بطاطا مقلية', 'شيبس', 'fries', 'french fries'],
  pasta_red_sauce: ['مكرونه', 'مكرونة', 'باستا', 'معكرونة', 'pasta', 'spaghetti'],
  chicken_shawarma: ['شاورما', 'شاورما دجاج', 'shawarma', 'chicken shawarma'],
  grilled_kebab: ['كباب', 'كفته', 'كفتة', 'kebab', 'kofta'],
  boiled_egg: ['بيضه مسلوقه', 'بيض مسلوق', 'boiled egg', 'eggs'],
  fried_egg: ['بيضه مقليه', 'بيض مقلي', 'عجه', 'عجة', 'fried egg', 'omelette'],
  milk_full_fat: ['حليب', 'لبن حليب', 'milk'],
  lentil_soup: ['شوربة عدس', 'شوربه عدس', 'عدس', 'lentil soup', 'lentils'],
  oats_porridge: ['شوفان', 'بوريدج', 'oats', 'oatmeal', 'porridge'],
  tuna_canned: ['تونة', 'تونس', 'tuna'],
  banana: ['موز', 'banana'],
  apple: ['تفاح', 'تفاحة', 'apple'],
  orange: ['برتقال', 'orange'],
  watermelon: ['بطيخ', 'حبحب', 'watermelon'],
  boiled_potato: ['بطاطس مسلوقة', 'بطاطا مسلوقة', 'boiled potato'],
  cucumber: ['خيار', 'cucumber'],
  tomato: ['طماطم', 'بندورة', 'tomato'],
  chocolate: ['شوكولاته', 'شكولاته', 'chocolate'],
  honey: ['عسل', 'honey'],
};

interface IndexEntry {
  id: string;
  item: NutritionReferenceItem;
  keywords: string[]; // already normalized
}

const FOOD_INDEX: IndexEntry[] = Object.entries(FOOD_KEYWORDS)
  .map(([id, keywords]) => {
    const item = NUTRITION_DATABASE[id];
    if (!item) return null;
    const normalized = new Set<string>([
      ...keywords.map(normalizeFoodText),
      normalizeFoodText(item.nameAr),
      normalizeFoodText(item.nameEn),
    ]);
    return { id, item, keywords: Array.from(normalized).filter(Boolean) };
  })
  .filter((entry): entry is IndexEntry => entry !== null);

/* ------------------------------------------------------------------ */
/* 3. Matching                                                         */
/* ------------------------------------------------------------------ */

export interface LocalMatch {
  id: string;
  item: NutritionReferenceItem;
  score: number; // 0..1
  matchedKeyword: string;
}

function scoreKeyword(query: string, keyword: string): number {
  if (!query || !keyword) return 0;
  if (query === keyword) return 1;

  const paddedQuery = ` ${query} `;
  if (paddedQuery.includes(` ${keyword} `)) return 0.9;

  if (query.includes(keyword)) {
    return Math.min(0.88, 0.6 + (keyword.length / Math.max(4, query.length)) * 0.35);
  }

  if (keyword.includes(query) && query.length >= 3) {
    return Math.min(0.82, 0.55 + (query.length / keyword.length) * 0.3);
  }

  const qTokens = query.split(' ').filter((t) => t.length >= 3);
  const kTokens = keyword.split(' ').filter((t) => t.length >= 3);
  const shared = kTokens.filter((t) => qTokens.includes(t)).length;
  if (shared > 0) return Math.min(0.78, 0.45 + shared * 0.15);

  return 0;
}

/** يرجع كل الأطعمة المحلية المطابقة للنص، مرتبة بالأعلى ثقة. */
export function findLocalFoods(query: string): LocalMatch[] {
  const q = normalizeFoodText(query);
  if (!q) return [];

  const matches: LocalMatch[] = [];
  for (const entry of FOOD_INDEX) {
    let best = 0;
    let bestKeyword = '';
    for (const kw of entry.keywords) {
      const score = scoreKeyword(q, kw);
      if (score > best) {
        best = score;
        bestKeyword = kw;
      }
    }
    if (best > 0) {
      matches.push({ id: entry.id, item: entry.item, score: best, matchedKeyword: bestKeyword });
    }
  }

  return matches.sort((a, b) => b.score - a.score);
}

/** أولوية ترتيب مكوّنات الطبق عند دمج أكثر من عنصر في وجبة واحدة. */
const CATEGORY_PRIORITY: NutritionReferenceItem['category'][] = [
  'meat',
  'poultry',
  'fish',
  'stew',
  'legume',
  'grain',
  'bread',
  'vegetable',
  'dairy',
  'fat',
  'sweet',
];

/* ------------------------------------------------------------------ */
/* 4. Building a full analysis result                                  */
/* ------------------------------------------------------------------ */

const HEALTH_TIPS = {
  highProtein: {
    ar: 'وجبة غنية بالبروتين — مثالية بعد التمرين وتساعد على الشبع لفترة أطول.',
    en: 'High-protein meal — great after training and keeps you full longer.',
  },
  highCarb: {
    ar: 'غنية بالكربوهيدرات: أضف سلطة أو خضار لتخفيف الحمل السكري وتوازن الوجبة.',
    en: 'Carb-heavy: add a salad or vegetables to balance blood sugar and the plate.',
  },
  highFat: {
    ar: 'نسبة الدهون مرتفعة قليلاً — قلّل الزيوت المضافة واشرب ماءً أكثر.',
    en: 'Fat content is a bit high — reduce added oils and drink more water.',
  },
  balanced: {
    ar: 'وجبة متوازنة نسبياً، استمر على هذا النمط.',
    en: 'Reasonably balanced meal — keep it up.',
  },
};

function pickHealthTip(totals: { protein: number; carbs: number; fats: number; calories: number }) {
  if (totals.calories <= 0) return HEALTH_TIPS.balanced;
  const proteinPct = (totals.protein * 4) / totals.calories;
  const carbPct = (totals.carbs * 4) / totals.calories;
  const fatPct = (totals.fats * 9) / totals.calories;
  if (fatPct > 0.4) return HEALTH_TIPS.highFat;
  if (proteinPct >= 0.25) return HEALTH_TIPS.highProtein;
  if (carbPct > 0.6) return HEALTH_TIPS.highCarb;
  return HEALTH_TIPS.balanced;
}

export interface LocalAnalysis {
  result: FoodAnalysisResult;
  /** high = تطابق نصي قوي (لا حاجة للـ AI) */
  confidence: 'high' | 'medium';
  matchedIds: string[];
}

/**
 * يبني نتيجة تحليل كاملة من عناصر قاعدة البيانات مع أوزان محددة.
 */
export function buildAnalysisFromItems(
  picks: { id: string; grams: number }[],
  language: Language
): LocalAnalysis | null {
  const ingredients: FoodIngredientItem[] = [];

  for (const pick of picks) {
    const ref = NUTRITION_DATABASE[pick.id];
    if (!ref) continue;
    ingredients.push({
      id: ref.id,
      name: ref.nameEn,
      nameAr: ref.nameAr,
      weightGrams: pick.grams,
      caloriesPer100g: ref.caloriesPer100g,
      proteinPer100g: ref.proteinPer100g,
      carbsPer100g: ref.carbsPer100g,
      fatsPer100g: ref.fatsPer100g,
      fiberPer100g: ref.fiberPer100g,
    });
  }

  if (ingredients.length === 0) return null;

  const totals = calculateDishTotals(ingredients);
  const tip = pickHealthTip(totals);

  const namesEn = picks
    .map((p) => NUTRITION_DATABASE[p.id]?.nameEn)
    .filter(Boolean)
    .slice(0, 3) as string[];
  const namesAr = picks
    .map((p) => NUTRITION_DATABASE[p.id]?.nameAr)
    .filter(Boolean)
    .slice(0, 3) as string[];

  const labelEn = namesEn.join(' + ');
  const labelAr = namesAr.join(' + ');

  const result: FoodAnalysisResult = {
    foodName: labelEn || 'Meal',
    foodNameAr: labelAr || 'وجبة',
    calories: totals.calories,
    protein: totals.protein,
    carbs: totals.carbs,
    fats: totals.fats,
    fiber: totals.fiber,
    totalWeightGrams: totals.totalWeightGrams,
    portionSize:
      language === 'ar'
        ? `حصة ~${totals.totalWeightGrams} جم`
        : `~${totals.totalWeightGrams} g portion`,
    portionSizeAr: `حصة ~${totals.totalWeightGrams} جم`,
    healthTip: tip.en,
    healthTipAr: tip.ar,
    confidence: language === 'ar' ? 'مرتفع' : 'High',
    ingredients: totals.ingredients,
    source: 'local_database',
  };

  return { result, confidence: 'high', matchedIds: picks.map((p) => p.id) };
}

const PORTION_HINTS: { re: RegExp; factor: number }[] = [
  { re: /(كبير|كبيره|كبيرة|large|big)/, factor: 1.3 },
  { re: /(وسط|متوسط|medium|regular)/, factor: 1.0 },
  { re: /(صغير|صغيره|صغيرة|small|little|نص|نصف|half)/, factor: 0.65 },
];

/**
 * تحليل محلي كامل من نص حر (وصف المستخدم للوجبة).
 * يرجع null عندما لا توجد ثقة كافية — وعندها فقط نلجأ إلى الـ AI.
 */
export function analyzeFoodTextLocally(text: string, language: Language): LocalAnalysis | null {
  const query = normalizeFoodText(text);
  if (!query) return null;

  const matches = findLocalFoods(text).filter((m) => m.score >= 0.55);
  if (matches.length === 0) return null;

  // نرفض المطابقات الضعيفة (مثل "لحم مشوي" عندما يصف المستخدم الدجاج)
  const topScore = matches[0].score;
  const minScore = Math.max(0.68, topScore - 0.2);
  const reliable = matches.filter((m) => m.score >= minScore);
  if (reliable.length === 0) return null;

  // عنصر واحد فقط من كل فئة (أرز + لحم + سلطة، وليس ثلاث أنواع أرز)
  const usedCategories = new Set<string>();
  const picked: { id: string; grams: number }[] = [];

  for (const category of CATEGORY_PRIORITY) {
    if (picked.length >= 4) break;
    const best = reliable.find(
      (m) => m.item.category === category && !usedCategories.has(m.item.category)
    );
    if (best) {
      usedCategories.add(best.item.category);
      picked.push({ id: best.id, grams: best.item.typicalServingGrams });
    }
  }

  if (picked.length === 0) return null;

  // تعديل الحصة حسب وصف المستخدم: "حصة كبيرة / صغيرة / نص"
  let factor = 1;
  for (const hint of PORTION_HINTS) {
    if (hint.re.test(query)) {
      factor = hint.factor;
      break;
    }
  }
  const scaled = picked.map((p) => ({
    id: p.id,
    grams: Math.max(10, Math.round(p.grams * factor)),
  }));

  const analysis = buildAnalysisFromItems(scaled, language);
  if (!analysis) return null;

  const strongMatch = reliable[0].score >= 0.88 && picked.length >= 1;
  if (!strongMatch) {
    analysis.confidence = 'medium';
    analysis.result.confidence = language === 'ar' ? 'متوسط' : 'Medium';
  }

  return analysis;
}

/* ------------------------------------------------------------------ */
/* 5. One-tap presets (chips) — the fastest zero-AI path               */
/* ------------------------------------------------------------------ */

export interface QuickFoodHint {
  id: string;
  labelAr: string;
  labelEn: string;
  items: { id: string; grams: number }[];
}

export const QUICK_FOOD_HINTS: QuickFoodHint[] = [
  {
    id: 'rice_chicken',
    labelAr: 'أرز ودجاج',
    labelEn: 'Rice & Chicken',
    items: [
      { id: 'white_rice', grams: 200 },
      { id: 'chicken_breast_grilled', grams: 150 },
      { id: 'green_salad', grams: 80 },
    ],
  },
  {
    id: 'kabsa_lamb',
    labelAr: 'كبسة لحم',
    labelEn: 'Lamb Kabsa',
    items: [
      { id: 'kabsa_rice', grams: 220 },
      { id: 'mutton_lamb_roast', grams: 160 },
    ],
  },
  {
    id: 'mandi_chicken',
    labelAr: 'مندي دجاج',
    labelEn: 'Chicken Mandi',
    items: [
      { id: 'mandi_rice', grams: 220 },
      { id: 'chicken_roast', grams: 180 },
    ],
  },
  {
    id: 'saltah',
    labelAr: 'سلتة يمنية',
    labelEn: 'Yemeni Saltah',
    items: [
      { id: 'saltah_meat_vegetable_stew', grams: 200 },
      { id: 'hilbeh_fenugreek_foam', grams: 60 },
      { id: 'molawah_bread', grams: 100 },
    ],
  },
  {
    id: 'foul_bread',
    labelAr: 'فول وخبز',
    labelEn: 'Foul & Bread',
    items: [
      { id: 'foul_mudammas', grams: 180 },
      { id: 'arabic_pita_bread', grams: 80 },
    ],
  },
  {
    id: 'shakshouka',
    labelAr: 'شكشوكة',
    labelEn: 'Shakshouka',
    items: [
      { id: 'shakshouka', grams: 180 },
      { id: 'arabic_pita_bread', grams: 60 },
    ],
  },
  {
    id: 'fish_rice',
    labelAr: 'سمك وأرز',
    labelEn: 'Fish & Rice',
    items: [
      { id: 'fish_grilled', grams: 180 },
      { id: 'white_rice', grams: 180 },
    ],
  },
  {
    id: 'shawarma',
    labelAr: 'شاورما دجاج',
    labelEn: 'Chicken Shawarma',
    items: [{ id: 'chicken_shawarma', grams: 220 }],
  },
  {
    id: 'pizza',
    labelAr: 'بيتزا',
    labelEn: 'Pizza',
    items: [{ id: 'pizza_cheese', grams: 150 }],
  },
  {
    id: 'burger_fries',
    labelAr: 'برجر وبطاطس',
    labelEn: 'Burger & Fries',
    items: [
      { id: 'beef_burger', grams: 180 },
      { id: 'french_fries', grams: 100 },
    ],
  },
  {
    id: 'eggs_bread',
    labelAr: 'بيض وخبز',
    labelEn: 'Eggs & Bread',
    items: [
      { id: 'fried_egg', grams: 100 },
      { id: 'arabic_pita_bread', grams: 60 },
      { id: 'tomato', grams: 80 },
    ],
  },
  {
    id: 'oats_banana',
    labelAr: 'شوفان وموز',
    labelEn: 'Oats & Banana',
    items: [
      { id: 'oats_porridge', grams: 250 },
      { id: 'banana', grams: 120 },
    ],
  },
  {
    id: 'dates_milk',
    labelAr: 'تمر وحليب',
    labelEn: 'Dates & Milk',
    items: [
      { id: 'dates', grams: 50 },
      { id: 'milk_full_fat', grams: 200 },
    ],
  },
  {
    id: 'salad_yogurt',
    labelAr: 'سلطة ولبن',
    labelEn: 'Salad & Yogurt',
    items: [
      { id: 'green_salad', grams: 120 },
      { id: 'plain_yogurt', grams: 150 },
    ],
  },
];

export function buildQuickHintAnalysis(hintId: string, language: Language): LocalAnalysis | null {
  const hint = QUICK_FOOD_HINTS.find((h) => h.id === hintId);
  if (!hint) return null;
  return buildAnalysisFromItems(hint.items, language);
}

/* ------------------------------------------------------------------ */
/* 6. Graceful offline fallback                                        */
/* ------------------------------------------------------------------ */

/**
 * عند فشل الاتصال أو تجاوز الحصة: نجرب مطابقة وصف المستخدم محلياً أولاً،
 * وإن لم يوجد وصف مطابق نرجع الوجبة التقديرية المتوازنة.
 */
export function resolveLocalFallback(hint: string | undefined, language: Language): FoodAnalysisResult {
  const local = hint ? analyzeFoodTextLocally(hint, language) : null;
  if (local) return local.result;
  return buildGenericFallback(language);
}

/**
 * وجبة تقديرية متوازنة تُستخدم فقط عند فشل كل شيء (لا إنترنت + لا وصف).
 */
export function buildGenericFallback(language: Language): FoodAnalysisResult {
  const analysis = buildAnalysisFromItems(
    [
      { id: 'white_rice', grams: 160 },
      { id: 'chicken_breast_grilled', grams: 130 },
      { id: 'green_salad', grams: 80 },
    ],
    language
  );

  const base: FoodAnalysisResult =
    analysis?.result ??
    ({
      foodName: 'Balanced Meal',
      foodNameAr: 'وجبة متوازنة',
      calories: 465,
      protein: 38.5,
      carbs: 52,
      fats: 11.2,
      fiber: 4.8,
    } as FoodAnalysisResult);

  return {
    ...base,
    foodName: 'Nutritious Balanced Meal',
    foodNameAr: 'وجبة متوازنة ومغذية (تقدير فوري)',
    healthTip: 'You can review and customize ingredients, portions and weights directly.',
    healthTipAr: 'تم التقدير محلياً من قاعدة البيانات الغذائية. يمكنك تعديل المكونات والأوزان بدقة.',
    confidence: language === 'ar' ? 'متوسط' : 'Medium',
    source: 'offline_fallback',
  };
}
