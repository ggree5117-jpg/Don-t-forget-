/**
 * Meal Images — صور الأطباق المقترحة
 * ==================================
 * يربط اسم الوجبة (عربي/إنجليزي) بمجموعة صور احترافية موحّدة الأسلوب.
 *
 * لماذا بالكلمات المفتاحية بدل ربط يدوي لكل وجبة؟
 * لأن الاستشارة والخطة تأتي أسماءها من الذكاء الاصطناعي (نصوص حرة متغيّرة)،
 * والربط بالكلمات المفتاحية يغطي أي اسم جديد تلقائياً.
 */

export type MealImageKey =
  | 'eggs_breakfast'
  | 'foul_beans'
  | 'dates_nuts'
  | 'fruit_yogurt'
  | 'rice_chicken'
  | 'grilled_chicken'
  | 'beef_steak'
  | 'fish_salmon'
  | 'salad_bowl'
  | 'soup_lentil'
  // الأربعة المتبقية (تُولَّد لاحقاً) — لها بدائل مؤقتة إن لم توجد
  | 'wrap_shawarma'
  | 'smoothie_drink'
  | 'hummus_mezze'
  | 'oats_porridge';

interface MealImageRule {
  key: MealImageKey;
  /** كلمات مفتاحية عربية وإنجليزية مرتبة بالأولوية */
  keywords: string[];
}

/**
 * الترتيب مهم: أول قاعدة تُطابق هو الفائز.
 * القواعد الأكثر تخصيصاً أولاً (سمك/دجاج/لحم) قبل العامة.
 */
const RULES: MealImageRule[] = [
  {
    key: 'fish_salmon',
    keywords: ['سمك', 'سلمون', 'تونة', 'صيادية', 'fish', 'salmon', 'tuna', 'seafood', 'shrimp', 'روبيان'],
  },
  {
    key: 'beef_steak',
    keywords: ['ستيك', 'لحم بقري', 'لحم', 'كباب', 'كفتة', 'برجر', 'steak', 'beef', 'kebab', 'kofta', 'burger', 'meat'],
  },
  {
    key: 'grilled_chicken',
    keywords: ['دجاج', 'ديك رومي', 'شاورما', 'تركي', 'chicken', 'turkey', 'shawarma', 'poultry'],
  },
  {
    key: 'smoothie_drink',
    keywords: ['سموذي', 'شيك', 'عصير', 'لبن رايب', 'smoothie', 'shake', 'juice', 'drink'],
  },
  {
    key: 'soup_lentil',
    keywords: ['شوربة', 'شوربه', 'عدس', 'حساء', 'مرق', 'soup', 'lentil', 'broth'],
  },
  {
    key: 'salad_bowl',
    keywords: ['سلطة', 'سلطه', 'كينوا', 'تبولة', 'جرجير', 'خضار مشوي', 'salad', 'quinoa', 'bowl', 'tabbouleh'],
  },
  {
    key: 'fruit_yogurt',
    keywords: ['زبادي', 'لبن', 'توت', 'فواكه', 'تفاح', 'موز', 'yogurt', 'berries', 'fruit', 'apple', 'banana'],
  },
  {
    key: 'oats_porridge',
    keywords: ['شوفان', 'بوريدج', 'oats', 'oatmeal', 'porridge', 'granola'],
  },
  {
    key: 'hummus_mezze',
    keywords: ['حمص', 'متبل', 'بابا غنوج', 'مقبلات', 'hummus', 'mezze', 'mutabbal'],
  },
  {
    key: 'foul_beans',
    keywords: ['فول', 'فاصوليا', 'إدمامي', 'ادمامي', 'بقوليات', 'foul', 'fava', 'beans', 'edamame'],
  },
  {
    key: 'eggs_breakfast',
    keywords: ['بيض', 'شكشوكة', 'أومليت', 'اومليت', 'عجة', 'eggs', 'shakshuka', 'omelette', 'scrambled'],
  },
  {
    key: 'wrap_shawarma',
    keywords: ['ساندويتش', 'خبز', 'توست', 'رغيف', 'ملوح', 'مطبق', 'sandwich', 'wrap', 'toast', 'bread', 'pita'],
  },
  {
    key: 'rice_chicken',
    keywords: ['أرز', 'ارز', 'كبسة', 'مندي', 'زربيان', 'برياني', 'عصيدة', 'rice', 'mandi', 'kabsa', 'biryani', 'pasta', 'مكرونة'],
  },
  {
    key: 'dates_nuts',
    keywords: ['تمر', 'مكسرات', 'لوز', 'جوز', 'بذور', 'جبن', 'قهوة', 'snack', 'dates', 'nuts', 'almond', 'cheese', 'coffee'],
  },
];

/** صور متاحة فعلياً الآن (الباقي يحتاج توليداً) */
const AVAILABLE: MealImageKey[] = [
  'eggs_breakfast',
  'foul_beans',
  'dates_nuts',
  'fruit_yogurt',
  'rice_chicken',
  'grilled_chicken',
  'beef_steak',
  'fish_salmon',
  'salad_bowl',
  'soup_lentil',
];

const FALLBACKS: Partial<Record<MealImageKey, MealImageKey>> = {
  wrap_shawarma: 'grilled_chicken',
  smoothie_drink: 'fruit_yogurt',
  hummus_mezze: 'foul_beans',
  oats_porridge: 'fruit_yogurt',
};

/** كلمة مفتاحية ثابتة لكل خانة — تُستخدم عندما لا يطابق الاسم أي قاعدة */
const SLOT_DEFAULT: Record<string, MealImageKey> = {
  breakfast: 'eggs_breakfast',
  snack_am: 'fruit_yogurt',
  lunch: 'rice_chicken',
  snack_pm: 'dates_nuts',
  dinner: 'fish_salmon',
};

/** الخريطة النهائية لكل صورة متاحة */
export const MEAL_IMAGE_PATHS: Record<MealImageKey, string> = {
  eggs_breakfast: '/images/meals/eggs_breakfast.jpg',
  foul_beans: '/images/meals/foul_beans.jpg',
  dates_nuts: '/images/meals/dates_nuts.jpg',
  fruit_yogurt: '/images/meals/fruit_yogurt.jpg',
  rice_chicken: '/images/meals/rice_chicken.jpg',
  grilled_chicken: '/images/meals/grilled_chicken.jpg',
  beef_steak: '/images/meals/beef_steak.jpg',
  fish_salmon: '/images/meals/fish_salmon.jpg',
  salad_bowl: '/images/meals/salad_bowl.jpg',
  soup_lentil: '/images/meals/soup_lentil.jpg',
  wrap_shawarma: '/images/meals/wrap_shawarma.jpg',
  smoothie_drink: '/images/meals/smoothie_drink.jpg',
  hummus_mezze: '/images/meals/hummus_mezze.jpg',
  oats_porridge: '/images/meals/oats_porridge.jpg',
};

function normalize(text: string): string {
  return String(text || '')
    .toLowerCase()
    .replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/[^\u0600-\u06FFa-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** يحدد مفتاح الصورة المناسب لاسم الوجبة */
export function resolveMealImageKey(
  nameAr?: string | null,
  nameEn?: string | null,
  slot?: string | null
): MealImageKey {
  const haystack = `${normalize(nameAr || '')} ${normalize(nameEn || '')}`.trim();

  if (haystack) {
    for (const rule of RULES) {
      for (const kw of rule.keywords) {
        if (haystack.includes(normalize(kw))) {
          return AVAILABLE.includes(rule.key)
            ? rule.key
            : FALLBACKS[rule.key] || 'rice_chicken';
        }
      }
    }
  }

  if (slot && SLOT_DEFAULT[slot]) return SLOT_DEFAULT[slot];
  return 'rice_chicken';
}

/** المسار الجاهز للاستخدام في <img src> */
export function resolveMealImageUrl(
  nameAr?: string | null,
  nameEn?: string | null,
  slot?: string | null
): string {
  const key = resolveMealImageKey(nameAr, nameEn, slot);
  return MEAL_IMAGE_PATHS[AVAILABLE.includes(key) ? key : 'rice_chicken'];
}
