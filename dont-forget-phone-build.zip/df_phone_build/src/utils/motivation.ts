/**
 * Motivation states configuration for HomeDashboard
 * Changes message, theme colors, progress ring, and visuals based on task completion percentage.
 */

export type MotivationStateKey =
  | 'none'
  | 'complete'
  | 'great'
  | 'half'
  | 'low'
  | 'warning';

export interface MotivationStateConfig {
  key: MotivationStateKey;
  // Titles & text
  titleAr: string;
  titleEn: string;
  descAr: string;
  descEn: string;
  badgeAr: string;
  badgeEn: string;
  // Configurable image paths (user can place webp or png files into public/images/motivation/)
  imagePathWebp: string;
  imagePathPng: string;
  // Icon fallback until custom image files are placed in public/images/motivation/
  iconName: 'clipboard' | 'trophy' | 'rocket' | 'compass' | 'zap' | 'alert';
  // Visual Theme tokens
  theme: {
    cardBg: string;
    cardBorder: string;
    cardShadow: string;
    ringTrackColor: string;
    ringProgressColor: string;
    titleColor: string;
    descColor: string;
    badgeBg: string;
    badgeText: string;
    percentageColor: string;
    iconContainerBg: string;
    iconColor: string;
  };
}

export const MOTIVATION_CONFIGS: Record<MotivationStateKey, MotivationStateConfig> = {
  // 1. لا توجد مهام (No Tasks yet - Neutral State)
  none: {
    key: 'none',
    titleAr: 'ابدأ رحلتك اليومية',
    titleEn: 'Start Your Daily Journey',
    descAr: 'أضف مهمتك الأولى لتشاهد تقدمك وتنجز مهامك بكفاءة.',
    descEn: 'Add your first task to track your progress and achieve goals.',
    badgeAr: '0% أضف مهمتك الأولى',
    badgeEn: '0% Add First Task',
    imagePathWebp: '/images/motivation/none.webp',
    imagePathPng: '/images/motivation/none.png',
    iconName: 'clipboard',
    theme: {
      cardBg: 'bg-white',
      cardBorder: 'border-slate-200/80',
      cardShadow: '0 10px 25px -5px rgba(100, 116, 139, 0.08), 0 2px 6px -2px rgba(0, 0, 0, 0.02)',
      ringTrackColor: '#F1F5F9',
      ringProgressColor: '#94A3B8',
      titleColor: 'text-[#1E293B]',
      descColor: 'text-slate-500',
      badgeBg: 'bg-slate-100',
      badgeText: 'text-slate-600',
      percentageColor: 'text-slate-400',
      iconContainerBg: 'bg-slate-100',
      iconColor: 'text-slate-500',
    },
  },

  // 2. 100% مكتمل (100% Complete - Celebration & Hero of the Day)
  complete: {
    key: 'complete',
    titleAr: 'إنجاز رائع وبطل اليوم!',
    titleEn: 'Hero of the Day!',
    descAr: 'أتممت جميع المهام بنجاح، استمتع بيومك المريح.',
    descEn: 'All tasks completed successfully. Enjoy your well-earned rest.',
    badgeAr: '100% مكتمل ✓',
    badgeEn: '100% Completed ✓',
    imagePathWebp: '/images/motivation/complete.webp',
    imagePathPng: '/images/motivation/complete.png',
    iconName: 'trophy',
    theme: {
      cardBg: 'bg-gradient-to-br from-[#064E3B] via-[#047857] to-[#065F46]',
      cardBorder: 'border-emerald-600/40',
      cardShadow: '0 12px 30px -4px rgba(5, 150, 105, 0.3), 0 2px 8px -2px rgba(0, 0, 0, 0.1)',
      ringTrackColor: 'rgba(255, 255, 255, 0.2)',
      ringProgressColor: '#FBBF24',
      titleColor: 'text-white',
      descColor: 'text-emerald-100',
      badgeBg: 'bg-emerald-900/60 backdrop-blur-xs border border-emerald-400/40',
      badgeText: 'text-amber-300',
      percentageColor: 'text-amber-300 font-black',
      iconContainerBg: 'bg-emerald-800/80 text-amber-300 border border-amber-400/30',
      iconColor: 'text-amber-300',
    },
  },

  // 3. 75% إلى 99% (75-99% - Excellent Progress)
  great: {
    key: 'great',
    titleAr: 'تقدم ممتاز، القليل وتصل!',
    titleEn: 'Excellent Progress, Almost There!',
    descAr: 'أنت على وشك الانتهاء من كافة مهامك، واصل هذا الزخم.',
    descEn: 'You are close to finishing all tasks. Keep up this momentum.',
    badgeAr: 'على وشك الإنجاز 🚀',
    badgeEn: 'Almost There 🚀',
    imagePathWebp: '/images/motivation/great.webp',
    imagePathPng: '/images/motivation/great.png',
    iconName: 'rocket',
    theme: {
      cardBg: 'bg-gradient-to-br from-[#0284C7] via-[#0369A1] to-[#075985]',
      cardBorder: 'border-sky-500/40',
      cardShadow: '0 12px 30px -4px rgba(2, 132, 199, 0.28), 0 2px 8px -2px rgba(0, 0, 0, 0.08)',
      ringTrackColor: 'rgba(255, 255, 255, 0.25)',
      ringProgressColor: '#38BDF8',
      titleColor: 'text-white',
      descColor: 'text-sky-100',
      badgeBg: 'bg-sky-950/40 backdrop-blur-xs border border-sky-300/40',
      badgeText: 'text-sky-200',
      percentageColor: 'text-white',
      iconContainerBg: 'bg-sky-500/30 text-sky-200 border border-sky-300/30',
      iconColor: 'text-sky-200',
    },
  },

  // 4. 50% إلى 74% (50-74% - Halfway There)
  half: {
    key: 'half',
    titleAr: 'في منتصف الطريق!',
    titleEn: 'Halfway There!',
    descAr: 'أداء جيد، تجاوزت النصف وباقي القليل للوصول للهدف.',
    descEn: 'Good job, you crossed the halfway mark. Keep moving forward.',
    badgeAr: 'تجاوزت النصف 🧭',
    badgeEn: 'Halfway 🧭',
    imagePathWebp: '/images/motivation/half.webp',
    imagePathPng: '/images/motivation/half.png',
    iconName: 'compass',
    theme: {
      cardBg: 'bg-white',
      cardBorder: 'border-teal-200',
      cardShadow: '0 12px 28px -4px rgba(13, 148, 136, 0.12), 0 2px 6px -2px rgba(0, 0, 0, 0.02)',
      ringTrackColor: '#F0FDFA',
      ringProgressColor: '#0D9488',
      titleColor: 'text-[#0F766E]',
      descColor: 'text-slate-500',
      badgeBg: 'bg-teal-50 border border-teal-200',
      badgeText: 'text-teal-700',
      percentageColor: 'text-[#0F766E]',
      iconContainerBg: 'bg-teal-50 border border-teal-200/80',
      iconColor: 'text-[#0D9488]',
    },
  },

  // 5. 25% إلى 49% (25-49% - Need a Push)
  low: {
    key: 'low',
    titleAr: 'تحتاج لدفعة قوية!',
    titleEn: 'Need a Strong Push!',
    descAr: 'لا تستسلم، بضع خطوات إضافية وسترى فرقاً كبيراً في إنجازك.',
    descEn: "Don't give up! A few extra steps will make a huge difference.",
    badgeAr: 'واصل المحاولة ⚡',
    badgeEn: 'Keep Pushing ⚡',
    imagePathWebp: '/images/motivation/low.webp',
    imagePathPng: '/images/motivation/low.png',
    iconName: 'zap',
    theme: {
      cardBg: 'bg-white',
      cardBorder: 'border-amber-200',
      cardShadow: '0 12px 28px -4px rgba(245, 158, 11, 0.12), 0 2px 6px -2px rgba(0, 0, 0, 0.02)',
      ringTrackColor: '#FFFBEB',
      ringProgressColor: '#F59E0B',
      titleColor: 'text-[#B45309]',
      descColor: 'text-slate-500',
      badgeBg: 'bg-amber-50 border border-amber-200',
      badgeText: 'text-amber-800',
      percentageColor: 'text-[#B45309]',
      iconContainerBg: 'bg-amber-50 border border-amber-200/80',
      iconColor: 'text-[#D97706]',
    },
  },

  // 6. أقل من 25% مع وجود مهام (Under 25% with Tasks - Warning State)
  warning: {
    key: 'warning',
    titleAr: 'تنبيه: انخفاض كبير في الإنجاز!',
    titleEn: 'Warning: Low Task Completion!',
    descAr: 'مهامك تتراكم! ركّز على مهمة واحدة الآن وابدأ فوراً.',
    descEn: 'Tasks are piling up! Pick one task right now and start immediately.',
    badgeAr: 'انتبه لمهامك ⚠️',
    badgeEn: 'Action Needed ⚠️',
    imagePathWebp: '/images/motivation/warning.webp',
    imagePathPng: '/images/motivation/warning.png',
    iconName: 'alert',
    theme: {
      cardBg: 'bg-gradient-to-br from-[#881337] via-[#9F1239] to-[#4C0519]',
      cardBorder: 'border-rose-700/50',
      cardShadow: '0 12px 30px -4px rgba(225, 29, 72, 0.35), 0 2px 8px -2px rgba(0, 0, 0, 0.12)',
      ringTrackColor: 'rgba(255, 255, 255, 0.2)',
      ringProgressColor: '#FB7185',
      titleColor: 'text-white',
      descColor: 'text-rose-100',
      badgeBg: 'bg-rose-950/50 backdrop-blur-xs border border-rose-400/40',
      badgeText: 'text-rose-200',
      percentageColor: 'text-rose-200',
      iconContainerBg: 'bg-rose-900/60 border border-rose-400/40',
      iconColor: 'text-rose-300',
    },
  },
};

/**
 * Returns the active motivation state configuration based on total tasks and completed count
 */
export function getMotivationState(totalCount: number, completedCount: number): {
  state: MotivationStateConfig;
  percentage: number;
} {
  if (totalCount === 0) {
    return {
      state: MOTIVATION_CONFIGS.none,
      percentage: 0,
    };
  }

  const percentage = Math.round((completedCount / totalCount) * 100);

  if (percentage === 100) {
    return { state: MOTIVATION_CONFIGS.complete, percentage };
  }
  if (percentage >= 75) {
    return { state: MOTIVATION_CONFIGS.great, percentage };
  }
  if (percentage >= 50) {
    return { state: MOTIVATION_CONFIGS.half, percentage };
  }
  if (percentage >= 25) {
    return { state: MOTIVATION_CONFIGS.low, percentage };
  }

  return { state: MOTIVATION_CONFIGS.warning, percentage };
}
