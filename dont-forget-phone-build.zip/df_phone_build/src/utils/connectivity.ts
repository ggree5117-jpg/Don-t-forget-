/**
 * Connectivity — فصل صريح بين ما يعمل بدون إنترنت وما يحتاجه
 * =========================================================
 * المهام وحفظها وتنبيهاتها: محلية 100% (لا تحتاج هذا الملف أصلاً للعمل).
 * ميزات الصحة (التصوير بالـ AI، الخطة الغذائية، استشارة الذكاء الاصطناعي): تحتاج اتصالاً.
 *
 * نستخدم navigator.onLine كمؤشر سريع، مع "فحص سيرفر" اختياري لأن
 * navigator.onLine قد يقول "متصل" بينما الشبكة فعلياً مقطوعة (واي فاي بلا إنترنت).
 */

import { useEffect, useState } from 'react';

export function isOnline(): boolean {
  if (typeof navigator === 'undefined') return true;
  return navigator.onLine !== false;
}

/** يعيد دالة إلغاء الاشتراك */
export function subscribeToConnectivity(callback: (online: boolean) => void): () => void {
  if (typeof window === 'undefined') return () => {};

  const handleOnline = () => callback(true);
  const handleOffline = () => callback(false);

  window.addEventListener('online', handleOnline);
  window.addEventListener('offline', handleOffline);

  return () => {
    window.removeEventListener('online', handleOnline);
    window.removeEventListener('offline', handleOffline);
  };
}

/** Hook جاهز للاستخدام داخل المكوّنات */
export function useOnlineStatus(): boolean {
  const [online, setOnline] = useState<boolean>(() => isOnline());

  useEffect(() => {
    setOnline(isOnline());
    return subscribeToConnectivity(setOnline);
  }, []);

  return online;
}

/** نص واضح للمستخدم حسب اللغة */
export function offlineMessage(language: 'ar' | 'en', feature: 'scan' | 'advice' | 'plan' | 'generic') {
  const ar: Record<string, string> = {
    scan: 'التصوير والتحليل بالذكاء الاصطناعي يحتاج اتصالاً بالإنترنت. يمكنك التسجيل السريع أو كتابة وصف الوجبة الآن.',
    advice: 'استشارة الذكاء الاصطناعي تحتاج اتصالاً بالإنترنت.',
    plan: 'توليد خطة الأكل يحتاج اتصالاً بالإنترنت. خطتك المحفوظة تبقى متاحة.',
    generic: 'هذه الميزة تحتاج اتصالاً بالإنترنت.',
  };
  const en: Record<string, string> = {
    scan: 'AI photo analysis needs an internet connection. You can still quick-log or type the meal name.',
    advice: 'AI consultation needs an internet connection.',
    plan: 'Generating a meal plan needs an internet connection. Your saved plan stays available.',
    generic: 'This feature needs an internet connection.',
  };
  return language === 'ar' ? ar[feature] : en[feature];
}
