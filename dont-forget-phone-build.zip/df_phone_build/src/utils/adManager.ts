/**
 * مدير الإعلانات — التحكم في التكرار والتخزين المحلي
 * =================================================
 * كل القرارات هنا، والواجهات لا تعرف شيئاً عن المنطق.
 *
 * يعمل بدون إنترنت وبدون قاعدة بيانات:
 *  - آخر ظهور لإعلان الفتح + عدّاد اليوم في localStorage.
 *  - إزالة الإعلانات (Premium) عبر مفتاح واحد.
 */

import { ADS_CONFIG } from './adsConfig';

const STATE_KEY = 'df_ads_state_v1';

interface AdsState {
  lastAppOpenShownAt: number;
  shownToday: number;
  dayKey: string;
  installAt: number;
  appOpenCount: number;
}

function todayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

function readState(): AdsState {
  const fallback: AdsState = {
    lastAppOpenShownAt: 0,
    shownToday: 0,
    dayKey: todayKey(),
    installAt: Date.now(),
    appOpenCount: 0,
  };

  try {
    const raw = localStorage.getItem(STATE_KEY);
    if (!raw) {
      localStorage.setItem(STATE_KEY, JSON.stringify(fallback));
      return fallback;
    }
    const parsed = JSON.parse(raw) as AdsState;
    if (parsed.dayKey !== todayKey()) {
      parsed.dayKey = todayKey();
      parsed.shownToday = 0;
    }
    if (!parsed.installAt) parsed.installAt = Date.now();
    return { ...fallback, ...parsed };
  } catch {
    return fallback;
  }
}

function writeState(state: AdsState): void {
  try {
    localStorage.setItem(STATE_KEY, JSON.stringify(state));
  } catch {
    /* السعة ممتلئة — تجاهل */
  }
}

/** هل أزال المستخدم الإعلانات (اشتراك/ترقية)؟ */
export function hasRemovedAds(): boolean {
  try {
    return localStorage.getItem(ADS_CONFIG.premiumRemovalKey) === 'true';
  } catch {
    return false;
  }
}

export function setAdsRemoved(removed: boolean): void {
  try {
    if (removed) localStorage.setItem(ADS_CONFIG.premiumRemovalKey, 'true');
    else localStorage.removeItem(ADS_CONFIG.premiumRemovalKey);
  } catch {
    /* ignore */
  }
}

/** تسجيل فتح للتطبيق (يُحسب مرة واحدة لكل تشغيل) */
export function registerAppOpen(): void {
  const state = readState();
  state.appOpenCount += 1;
  writeState(state);
}

/**
 * هل نعرض إعلان الفتح الآن؟
 * يراعي: مفتاح الإيقاف، إزالة الإعلانات، الحد اليومي، الفاصل الزمني، وأول تشغيل.
 */
export function shouldShowAppOpenAd(): { show: boolean; reason: string } {
  if (!ADS_CONFIG.enabled) return { show: false, reason: 'ads_disabled' };
  if (hasRemovedAds()) return { show: false, reason: 'premium_user' };

  const state = readState();

  if (ADS_CONFIG.appOpen.neverOnFirstRun && state.appOpenCount <= 1) {
    return { show: false, reason: 'first_run' };
  }

  if (state.shownToday >= ADS_CONFIG.appOpen.maxPerDay) {
    return { show: false, reason: 'daily_cap_reached' };
  }

  const elapsed = Date.now() - state.lastAppOpenShownAt;
  if (state.lastAppOpenShownAt > 0 && elapsed < ADS_CONFIG.appOpen.minIntervalMs) {
    return { show: false, reason: 'too_soon' };
  }

  return { show: true, reason: 'ok' };
}

/** يُستدعى لحظة عرض الإعلان فعلياً (تسجيل) */
export function markAppOpenAdShown(): void {
  const state = readState();
  state.lastAppOpenShownAt = Date.now();
  state.shownToday += 1;
  writeState(state);
}

/** هل يظهر البانر في هذه الشاشة؟ */
export function shouldShowBanner(tab: string): boolean {
  if (!ADS_CONFIG.enabled) return false;
  if (hasRemovedAds()) return false;
  return (ADS_CONFIG.banner.showOn as string[]).includes(tab);
}

/** معلومات تشخيصية للمطور (تظهر في الإعدادات عند الحاجة) */
export function getAdsDebugInfo() {
  const state = readState();
  return {
    ...state,
    provider: ADS_CONFIG.provider,
    removed: hasRemovedAds(),
    today: todayKey(),
  };
}
