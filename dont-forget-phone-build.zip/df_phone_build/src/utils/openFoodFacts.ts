/**
 * Open Food Facts — Barcode Nutrition Lookup (Free, No API Key)
 * ============================================================
 * للأكل المعلّب والمشروبات: إدخال/مسح الباركود يعطي قيماً غذائية حقيقية
 * من قاعدة بيانات مفتوحة المصدر (أكثر من 3 ملايين منتج) بدون أي تكلفة
 * وبدون أي استهلاك لحصة الذكاء الاصطناعي.
 *
 * Docs: https://openfoodfacts.github.io/openfoodfacts-server/api/
 */

import { Language } from '../types';
import { FoodAnalysisResult } from '../types/health';
import { calculateComponentNutrition } from './nutritionDatabase';

const API_BASE = 'https://world.openfoodfacts.org/api/v2/product';
const FIELDS = [
  'product_name',
  'product_name_ar',
  'brands',
  'nutriments',
  'serving_quantity',
  'serving_size',
  'image_front_small_url',
  'quantity',
].join(',');

export interface BarcodeProduct {
  barcode: string;
  name: string;
  nameAr: string;
  brand: string;
  /** القيم لكل 100 غرام */
  caloriesPer100g: number;
  proteinPer100g: number;
  carbsPer100g: number;
  fatsPer100g: number;
  fiberPer100g: number;
  servingGrams: number;
  imageUrl?: string;
}

interface OffNutriments {
  'energy-kcal_100g'?: number;
  energy_100g?: number; // kJ fallback
  proteins_100g?: number;
  carbohydrates_100g?: number;
  fat_100g?: number;
  fiber_100g?: number;
}

function toNumber(value: unknown): number {
  const n = typeof value === 'string' ? parseFloat(value) : (value as number);
  return Number.isFinite(n) ? n : 0;
}

/**
 * يجلب منتجاً من Open Food Facts بواسطة الباركود.
 * يرجع null إذا لم يوجد المنتج أو تعذّر الاتصال.
 */
export async function fetchProductByBarcode(barcode: string): Promise<BarcodeProduct | null> {
  const clean = String(barcode || '').replace(/\D/g, '');
  if (clean.length < 8 || clean.length > 14) return null;

  try {
    const res = await fetch(`${API_BASE}/${clean}.json?fields=${FIELDS}`, {
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) return null;

    const json: any = await res.json();
    if (!json || json.status !== 1 || !json.product) return null;

    const product = json.product;
    const nutriments: OffNutriments = product.nutriments || {};

    let calories = toNumber(nutriments['energy-kcal_100g']);
    if (!calories) {
      const kj = toNumber(nutriments.energy_100g);
      if (kj) calories = Math.round(kj / 4.184);
    }

    const servingGrams = toNumber(product.serving_quantity) || 100;
    const brand = String(product.brands || '').split(',')[0].trim();
    const name = String(product.product_name || '').trim();
    if (!name && !product.product_name_ar) return null;

    return {
      barcode: clean,
      name: name || String(product.product_name_ar || 'Product'),
      nameAr: String(product.product_name_ar || name || 'منتج'),
      brand,
      caloriesPer100g: Math.round(calories),
      proteinPer100g: toNumber(nutriments.proteins_100g),
      carbsPer100g: toNumber(nutriments.carbohydrates_100g),
      fatsPer100g: toNumber(nutriments.fat_100g),
      fiberPer100g: toNumber(nutriments.fiber_100g),
      servingGrams: servingGrams > 0 ? servingGrams : 100,
      imageUrl: product.image_front_small_url,
    };
  } catch (err) {
    console.warn('[OpenFoodFacts] lookup failed:', err);
    return null;
  }
}

/** يحوّل منتج الباركود إلى نتيجة تحليل جاهزة للحفظ. */
export function barcodeProductToAnalysis(
  product: BarcodeProduct,
  grams: number,
  language: Language
): FoodAnalysisResult {
  const weight = Math.max(1, Math.round(grams || product.servingGrams));
  const computed = calculateComponentNutrition(weight, {
    caloriesPer100g: product.caloriesPer100g,
    proteinPer100g: product.proteinPer100g,
    carbsPer100g: product.carbsPer100g,
    fatsPer100g: product.fatsPer100g,
    fiberPer100g: product.fiberPer100g,
  });

  const displayName = product.brand ? `${product.name} (${product.brand})` : product.name;
  const displayNameAr = product.brand ? `${product.nameAr} (${product.brand})` : product.nameAr;

  return {
    foodName: displayName,
    foodNameAr: displayNameAr,
    calories: computed.calories,
    protein: computed.protein,
    carbs: computed.carbs,
    fats: computed.fats,
    fiber: computed.fiber,
    totalWeightGrams: weight,
    portionSize: `${weight} g (barcode ${product.barcode})`,
    portionSizeAr: `${weight} جم (باركود ${product.barcode})`,
    healthTip: 'Values read directly from the product barcode — no AI estimation needed.',
    healthTipAr: 'القيم مقروءة مباشرة من باركود المنتج — بدون أي تخمين من الذكاء الاصطناعي.',
    confidence: language === 'ar' ? 'مرتفع' : 'High',
    source: 'barcode_openfoodfacts',
    ingredients: [
      {
        id: `barcode_${product.barcode}`,
        name: displayName,
        nameAr: displayNameAr,
        weightGrams: weight,
        caloriesPer100g: product.caloriesPer100g,
        proteinPer100g: product.proteinPer100g,
        carbsPer100g: product.carbsPer100g,
        fatsPer100g: product.fatsPer100g,
        fiberPer100g: product.fiberPer100g,
        calories: computed.calories,
        protein: computed.protein,
        carbs: computed.carbs,
        fats: computed.fats,
        fiber: computed.fiber,
      },
    ],
  };
}
