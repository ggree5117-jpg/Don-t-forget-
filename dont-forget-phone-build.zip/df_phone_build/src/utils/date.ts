/**
 * Date and time parsing utilities for "DON'T FORGET" (لا تنسَ)
 */

export interface ParsedTaskDateTime {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  dateObj: Date;
}

/**
 * Parses task date string (YYYY-MM-DD) and time string (e.g. "09:00 ص", "08:00 م", "09:00 AM", "08:30 PM")
 */
export function parseTaskDateTime(dateStr: string, timeStr: string): Date | null {
  try {
    if (!dateStr) return null;

    const [yearStr, monthStr, dayStr] = dateStr.split('-');
    const year = parseInt(yearStr, 10);
    const month = parseInt(monthStr, 10) - 1; // 0-indexed in JS
    const day = parseInt(dayStr, 10);

    if (isNaN(year) || isNaN(month) || isNaN(day)) return null;

    let hour = 12;
    let minute = 0;

    if (timeStr) {
      const parts = timeStr.trim().split(' ');
      const timePart = parts[0] || '12:00';
      const periodPart = (parts[1] || '').trim();

      const [hStr, mStr] = timePart.split(':');
      let rawHour = parseInt(hStr, 10) || 12;
      minute = parseInt(mStr, 10) || 0;

      const isPM = periodPart.includes('م') || periodPart.toUpperCase().includes('PM');
      const isAM = periodPart.includes('ص') || periodPart.toUpperCase().includes('AM');

      if (isPM && rawHour < 12) {
        hour = rawHour + 12;
      } else if (isAM && rawHour === 12) {
        hour = 0;
      } else {
        hour = rawHour;
      }
    }

    return new Date(year, month, day, hour, minute);
  } catch {
    return null;
  }
}

/**
 * Checks whether a given task is past its scheduled date and time.
 * If the task is completed, it is never overdue.
 */
export function isTaskOverdue(
  taskOrDate: { date: string; time: string; completed: boolean; isOverdue?: boolean } | string,
  timeStr?: string,
  isCompleted?: boolean,
  referenceTime?: Date
): boolean {
  if (typeof taskOrDate === 'object') {
    if (taskOrDate.completed) return false;
    if (taskOrDate.isOverdue === true) return true;
    return isDateTimePast(taskOrDate.date, taskOrDate.time, referenceTime);
  }

  if (isCompleted) return false;
  return isDateTimePast(taskOrDate, timeStr || '', referenceTime);
}

function isDateTimePast(dateStr: string, timeStr: string, referenceTime?: Date): boolean {
  const taskDate = parseTaskDateTime(dateStr, timeStr);
  if (!taskDate) return false;

  const now = referenceTime || new Date();
  return taskDate.getTime() < now.getTime();
}
