import { BuiltInRingtoneId, RingtoneInfo } from '../types';

let sharedAudioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  try {
    if (!sharedAudioCtx || sharedAudioCtx.state === 'closed') {
      const AudioContextClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return null;
      sharedAudioCtx = new AudioContextClass();
    }
    if (sharedAudioCtx.state === 'suspended') {
      sharedAudioCtx.resume().catch(() => {});
    }
    return sharedAudioCtx;
  } catch {
    return null;
  }
}

/**
 * 6 Built-in High Quality Ringtones
 */
export const BUILT_IN_RINGTONES: RingtoneInfo[] = [
  { id: 'classic', nameAr: 'منبه كلاسيكي', nameEn: 'Classic Alarm', descAr: 'رنين المنبه التقليدي المستمر', descEn: 'Traditional continuous ringing' },
  { id: 'phone', nameAr: 'رنين اتصال', nameEn: 'Phone Ring', descAr: 'رنين هاتف مزدوج مميز', descEn: 'Crisp telephone dual-burst' },
  { id: 'chime', nameAr: 'جرس هادئ', nameEn: 'Calm Chime', descAr: 'نغمات تأملية هادئة ومريحة', descEn: 'Calm and peaceful harmonic tones' },
  { id: 'digital', nameAr: 'بيب رقمي', nameEn: 'Digital Beep', descAr: 'نغمات ساعة رقمية سريعة', descEn: 'Fast modern digital pulse' },
  { id: 'crescendo', nameAr: 'نغمة متصاعدة', nameEn: 'Crescendo Tone', descAr: 'تبدأ هادئة وتعلو تدريجياً', descEn: 'Soft start that builds in intensity' },
  { id: 'melody', nameAr: 'لحن قصير', nameEn: 'Short Melody', descAr: 'معزوفة مبهجة من 5 درجات', descEn: 'Pleasant 5-note cheerful tune' },
];

export const DEFAULT_RINGTONE_ID: BuiltInRingtoneId = 'chime';

// 1. Classic Mechanical Alarm
function synthesizeClassicAlarm(ctx: AudioContext, now: number) {
  const bursts = [0, 0.15, 0.3, 0.45, 0.65, 0.8];
  bursts.forEach((offset) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(offset % 0.3 === 0 ? 750 : 880, now + offset);

    gain.gain.setValueAtTime(0, now + offset);
    gain.gain.linearRampToValueAtTime(0.28, now + offset + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.12);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + offset);
    osc.stop(now + offset + 0.13);
  });
}

// 2. Telephone Call Ring
function synthesizePhoneRing(ctx: AudioContext, now: number) {
  const rings = [0, 0.4];
  rings.forEach((ringOffset) => {
    // 440 Hz + 480 Hz US/International standard dial/ring cadence
    [440, 480].forEach((freq) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + ringOffset);

      gain.gain.setValueAtTime(0, now + ringOffset);
      gain.gain.linearRampToValueAtTime(0.2, now + ringOffset + 0.03);
      gain.gain.setValueAtTime(0.2, now + ringOffset + 0.28);
      gain.gain.exponentialRampToValueAtTime(0.001, now + ringOffset + 0.32);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + ringOffset);
      osc.stop(now + ringOffset + 0.33);
    });
  });
}

// 3. Calm Mindfulness Champagne Chime
function synthesizeCalmChime(ctx: AudioContext, now: number) {
  const fundamentalFreq = 587.33; // D5
  const harmonics = [
    { freqMultiplier: 1.0, gain: 0.35, decay: 1.8 },
    { freqMultiplier: 2.02, gain: 0.15, decay: 1.2 },
    { freqMultiplier: 3.01, gain: 0.08, decay: 0.8 },
    { freqMultiplier: 4.15, gain: 0.04, decay: 0.5 },
  ];

  harmonics.forEach(({ freqMultiplier, gain, decay }) => {
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(fundamentalFreq * freqMultiplier, now);

    gainNode.gain.setValueAtTime(0, now);
    gainNode.gain.linearRampToValueAtTime(gain, now + 0.02);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, now + decay);

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + decay + 0.1);
  });
}

// 4. Digital Beep (Electronic watch alarm pattern)
function synthesizeDigitalBeep(ctx: AudioContext, now: number) {
  const beeps = [0, 0.1, 0.25, 0.35];
  beeps.forEach((offset) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(2048, now + offset);

    gain.gain.setValueAtTime(0, now + offset);
    gain.gain.linearRampToValueAtTime(0.15, now + offset + 0.008);
    gain.gain.setValueAtTime(0.15, now + offset + 0.055);
    gain.gain.linearRampToValueAtTime(0, now + offset + 0.065);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + offset);
    osc.stop(now + offset + 0.07);
  });
}

// 5. Crescendo Tone (Starts gentle and gradually rises in volume & pitch)
let crescendoCycleCount = 0;
function synthesizeCrescendoTone(ctx: AudioContext, now: number) {
  // Steps through 4 rising stages (0 to 3)
  const step = crescendoCycleCount % 4;
  crescendoCycleCount++;

  const baseFreqs = [392, 440, 523, 659]; // G4 -> A4 -> C5 -> E5
  const gains = [0.08, 0.16, 0.26, 0.38];

  const freq = baseFreqs[step];
  const maxGain = gains[step];

  [freq, freq * 1.5].forEach((f, idx) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(f, now);

    const adjustedGain = idx === 0 ? maxGain : maxGain * 0.4;
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(adjustedGain, now + 0.06);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.75);
  });
}

// 6. Short Melody (Gentle uplifting 5-note chime sequence)
function synthesizeShortMelody(ctx: AudioContext, now: number) {
  // Pentatonic notes: C5, E5, G5, B5, C6
  const notes = [
    { freq: 523.25, time: 0, decay: 0.6 },
    { freq: 659.25, time: 0.16, decay: 0.6 },
    { freq: 783.99, time: 0.32, decay: 0.6 },
    { freq: 987.77, time: 0.48, decay: 0.8 },
    { freq: 1046.5, time: 0.64, decay: 1.2 },
  ];

  notes.forEach(({ freq, time, decay }) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now + time);

    gain.gain.setValueAtTime(0, now + time);
    gain.gain.linearRampToValueAtTime(0.25, now + time + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + time + decay);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + time);
    osc.stop(now + time + decay + 0.05);
  });
}

/**
 * Quick chime for buttons and toggle interactions
 */
export function playChimeSound() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    synthesizeCalmChime(ctx, ctx.currentTime);
  } catch (err) {
    console.warn('Audio chime notice:', err);
  }
}

// State for active ringtone looping
let activeInterval: ReturnType<typeof setInterval> | null = null;
let activeHtmlAudio: HTMLAudioElement | null = null;
let activeBlobUrl: string | null = null;
let currentlyPlayingRingtoneId: string | null = null;

/**
 * Stops any actively looping ringtone, releases HTML audio, and cancels vibration.
 */
export function stopRingtone() {
  if (activeInterval) {
    clearInterval(activeInterval);
    activeInterval = null;
  }
  crescendoCycleCount = 0;

  if (activeHtmlAudio) {
    try {
      activeHtmlAudio.pause();
      activeHtmlAudio.currentTime = 0;
      activeHtmlAudio.src = '';
    } catch {}
    activeHtmlAudio = null;
  }

  if (activeBlobUrl) {
    try {
      URL.revokeObjectURL(activeBlobUrl);
    } catch {}
    activeBlobUrl = null;
  }

  currentlyPlayingRingtoneId = null;

  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(0);
    } catch {}
  }
}

/**
 * Returns the ID of the ringtone currently playing, or null if idle.
 */
export function getCurrentlyPlayingRingtoneId(): string | null {
  return currentlyPlayingRingtoneId;
}

/**
 * Starts a repeating ringtone (built-in synthesis or custom audio Blob).
 * Loops continuously until stopRingtone() is called.
 * Fallback: if custom audio fails, falls back gracefully to 'chime'.
 */
export async function startRingtone(
  ringtoneId: string = 'chime',
  customBlobOrUrl?: Blob | string | null
): Promise<void> {
  stopRingtone();
  currentlyPlayingRingtoneId = ringtoneId;

  // 1. Custom Audio File Playback
  if (customBlobOrUrl) {
    try {
      const srcUrl =
        typeof customBlobOrUrl === 'string'
          ? customBlobOrUrl
          : URL.createObjectURL(customBlobOrUrl);
      activeBlobUrl = typeof customBlobOrUrl === 'string' ? null : srcUrl;

      const audio = new Audio(srcUrl);
      audio.loop = true;
      audio.preload = 'auto';

      activeHtmlAudio = audio;

      // Trigger vibration
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try {
          navigator.vibrate([400, 200, 400, 200, 600]);
        } catch {}
      }

      await audio.play();
      return;
    } catch (err) {
      console.warn('Failed to play custom audio file, falling back to default chime:', err);
      // Fallback cleanly to built-in chime tone
      return startRingtone('chime');
    }
  }

  // 2. Built-in Web Audio API Synthesis
  const ctx = getAudioContext();
  if (!ctx) return;

  const playSingleCycle = () => {
    if (!sharedAudioCtx || sharedAudioCtx.state === 'closed') return;
    const now = sharedAudioCtx.currentTime;

    switch (ringtoneId) {
      case 'classic':
        synthesizeClassicAlarm(sharedAudioCtx, now);
        break;
      case 'phone':
        synthesizePhoneRing(sharedAudioCtx, now);
        break;
      case 'digital':
        synthesizeDigitalBeep(sharedAudioCtx, now);
        break;
      case 'crescendo':
        synthesizeCrescendoTone(sharedAudioCtx, now);
        break;
      case 'melody':
        synthesizeShortMelody(sharedAudioCtx, now);
        break;
      case 'chime':
      default:
        synthesizeCalmChime(sharedAudioCtx, now);
        break;
    }

    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate([400, 200, 400, 200, 600]);
      } catch {}
    }
  };

  // Determine cycle repeat interval
  const intervalMap: Record<string, number> = {
    classic: 1400,
    phone: 2200,
    digital: 1200,
    crescendo: 1000,
    melody: 1900,
    chime: 2200,
  };
  const intervalMs = intervalMap[ringtoneId] || 2000;

  playSingleCycle();
  activeInterval = setInterval(playSingleCycle, intervalMs);
}

// Backward compatibility aliases
export const startAlarmRingtone = () => startRingtone('chime');
export const stopAlarmRingtone = stopRingtone;
