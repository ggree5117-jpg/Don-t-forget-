# ربط Start.io — دليل التنفيذ الكامل

> تطبيق **DON'T FORGET | لا تنسَ** · App ID: **210222499** · تحديث: 12 نوفمبر 2026

---

## ✅ ما تم اعتماده الآن

| العنصر | الحالة |
|---|---|
| معرّف التطبيق `210222499` | ✅ مضبوط في `adsConfig.ts` و `StartioAdConfig.java` و `AndroidManifest.xml` (تعليمات) |
| مزوّد الإعلانات | ✅ `provider: 'startio'` |
| إعلان الفتح الكامل | ✅ مربوط (interstitial عند فتح التطبيق) |
| البانر السفلي | ✅ مربوط (Start.io Banner) |
| وضع الاختبار | ✅ `testAds: true` (اجعله `false` قبل النشر) |
| إضافة Capacitor أصلية | ✅ مكتوبة كاملة في `native-android/` |

---

## ⚠️ حقيقة يجب أن تعرفها قبل البناء

**Start.io لا توفّر إضافة Capacitor رسمية.** لذلك لا يمكن «تثبيت حزمة npm» كما في AdMob.

الحل الذي نفّذته: كتبت لك **إضافة Capacitor أصلية بـ Java** تربط SDK الخاص بـ Start.io بواجهة JavaScript في تطبيقك. الكود جاهز بالكامل — تحتاج فقط لنسخه في مشروع الأندرويد بعد إنشائه.

**ولا يمكنني بناء APK هنا** — هذه البيئة لا تحتوي Android SDK. ستبنيها على جهازك بخطوات أدناه (5 دقائق).

---

## 🔧 خطوات التنفيذ (بالترتيب)

### 1) إنشاء مشروع أندرويد (مرة واحدة)

```bash
cd app
npm i @capacitor/android
npx cap add android
npx cap sync android
```

### 2) إضافة مكتبة Start.io في Gradle

افتح `android/app/build.gradle` وأضف داخل `dependencies`:

```gradle
dependencies {
    implementation 'com.startapp:inapp-sdk:5.4.0'
    // ... بقية الاعتماديات
}
```

> إن ظهر خطأ `compileSdk` — ارفعها إلى 36 في `android/variables.gradle`:
> ```gradle
> compileSdkVersion = 36
> targetSdkVersion = 36
> ```

### 3) نسخ الإضافة الأصلية

انسخ الملفين من `native-android/` إلى مجلد الحزمة:

```
native-android/StartioAdsPlugin.java  →  android/app/src/main/java/com/dontforget/app/StartioAdsPlugin.java
native-android/StartioAdConfig.java   →  android/app/src/main/java/com/dontforget/app/StartioAdConfig.java
```

> ⚠️ غيّر `package com.dontforget.app;` في أعلى الملفين ليطابق `appId` تطبيقك في `capacitor.config.json`.
> مثال: إن كان `appId: "com.mohammed.dontforget"` فالبديل: `package com.mohammed.dontforget;`

### 4) تسجيل الإضافة في MainActivity

افتح `android/app/src/main/java/.../MainActivity.java`:

```java
package com.dontforget.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(StartioAdsPlugin.class);   // ← السطر المهم
        super.onCreate(savedInstanceState);
    }
}
```

### 5) إضافة المعرّف في AndroidManifest.xml

افتح `android/app/src/main/AndroidManifest.xml` وأضف داخل `<application>`:

```xml
<meta-data
    android:name="com.startapp.sdk.APPLICATION_ID"
    android:value="210222499" />

<meta-data
    android:name="com.startapp.sdk.SPLASH_ADS_ENABLED"
    android:value="false" />
```

> `SPLASH_ADS_ENABLED = false` مهم: نحن نتحكم بأنفسنا في تكرار إعلان الفتح (مرتين يومياً)،
> لو تركتها `true` سيعرض Start.io إعلاناً في **كل** فتح تطبيق بدون أي حد.

وأضف الصلاحيات خارج `<application>`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
```

### 6) البناء والتشغيل

```bash
npm run build
npx cap sync android
npx cap open android     # يفتح Android Studio
# أو مباشرة:
cd android && ./gradlew assembleDebug
```

---

## 📋 ما يحدث داخل التطبيق (تلقائي — لا تحتاج تعديل)

```
فتح التطبيق
   ↓
initStartio()  ← تهيئة SDK بـ 210222499
   ↓
preloadInterstitial()  ← تحميل مسبق لسرعة الظهور
   ↓
adManager يقرر: هل نعرض؟
   ├─ أول تشغيل؟        → لا
   ├─ تجاوز حد اليوم؟   → لا (2/يوم)
   ├─ مرّ أقل من 4 ساعات؟ → لا
   └─ نعم → Start.io interstitial ملء الشاشة
              ↓
        markAppOpenAdShown() ← تسجيل لحساب الحد

التنقل بين الشاشات
   ↓
showBanner() عند الدخول لشاشة مسموحة
hideBanner() عند الخروج منها (مثل شاشة ترحيب)
   ↓
onNativeHeight(px) → التطبيق يحجز المساحة فلا يغطي البانر شريط التنقل
```

---

## 🧪 نتائج الاختبار في المتصفح (5/5)

| # | الاختبار | النتيجة |
|---|---|---|
| 1 | ظهور إعلان الفتح + عرض معرّف `210222499` | ✅ |
| 2 | بانر واحد فقط موسوم Start.io (slot-2 مُلغى) | ✅ |
| 3 | عدم التكرار عند إعادة التحميل (حد 4 ساعات) | ✅ |
| 4 | البانر يظهر على شاشة الصحة | ✅ |
| 5 | زر «إزالة الإعلانات» يخفي كل شيء | ✅ |
| — | أخطاء JavaScript | **صفر** |

> داخل المتصفح يظهر التصميم التجريبي لأن `Capacitor.isNativePlatform()` ترجع `false`.
> داخل APK تتحول كل الدوال تلقائياً إلى SDK الحقيقي.

---

## 💡 تنبيهات مهمة

### 1) البانر الواحد
طلبت في البداية إعلانين سفليين، لكن SDK الخاص بـ Start.io يعرض بانراً واحداً لكل نشاط (Activity).
ضبطتُ `slots: 1` — لو أردت التجربة بالخانتين في المتصفح فقط غيّرها إلى `2`، لكن في التطبيق الحقيقي ستظهر خانة واحدة (الأخرى ستكون فارغة).

> من مصلحتك: تراكم البانرات يقلل تقييم التطبيق ويحدّ من الأرباح على المدى الطويل.

### 2) وضع الاختبار
`testAds: true` حالياً. **قبل النشر**:
- غيّر في `src/utils/adsConfig.ts` → `testAds: false`
- غيّر في `native-android/StartioAdConfig.java` → `TEST_ADS = false`

وإلا ستبقى ترى إعلانات تجريبية لن تُدرّ أي ربح.

### 3) متطلبات Start.io قبل الأرباح
| المتطلب | ملاحظة |
|---|---|
| حساب ناشر مفعّل | app.start.io |
| التطبيق مضاف بالمعرّف 210222499 | تأكد أن الاسم يطابق اسم التطبيق في المتجر |
| **app-ads.txt** | إلزامي — يُرفع على موقعك/نطاقك المذكور في لوحة Start.io |
| التطبيق منشور أو معتمد | الإعلانات الحقيقية تبدأ بعد الموافقة |

**app-ads.txt** — ستحتاج سطراً مشابهاً لهذا في موقعك:
```
start.io, 210222499, DIRECT
```

### 4) سياسة المحتوى
- لا نقرات وهمية (لا تطلب من المستخدمين الضغط) — سبب رئيسي لإيقاف الحساب.
- لا تحفيز على مشاهدة الإعلان («شاهد إعلاناً لتحصل على…») إلا في Rewarded.
- البانر لا يجب أن يغطي أزراراً تفاعلية (حللناها بحجز المساحة).

### 5) الخصوصية (مهم للمتجر)
Start.io يجمع معرّف الإعلان. يجب:
- تحديث سياسة الخصوصية في Google Play بذكر Start.io.
- إضافة إفصاح Data Safety: «Device or other IDs — Advertising».
- بدونها يُرفض التطبيق أو يُحذف لاحقاً.

---

## 📊 توقعات الأرباح

| المؤشر | القيمة التقريبية |
|---|---|
| eCPM (الخليج) | 1.5 – 4 دولار |
| eCPM (اليمن/مصر) | 0.3 – 1.2 دولار |
| ظهور البانر لكل مستخدم/يوم | 8 – 15 |
| إعلان الفتح لكل مستخدم/يوم | 1 – 2 |
| **1000 مستخدم نشط شهرياً** | **~8 – 35 دولاراً** |

---

## ❓ ماذا أحتاج منك بعد البناء؟

جرّب APK قائماً على جهاز حقيقي وأخبرني بالنتيجة:
- ✅ «ظهر الإعلان» → ننتقل لضبط `testAds: false` والنشر.
- ⚠️ «لا يظهر شيء» → أرسل لي `Logcat` مفلتراً على `StartioAds` (كل الأخطاء تُطبع هناك بوسم واضح).
- ⚠️ خطأ بناء → أرسل نص الخطأ وأصلحه فوراً.

**أشهر سببين لعدم الظهور:** (1) `appId` في الحزمة لا يطابق الحزمة في المنيفست، (2) لا يوجد fill للمنطقة — جرّب مع `testAds: true` أولاً.

---

## 🍽️ تحليل صور الطعام بالذكاء الاصطناعي (Gemini)

### الحالة: يعمل ✅ — مُختبَر فعلياً

| المؤشر | القيمة |
|---|---|
| الموديل | `gemini-3.1-flash-lite` (الأسرع والأثبت) |
| متوسط الزمن | **5.3 ثانية** بعد التحسين (كان 29-90 ثانية) |
| الدقة | **10/10** على صور الأطباق العشرة |
| وضع التفكير | `thinkingLevel: LOW` — إلزامي، بدونه يتضاعف الزمن 10× |
| حد المحاولة | 15 ثانية/محاولة، ثم موديل بديل تلقائياً |

### نتائج الاختبار الفعلي

| الصورة | ما تعرّف عليه | السعرات | الثقة | الزمن |
|---|---|---|---|---|
| grilled_chicken | صدر دجاج مشوي مع خضار مشوية | 396 | High | 2.2s |
| foul_beans | فول مدمس | 526 | High | 2.5s |
| salad_bowl | وعاء الكينوا والحمص | 486 | High | 2.8s |
| fish_salmon | سمك سلمون مشوي مع كينوا وسلطة | 620 | High | 4.9s |
| soup_lentil | شوربة عدس | 457 | High | 7.6s |
| rice_chicken | مندي/كبسة دجاج مع الزبيب واللوز | 882 | High | 5.8s |
| beef_steak | ستيك مع بطاطا حلوة وبروكلي | 635 | High | 2.3s |
| eggs_breakfast | شكشوكة | 511 | High | 17.8s |
| dates_nuts | طبق إفطار تمر ومكسرات وجبن | 688 | High | 5.1s |
| fruit_yogurt | وعاء الزبادي بالفواكه | 211 | High | 2.4s |

> **ملاحظة تقنية مهمة:** `gemini-3.5-flash-lite` و `gemini-3.8-flash` يعيدان 503 (ضغط عالٍ) في هذا المشروع دائماً.
> الكود الآن يستخدم `gemini-3.1-flash-lite` كمسار أساسي ولا يُشغّل الآخرين إلا عند الفشل — هذا يوفر الحصة المجانية.

### أين يوضع المفتاح
```
app/.env   ←  GEMINI_API_KEY=...      (على السيرفر فقط، غير مضمّن في التطبيق أو الحزمة)
```
⚠️ المفتاح **لا** يوضع في كود العميل ولا في APK. أي شخص يفكّ APK يقرأ الكود بسهولة.

