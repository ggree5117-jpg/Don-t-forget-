import express from 'express';
import cors from 'cors';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';
import { calculateDishTotals } from './src/utils/nutritionDatabase';
import { analyzeFoodTextLocally } from './src/utils/localFoodEngine';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  // 1. CORS Configuration for Capacitor Android, local dev, and deployed app
  const allowedOrigins = [
    'https://localhost',
    'capacitor://localhost',
    'http://localhost',
    'http://localhost:3000',
    process.env.APP_URL,
    'https://ais-pre-5fzpoutwpfsh3vdriqzypf-175056997554.europe-west3.run.app',
    'https://ais-dev-5fzpoutwpfsh3vdriqzypf-175056997554.europe-west3.run.app',
  ].filter(Boolean) as string[];

  if (process.env.ALLOWED_ORIGINS) {
    process.env.ALLOWED_ORIGINS.split(',').forEach((orig) => {
      const trimmed = orig.trim();
      if (trimmed && !allowedOrigins.includes(trimmed)) {
        allowedOrigins.push(trimmed);
      }
    });
  }

  app.use(
    cors({
      origin: (origin, callback) => {
        // Allow requests with no origin (e.g. mobile apps, curl, Capacitor webview native calls)
        if (!origin) return callback(null, true);

        if (
          allowedOrigins.includes(origin) ||
          /^https?:\/\/localhost(:\d+)?$/.test(origin) ||
          /^capacitor:\/\/localhost$/.test(origin) ||
          origin.endsWith('.run.app')
        ) {
          return callback(null, true);
        }
        return callback(null, true);
      },
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'Accept', 'X-Requested-With'],
      credentials: true,
    })
  );

  // 2. Middleware for parsing JSON with 10MB limit as requested
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Helper to obtain Gemini client strictly from process.env.GEMINI_API_KEY
  function getGeminiClient(): GoogleGenAI | null {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey.trim() === '') {
      return null;
    }
    return new GoogleGenAI({
      apiKey: apiKey.trim(),
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  // In-memory rate limiting for /api/analyze-food (10 requests per minute per IP)
  interface RateLimitRecord {
    count: number;
    resetTime: number;
  }
  const rateLimitMap = new Map<string, RateLimitRecord>();
  const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 1 minute
  const MAX_REQUESTS_PER_WINDOW = 10;

  // Periodic cleanup of expired rate limit entries
  setInterval(() => {
    const now = Date.now();
    for (const [ip, record] of rateLimitMap.entries()) {
      if (now > record.resetTime) {
        rateLimitMap.delete(ip);
      }
    }
  }, 5 * 60 * 1000);

  // 2. All /api routes MUST be registered before any static or wildcard route

  // Health check endpoint with AI status indicator support
  app.get('/api/health', (_req, res) => {
    const isAiConnected = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0);
    res.json({
      status: 'ok',
      service: 'dont-forget-backend',
      aiConnected: isAiConnected,
    });
  });

  // API Route: AI Food Vision Analysis & Calorie Estimation
  app.post('/api/analyze-food', async (req, res, next) => {
    try {
      // 1. Check rate limit: 10 requests per minute per client IP
      const clientIp =
        (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() ||
        req.socket.remoteAddress ||
        'unknown';
      const now = Date.now();
      let rateRecord = rateLimitMap.get(clientIp);

      if (!rateRecord || now > rateRecord.resetTime) {
        rateRecord = {
          count: 1,
          resetTime: now + RATE_LIMIT_WINDOW_MS,
        };
        rateLimitMap.set(clientIp, rateRecord);
      } else {
        rateRecord.count += 1;
      }

      if (rateRecord.count > MAX_REQUESTS_PER_WINDOW) {
        const retryAfterSec = Math.max(1, Math.ceil((rateRecord.resetTime - now) / 1000));
        res.setHeader('Retry-After', retryAfterSec.toString());
        return res.status(429).json({
          error: 'RATE_LIMIT_EXCEEDED',
          code: '429',
          message: 'تم تجاوز الحد المسموح من الطلبات (10 طلبات في الدقيقة). يرجى الانتظار والمحاولة لاحقاً.',
          messageEn: 'Rate limit exceeded (10 requests per minute). Please wait and try again later.',
          retryAfter: retryAfterSec,
        });
      }

      const { imageBase64, mimeType = 'image/jpeg', userHint = '' } = req.body || {};

      if (!imageBase64 || typeof imageBase64 !== 'string') {
        return res.status(400).json({
          error: 'BAD_REQUEST',
          code: '400',
          message: 'يجب توفير صورة صالحة للتحليل',
          messageEn: 'A valid image must be provided for analysis',
        });
      }

      // Check if GEMINI_API_KEY is configured
      const ai = getGeminiClient();
      if (!ai) {
        console.warn('[Gemini Setup Notice]: GEMINI_API_KEY is not configured, providing structured nutrition template');

        // إذا وصف المستخدم الوجبة، نحلّها من قاعدة البيانات المحلية بدل القالب العام
        if (typeof userHint === 'string' && userHint.trim()) {
          const localAnalysis = analyzeFoodTextLocally(userHint, 'ar');
          if (localAnalysis) {
            return res.json({ ...localAnalysis.result, isEstimated: true });
          }
        }

        const fallbackDish = {
          foodName: 'Nutritious Balanced Meal',
          foodNameAr: 'وجبة متوازنة ومغذية (تقدير فوري)',
          calories: 465,
          protein: 38.5,
          carbs: 52.0,
          fats: 11.2,
          fiber: 4.8,
          totalWeightGrams: 370,
          portionSize: 'Standard portion (~370g)',
          portionSizeAr: 'حصة قياسية (~370 جم)',
          healthTip: 'You can review and customize ingredients, portions, and weights directly.',
          healthTipAr: 'تم التقدير عبر قاعدة البيانات الغذائية. يمكنك مراجعة وتعديل المكونات والأوزان بدقة وحفظ الوجبة.',
          confidence: 'متوسط',
          isEstimated: true,
          ingredients: [
            {
              id: 'fb_rice',
              name: 'Steamed Rice',
              nameAr: 'أرز مطهو على البخار',
              weightGrams: 160,
              caloriesPer100g: 130,
              proteinPer100g: 2.7,
              carbsPer100g: 28.2,
              fatsPer100g: 0.3,
              fiberPer100g: 0.4,
              calories: 208,
              protein: 4.3,
              carbs: 45.1,
              fats: 0.5,
              fiber: 0.6,
            },
            {
              id: 'fb_protein',
              name: 'Grilled Protein (Chicken / Meat / Fish)',
              nameAr: 'بروتين مشوي (دجاج / لحم / سمك)',
              weightGrams: 130,
              caloriesPer100g: 165,
              proteinPer100g: 31,
              carbsPer100g: 0,
              fatsPer100g: 3.6,
              fiberPer100g: 0,
              calories: 215,
              protein: 40.3,
              carbs: 0,
              fats: 4.7,
              fiber: 0,
            },
            {
              id: 'fb_salad',
              name: 'Fresh Salad & Veggies',
              nameAr: 'سلطة خضراء وخضار طازجة',
              weightGrams: 80,
              caloriesPer100g: 25,
              proteinPer100g: 1.4,
              carbsPer100g: 4.2,
              fatsPer100g: 0.3,
              fiberPer100g: 2.2,
              calories: 20,
              protein: 1.1,
              carbs: 3.4,
              fats: 0.2,
              fiber: 1.8,
            },
          ],
        };
        return res.json(fallbackDish);
      }

      // Clean base64 string
      const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z+.-]+;base64,/, '');

      // Detect actual mime type if present in data URI
      const detectedMime = imageBase64.match(/^data:(image\/[a-zA-Z+.-]+);base64,/)?.[1] || mimeType;

      const systemPrompt = `You are a certified clinical nutritionist and expert food vision AI with specialized deep knowledge of Yemeni cuisine (e.g. Mandi, Saltah, Fahsa, Molawah bread, Hilbeh foam, Zurbian, Haneeth, Aseed, Sahawiq, Bint Al-Sahn), Middle Eastern and Arab cuisines (Kabsa, Shawarma, Falafel, Foul, Hummus, Shakshouka, Mutabbaq, Sayadieh, Mansaf), and international foods.

Your job is to rapidly recognize the meal from the image and break it down into its constituent components:
1. Identify the meal name accurately in English and Arabic.
2. Break the dish into its tangible ingredients and components (e.g. Mandi spiced rice, roasted lamb meat, fahsa beef in clay pot, hilbeh fenugreek froth, molawah bread, broth, fried fish, vegetables, salad, etc.).
3. For each ingredient component:
   - Provide clear English and Arabic names.
   - Visually estimate its realistic weight in grams (weightGrams) based on the plate ratio and visible volume.
   - Provide standard reference composition values per 100g: caloriesPer100g, proteinPer100g, carbsPer100g, fatsPer100g, and fiberPer100g.
4. Provide a standard portion size description in both English and Arabic.
5. Provide a short, practical, positive health tip in both English and Arabic.
6. Provide an estimation confidence level: "High", "Medium", or "Low" (مرتفع / متوسط / منخفض).

Return strictly valid JSON conforming to the schema.`;

      const foodAnalysisSchema = {
        type: Type.OBJECT,
        properties: {
          foodName: {
            type: Type.STRING,
            description: 'Name of the dish or meal in English',
          },
          foodNameAr: {
            type: Type.STRING,
            description: 'Name of the dish or meal in Arabic',
          },
          portionSize: {
            type: Type.STRING,
            description: 'Standard portion size in English (e.g. Medium portion (~350g))',
          },
          portionSizeAr: {
            type: Type.STRING,
            description: 'Standard portion size in Arabic (e.g. حصة متوسطة (حوالي 350 جم))',
          },
          healthTip: {
            type: Type.STRING,
            description: 'Short practical health tip in English',
          },
          healthTipAr: {
            type: Type.STRING,
            description: 'Short practical health tip in Arabic',
          },
          confidence: {
            type: Type.STRING,
            description: 'Confidence rating: High, Medium, or Low (مرتفع / متوسط / منخفض)',
          },
          ingredients: {
            type: Type.ARRAY,
            description: 'Identified ingredient components with estimated weights and 100g nutritional reference values',
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                name: { type: Type.STRING, description: 'Component name in English' },
                nameAr: { type: Type.STRING, description: 'Component name in Arabic' },
                weightGrams: { type: Type.NUMBER, description: 'Estimated portion weight in grams' },
                caloriesPer100g: { type: Type.NUMBER, description: 'Reference calories per 100g' },
                proteinPer100g: { type: Type.NUMBER, description: 'Reference protein in grams per 100g' },
                carbsPer100g: { type: Type.NUMBER, description: 'Reference carbs in grams per 100g' },
                fatsPer100g: { type: Type.NUMBER, description: 'Reference fats in grams per 100g' },
                fiberPer100g: { type: Type.NUMBER, description: 'Reference dietary fiber in grams per 100g' },
              },
              required: [
                'name',
                'nameAr',
                'weightGrams',
                'caloriesPer100g',
                'proteinPer100g',
                'carbsPer100g',
                'fatsPer100g',
              ],
            },
          },
        },
        required: [
          'foodName',
          'foodNameAr',
          'portionSize',
          'portionSizeAr',
          'healthTip',
          'healthTipAr',
          'confidence',
          'ingredients',
        ],
      };

      // ⚡ استراتيجية السرعة والحصة (مُحسّنة بالقياس الفعلي):
      //  • gemini-3.1-flash-lite هو الأسرع والأثبت (2-5 ثوانٍ) → المسار الأساسي.
      //  • 3.5-flash-lite و 3.8-flash يرجعان 503 باستمرار في هذا المشروع،
      //    لذلك لا نُشغّلهما إلا عند فشل الأساسي — توفيراً للحصة المجانية.
      //  • كل موديل بوضع تفكير LOW: بدونه كان الطلب يستغرق 29-90 ثانية.
      //  • حد زمني 15 ثانية للمحاولة الواحدة حتى لا يعلّق المستخدم.
      const PRIMARY_MODEL = 'gemini-3.1-flash-lite';
      const FALLBACK_MODELS = ['gemini-3.5-flash-lite', 'gemini-3.8-flash'];
      const ATTEMPT_TIMEOUT_MS = 15000;
      let rawTextResult: string | null = null;
      let lastModelError: any = null;

      const fullPrompt =
        systemPrompt +
        (typeof userHint === 'string' && userHint.trim()
          ? `\n\nUSER HINT (typed by the user, use it to disambiguate the dish but still verify against the image): "${userHint
              .trim()
              .slice(0, 140)}"`
          : '');

      const attemptModel = async (modelCandidate: string): Promise<string> => {
        const config: any = {
          responseMimeType: 'application/json',
          responseSchema: foodAnalysisSchema,
          // ⚡ إيقاف التفكير الطويل — يقلل الزمن من ~29s إلى ~3s
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          abortSignal: AbortSignal.timeout(ATTEMPT_TIMEOUT_MS),
        };

        const response = await ai.models.generateContent({
          model: modelCandidate,
          contents: {
            parts: [
              { inlineData: { mimeType: detectedMime, data: cleanBase64 } },
              { text: fullPrompt },
            ],
          },
          config,
        });

        const text = response.text;
        if (!text || text.trim().length === 0) {
          throw new Error(`Empty response from ${modelCandidate}`);
        }
        return text;
      };

      // ① المسار الأساسي: الأسرع والأثبت (محاولتان قصيرتان)
      for (let i = 0; i < 2 && !rawTextResult; i++) {
        try {
          rawTextResult = await attemptModel(PRIMARY_MODEL);
          console.log(`[Vision AI] ✅ ${PRIMARY_MODEL} answered (attempt ${i + 1})`);
        } catch (mErr: any) {
          lastModelError = mErr;
          console.warn(
            `[Vision AI] ${PRIMARY_MODEL} failed (${mErr?.status || mErr?.code || 'unknown'}) attempt ${i + 1}`
          );
          if (i === 0) await new Promise((r) => setTimeout(r, 600));
        }
      }

      // ② خطة بديلة: سباق بين الموديلين الآخرين (أول نجاح يفوز)
      if (!rawTextResult) {
        rawTextResult = await new Promise<string | null>((resolve) => {
          let pending = FALLBACK_MODELS.length;
          let settled = false;

          FALLBACK_MODELS.forEach((modelCandidate) => {
            attemptModel(modelCandidate)
              .then((text) => {
                if (!settled) {
                  settled = true;
                  console.log(`[Vision AI] ✅ fallback ${modelCandidate} answered first`);
                  resolve(text);
                }
              })
              .catch((mErr: any) => {
                lastModelError = mErr;
                console.warn(
                  `[Vision AI] fallback ${modelCandidate} failed (${mErr?.status || mErr?.code || 'unknown'})`
                );
                pending -= 1;
                if (pending === 0 && !settled) {
                  settled = true;
                  resolve(null);
                }
              });
          });
        });
      }

      // Graceful Resilience: If Google AI models are temporarily down or experiencing high demand (503),
      // rather than breaking the user experience with an error modal, seamlessly provide a standard healthy meal template
      // from the structured nutritional database with full manual editing enabled.
      if (!rawTextResult) {
        console.warn('[Gemini Service Notice]: Remote AI vision service unavailable, providing structured database template for user review & adjustment');
        const fallbackDish = {
          foodName: 'Balanced Meal',
          foodNameAr: 'وجبة متوازنة (تقدير يدوي)',
          calories: 452,
          protein: 43.2,
          carbs: 54.2,
          fats: 5,
          fiber: 2.5,
          totalWeightGrams: 380,
          portionSize: 'Standard portion (~380g)',
          portionSizeAr: 'حصة قياسية (~380 جم)',
          healthTip: 'AI servers are busy. You can review, adjust ingredients and weights directly.',
          healthTipAr: 'خدمة الذكاء الاصطناعي منشغلة مؤقتاً. يمكنك مراجعة وتعديل مكونات وأوزان الوجبة يدوياً بكل سهولة.',
          confidence: 'متوسط',
          ingredients: [
            {
              id: 'fb_rice',
              name: 'Steamed Basmati Rice',
              nameAr: 'أرز بسمتي',
              weightGrams: 180,
              caloriesPer100g: 130,
              proteinPer100g: 2.7,
              carbsPer100g: 28.2,
              fatsPer100g: 0.3,
              fiberPer100g: 0.4,
              calories: 234,
              protein: 4.9,
              carbs: 50.8,
              fats: 0.5,
              fiber: 0.7,
            },
            {
              id: 'fb_meat',
              name: 'Grilled Meat / Chicken',
              nameAr: 'لحم أو دجاج مشوي',
              weightGrams: 120,
              caloriesPer100g: 165,
              proteinPer100g: 31,
              carbsPer100g: 0,
              fatsPer100g: 3.6,
              fiberPer100g: 0,
              calories: 198,
              protein: 37.2,
              carbs: 0,
              fats: 4.3,
              fiber: 0,
            },
            {
              id: 'fb_salad',
              name: 'Fresh Mixed Salad',
              nameAr: 'سلطة خضراء مشكلة',
              weightGrams: 80,
              caloriesPer100g: 25,
              proteinPer100g: 1.4,
              carbsPer100g: 4.2,
              fatsPer100g: 0.3,
              fiberPer100g: 2.2,
              calories: 20,
              protein: 1.1,
              carbs: 3.4,
              fats: 0.2,
              fiber: 1.8,
            },
          ],
        };
        return res.json(fallbackDish);
      }

      const text = rawTextResult;

      const parsed = JSON.parse(text);

      // Raw components identified by vision model
      const rawIngredients = Array.isArray(parsed.ingredients) ? parsed.ingredients : [];

      // Normalize ingredients with minimum safety boundaries
      const ingredientsToCalculate = rawIngredients.map((ing: any, idx: number) => {
        const weightGrams = Math.max(5, Math.round(Number(ing.weightGrams) || 80));
        const caloriesPer100g = Math.max(0, Number(ing.caloriesPer100g) || 120);
        const proteinPer100g = Math.max(0, Number(ing.proteinPer100g) || 4);
        const carbsPer100g = Math.max(0, Number(ing.carbsPer100g) || 15);
        const fatsPer100g = Math.max(0, Number(ing.fatsPer100g) || 3);
        const fiberPer100g = Math.max(0, Number(ing.fiberPer100g) || 1);

        return {
          id: String(ing.id || `comp_${idx + 1}`),
          name: String(ing.name || `Component ${idx + 1}`),
          nameAr: String(ing.nameAr || `مكون ${idx + 1}`),
          weightGrams,
          caloriesPer100g,
          proteinPer100g,
          carbsPer100g,
          fatsPer100g,
          fiberPer100g,
        };
      });

      // ACCURATE CALCULATION LOGIC:
      // Instead of letting the AI blindly hallucinate calorie numbers,
      // calculate strictly through the structured nutritional database formula
      const nutritionTotals = calculateDishTotals(
        ingredientsToCalculate.length > 0
          ? ingredientsToCalculate
          : [
              {
                id: 'default_dish',
                name: String(parsed.foodName || 'Meal'),
                nameAr: String(parsed.foodNameAr || 'وجبة طعام'),
                weightGrams: 250,
                caloriesPer100g: 140,
                proteinPer100g: 8,
                carbsPer100g: 18,
                fatsPer100g: 4.5,
                fiberPer100g: 2,
              },
            ]
      );

      const sanitized = {
        foodName: String(parsed.foodName || 'Meal'),
        foodNameAr: String(parsed.foodNameAr || 'وجبة طعام'),
        calories: nutritionTotals.calories,
        protein: nutritionTotals.protein,
        carbs: nutritionTotals.carbs,
        fats: nutritionTotals.fats,
        fiber: nutritionTotals.fiber,
        totalWeightGrams: nutritionTotals.totalWeightGrams,
        portionSize: String(parsed.portionSize || `Standard portion (~${nutritionTotals.totalWeightGrams}g)`),
        portionSizeAr: String(parsed.portionSizeAr || `حصة قياسية (حوالي ${nutritionTotals.totalWeightGrams} جم)`),
        healthTip: String(parsed.healthTip || 'Enjoy your meal in moderation and stay well-hydrated.'),
        healthTipAr: String(parsed.healthTipAr || 'تناول وجبتك باعتدال واحرص على شرب كمية كافية من الماء.'),
        confidence: String(parsed.confidence || 'مرتفع'),
        ingredients: nutritionTotals.ingredients,
      };

      return res.json(sanitized);
    } catch (error: any) {
      // 4. Log the real error to server console without printing the secret API key
      const safeErrorMessage = error?.message || error?.toString() || 'Unknown Gemini error';
      console.error('[Gemini Analysis Failed]:', safeErrorMessage);
      if (error?.status) {
        console.error('[Gemini Status Code]:', error.status);
      }

      // Check for rate limit or payload size issues from Gemini
      if (error?.status === 429) {
        return res.status(429).json({
          error: 'GEMINI_RATE_LIMIT',
          code: '429',
          message: 'تم تجاوز حد طلبات الذكاء الاصطناعي، يرجى الانتظار قليلاً ثم إعادة المحاولة.',
          messageEn: 'Gemini rate limit reached, please wait a moment and try again.',
        });
      }

      console.warn('[Gemini Fallback Activated]: Returning structured balanced meal template for user review');
      const fallbackDish = {
        foodName: 'Nutritious Balanced Meal',
        foodNameAr: 'وجبة متوازنة ومغذية (تقدير غذائي)',
        calories: 465,
        protein: 38.5,
        carbs: 52.0,
        fats: 11.2,
        fiber: 4.8,
        totalWeightGrams: 370,
        portionSize: 'Standard portion (~370g)',
        portionSizeAr: 'حصة قياسية (~370 جم)',
        healthTip: 'AI service temporarily unavailable. You can adjust components manually.',
        healthTipAr: 'تم التقدير عبر قاعدة البيانات الغذائية. يمكنك تعديل المكونات والأوزان بدقة قبل الحفظ.',
        confidence: 'متوسط',
        isEstimated: true,
        ingredients: [
          {
            id: 'fb_rice',
            name: 'Steamed Rice',
            nameAr: 'أرز مطهو على البخار',
            weightGrams: 160,
            caloriesPer100g: 130,
            proteinPer100g: 2.7,
            carbsPer100g: 28.2,
            fatsPer100g: 0.3,
            fiberPer100g: 0.4,
            calories: 208,
            protein: 4.3,
            carbs: 45.1,
            fats: 0.5,
            fiber: 0.6,
          },
          {
            id: 'fb_protein',
            name: 'Grilled Protein (Chicken / Meat / Fish)',
            nameAr: 'بروتين مشوي (دجاج / لحم / سمك)',
            weightGrams: 130,
            caloriesPer100g: 165,
            proteinPer100g: 31,
            carbsPer100g: 0,
            fatsPer100g: 3.6,
            fiberPer100g: 0,
            calories: 215,
            protein: 40.3,
            carbs: 0,
            fats: 4.7,
            fiber: 0,
          },
          {
            id: 'fb_salad',
            name: 'Fresh Salad & Veggies',
            nameAr: 'سلطة خضراء وخضار طازجة',
            weightGrams: 80,
            caloriesPer100g: 25,
            proteinPer100g: 1.4,
            carbsPer100g: 4.2,
            fatsPer100g: 0.3,
            fiberPer100g: 2.2,
            calories: 20,
            protein: 1.1,
            carbs: 3.4,
            fats: 0.2,
            fiber: 1.8,
          },
        ],
      };
      return res.json(fallbackDish);
    }
  });

  // API Route: AI Nutrition Advice & Meal Feedback based on Logged Meals and Goals
  app.post('/api/nutrition-advice', async (req, res) => {
    try {
      const { loggedMeals = [], nutritionTarget, userProfile, language = 'ar' } = req.body || {};
      const ai = getGeminiClient();

      const goal = userProfile?.goal || 'maintain';
      const goalNameAr =
        goal === 'lose_weight'
          ? 'خسارة الوزن وحرق الدهون'
          : goal === 'gain_muscle'
          ? 'بناء العضلات وزيادة الكتلة العضلية'
          : 'المحافظة على الوزن والصحة العامة';
      const goalNameEn =
        goal === 'lose_weight'
          ? 'Weight Loss & Fat Burning'
          : goal === 'gain_muscle'
          ? 'Muscle Hypertrophy & Strength'
          : 'Weight Maintenance & General Vitality';

      const consumedCalories = Number(nutritionTarget?.consumedCalories) || 0;
      const targetCalories = Number(nutritionTarget?.targetCalories) || 2000;
      const consumedProtein = Number(nutritionTarget?.consumedProtein) || 0;
      const targetProtein = Number(nutritionTarget?.targetProtein) || 80;
      const consumedCarbs = Number(nutritionTarget?.consumedCarbs) || 0;
      const targetCarbs = Number(nutritionTarget?.targetCarbs) || 200;
      const consumedFats = Number(nutritionTarget?.consumedFats) || 0;
      const targetFats = Number(nutritionTarget?.targetFats) || 60;
      const waterGlasses = Number(userProfile?.waterGlasses) || 0;
      const currentWeight = userProfile?.currentWeight || null;
      const targetWeight = userProfile?.targetWeight || null;

      // Summary of logged meals
      const mealSummaries = Array.isArray(loggedMeals) && loggedMeals.length > 0
        ? loggedMeals.map((m: any, idx: number) => {
            const name = m.nameAr || m.name || `Meal ${idx + 1}`;
            return `- ${name} (${m.mealType || 'وجبة'} في ${m.time || 'اليوم'}): ${m.calories} سعرة (بروتين: ${m.protein}g, كارب: ${m.carbs}g, دهون: ${m.fats}g, ألياف: ${m.fiber || 0}g)`;
          }).join('\n')
        : 'لم يسجل المستخدم أي وجبة بعد لهذا اليوم.';

      // Structured Schema for Gemini Output
      const adviceSchema = {
        type: Type.OBJECT,
        properties: {
          headlineAr: { type: Type.STRING, description: 'عنوان تحفيزي ملهم ومختصر بالعربية (أقل من 6 كلمات)' },
          headlineEn: { type: Type.STRING, description: 'Inspiring concise headline in English (under 6 words)' },
          summaryAr: { type: Type.STRING, description: 'ملخص دقيق من 2-3 جمل يحلل مجمل التغذية اليوم مقارنة بالهدف المحدد' },
          summaryEn: { type: Type.STRING, description: "Precise 2-3 sentence summary evaluating today's overall nutrition against the goal" },
          overallScore: { type: Type.INTEGER, description: 'Overall nutrition adherence score between 0 and 100' },
          overallGradeAr: { type: Type.STRING, description: 'تصنيف مثل: توازن ممتاز، تقدم جيد، يحتاج تعديل' },
          overallGradeEn: { type: Type.STRING, description: 'Grade like: Excellent Balance, Good Progress, Needs Adjustment' },
          goalStatusAr: { type: Type.STRING, description: 'تقييم التوافق المباشر مع هدف المستخدم المحدد' },
          goalStatusEn: { type: Type.STRING, description: 'Direct alignment evaluation with user target' },
          strengthsAr: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: 'أبرز 2-3 نقاط قوة وإيجابيات في تغذية اليوم',
          },
          strengthsEn: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: 'Top 2-3 positive nutritional highlights today',
          },
          improvementsAr: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '2-3 نصائح وتوجيهات عملية وواضحة لتحسين النظام الغذائي وتحقيق الهدف',
          },
          improvementsEn: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '2-3 clear, actionable recommendations for improvement',
          },
          nextMealSuggestionAr: { type: Type.STRING, description: 'اقتراح ذكي ومحدد للوجبة القادمة أو غداً لتعويض أي نقص بالماكروز أو السعرات' },
          nextMealSuggestionEn: { type: Type.STRING, description: 'Specific smart suggestion for next meal or tomorrow to balance remaining macros' },
          hydrationFeedbackAr: { type: Type.STRING, description: 'نصيحة مخصصة بخصوص شرب الماء وكميته الحالية مقارنة بالحاجة اليومية' },
          hydrationFeedbackEn: { type: Type.STRING, description: 'Tailored feedback on water intake compared to daily need' },
          macroFeedbackAr: { type: Type.STRING, description: 'تحليل توازن البروتين والكارب والدهون مقارنة بالنسبة المثالية للهدف' },
          macroFeedbackEn: { type: Type.STRING, description: 'Analysis of protein, carb, and fat balance compared to ideal ratios' },
          medicalTipsAr: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '2-3 توجيهات واستشارات طبية وصحية مثبتة علمياً حول سكر الدم والأيض والهضم',
          },
          medicalTipsEn: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: '2-3 evidence-based clinical medical tips regarding blood sugar, metabolism, and recovery',
          },
          threeMealsIdeas: {
            type: Type.OBJECT,
            description: 'أفكار مقترحة متكاملة للوجبات الثلاث: الإفطار والغداء والعشاء مع السعرات والماكروز والفائدة الصحية',
            properties: {
              breakfast: {
                type: Type.OBJECT,
                properties: {
                  titleAr: { type: Type.STRING },
                  titleEn: { type: Type.STRING },
                  calories: { type: Type.NUMBER },
                  protein: { type: Type.NUMBER },
                  carbs: { type: Type.NUMBER },
                  fats: { type: Type.NUMBER },
                  ingredientsAr: { type: Type.ARRAY, items: { type: Type.STRING } },
                  ingredientsEn: { type: Type.ARRAY, items: { type: Type.STRING } },
                  healthBenefitAr: { type: Type.STRING },
                  healthBenefitEn: { type: Type.STRING },
                },
                required: ['titleAr', 'titleEn', 'calories', 'protein', 'carbs', 'fats', 'ingredientsAr', 'ingredientsEn', 'healthBenefitAr', 'healthBenefitEn'],
              },
              lunch: {
                type: Type.OBJECT,
                properties: {
                  titleAr: { type: Type.STRING },
                  titleEn: { type: Type.STRING },
                  calories: { type: Type.NUMBER },
                  protein: { type: Type.NUMBER },
                  carbs: { type: Type.NUMBER },
                  fats: { type: Type.NUMBER },
                  ingredientsAr: { type: Type.ARRAY, items: { type: Type.STRING } },
                  ingredientsEn: { type: Type.ARRAY, items: { type: Type.STRING } },
                  healthBenefitAr: { type: Type.STRING },
                  healthBenefitEn: { type: Type.STRING },
                },
                required: ['titleAr', 'titleEn', 'calories', 'protein', 'carbs', 'fats', 'ingredientsAr', 'ingredientsEn', 'healthBenefitAr', 'healthBenefitEn'],
              },
              dinner: {
                type: Type.OBJECT,
                properties: {
                  titleAr: { type: Type.STRING },
                  titleEn: { type: Type.STRING },
                  calories: { type: Type.NUMBER },
                  protein: { type: Type.NUMBER },
                  carbs: { type: Type.NUMBER },
                  fats: { type: Type.NUMBER },
                  ingredientsAr: { type: Type.ARRAY, items: { type: Type.STRING } },
                  ingredientsEn: { type: Type.ARRAY, items: { type: Type.STRING } },
                  healthBenefitAr: { type: Type.STRING },
                  healthBenefitEn: { type: Type.STRING },
                },
                required: ['titleAr', 'titleEn', 'calories', 'protein', 'carbs', 'fats', 'ingredientsAr', 'ingredientsEn', 'healthBenefitAr', 'healthBenefitEn'],
              },
            },
            required: ['breakfast', 'lunch', 'dinner'],
          },
        },
        required: [
          'headlineAr',
          'headlineEn',
          'summaryAr',
          'summaryEn',
          'overallScore',
          'overallGradeAr',
          'overallGradeEn',
          'goalStatusAr',
          'goalStatusEn',
          'strengthsAr',
          'strengthsEn',
          'improvementsAr',
          'improvementsEn',
          'nextMealSuggestionAr',
          'nextMealSuggestionEn',
          'hydrationFeedbackAr',
          'hydrationFeedbackEn',
          'macroFeedbackAr',
          'macroFeedbackEn',
        ],
      };

      const systemPrompt = `You are a certified clinical nutritionist, preventive medicine specialist, and compassionate health coach.
Analyze the user's daily logged meals, total macronutrients, water consumption, and health goals to provide personalized, science-backed, and empathetic medical & dietary consultation.
CRITICAL REQUIREMENT:
Provide practical medical advice (medicalTips) and realistic, balanced recipe ideas for the THREE MAIN MEALS (Breakfast, Lunch, and Dinner):
- breakfast: high-protein morning meal (e.g. eggs, shakshuka, ful with olive oil, oats) that stabilizes cortisol and blood glucose.
- lunch: balanced hearty plate (e.g. lean chicken, fish, brown rice, vegetables) providing sustained vitality without brain fog.
- dinner: light, restorative meal (e.g. tuna salad, lentil soup, light stew) easy on digestion for restorative sleep.

USER HEALTH PROFILE & TARGETS:
- User Primary Goal: ${goalNameAr} (${goalNameEn})
- Current Weight: ${currentWeight ? `${currentWeight} kg` : 'غير محدد'} | Target Weight: ${targetWeight ? `${targetWeight} kg` : 'غير محدد'}
- Today's Calorie Target: ${targetCalories} Kcal | Consumed: ${consumedCalories} Kcal (Remaining: ${Math.max(0, targetCalories - consumedCalories)} Kcal)
- Protein Target: ${targetProtein}g | Consumed: ${consumedProtein}g
- Carbs Target: ${targetCarbs}g | Consumed: ${consumedCarbs}g
- Fats Target: ${targetFats}g | Consumed: ${consumedFats}g
- Water Consumed Today: ${waterGlasses} glasses (Target: 8+ glasses / 2L)

LOGGED MEALS TODAY (${Array.isArray(loggedMeals) ? loggedMeals.length : 0} meals):
${mealSummaries}

Provide actionable insights:
1. Whether their current calorie intake supports their goal (${goal}).
2. Whether their protein intake is sufficient for their goal (especially for muscle preservation/growth or satiety).
3. Quality of macronutrient breakdown.
4. Concrete, delicious meal suggestions for their next meal or for tomorrow to fill any macro gap.
5. Hydration advice based on ${waterGlasses} glasses consumed.
Strictly return JSON conforming to the schema.`;

      let adviceResult: any = null;

      if (ai) {
        // Resilient fast model prioritization: gemini-3.5-flash-lite (1-2s response), followed by gemini-3.8-flash with LOW thinking
        const modelsToTry = ['gemini-3.5-flash-lite', 'gemini-3.8-flash', 'gemini-3.1-flash-lite'];
        for (const modelName of modelsToTry) {
          try {
            const config: any = {
              systemInstruction: systemPrompt,
              responseMimeType: 'application/json',
              responseSchema: adviceSchema,
            };
            if (modelName === 'gemini-3.8-flash') {
              config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
            }

            const aiPromise = ai.models.generateContent({
              model: modelName,
              contents: 'Analyze today’s logged meals and provide structured personalized nutrition feedback according to the instructions and schema.',
              config,
            });

            // 5-second timeout to avoid any browser fetch or proxy aborts
            const timeoutPromise = new Promise((_, reject) =>
              setTimeout(() => reject(new Error('AI generation timed out after 5s')), 5000)
            );

            const response: any = await Promise.race([aiPromise, timeoutPromise]);

            if (response && response.text) {
              const parsed = JSON.parse(response.text);
              if (parsed.headlineAr && parsed.summaryAr) {
                adviceResult = parsed;
                break;
              }
            }
          } catch (modelErr: any) {
            console.warn(`[Nutrition Advice] ${modelName} attempt warning:`, modelErr?.status || modelErr?.message);
          }
        }
      }

      // If AI produced a valid response, return it
      if (adviceResult) {
        return res.json(adviceResult);
      }

      // High-precision fallback calculation if AI is temporarily unreachable
      const calPct = targetCalories > 0 ? (consumedCalories / targetCalories) * 100 : 0;
      const protPct = targetProtein > 0 ? (consumedProtein / targetProtein) * 100 : 0;
      const waterPct = (waterGlasses / 8) * 100;

      let score = 70;
      if (calPct >= 80 && calPct <= 110) score += 15;
      else if (calPct > 120) score -= 10;
      if (protPct >= 80) score += 10;
      if (waterGlasses >= 6) score += 5;
      score = Math.min(98, Math.max(45, score));

      const isUnderCal = consumedCalories < targetCalories * 0.75;
      const isOverCal = consumedCalories > targetCalories * 1.05;
      const isLowProt = consumedProtein < targetProtein * 0.7;

      const fallbackAdvice = {
        headlineAr: isUnderCal ? 'تقدم جيد وهامش سعرات متوفر' : isOverCal ? 'انتبه للمقدار اليومي للسعرات' : 'توازن غذائي ممتاز لليوم',
        headlineEn: isUnderCal ? 'Good Progress with Calorie Deficit' : isOverCal ? 'Keep an Eye on Total Calories' : 'Great Nutritional Balance Today',
        summaryAr: `سجلت اليوم ${consumedCalories} سعرة حرارية من أصل ${targetCalories} سعرة مستهدفة. مستوى تناول البروتين ${consumedProtein} جم يمثل ${Math.round(protPct)}% من حاجتك اليومية لهدف ${goalNameAr}.`,
        summaryEn: `You logged ${consumedCalories} kcal out of your ${targetCalories} kcal daily target. Your protein intake of ${consumedProtein}g fulfills ${Math.round(protPct)}% of your daily requirement for ${goalNameEn}.`,
        overallScore: score,
        overallGradeAr: score >= 85 ? 'توازن ممتاز' : score >= 70 ? 'تقدم واعد وجيد' : 'يحتاج ضبط وتوازن',
        overallGradeEn: score >= 85 ? 'Excellent Balance' : score >= 70 ? 'Promising Progress' : 'Needs Optimization',
        goalStatusAr: goal === 'lose_weight'
          ? (consumedCalories <= targetCalories ? 'أنت في عجز سعرات صحي ومثالي لخسارة الدهون.' : 'تجاوزت سقف السعرات قليلاً، ركز على تقليل الزيوت والمخبوزات.')
          : goal === 'gain_muscle'
          ? (consumedProtein >= targetProtein ? 'كمية البروتين ممتازة لدعم تعافي الألياف العضلية ونموها.' : 'تحتاج لزيادة مصادر البروتين الصافية لدعم النمو العضلي.')
          : 'أنت قريب جداً من نطاق التوازن والمحافظة الصحية.',
        goalStatusEn: goal === 'lose_weight'
          ? (consumedCalories <= targetCalories ? 'You are in a healthy calorie deficit ideal for fat loss.' : 'Slightly above calorie limit; moderate added fats and refined carbs.')
          : goal === 'gain_muscle'
          ? (consumedProtein >= targetProtein ? 'Protein intake is on point to support muscle recovery.' : 'Boost lean protein sources to maximize muscle synthesis.')
          : 'You are right in the sweet spot for sustainable weight maintenance.',
        strengthsAr: [
          `تسجيل وجبات منتظم يعزز وعيك الغذائي (${loggedMeals.length} وجبات مسجلة).`,
          consumedProtein > 30 ? `تناول ${consumedProtein} جم بروتين يدعم الكتلة العضلية والشبع.` : 'المبادرة بتتبع قيم الوجبات بدقة.',
          waterGlasses >= 5 ? `مستوى شرب الماء جيد (${waterGlasses} أكواب حتى الآن).` : 'الوعي بالسعرات المتناولة ومقارنتها بالهدف.',
        ],
        strengthsEn: [
          `Consistent meal tracking boosts nutritional mindfulness (${loggedMeals.length} meals logged).`,
          consumedProtein > 30 ? `Consuming ${consumedProtein}g of protein supports satiety and lean muscle.` : 'Tracking meal macros accurately.',
          waterGlasses >= 5 ? `Solid hydration with ${waterGlasses} glasses so far.` : 'Staying conscious of your calorie allowance.',
        ],
        improvementsAr: [
          isLowProt ? 'احرص على إضافة مصدر بروتين صافٍ (كالبيض، صدر الدجاج، أو الزبادي اليوناني) في وجبتك القادمة.' : 'حافظ على وتيرة توزيع البروتين على مدار اليوم.',
          waterGlasses < 6 ? `احرص على شرب ${Math.max(1, 8 - waterGlasses)} أكواب ماء إضافية للوصول للمعدل الموصى به (2 لتر).` : 'واصل شرب الماء بانتظام لتنشيط الحرق والهضم.',
          isUnderCal ? `تبقى لديك ${targetCalories - consumedCalories} سعرة يمكنك استغلالها في وجبة خفيفة غنية بالمغذيات أو المكسرات.` : 'احرص على أن تكون الوجبة التالية غنية بالخضروات الورقية والألياف.',
        ],
        improvementsEn: [
          isLowProt ? 'Add a clean protein source (eggs, chicken breast, Greek yogurt) to your next meal.' : 'Keep distributing your protein evenly across meals.',
          waterGlasses < 6 ? `Drink ${Math.max(1, 8 - waterGlasses)} more glasses of water to hit your 2L target.` : 'Keep up regular hydration to fuel metabolism.',
          isUnderCal ? `You have ${targetCalories - consumedCalories} kcal left to fuel up with nutrient-dense foods or nuts.` : 'Ensure your next plate is packed with leafy greens and fiber.',
        ],
        nextMealSuggestionAr: isLowProt
          ? 'سلطة دجاج مشوي مع كينوا أو تونة مع خضروات، لتعويض نقص البروتين بدون سعرات زائدة.'
          : isUnderCal
          ? 'طبق شوفان بالحليب والموز وبذور الشيا أو حفنة لوز وجوز لتغذية صحية متوازنة.'
          : 'طبق خفيف من الخضار المطهوة على البخار مع قطعة سمك أو بيض مسلوق لتجنب الإثقال.',
        nextMealSuggestionEn: isLowProt
          ? 'Grilled chicken salad with quinoa or tuna with vegetables to boost protein efficiently.'
          : isUnderCal
          ? 'Oatmeal bowl with milk, banana, and chia seeds or a handful of raw nuts for balanced fuel.'
          : 'Steamed vegetables with grilled fish or boiled eggs to keep calories in check.',
        hydrationFeedbackAr: waterGlasses >= 8
          ? 'ممتاز! وصلت للهدف الموصى به من الماء (8 أكواب). هذا يحسن حرق الدهون ونضارة الجسم.'
          : `شربت ${waterGlasses} من أصل 8 أكواب. شرب كوبين إضافيين سيساعد في تقليل الجوع الكاذب وتحسين الهضم.`,
        hydrationFeedbackEn: waterGlasses >= 8
          ? 'Fantastic! You achieved your 8 glasses daily target, optimizing metabolic function.'
          : `You logged ${waterGlasses}/8 glasses. Having two more glasses will curb false hunger and enhance digestion.`,
        macroFeedbackAr: `توزيعك اليوم: بروتين (${consumedProtein}g)، كربوهيدرات (${consumedCarbs}g)، دهون (${consumedFats}g). النمط متناسق مع هدف ${goalNameAr}.`,
        macroFeedbackEn: `Today's macro split: Protein (${consumedProtein}g), Carbs (${consumedCarbs}g), Fats (${consumedFats}g), supporting ${goalNameEn}.`,
        medicalTipsAr: [
          'تثبيت منحنى الجلوكوز: ابدأ وجبتك بالألياف والخضار ثم البروتين لتفادي الارتفاع السريع للأنسولين.',
          'الترطيب الأيوني: شرب الماء قبل الوجبة بـ 20 دقيقة يحسن حموضة المعدة وكفاءة امتصاص المغذيات.',
          'التناغم الحيوي للنوم: تناول وجبة العشاء قبل النوم بساعتين إلى 3 ساعات يرفع جودة إفراز هرمون النمو والميلاتونين.',
        ],
        medicalTipsEn: [
          'Glucose curve stabilization: Start meals with fiber and greens, then protein to prevent insulin spikes.',
          'Cellular hydration: Drinking water 20 mins before meals primes stomach acidity and nutrient absorption.',
          'Circadian rhythm: Finishing dinner 2-3 hours before bed optimizes melatonin secretion and sleep architecture.',
        ],
        threeMealsIdeas: {
          breakfast: {
            titleAr: 'شكشوكة بيض بالخضار وزيت الزيتون مع رغيف بر',
            titleEn: 'Vegetable Shakshuka with Whole Wheat Flatbread',
            calories: 380,
            protein: 22,
            carbs: 38,
            fats: 14,
            ingredientsAr: ['بيضتان طازجتان', 'طماطم وفلفل رومي وبصل', 'ملعقة صغيرة زيت زيتون', 'خبز بر نخالة'],
            ingredientsEn: ['2 fresh eggs', 'Tomatoes, bell peppers, onions', '1 tsp olive oil', 'Whole wheat pita'],
            healthBenefitAr: 'تثبيت إفراز الأنسولين الصباحي، وإمداد الجسم بالكولين لتعزيز التركيز والطاقة المستدامة.',
            healthBenefitEn: 'Stabilizes morning glucose curve and provides choline for sustained cognitive energy.',
          },
          lunch: {
            titleAr: 'صالونة دجاج صحية بالخضار وأرز بسمتي بني',
            titleEn: 'Tender Chicken Vegetable Stew with Brown Rice',
            calories: 550,
            protein: 46,
            carbs: 58,
            fats: 12,
            ingredientsAr: ['صدر دجاج مشوي 160 جم', 'كوسا وجزر وبامية', 'كوب أرز بسمتي بني مطهو على البخار', 'سلطة سحاوق خضراء'],
            ingredientsEn: ['160g chicken breast', 'Zucchini, carrots, okra', '1 cup brown basmati rice', 'Fresh cilantro salsa'],
            healthBenefitAr: 'بروتين صافٍ عالي القيمة الحيوية للشبع ومنع هبوط الطاقة بعد الظهر.',
            healthBenefitEn: 'High biological value protein promoting long satiety without postprandial fatigue.',
          },
          dinner: {
            titleAr: 'سلطة تونة خفيفة بالليمون والخردل مع توست أسمر',
            titleEn: 'Zesty Tuna Salad with Lemon & Whole Wheat Toast',
            calories: 330,
            protein: 34,
            carbs: 22,
            fats: 8,
            ingredientsAr: ['علبة تونة مصفاة بالماء', 'جرجير وخيار وطماطم كرزية', 'عصير ليمون ونصف ملعقة زيت زيتون', 'شريحة توست حب'],
            ingredientsEn: ['Canned tuna in water', 'Arugula, cucumber, cherry tomatoes', 'Lemon juice & olive oil', 'Whole grain toast'],
            healthBenefitAr: 'عشاء خفيف مهدئ غني بأحماض أوميغا 3 والمغنيسيوم لتسهيل الهضم ونوم عميق.',
            healthBenefitEn: 'Light restorative dinner rich in omega-3 and magnesium for digestion and deep sleep.',
          },
        },
      };

      return res.json(fallbackAdvice);
    } catch (err: any) {
      console.error('[Nutrition Advice Server Error]:', err?.message || err);
      return res.json({
        headlineAr: 'استشارة غذائية وطبية متوازنة',
        headlineEn: 'Balanced Medical & Nutritional Advice',
        summaryAr: 'احرص على موازنة وجباتك على مدار اليوم وشرب كمية كافية من الماء للحفاظ على نشاطك ومعدل الحرق الطبيعي.',
        summaryEn: 'Focus on balancing your meals throughout the day and staying well-hydrated to support energy and healthy metabolism.',
        overallScore: 82,
        overallGradeAr: 'توازن ممتاز',
        overallGradeEn: 'Excellent Balance',
        goalStatusAr: 'تتبع وجباتك بانتظام هو الخطوة الأولى لتحقيق أهدافك الصحية والوقائية.',
        goalStatusEn: 'Tracking your meals regularly is the foundation for achieving your health goals.',
        strengthsAr: ['المبادرة بتسجيل وتتبع الوجبات', 'الاهتمام بالوعي الغذائي والصحي'],
        strengthsEn: ['Initiative to track and monitor meals', 'Commitment to nutritional awareness'],
        improvementsAr: ['احرص على شرب 8 أكواب ماء يومياً', 'أضف مصادر بروتين صافية وخضروات طازجة'],
        improvementsEn: ['Aim for 8 glasses of water daily', 'Include lean protein sources and fresh greens'],
        nextMealSuggestionAr: 'طبق متوازن يحتوي على بروتين صافٍ وخضروات طازجة مع القليل من الكربوهيدرات المعقدة.',
        nextMealSuggestionEn: 'A balanced plate containing lean protein, fresh vegetables, and complex carbohydrates.',
        hydrationFeedbackAr: 'احرص على شرب كوب ماء قبل كل وجبة لدعم الهضم والشبع.',
        hydrationFeedbackEn: 'Drink a glass of water before each meal to support digestion and satiety.',
        macroFeedbackAr: 'حافظ على توزيع متوازن للبروتين والكربوهيدرات والدهون الصحية.',
        macroFeedbackEn: 'Maintain a balanced distribution of protein, complex carbs, and healthy fats.',
        medicalTipsAr: [
          'الحرص على أخذ قسط كافٍ من النوم (7-8 ساعات) لتنظيم هرمونات الشبع والتوتر (الليبتين والجريلين).',
          'تناول الطعام ببطء ومضغه جيداً لتحسين إشارات الشبع العصبية وصحة القولون.',
        ],
        medicalTipsEn: [
          'Prioritize 7-8 hours of quality sleep to regulate appetite hormones (leptin and ghrelin).',
          'Eat mindfully and chew thoroughly to enhance metabolic satiety signaling and gut health.',
        ],
        threeMealsIdeas: {
          breakfast: {
            titleAr: 'شكشوكة بيض بالخضار وزيت الزيتون مع رغيف بر',
            titleEn: 'Vegetable Shakshuka with Whole Wheat Flatbread',
            calories: 380,
            protein: 22,
            carbs: 38,
            fats: 14,
            ingredientsAr: ['بيضتان طازجتان', 'طماطم وفلفل رومي وبصل', 'ملعقة صغيرة زيت زيتون', 'خبز بر نخالة'],
            ingredientsEn: ['2 fresh eggs', 'Tomatoes, bell peppers, onions', '1 tsp olive oil', 'Whole wheat pita'],
            healthBenefitAr: 'تثبيت إفراز الأنسولين الصباحي، وإمداد الجسم بالكولين لتعزيز التركيز والطاقة المستدامة.',
            healthBenefitEn: 'Stabilizes morning glucose curve and provides choline for sustained cognitive energy.',
          },
          lunch: {
            titleAr: 'صالونة دجاج صحية بالخضار وأرز بسمتي بني',
            titleEn: 'Tender Chicken Vegetable Stew with Brown Rice',
            calories: 550,
            protein: 46,
            carbs: 58,
            fats: 12,
            ingredientsAr: ['صدر دجاج مشوي 160 جم', 'كوسا وجزر وبامية', 'كوب أرز بسمتي بني مطهو على البخار', 'سلطة سحاوق خضراء'],
            ingredientsEn: ['160g chicken breast', 'Zucchini, carrots, okra', '1 cup brown basmati rice', 'Fresh cilantro salsa'],
            healthBenefitAr: 'بروتين صافٍ عالي القيمة الحيوية للشبع ومنع هبوط الطاقة بعد الظهر.',
            healthBenefitEn: 'High biological value protein promoting long satiety without postprandial fatigue.',
          },
          dinner: {
            titleAr: 'سلطة تونة خفيفة بالليمون والخردل مع توست أسمر',
            titleEn: 'Zesty Tuna Salad with Lemon & Whole Wheat Toast',
            calories: 330,
            protein: 34,
            carbs: 22,
            fats: 8,
            ingredientsAr: ['علبة تونة مصفاة بالماء', 'جرجير وخيار وطماطم كرزية', 'عصير ليمون ونصف ملعقة زيت زيتون', 'شريحة توست حب'],
            ingredientsEn: ['Canned tuna in water', 'Arugula, cucumber, cherry tomatoes', 'Lemon juice & olive oil', 'Whole grain toast'],
            healthBenefitAr: 'عشاء خفيف مهدئ غني بأحماض أوميغا 3 والمغنيسيوم لتسهيل الهضم ونوم عميق.',
            healthBenefitEn: 'Light restorative dinner rich in omega-3 and magnesium for digestion and deep sleep.',
          },
        },
      });
    }
  });

  // API Route: AI Daily Meal & Health Plan Generator (Gemini + Nutrition Formula)
  app.post('/api/generate-meal-plan', async (req, res) => {
    try {
      const {
        targetCalories = 2000,
        cuisineStyle = 'arabic_healthy',
        goal = 'maintain',
      } = req.body || {};

      const ai = getGeminiClient();

      const styleLabels: Record<string, { ar: string; en: string }> = {
        arabic_healthy: { ar: 'مطبخ عربي ويمني صحي ومتوازن', en: 'Healthy Arabic & Yemeni Cuisine' },
        mediterranean: { ar: 'المطبخ المتوسطي الصحي بالزيت والأسماك', en: 'Mediterranean Diet with Olive Oil & Seafood' },
        high_protein: { ar: 'نظام عالي البروتين للرياضيين وبناء العضلات', en: 'High-Protein Athletic Muscle Building' },
        low_carb: { ar: 'قليل الكربوهيدرات (لو كرب صحي)', en: 'Clean Low-Carb Satiety Plan' },
        vegetarian: { ar: 'نباتي متكامل ومغذي', en: 'Nutrient-Dense Wholesome Vegetarian' },
      };

      const styleInfo = styleLabels[cuisineStyle] || styleLabels.arabic_healthy;

      // Plan Schema for Gemini
      const planSchema = {
        type: Type.OBJECT,
        properties: {
          goalSummaryAr: { type: Type.STRING, description: 'ملخص تحفيزي وتوجيهي للخطة اليومية بالعربية' },
          goalSummaryEn: { type: Type.STRING, description: 'Motivational English summary for today’s plan' },
          meals: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                slot: { type: Type.STRING, description: 'breakfast, snack_am, lunch, snack_pm, dinner' },
                slotNameAr: { type: Type.STRING },
                slotNameEn: { type: Type.STRING },
                recommendedTime: { type: Type.STRING },
                name: { type: Type.STRING },
                nameAr: { type: Type.STRING },
                calories: { type: Type.INTEGER },
                protein: { type: Type.INTEGER },
                carbs: { type: Type.INTEGER },
                fats: { type: Type.INTEGER },
                fiber: { type: Type.INTEGER },
                portionWeightGrams: { type: Type.INTEGER },
                ingredientsAr: { type: Type.ARRAY, items: { type: Type.STRING } },
                ingredientsEn: { type: Type.ARRAY, items: { type: Type.STRING } },
                healthBenefitAr: { type: Type.STRING },
                healthBenefitEn: { type: Type.STRING },
              },
              required: [
                'slot',
                'slotNameAr',
                'slotNameEn',
                'recommendedTime',
                'name',
                'nameAr',
                'calories',
                'protein',
                'carbs',
                'fats',
                'ingredientsAr',
                'ingredientsEn',
                'healthBenefitAr',
              ],
            },
          },
        },
        required: ['goalSummaryAr', 'goalSummaryEn', 'meals'],
      };

      const systemPrompt = `You are an elite sports dietitian and Arab cuisine specialist.
Design a personalized, delicious, and precisely calibrated 5-meal daily plan (breakfast, morning snack, lunch, afternoon snack, dinner) totaling approximately ${targetCalories} Kcal.
Cuisine Style: ${styleInfo.ar} (${styleInfo.en}).
Health Goal: ${goal}.
Ensure realistic ingredient measurements in Arabic and English, realistic portions in grams, and exact calories that sum close to ${targetCalories} Kcal.
Strictly return JSON conforming to the schema.`;

      let generatedPlan: any = null;

      if (ai) {
        const candidateModels = ['gemini-3.5-flash-lite', 'gemini-3.8-flash'];
        for (const modelCandidate of candidateModels) {
          try {
            const config: any = {
              systemInstruction: systemPrompt,
              responseMimeType: 'application/json',
              responseSchema: planSchema,
            };
            if (modelCandidate === 'gemini-3.8-flash') {
              config.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
            }

            const aiPromise = ai.models.generateContent({
              model: modelCandidate,
              contents: `Generate a full daily meal plan with 5 balanced meals matching ${targetCalories} kcal and ${cuisineStyle} style.`,
              config,
            });

            const timeoutPromise = new Promise((_, reject) =>
              setTimeout(() => reject(new Error('Meal plan generation timeout (6s)')), 6000)
            );

            const response: any = await Promise.race([aiPromise, timeoutPromise]);
            if (response && response.text) {
              const parsed = JSON.parse(response.text);
              if (parsed.meals && parsed.meals.length >= 4) {
                generatedPlan = parsed;
                break;
              }
            }
          } catch (modelErr: any) {
            console.warn(`[Meal Plan AI] ${modelCandidate} notice:`, modelErr?.message || modelErr);
          }
        }
      }

      // If AI generated valid meals, structure them cleanly
      if (generatedPlan && generatedPlan.meals) {
        const mealsWithIds = generatedPlan.meals.map((m: any, idx: number) => ({
          ...m,
          id: `ai_meal_${idx + 1}_${Date.now()}`,
          isCompleted: false,
        }));

        const totalCalories = mealsWithIds.reduce((sum: number, m: any) => sum + (m.calories || 0), 0);
        const totalProtein = mealsWithIds.reduce((sum: number, m: any) => sum + (m.protein || 0), 0);
        const totalCarbs = mealsWithIds.reduce((sum: number, m: any) => sum + (m.carbs || 0), 0);
        const totalFats = mealsWithIds.reduce((sum: number, m: any) => sum + (m.fats || 0), 0);

        return res.json({
          planId: `ai_plan_${Date.now()}`,
          dateStr: new Date().toISOString().split('T')[0],
          cuisineStyle,
          totalPlannedCalories: totalCalories,
          totalPlannedProtein: totalProtein,
          totalPlannedCarbs: totalCarbs,
          totalPlannedFats: totalFats,
          goalSummaryAr: generatedPlan.goalSummaryAr,
          goalSummaryEn: generatedPlan.goalSummaryEn,
          meals: mealsWithIds,
          habits: [
            {
              id: 'habit_water_1',
              titleAr: 'كوبان ماء عند الاستيقاظ',
              titleEn: '2 glasses of water upon waking',
              descAr: 'تنشيط الحرق وترطيب الجسم بعد النوم.',
              descEn: 'Kickstart metabolic rate and hydrate cells.',
              iconType: 'water',
              targetValue: '500 مل',
              isCompleted: false,
            },
            {
              id: 'habit_water_2',
              titleAr: 'شرب 6 أكواب ماء إضافية على مدار اليوم',
              titleEn: '6 additional glasses throughout day',
              descAr: 'كوب قبل كل وجبة لدعم الشبع والهضم.',
              descEn: 'One glass before each meal for optimal satiety.',
              iconType: 'water',
              targetValue: '1.5 لتر',
              isCompleted: false,
            },
            {
              id: 'habit_walk',
              titleAr: 'نشاط حركي يومي (مشي 30 دقيقة)',
              titleEn: '30-minute brisk walk or workout',
              descAr: 'حرق السعرات وتنشيط الدورة الدموية.',
              descEn: 'Burn calories and boost cardiovascular health.',
              iconType: 'activity',
              targetValue: '30 دقيقة',
              isCompleted: false,
            },
            {
              id: 'habit_sleep_rest',
              titleAr: 'نوم صحي ومريح 7-8 ساعات',
              titleEn: 'Restorative 7-8 hours sleep',
              descAr: 'توازن هرمونات الشبع واستشفاء العضلات.',
              descEn: 'Crucial for appetite regulation and recovery.',
              iconType: 'sleep',
              targetValue: '7-8 ساعات',
              isCompleted: false,
            },
          ],
          fastingWindow: {
            enabled: false,
            type: '16:8',
            startHour: 12,
            endHour: 20,
          },
        });
      }

      // Offline instant fallback with precision nutritional database
      const fallbackPlan = {
        planId: `local_plan_${Date.now()}`,
        dateStr: new Date().toISOString().split('T')[0],
        cuisineStyle,
        totalPlannedCalories: targetCalories,
        totalPlannedProtein: Math.round(targetCalories * 0.25 / 4),
        totalPlannedCarbs: Math.round(targetCalories * 0.45 / 4),
        totalPlannedFats: Math.round(targetCalories * 0.30 / 9),
        goalSummaryAr: 'خطة يومية ذكية ومتوازنة مصممة خصيصاً لتلبية احتياجك من السعرات والمغذيات الأساسية.',
        goalSummaryEn: 'Smart, balanced daily plan tailored to your exact energy and macro targets.',
        meals: [
          {
            id: `plan_meal_bf_${Date.now()}`,
            slot: 'breakfast',
            slotNameAr: 'فطور الصباح',
            slotNameEn: 'Breakfast',
            recommendedTime: '08:30 ص',
            name: 'Healthy Shakshuka with Whole Wheat Flatbread',
            nameAr: 'شكشوكة بيض بالخضار وزيت الزيتون مع رغيف بر',
            calories: Math.round(targetCalories * 0.25),
            protein: 24,
            carbs: 40,
            fats: 15,
            fiber: 6,
            portionWeightGrams: 280,
            ingredientsAr: ['بيضتان طازجتان', 'طماطم وبصل وفلفل', 'رغيف خبز بر أسمر', 'ملعقة صغيرة زيت زيتون'],
            ingredientsEn: ['2 fresh eggs', 'Tomato, onion & bell pepper', 'Whole wheat flatbread', '1 tsp olive oil'],
            healthBenefitAr: 'بداية صباحية غنية بالبروتين والدهون الصحية للتركيز والنشاط.',
            healthBenefitEn: 'High-protein breakfast stabilizing blood sugar.',
            isCompleted: false,
          },
          {
            id: `plan_meal_sam_${Date.now()}`,
            slot: 'snack_am',
            slotNameAr: 'سناك الصباح والطاقة',
            slotNameEn: 'Morning Fuel',
            recommendedTime: '11:30 ص',
            name: 'Dates with Raw Almonds & Green Tea',
            nameAr: 'حبات تمر مع لوز نيء وشاي أخضر بالنعناع',
            calories: Math.round(targetCalories * 0.10),
            protein: 5,
            carbs: 26,
            fats: 7,
            fiber: 4,
            portionWeightGrams: 75,
            ingredientsAr: ['3 حبات تمر سكري', '10 حبات لوز نيء', 'كوب شاي أخضر بالنعناع'],
            ingredientsEn: ['3 dates', '10 raw almonds', 'Mint green tea'],
            healthBenefitAr: 'طاقة طبيعية سريعة ومضادات أكسدة ومعادن أساسية للمخ.',
            healthBenefitEn: 'Brain-boosting minerals and clean sustained energy.',
            isCompleted: false,
          },
          {
            id: `plan_meal_lu_${Date.now()}`,
            slot: 'lunch',
            slotNameAr: 'الغداء المتوازن',
            slotNameEn: 'Balanced Lunch',
            recommendedTime: '02:30 م',
            name: 'Spiced Chicken Stew with Basmati Rice & Fresh Salad',
            nameAr: 'صالونة صدر دجاج بالخضار مع أرز بسمتي وسلطة خضراء',
            calories: Math.round(targetCalories * 0.35),
            protein: 48,
            carbs: 58,
            fats: 14,
            fiber: 7,
            portionWeightGrams: 400,
            ingredientsAr: ['صدر دجاج مشوي 160 جم', 'كوب خضار مشكلة (كوسا وجزر)', 'كوب أرز بسمتي على البخار', 'سلطة خضراء بليمون'],
            ingredientsEn: ['160g chicken breast', 'Zucchini & carrots', 'Steamed basmati rice', 'Fresh green salad'],
            healthBenefitAr: 'وجبة متكاملة توفر البروتين الصافي والألياف لدعم العضلات والشبع.',
            healthBenefitEn: 'Balanced complex carbs and lean protein for cellular repair.',
            isCompleted: false,
          },
          {
            id: `plan_meal_spm_${Date.now()}`,
            slot: 'snack_pm',
            slotNameAr: 'سناك المساء الخفيف',
            slotNameEn: 'Afternoon Fuel',
            recommendedTime: '05:30 م',
            name: 'Greek Yogurt with Pure Honey & Chia Seeds',
            nameAr: 'زبادي يوناني قليل الدسم بالعسل وبذور الشيا',
            calories: Math.round(targetCalories * 0.10),
            protein: 16,
            carbs: 18,
            fats: 4,
            fiber: 3,
            portionWeightGrams: 180,
            ingredientsAr: ['كوب زبادي يوناني 150 جم', 'ملعقة صغيرة عسل نقي', 'نصف ملعقة بذور شيا'],
            ingredientsEn: ['150g Greek yogurt', '1 tsp honey', '1/2 tsp chia seeds'],
            healthBenefitAr: 'بروتين كازين بطيء الامتصاص وبروبيوتيك يحسن صحة الأمعاء.',
            healthBenefitEn: 'Probiotics supporting digestive microbiome.',
            isCompleted: false,
          },
          {
            id: `plan_meal_di_${Date.now()}`,
            slot: 'dinner',
            slotNameAr: 'العشاء الصحي الخفيف',
            slotNameEn: 'Light Dinner',
            recommendedTime: '08:30 م',
            name: 'Zesty Tuna Salad with Arugula & Whole Wheat Toast',
            nameAr: 'سلطة تونة بالليمون والخردل والجرجير مع قطعة توست حب',
            calories: Math.round(targetCalories * 0.20),
            protein: 34,
            carbs: 22,
            fats: 8,
            fiber: 5,
            portionWeightGrams: 260,
            ingredientsAr: ['علبة تونة مصفاة 120 جم', 'جرجير وطماطم كرزية وخيار', 'ملعقة زيت زيتون وليمون', 'شريحة توست أسمر'],
            ingredientsEn: ['120g drained tuna', 'Arugula & cherry tomatoes', 'Olive oil & lemon', '1 slice whole wheat toast'],
            healthBenefitAr: 'عشاء خفيف جداً يمنع ثقل المعدة ويوفر بروتين ترميم النوم العميق.',
            healthBenefitEn: 'Easily digestible protein ensuring deep night rest.',
            isCompleted: false,
          },
        ],
        habits: [
          {
            id: 'habit_water_1',
            titleAr: 'كوبان ماء عند الاستيقاظ',
            titleEn: '2 glasses of water upon waking',
            descAr: 'تنشيط الحرق وترطيب الجسم بعد النوم.',
            descEn: 'Kickstart metabolic rate and hydrate cells.',
            iconType: 'water',
            targetValue: '500 مل',
            isCompleted: false,
          },
          {
            id: 'habit_water_2',
            titleAr: 'شرب 6 أكواب ماء إضافية على مدار اليوم',
            titleEn: '6 additional glasses throughout day',
            descAr: 'كوب قبل كل وجبة لدعم الشبع والهضم.',
            descEn: 'One glass before each meal for optimal satiety.',
            iconType: 'water',
            targetValue: '1.5 لتر',
            isCompleted: false,
          },
          {
            id: 'habit_walk',
            titleAr: 'نشاط حركي يومي (مشي 30 دقيقة)',
            titleEn: '30-minute brisk walk or workout',
            descAr: 'حرق السعرات وتنشيط الدورة الدموية.',
            descEn: 'Burn calories and boost cardiovascular health.',
            iconType: 'activity',
            targetValue: '30 دقيقة',
            isCompleted: false,
          },
          {
            id: 'habit_sleep_rest',
            titleAr: 'نوم صحي ومريح 7-8 ساعات',
            titleEn: 'Restorative 7-8 hours sleep',
            descAr: 'توازن هرمونات الشبع واستشفاء العضلات.',
            descEn: 'Crucial for appetite regulation and recovery.',
            iconType: 'sleep',
            targetValue: '7-8 ساعات',
            isCompleted: false,
          },
        ],
        fastingWindow: {
          enabled: false,
          type: '16:8',
          startHour: 12,
          endHour: 20,
        },
      };

      return res.json(fallbackPlan);
    } catch (err: any) {
      console.error('[Generate Meal Plan Error]:', err?.message || err);
      return res.json({
        planId: `safe_fallback_${Date.now()}`,
        totalPlannedCalories: 2000,
        goalSummaryAr: 'خطة صحية متوازنة لليوم',
        goalSummaryEn: 'Healthy balanced daily plan',
        meals: [],
        habits: [],
      });
    }
  });

  // Explicit 404 handler for any /api/* routes so they never fall through to Vite index.html
  app.all('/api/*', (req, res) => {
    res.status(404).json({
      error: 'ENDPOINT_NOT_FOUND',
      code: '404',
      message: `المسار البرمجي المطلوب غير موجود (${req.method} ${req.path})`,
      messageEn: `API endpoint not found: ${req.method} ${req.path}`,
    });
  });

  // 3. Error-handling middleware: ALWAYS returns JSON, never HTML
  app.use((err: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
    let statusCode = 500;
    let errorCode = 'INTERNAL_SERVER_ERROR';
    let messageAr = 'حدث خطأ في معالجة الطلب على الخادم';
    let messageEn = 'An internal server error occurred';

    if (err.type === 'entity.too.large' || err.status === 413 || err.statusCode === 413) {
      statusCode = 413;
      errorCode = 'PAYLOAD_TOO_LARGE';
      messageAr = 'حجم الصورة كبير جداً، الحد الأقصى المسموح به 10 ميجابايت';
      messageEn = 'Image payload is too large. Maximum size is 10MB.';
    } else if (err.status === 429 || err.statusCode === 429) {
      statusCode = 429;
      errorCode = 'RATE_LIMIT_EXCEEDED';
      messageAr = 'تم تجاوز الحد المسموح من الطلبات. يرجى الانتظار والمحاولة لاحقاً.';
      messageEn = 'Rate limit exceeded. Please wait and try again later.';
    } else if (err.status === 503 || err.statusCode === 503) {
      statusCode = 503;
      errorCode = 'SERVICE_UNAVAILABLE';
      messageAr = 'خدمة الذكاء الاصطناعي غير متاحة حالياً';
      messageEn = 'AI service is currently unavailable';
    } else if (err.status || err.statusCode) {
      statusCode = err.status || err.statusCode;
      errorCode = err.name || 'REQUEST_ERROR';
      messageAr = err.message || messageAr;
      messageEn = err.message || messageEn;
    }

    console.error(`[Server Error] Path: ${req.path} | Status: ${statusCode} | Code: ${errorCode} | Detail:`, err?.message || err);

    res.status(statusCode).json({
      error: errorCode,
      code: String(statusCode),
      message: messageAr,
      messageEn,
    });
  });

  // 4. Mount Vite middleware in development or serve static in production (AFTER all API routes)
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(process.cwd(), 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Don't Forget fullstack server running on port ${PORT}`);
  });
}

startServer();
